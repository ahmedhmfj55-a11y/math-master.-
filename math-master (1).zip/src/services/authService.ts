import {
  deleteUser,
  GoogleAuthProvider,
  RecaptchaVerifier,
  reauthenticateWithPopup,
  signInWithPhoneNumber,
  signInWithPopup,
  signOut,
  type ConfirmationResult,
  type User,
  type UserCredential,
} from 'firebase/auth';
import { auth } from '@/src/config/firebase';
import type { Language } from '@/src/types/i18n';

export type AuthErrorCode =
  | 'operation-not-allowed'
  | 'popup-blocked'
  | 'popup-closed'
  | 'invalid-phone'
  | 'invalid-otp'
  | 'too-many-requests'
  | 'requires-recent-login'
  | 'network-error'
  | 'unknown';

export class AuthServiceError extends Error {
  public readonly code: AuthErrorCode;
  public readonly rawCode?: string;

  constructor(code: AuthErrorCode, message: string, rawCode?: string) {
    super(message);
    this.name = 'AuthServiceError';
    this.code = code;
    this.rawCode = rawCode;
  }
}

function mapFirebaseAuthError(error: unknown): AuthServiceError {
  const rawCode =
    typeof error === 'object' && error !== null && 'code' in error
      ? String((error as { code: unknown }).code)
      : '';
  const message = error instanceof Error ? error.message : String(error);

  switch (rawCode) {
    case 'auth/operation-not-allowed':
    case 'auth/configuration-not-found':
      return new AuthServiceError('operation-not-allowed', message, rawCode);
    case 'auth/popup-blocked':
      return new AuthServiceError('popup-blocked', message, rawCode);
    case 'auth/popup-closed-by-user':
    case 'auth/cancelled-popup-request':
      return new AuthServiceError('popup-closed', message, rawCode);
    case 'auth/invalid-phone-number':
    case 'auth/missing-phone-number':
      return new AuthServiceError('invalid-phone', message, rawCode);
    case 'auth/invalid-verification-code':
    case 'auth/code-expired':
    case 'auth/session-expired':
      return new AuthServiceError('invalid-otp', message, rawCode);
    case 'auth/too-many-requests':
    case 'auth/quota-exceeded':
      return new AuthServiceError('too-many-requests', message, rawCode);
    case 'auth/requires-recent-login':
      return new AuthServiceError('requires-recent-login', message, rawCode);
    case 'auth/network-request-failed':
      return new AuthServiceError('network-error', message, rawCode);
    default:
      return new AuthServiceError('unknown', message, rawCode);
  }
}

let activeRecaptchaVerifier: RecaptchaVerifier | null = null;

export function clearRecaptchaVerifier(): void {
  if (activeRecaptchaVerifier) {
    try {
      activeRecaptchaVerifier.clear();
    } catch {
      // Ignore cleanup errors on unmounted nodes
    }
    activeRecaptchaVerifier = null;
  }
}

export const authService = {
  async signInWithGoogle(lang: Language): Promise<UserCredential> {
    try {
      auth.languageCode = lang;
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      return await signInWithPopup(auth, provider);
    } catch (error) {
      throw mapFirebaseAuthError(error);
    }
  },

  async sendPhoneVerificationCode(
    phoneNumberE164: string,
    containerId: string,
    lang: Language,
  ): Promise<ConfirmationResult> {
    try {
      auth.languageCode = lang;
      clearRecaptchaVerifier();
      activeRecaptchaVerifier = new RecaptchaVerifier(auth, containerId, {
        size: 'invisible',
      });
      return await signInWithPhoneNumber(auth, phoneNumberE164, activeRecaptchaVerifier);
    } catch (error) {
      clearRecaptchaVerifier();
      throw mapFirebaseAuthError(error);
    }
  },

  async confirmPhoneCode(
    confirmationResult: ConfirmationResult,
    otpCode: string,
  ): Promise<UserCredential> {
    try {
      return await confirmationResult.confirm(otpCode.trim());
    } catch (error) {
      throw mapFirebaseAuthError(error);
    }
  },

  async prepareAccountDeletionReauth(user: User, lang: Language): Promise<void> {
    const lastSignInMs = user.metadata.lastSignInTime ? Date.parse(user.metadata.lastSignInTime) : 0;
    const isStale = !lastSignInMs || Date.now() - lastSignInMs > 4 * 60 * 1000;
    if (!isStale) return;

    const providerId = user.providerData[0]?.providerId;
    if (providerId === 'google.com') {
      try {
        auth.languageCode = lang;
        const provider = new GoogleAuthProvider();
        provider.setCustomParameters({ prompt: 'select_account' });
        await reauthenticateWithPopup(user, provider);
        return;
      } catch (error) {
        throw mapFirebaseAuthError(error);
      }
    }

    throw new AuthServiceError(
      'requires-recent-login',
      'Recent authentication is required before deleting this account.',
      'auth/requires-recent-login',
    );
  },

  async deleteCurrentAuthUser(user: User): Promise<void> {
    try {
      clearRecaptchaVerifier();
      await deleteUser(user);
    } catch (error) {
      throw mapFirebaseAuthError(error);
    }
  },

  async logout(): Promise<void> {
    clearRecaptchaVerifier();
    await signOut(auth);
  },
};
