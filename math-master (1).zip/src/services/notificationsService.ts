import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  query,
  runTransaction,
  serverTimestamp,
  updateDoc,
  where,
  writeBatch,
  type Unsubscribe,
} from 'firebase/firestore';
import { db } from '@/src/config/firebase';
import { handleFirestoreError, OperationType } from '@/src/services/firestoreError';
import {
  DEFAULT_USER_PREFERENCES,
  type CreateNotificationInput,
  type UserNotificationRecord,
  type UserPreferencesRecord,
} from '@/src/types/notifications';

function clampText(raw: string, maxLen: number): string {
  const cleaned = raw.trim().slice(0, maxLen);
  return cleaned || 'Math Master';
}

function clampSafeId(raw: string, maxLen = 80): string {
  return raw.replace(/[^a-zA-Z0-9_-]/g, '-').slice(0, maxLen);
}

export const notificationsService = {
  subscribeNotifications(
    uid: string,
    onData: (items: UserNotificationRecord[]) => void,
    onError: (err: Error) => void,
  ): Unsubscribe {
    const path = `users/${uid}/notifications`;
    const q = query(collection(db, 'users', uid, 'notifications'), where('uid', '==', uid));

    return onSnapshot(
      q,
      (snapshot) => {
        const items: UserNotificationRecord[] = [];
        snapshot.forEach((docSnap) => {
          items.push(docSnap.data() as UserNotificationRecord);
        });
        items.sort((a, b) => (b.createdAt?.seconds ?? 0) - (a.createdAt?.seconds ?? 0));
        onData(items);
      },
      (error) => {
        try {
          handleFirestoreError(error, OperationType.LIST, path);
        } catch (wrapped) {
          onError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
        }
      },
    );
  },

  async createNotificationIfAbsent(
    uid: string,
    input: CreateNotificationInput,
  ): Promise<boolean> {
    const safeId = clampSafeId(input.id, 80);
    if (safeId.length < 3) return false;
    const notifRef = doc(db, 'users', uid, 'notifications', safeId);
    const path = `users/${uid}/notifications/${safeId}`;

    try {
      const created = await runTransaction(db, async (transaction) => {
        const existingSnap = await transaction.get(notifRef);
        if (existingSnap.exists()) {
          return false;
        }
        transaction.set(notifRef, {
          uid,
          id: safeId,
          type: input.type,
          titleAr: clampText(input.titleAr, 140),
          titleEn: clampText(input.titleEn, 140),
          bodyAr: clampText(input.bodyAr, 320),
          bodyEn: clampText(input.bodyEn, 320),
          refId: clampSafeId(input.refId, 80) || safeId,
          targetScreen: input.targetScreen,
          targetSectionId: input.targetSectionId ?? '',
          read: false,
          createdAt: serverTimestamp(),
        });
        return true;
      });
      return created;
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  async markAsRead(uid: string, notificationId: string): Promise<void> {
    const safeId = clampSafeId(notificationId, 80);
    const notifRef = doc(db, 'users', uid, 'notifications', safeId);
    const path = `users/${uid}/notifications/${safeId}`;
    try {
      await updateDoc(notifRef, { read: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },

  async markAllAsRead(uid: string, unreadIds: string[]): Promise<void> {
    if (unreadIds.length === 0) return;
    const path = `users/${uid}/notifications`;
    const BATCH_LIMIT = 400;
    try {
      for (let i = 0; i < unreadIds.length; i += BATCH_LIMIT) {
        const chunk = unreadIds.slice(i, i + BATCH_LIMIT);
        const batch = writeBatch(db);
        for (const id of chunk) {
          const safeId = clampSafeId(id, 80);
          batch.update(doc(db, 'users', uid, 'notifications', safeId), { read: true });
        }
        await batch.commit();
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },

  async deleteNotification(uid: string, notificationId: string): Promise<void> {
    const safeId = clampSafeId(notificationId, 80);
    const path = `users/${uid}/notifications/${safeId}`;
    try {
      await deleteDoc(doc(db, 'users', uid, 'notifications', safeId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  },

  async loadPreferences(uid: string): Promise<UserPreferencesRecord> {
    const prefRef = doc(db, 'users', uid, 'preferences', 'settings');
    const path = `users/${uid}/preferences/settings`;
    try {
      const snap = await getDoc(prefRef);
      if (!snap.exists()) {
        return {
          uid,
          ...DEFAULT_USER_PREFERENCES,
        };
      }
      const data = snap.data() as Partial<UserPreferencesRecord>;
      return {
        uid,
        themeMode:
          data.themeMode === 'dark' || data.themeMode === 'light' || data.themeMode === 'auto'
            ? data.themeMode
            : DEFAULT_USER_PREFERENCES.themeMode,
        notificationsEnabled:
          typeof data.notificationsEnabled === 'boolean'
            ? data.notificationsEnabled
            : DEFAULT_USER_PREFERENCES.notificationsEnabled,
        notifyDailyReminder:
          typeof data.notifyDailyReminder === 'boolean'
            ? data.notifyDailyReminder
            : DEFAULT_USER_PREFERENCES.notifyDailyReminder,
        notifyStageUnlock:
          typeof data.notifyStageUnlock === 'boolean'
            ? data.notifyStageUnlock
            : DEFAULT_USER_PREFERENCES.notifyStageUnlock,
        notifyStageWinPoints:
          typeof data.notifyStageWinPoints === 'boolean'
            ? data.notifyStageWinPoints
            : DEFAULT_USER_PREFERENCES.notifyStageWinPoints,
        notifyMedalsCerts:
          typeof data.notifyMedalsCerts === 'boolean'
            ? data.notifyMedalsCerts
            : DEFAULT_USER_PREFERENCES.notifyMedalsCerts,
        notifyExamsChallenges:
          typeof data.notifyExamsChallenges === 'boolean'
            ? data.notifyExamsChallenges
            : DEFAULT_USER_PREFERENCES.notifyExamsChallenges,
        notifyRankUp:
          typeof data.notifyRankUp === 'boolean'
            ? data.notifyRankUp
            : DEFAULT_USER_PREFERENCES.notifyRankUp,
        pushAlertsEnabled:
          typeof data.pushAlertsEnabled === 'boolean'
            ? data.pushAlertsEnabled
            : DEFAULT_USER_PREFERENCES.pushAlertsEnabled,
        bestGlobalRank:
          typeof data.bestGlobalRank === 'number' &&
          Number.isInteger(data.bestGlobalRank) &&
          data.bestGlobalRank >= 0
            ? data.bestGlobalRank
            : 0,
        updatedAt: data.updatedAt,
      };
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, path);
    }
  },

  async savePreferences(
    uid: string,
    patch: Partial<Omit<UserPreferencesRecord, 'uid' | 'updatedAt'>>,
  ): Promise<UserPreferencesRecord> {
    const prefRef = doc(db, 'users', uid, 'preferences', 'settings');
    const path = `users/${uid}/preferences/settings`;

    let savedRecord: UserPreferencesRecord = {
      uid,
      ...DEFAULT_USER_PREFERENCES,
      ...patch,
    };

    try {
      await runTransaction(db, async (transaction) => {
        const snap = await transaction.get(prefRef);
        const base = snap.exists()
          ? (snap.data() as Partial<UserPreferencesRecord>)
          : DEFAULT_USER_PREFERENCES;

        const nextRank =
          typeof patch.bestGlobalRank === 'number'
            ? Math.min(1000000, Math.max(0, Math.floor(patch.bestGlobalRank)))
            : Math.min(1000000, Math.max(0, Math.floor(base.bestGlobalRank ?? 0)));

        const payload = {
          uid,
          themeMode: patch.themeMode ?? base.themeMode ?? DEFAULT_USER_PREFERENCES.themeMode,
          notificationsEnabled:
            patch.notificationsEnabled ??
            base.notificationsEnabled ??
            DEFAULT_USER_PREFERENCES.notificationsEnabled,
          notifyDailyReminder:
            patch.notifyDailyReminder ??
            base.notifyDailyReminder ??
            DEFAULT_USER_PREFERENCES.notifyDailyReminder,
          notifyStageUnlock:
            patch.notifyStageUnlock ??
            base.notifyStageUnlock ??
            DEFAULT_USER_PREFERENCES.notifyStageUnlock,
          notifyStageWinPoints:
            patch.notifyStageWinPoints ??
            base.notifyStageWinPoints ??
            DEFAULT_USER_PREFERENCES.notifyStageWinPoints,
          notifyMedalsCerts:
            patch.notifyMedalsCerts ??
            base.notifyMedalsCerts ??
            DEFAULT_USER_PREFERENCES.notifyMedalsCerts,
          notifyExamsChallenges:
            patch.notifyExamsChallenges ??
            base.notifyExamsChallenges ??
            DEFAULT_USER_PREFERENCES.notifyExamsChallenges,
          notifyRankUp:
            patch.notifyRankUp ??
            base.notifyRankUp ??
            DEFAULT_USER_PREFERENCES.notifyRankUp,
          pushAlertsEnabled:
            patch.pushAlertsEnabled ??
            base.pushAlertsEnabled ??
            DEFAULT_USER_PREFERENCES.pushAlertsEnabled,
          bestGlobalRank: nextRank,
          updatedAt: serverTimestamp(),
        };

        if (snap.exists()) {
          transaction.update(prefRef, payload);
        } else {
          transaction.set(prefRef, payload);
        }

        savedRecord = {
          ...payload,
          updatedAt: undefined,
        };
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }

    return savedRecord;
  },
};
