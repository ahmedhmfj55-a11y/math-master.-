import {
  collection,
  doc,
  getDocs,
  query,
  runTransaction,
  serverTimestamp,
  where,
} from 'firebase/firestore';
import { db } from '@/src/config/firebase';
import { DEFAULT_AVATAR_ID, getRewardById, isFreeAvatarId } from '@/src/data/rewardsCatalog';
import { handleFirestoreError, OperationType } from '@/src/services/firestoreError';
import type {
  PointTransactionRecord,
  RewardCategory,
  RewardPurchaseRecord,
} from '@/src/types/rewards';
import type { UserProfile } from '@/src/types/user';

export const rewardsService = {
  async loadOwnedRewards(uid: string): Promise<RewardPurchaseRecord[]> {
    const path = `users/${uid}/purchases`;
    try {
      const q = query(collection(db, 'users', uid, 'purchases'), where('uid', '==', uid));
      const snap = await getDocs(q);
      const list: RewardPurchaseRecord[] = [];
      snap.forEach((docSnap) => {
        list.push(docSnap.data() as RewardPurchaseRecord);
      });
      return list;
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  },

  async loadPointTransactions(uid: string): Promise<PointTransactionRecord[]> {
    const path = `users/${uid}/pointTransactions`;
    try {
      const q = query(collection(db, 'users', uid, 'pointTransactions'), where('uid', '==', uid));
      const snap = await getDocs(q);
      const list: PointTransactionRecord[] = [];
      snap.forEach((docSnap) => {
        list.push(docSnap.data() as PointTransactionRecord);
      });
      return list.sort((a, b) => {
        const aSec = a.createdAt?.seconds ?? 0;
        const bSec = b.createdAt?.seconds ?? 0;
        return bSec - aSec;
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  },

  async purchaseReward(uid: string, itemId: string): Promise<{ newBalance: number }> {
    const catalogItem = getRewardById(itemId);
    if (!catalogItem) {
      throw new Error('Reward item not found.');
    }

    const userRef = doc(db, 'users', uid);
    const purchaseRef = doc(db, 'users', uid, 'purchases', itemId);
    const txId = `purchase-${itemId}`;
    const txRef = doc(db, 'users', uid, 'pointTransactions', txId);
    const path = `users/${uid}/purchases/${itemId}`;

    let newBalance = 0;

    try {
      await runTransaction(db, async (transaction) => {
        const userSnap = await transaction.get(userRef);
        const purchaseSnap = await transaction.get(purchaseRef);

        if (!userSnap.exists()) {
          throw new Error('User profile does not exist.');
        }

        if (purchaseSnap.exists()) {
          throw new Error('ALREADY_OWNED');
        }

        const userData = userSnap.data() as UserProfile;
        const currentPoints = userData.points ?? 0;
        if (currentPoints < catalogItem.cost) {
          throw new Error('INSUFFICIENT_POINTS');
        }

        newBalance = currentPoints - catalogItem.cost;

        transaction.set(purchaseRef, {
          uid,
          itemId: catalogItem.id,
          category: catalogItem.category,
          cost: catalogItem.cost,
          purchasedAt: serverTimestamp(),
        });

        transaction.set(txRef, {
          uid,
          txId,
          type: 'shop_purchase',
          refId: catalogItem.id,
          amount: -catalogItem.cost,
          balanceAfter: newBalance,
          createdAt: serverTimestamp(),
        });

        transaction.update(userRef, {
          points: newBalance,
          lastLedgerId: txId,
          updatedAt: serverTimestamp(),
        });
      });
    } catch (error) {
      if (
        error instanceof Error &&
        (error.message === 'ALREADY_OWNED' || error.message === 'INSUFFICIENT_POINTS')
      ) {
        throw error;
      }
      handleFirestoreError(error, OperationType.WRITE, path);
    }

    return { newBalance };
  },

  async equipReward(uid: string, category: RewardCategory, itemId: string): Promise<void> {
    const userRef = doc(db, 'users', uid);
    const leaderboardRef = doc(db, 'leaderboard', uid);
    const path = `users/${uid}`;

    const isDefaultOrClear =
      (category === 'avatar' && isFreeAvatarId(itemId)) ||
      ((category === 'title' || category === 'badge') && itemId === '');

    try {
      await runTransaction(db, async (transaction) => {
        const userSnap = await transaction.get(userRef);
        const lbSnap = await transaction.get(leaderboardRef);

        if (!userSnap.exists()) {
          throw new Error('User profile does not exist.');
        }

        if (!isDefaultOrClear) {
          const purchaseSnap = await transaction.get(doc(db, 'users', uid, 'purchases', itemId));
          if (!purchaseSnap.exists()) {
            throw new Error('ITEM_NOT_OWNED');
          }
        }

        const current = userSnap.data() as UserProfile;
        const nextAvatar = category === 'avatar' ? itemId : current.equippedAvatarId || DEFAULT_AVATAR_ID;
        const nextTitle = category === 'title' ? itemId : current.equippedTitleId ?? '';
        const nextBadge = category === 'badge' ? itemId : current.equippedBadgeId ?? '';

        transaction.update(userRef, {
          equippedAvatarId: nextAvatar,
          equippedTitleId: nextTitle,
          equippedBadgeId: nextBadge,
          updatedAt: serverTimestamp(),
        });

        if (lbSnap.exists()) {
          transaction.update(leaderboardRef, {
            avatarId: nextAvatar,
            titleId: nextTitle,
            badgeId: nextBadge,
            updatedAt: serverTimestamp(),
          });
        }
      });
    } catch (error) {
      if (error instanceof Error && error.message === 'ITEM_NOT_OWNED') {
        throw error;
      }
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },
};
