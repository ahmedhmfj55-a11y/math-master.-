import {
  collection,
  doc,
  getDocs,
  limit,
  onSnapshot,
  orderBy,
  query,
  runTransaction,
  serverTimestamp,
  updateDoc,
  where,
  type Unsubscribe,
} from 'firebase/firestore';
import { db } from '@/src/config/firebase';
import { buildDuelQuestions } from '@/src/data/duelQuestionGenerator';
import { DEFAULT_AVATAR_ID } from '@/src/data/rewardsCatalog';
import { handleFirestoreError, OperationType } from '@/src/services/firestoreError';
import type { SectionId } from '@/src/types/curriculum';
import {
  DUEL_DRAW_POINTS,
  DUEL_PARTICIPATION_POINTS,
  DUEL_WIN_POINTS,
  type DuelCompetitorStatsRecord,
  type DuelDurationSeconds,
  type DuelMatchRecord,
  type DuelQuestionCount,
} from '@/src/types/duels';
import type { LeaderboardEntry } from '@/src/types/rewards';
import type { UserProfile } from '@/src/types/user';

function clampString(value: string, maxLen: number): string {
  return value.trim().slice(0, maxLen) || 'Learner';
}

function generateDuelId(): string {
  const ts = Date.now().toString(36);
  const rand = Math.random().toString(36).slice(2, 8);
  return `duel-${ts}-${rand}`.slice(0, 64);
}

function generateQuestionSeed(): number {
  return Math.floor(100000 + Math.random() * 899999999);
}

function resolveWinnerUid(params: {
  challengerUid: string;
  opponentUid: string;
  challengerCorrect: number;
  opponentCorrect: number;
  challengerDurationSec: number;
  opponentDurationSec: number;
}): string {
  const {
    challengerUid,
    opponentUid,
    challengerCorrect,
    opponentCorrect,
    challengerDurationSec,
    opponentDurationSec,
  } = params;

  if (challengerCorrect > opponentCorrect) return challengerUid;
  if (opponentCorrect > challengerCorrect) return opponentUid;
  if (challengerDurationSec < opponentDurationSec) return challengerUid;
  if (opponentDurationSec < challengerDurationSec) return opponentUid;
  return 'draw';
}

export const duelsService = {
  subscribeUserDuels(
    uid: string,
    onData: (duels: DuelMatchRecord[]) => void,
    onError: (err: Error) => void,
  ): Unsubscribe {
    const path = 'duels';
    const q = query(
      collection(db, 'duels'),
      where('participantUids', 'array-contains', uid),
    );

    return onSnapshot(
      q,
      (snapshot) => {
        const list: DuelMatchRecord[] = [];
        snapshot.forEach((docSnap) => {
          list.push(docSnap.data() as DuelMatchRecord);
        });
        list.sort(
          (a, b) =>
            (b.updatedAt?.seconds ?? b.createdAt?.seconds ?? 0) -
            (a.updatedAt?.seconds ?? a.createdAt?.seconds ?? 0),
        );
        onData(list);
      },
      (error) => {
        try {
          handleFirestoreError(error, OperationType.LIST, path);
        } catch (wrapped) {
          onError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
        }
      },
    );
  },

  subscribeTopCompetitors(
    limitCount: number,
    onData: (stats: DuelCompetitorStatsRecord[]) => void,
    onError: (err: Error) => void,
  ): Unsubscribe {
    const path = 'duelStats';
    const q = query(
      collection(db, 'duelStats'),
      orderBy('duelPoints', 'desc'),
      limit(limitCount),
    );

    return onSnapshot(
      q,
      (snapshot) => {
        const items: DuelCompetitorStatsRecord[] = [];
        snapshot.forEach((docSnap) => {
          items.push(docSnap.data() as DuelCompetitorStatsRecord);
        });
        onData(items);
      },
      (error) => {
        try {
          handleFirestoreError(error, OperationType.LIST, path);
        } catch (wrapped) {
          onError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
        }
      },
    );
  },

  async fetchCandidateOpponents(currentUid: string): Promise<LeaderboardEntry[]> {
    const path = 'leaderboard';
    try {
      const q = query(
        collection(db, 'leaderboard'),
        orderBy('totalEarnedPoints', 'desc'),
        limit(60),
      );
      const snap = await getDocs(q);
      const candidates: LeaderboardEntry[] = [];
      snap.forEach((docSnap) => {
        const entry = docSnap.data() as LeaderboardEntry;
        if (entry.uid && entry.uid !== currentUid) {
          candidates.push(entry);
        }
      });
      return candidates;
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  },

  async createDuelChallenge(params: {
    challengerProfile: UserProfile;
    opponent: LeaderboardEntry;
    sectionId: SectionId;
    questionCount: DuelQuestionCount;
    durationSeconds: DuelDurationSeconds;
  }): Promise<string> {
    const {
      challengerProfile,
      opponent,
      sectionId,
      questionCount,
      durationSeconds,
    } = params;

    if (challengerProfile.uid === opponent.uid) {
      throw new Error('Cannot challenge yourself.');
    }

    const duelId = generateDuelId();
    const questionSeed = generateQuestionSeed();
    const duelRef = doc(db, 'duels', duelId);
    const path = `duels/${duelId}`;

    try {
      await runTransaction(db, async (transaction) => {
        transaction.set(duelRef, {
          duelId,
          participantUids: [challengerProfile.uid, opponent.uid],
          challengerUid: challengerProfile.uid,
          challengerName: clampString(challengerProfile.displayName, 100),
          challengerCountry: challengerProfile.countryCode.slice(0, 3),
          challengerAvatar: challengerProfile.equippedAvatarId || DEFAULT_AVATAR_ID,
          opponentUid: opponent.uid,
          opponentName: clampString(opponent.displayName, 100),
          opponentCountry: opponent.countryCode.slice(0, 3),
          opponentAvatar: opponent.avatarId || DEFAULT_AVATAR_ID,
          sectionId,
          questionCount,
          durationSeconds,
          questionSeed,
          status: 'pending',
          challengerSubmitted: false,
          challengerCorrect: 0,
          challengerScore: 0,
          challengerDurationSec: 0,
          challengerRewardClaimed: false,
          opponentSubmitted: false,
          opponentCorrect: 0,
          opponentScore: 0,
          opponentDurationSec: 0,
          opponentRewardClaimed: false,
          winnerUid: '',
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }

    return duelId;
  },

  async respondToDuel(
    duelId: string,
    nextStatus: 'active' | 'declined' | 'cancelled',
  ): Promise<void> {
    const path = `duels/${duelId}`;
    try {
      await updateDoc(doc(db, 'duels', duelId), {
        status: nextStatus,
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },

  async submitDuelAnswers(params: {
    duelId: string;
    uid: string;
    selectedAnswers: number[];
    durationSeconds: number;
  }): Promise<{
    correctCount: number;
    score: number;
    matchCompleted: boolean;
    winnerUid: string;
  }> {
    const { duelId, uid, selectedAnswers, durationSeconds } = params;
    const duelRef = doc(db, 'duels', duelId);
    const path = `duels/${duelId}`;

    let correctCount = 0;
    let score = 0;
    let matchCompleted = false;
    let winnerUid = '';

    try {
      await runTransaction(db, async (transaction) => {
        const snap = await transaction.get(duelRef);
        if (!snap.exists()) {
          throw new Error('Duel not found.');
        }

        const duel = snap.data() as DuelMatchRecord;
        if (duel.status !== 'active') {
          throw new Error('Duel is not active.');
        }

        const isChallenger = uid === duel.challengerUid;
        const isOpponent = uid === duel.opponentUid;
        if (!isChallenger && !isOpponent) {
          throw new Error('Not a duel participant.');
        }
        if ((isChallenger && duel.challengerSubmitted) || (isOpponent && duel.opponentSubmitted)) {
          throw new Error('Duel already submitted.');
        }

        const questions = buildDuelQuestions(
          duel.sectionId,
          duel.questionCount,
          duel.questionSeed,
        );
        correctCount = questions.reduce((sum, q, idx) => {
          return sum + (selectedAnswers[idx] === q.correctIndex ? 1 : 0);
        }, 0);
        score = Math.round((correctCount / questions.length) * 100);
        const safeDuration = Math.min(
          duel.durationSeconds,
          Math.max(0, Math.round(durationSeconds)),
        );

        const otherSubmitted = isChallenger ? duel.opponentSubmitted : duel.challengerSubmitted;

        if (isChallenger) {
          const resolvedWinner = otherSubmitted
            ? resolveWinnerUid({
                challengerUid: duel.challengerUid,
                opponentUid: duel.opponentUid,
                challengerCorrect: correctCount,
                opponentCorrect: duel.opponentCorrect,
                challengerDurationSec: safeDuration,
                opponentDurationSec: duel.opponentDurationSec,
              })
            : '';

          matchCompleted = otherSubmitted;
          winnerUid = resolvedWinner;

          transaction.update(duelRef, {
            challengerSubmitted: true,
            challengerCorrect: correctCount,
            challengerScore: score,
            challengerDurationSec: safeDuration,
            status: otherSubmitted ? 'completed' : 'active',
            winnerUid: resolvedWinner,
            updatedAt: serverTimestamp(),
          });
        } else {
          const resolvedWinner = otherSubmitted
            ? resolveWinnerUid({
                challengerUid: duel.challengerUid,
                opponentUid: duel.opponentUid,
                challengerCorrect: duel.challengerCorrect,
                opponentCorrect: correctCount,
                challengerDurationSec: duel.challengerDurationSec,
                opponentDurationSec: safeDuration,
              })
            : '';

          matchCompleted = otherSubmitted;
          winnerUid = resolvedWinner;

          transaction.update(duelRef, {
            opponentSubmitted: true,
            opponentCorrect: correctCount,
            opponentScore: score,
            opponentDurationSec: safeDuration,
            status: otherSubmitted ? 'completed' : 'active',
            winnerUid: resolvedWinner,
            updatedAt: serverTimestamp(),
          });
        }
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }

    return { correctCount, score, matchCompleted, winnerUid };
  },

  async claimDuelRewardAndSyncStats(params: {
    uid: string;
    duelId: string;
  }): Promise<{ pointsAwarded: number; outcome: 'win' | 'draw' | 'loss' } | null> {
    const { uid, duelId } = params;
    const duelRef = doc(db, 'duels', duelId);
    const userRef = doc(db, 'users', uid);
    const lbRef = doc(db, 'leaderboard', uid);
    const duelStatsRef = doc(db, 'duelStats', uid);
    const path = `duels/${duelId}`;

    let result: { pointsAwarded: number; outcome: 'win' | 'draw' | 'loss' } | null = null;

    try {
      await runTransaction(db, async (transaction) => {
        const duelSnap = await transaction.get(duelRef);
        const userSnap = await transaction.get(userRef);
        const lbSnap = await transaction.get(lbRef);
        const statsSnap = await transaction.get(duelStatsRef);

        if (!duelSnap.exists() || !userSnap.exists()) return;

        const duel = duelSnap.data() as DuelMatchRecord;
        if (duel.status !== 'completed') return;

        const isChallenger = uid === duel.challengerUid;
        const isOpponent = uid === duel.opponentUid;
        if (!isChallenger && !isOpponent) return;

        if ((isChallenger && duel.challengerRewardClaimed) || (isOpponent && duel.opponentRewardClaimed)) {
          return;
        }

        const outcome: 'win' | 'draw' | 'loss' =
          duel.winnerUid === 'draw'
            ? 'draw'
            : duel.winnerUid === uid
              ? 'win'
              : 'loss';

        const pointsAwarded =
          outcome === 'win'
            ? DUEL_WIN_POINTS
            : outcome === 'draw'
              ? DUEL_DRAW_POINTS
              : DUEL_PARTICIPATION_POINTS;

        const txType =
          outcome === 'win' ? 'duel_win' : outcome === 'draw' ? 'duel_draw' : 'duel_part';
        const txId =
          outcome === 'win'
            ? `duel-win-${duelId}`
            : outcome === 'draw'
              ? `duel-draw-${duelId}`
              : `duel-part-${duelId}`;

        const txRef = doc(db, 'users', uid, 'pointTransactions', txId);
        const existingTxSnap = await transaction.get(txRef);
        if (existingTxSnap.exists()) {
          return;
        }

        const userData = userSnap.data() as UserProfile;
        const prevPoints = userData.points ?? 0;
        const prevTotalEarned = userData.totalEarnedPoints ?? prevPoints;
        const newPoints = prevPoints + pointsAwarded;
        const newTotalEarned = prevTotalEarned + pointsAwarded;

        // 1. Mark duel reward claimed
        transaction.update(
          duelRef,
          isChallenger
            ? { challengerRewardClaimed: true, updatedAt: serverTimestamp() }
            : { opponentRewardClaimed: true, updatedAt: serverTimestamp() },
        );

        // 2. Write immutable pointTransaction
        transaction.set(txRef, {
          uid,
          txId,
          type: txType,
          refId: duelId,
          amount: pointsAwarded,
          balanceAfter: newPoints,
          createdAt: serverTimestamp(),
        });

        // 3. Update users/{uid} & leaderboard/{uid}
        transaction.update(userRef, {
          points: newPoints,
          totalEarnedPoints: newTotalEarned,
          currentStage: userData.currentStage ?? 1,
          completedStagesCount: userData.completedStagesCount ?? 0,
          completedSectionsCount: userData.completedSectionsCount ?? 0,
          certificatesCount: userData.certificatesCount ?? 0,
          lastLedgerId: txId,
          updatedAt: serverTimestamp(),
        });

        if (lbSnap.exists()) {
          transaction.update(lbRef, {
            totalEarnedPoints: newTotalEarned,
            updatedAt: serverTimestamp(),
          });
        }

        // 4. Update public competitive stats (/duelStats/{uid})
        const prevStats = statsSnap.exists()
          ? (statsSnap.data() as DuelCompetitorStatsRecord)
          : null;

        const nextWins = (prevStats?.wins ?? 0) + (outcome === 'win' ? 1 : 0);
        const nextDraws = (prevStats?.draws ?? 0) + (outcome === 'draw' ? 1 : 0);
        const nextLosses = (prevStats?.losses ?? 0) + (outcome === 'loss' ? 1 : 0);
        const nextMatches = nextWins + nextDraws + nextLosses;
        const nextDuelPoints = (prevStats?.duelPoints ?? 0) + pointsAwarded;

        const statsPayload = {
          uid,
          displayName: clampString(userData.displayName, 100),
          countryCode: userData.countryCode.slice(0, 3),
          avatarId: userData.equippedAvatarId || DEFAULT_AVATAR_ID,
          photoUrl: userData.photoUrl ?? '',
          wins: nextWins,
          draws: nextDraws,
          losses: nextLosses,
          matchesPlayed: nextMatches,
          duelPoints: nextDuelPoints,
          updatedAt: serverTimestamp(),
        };

        if (statsSnap.exists()) {
          transaction.update(duelStatsRef, statsPayload);
        } else {
          transaction.set(duelStatsRef, statsPayload);
        }

        result = { pointsAwarded, outcome };
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }

    return result;
  },
};
