import type { SectionId } from '@/src/types/curriculum';
import type { Language } from '@/src/types/i18n';
import type { ThemeMode } from '@/src/types/notifications';

const COUNTRY_KEY = 'math_master_country_code';
const LANG_KEY = 'math_master_language';
const THEME_KEY = 'math_master_theme_mode';
const EXAM_DRAFT_PREFIX = 'math_master_exam_draft_';
const DAILY_DRAFT_PREFIX = 'math_master_daily_draft_';
const DAILY_REVIEW_PREFIX = 'math_master_daily_review_';
const DUEL_DRAFT_PREFIX = 'math_master_duel_draft_';

export interface ExamDraftState {
  uid: string;
  sectionId: SectionId;
  startedAtMs: number;
  expiresAtMs: number;
  currentIdx: number;
  answers: number[];
}

export interface DailyDraftState {
  uid: string;
  dateKey: string;
  startedAtMs: number;
  expiresAtMs: number;
  currentIdx: number;
  answers: number[];
}

export const storageService = {
  getSelectedCountryCode(): string | null {
    try {
      return window.localStorage.getItem(COUNTRY_KEY);
    } catch {
      return null;
    }
  },

  setSelectedCountryCode(code: string): void {
    try {
      window.localStorage.setItem(COUNTRY_KEY, code.toUpperCase());
    } catch {
      // Ignore storage quota or private browsing errors
    }
  },

  getLanguage(): Language {
    try {
      const saved = window.localStorage.getItem(LANG_KEY);
      if (saved === 'ar' || saved === 'en') {
        return saved;
      }
    } catch {
      // Ignore storage access errors
    }
    return 'ar';
  },

  setLanguage(lang: Language): void {
    try {
      window.localStorage.setItem(LANG_KEY, lang);
    } catch {
      // Ignore storage access errors
    }
  },

  getThemeMode(): ThemeMode {
    try {
      const saved = window.localStorage.getItem(THEME_KEY);
      if (saved === 'dark' || saved === 'light' || saved === 'auto') {
        return saved;
      }
    } catch {
      // Ignore storage access errors
    }
    return 'dark';
  },

  setThemeMode(mode: ThemeMode): void {
    try {
      window.localStorage.setItem(THEME_KEY, mode);
    } catch {
      // Ignore storage access errors
    }
  },

  getExamDraft(uid: string, sectionId: SectionId): ExamDraftState | null {
    try {
      const raw = window.localStorage.getItem(`${EXAM_DRAFT_PREFIX}${uid}_${sectionId}`);
      if (!raw) return null;
      const parsed = JSON.parse(raw) as Partial<ExamDraftState>;
      if (
        parsed.uid !== uid ||
        parsed.sectionId !== sectionId ||
        typeof parsed.startedAtMs !== 'number' ||
        typeof parsed.expiresAtMs !== 'number' ||
        typeof parsed.currentIdx !== 'number' ||
        !Array.isArray(parsed.answers) ||
        parsed.answers.length !== 30
      ) {
        return null;
      }
      const sanitizedAnswers = parsed.answers.map((v) =>
        typeof v === 'number' && Number.isInteger(v) && v >= -1 && v <= 3 ? v : -1,
      );
      return {
        uid,
        sectionId,
        startedAtMs: parsed.startedAtMs,
        expiresAtMs: parsed.expiresAtMs,
        currentIdx: Math.min(29, Math.max(0, Math.floor(parsed.currentIdx))),
        answers: sanitizedAnswers,
      };
    } catch {
      return null;
    }
  },

  saveExamDraft(draft: ExamDraftState): void {
    try {
      window.localStorage.setItem(
        `${EXAM_DRAFT_PREFIX}${draft.uid}_${draft.sectionId}`,
        JSON.stringify(draft),
      );
    } catch {
      // Ignore storage quota or private browsing errors
    }
  },

  clearExamDraft(uid: string, sectionId: SectionId): void {
    try {
      window.localStorage.removeItem(`${EXAM_DRAFT_PREFIX}${uid}_${sectionId}`);
    } catch {
      // Ignore storage access errors
    }
  },

  getDailyDraft(uid: string, dateKey: string): DailyDraftState | null {
    try {
      const raw = window.localStorage.getItem(`${DAILY_DRAFT_PREFIX}${uid}_${dateKey}`);
      if (!raw) return null;
      const parsed = JSON.parse(raw) as Partial<DailyDraftState>;
      if (
        parsed.uid !== uid ||
        parsed.dateKey !== dateKey ||
        typeof parsed.startedAtMs !== 'number' ||
        typeof parsed.expiresAtMs !== 'number' ||
        typeof parsed.currentIdx !== 'number' ||
        !Array.isArray(parsed.answers) ||
        parsed.answers.length !== 10
      ) {
        return null;
      }
      const sanitizedAnswers = parsed.answers.map((v) =>
        typeof v === 'number' && Number.isInteger(v) && v >= -1 && v <= 3 ? v : -1,
      );
      return {
        uid,
        dateKey,
        startedAtMs: parsed.startedAtMs,
        expiresAtMs: parsed.expiresAtMs,
        currentIdx: Math.min(9, Math.max(0, Math.floor(parsed.currentIdx))),
        answers: sanitizedAnswers,
      };
    } catch {
      return null;
    }
  },

  saveDailyDraft(draft: DailyDraftState): void {
    try {
      window.localStorage.setItem(
        `${DAILY_DRAFT_PREFIX}${draft.uid}_${draft.dateKey}`,
        JSON.stringify(draft),
      );
    } catch {
      // Ignore storage quota or private browsing errors
    }
  },

  clearDailyDraft(uid: string, dateKey: string): void {
    try {
      window.localStorage.removeItem(`${DAILY_DRAFT_PREFIX}${uid}_${dateKey}`);
    } catch {
      // Ignore storage access errors
    }
  },

  saveDailyCompletedAnswers(uid: string, dateKey: string, answers: number[]): void {
    try {
      window.localStorage.setItem(
        `${DAILY_REVIEW_PREFIX}${uid}_${dateKey}`,
        JSON.stringify(answers),
      );
    } catch {
      // Ignore storage quota or private browsing errors
    }
  },

  getDailyCompletedAnswers(uid: string, dateKey: string): number[] | null {
    try {
      const raw = window.localStorage.getItem(`${DAILY_REVIEW_PREFIX}${uid}_${dateKey}`);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed) || parsed.length !== 10) return null;
      return parsed.map((v) =>
        typeof v === 'number' && Number.isInteger(v) && v >= -1 && v <= 3 ? v : -1,
      );
    } catch {
      return null;
    }
  },

  clearUserLocalData(uid: string): void {
    try {
      const keysToDelete: string[] = [];
      for (let i = 0; i < window.localStorage.length; i += 1) {
        const key = window.localStorage.key(i);
        if (!key) continue;
        if (
          key.startsWith(`${EXAM_DRAFT_PREFIX}${uid}_`) ||
          key.startsWith(`${DAILY_DRAFT_PREFIX}${uid}_`) ||
          key.startsWith(`${DAILY_REVIEW_PREFIX}${uid}_`) ||
          key.startsWith(`${DUEL_DRAFT_PREFIX}${uid}_`)
        ) {
          keysToDelete.push(key);
        }
      }
      for (const k of keysToDelete) {
        window.localStorage.removeItem(k);
      }
      window.localStorage.removeItem(COUNTRY_KEY);
    } catch {
      // Ignore storage access errors
    }
  },
};

