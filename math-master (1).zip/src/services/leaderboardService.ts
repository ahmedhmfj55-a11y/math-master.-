import {
  collection,
  getCountFromServer,
  limit,
  onSnapshot,
  orderBy,
  query,
  where,
  type Unsubscribe,
} from 'firebase/firestore';
import { db } from '@/src/config/firebase';
import { handleFirestoreError, OperationType } from '@/src/services/firestoreError';
import type { LeaderboardEntry } from '@/src/types/rewards';

export const leaderboardService = {
  subscribeTopLeaderboard(
    limitCount: number,
    onData: (entries: LeaderboardEntry[]) => void,
    onError: (err: Error) => void,
  ): Unsubscribe {
    const path = 'leaderboard';
    const q = query(
      collection(db, 'leaderboard'),
      orderBy('totalEarnedPoints', 'desc'),
      limit(limitCount),
    );

    return onSnapshot(
      q,
      (snapshot) => {
        const entries: LeaderboardEntry[] = [];
        snapshot.forEach((docSnap) => {
          entries.push(docSnap.data() as LeaderboardEntry);
        });
        onData(entries);
      },
      (error) => {
        try {
          handleFirestoreError(error, OperationType.LIST, path);
        } catch (wrapped) {
          onError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
        }
      },
    );
  },

  async fetchUserGlobalRank(totalEarnedPoints: number): Promise<number> {
    const path = 'leaderboard';
    try {
      const q = query(
        collection(db, 'leaderboard'),
        where('totalEarnedPoints', '>', totalEarnedPoints),
      );
      const countSnap = await getCountFromServer(q);
      return countSnap.data().count + 1;
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  },
};
