import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  runTransaction,
  serverTimestamp,
  where,
} from 'firebase/firestore';
import { db } from '@/src/config/firebase';
import {
  BANK_MASTERY_THRESHOLD,
  BANK_TIER_MASTERY_POINTS,
  GENIUS_SOLVE_POINTS,
  getGradeById,
  getNextTier,
} from '@/src/data/questionBank/catalog';
import { computeNextAdaptiveRecommendation, makeBankKey } from '@/src/data/questionBank/bankEngine';
import { isWrittenAnswerCorrect } from '@/src/data/questionBank/mathHelpers';
import { handleFirestoreError, OperationType } from '@/src/services/firestoreError';
import type {
  AdaptiveProfileSummary,
  BankDifficultyTier,
  BankQuestion,
  BankQuestionReviewItem,
  BankQuizSubmissionResult,
  BankTierProgressRecord,
  GeniusChallengeItem,
  GradeId,
  TopicMasteryStat,
} from '@/src/types/questionBank';
import type { UserProfile } from '@/src/types/user';

function formatUserDisplayAnswer(
  q: BankQuestion,
  answer: { selectedIndex?: number; writtenValue?: string } | undefined,
): { isCorrect: boolean; userAnswerDisplay: string } {
  if (q.format === 'written') {
    const raw = (answer?.writtenValue ?? '').trim();
    const isCorrect = Boolean(raw && q.acceptedAnswers && isWrittenAnswerCorrect(raw, q.acceptedAnswers));
    return {
      isCorrect,
      userAnswerDisplay: raw || '—',
    };
  }

  const idx = answer?.selectedIndex ?? -1;
  const isCorrect = idx >= 0 && idx === q.correctIndex;
  const display = idx >= 0 && q.options ? (q.options[idx] ?? '—') : '—';
  return {
    isCorrect,
    userAnswerDisplay: display,
  };
}

export const questionBankService = {
  async loadQuestionBankState(uid: string): Promise<{
    bankProgressMap: Record<string, BankTierProgressRecord>;
    adaptiveProfile: AdaptiveProfileSummary | null;
  }> {
    const bankProgressPath = `users/${uid}/bankProgress`;
    const adaptivePath = `users/${uid}/adaptiveProfile/summary`;

    const bankProgressMap: Record<string, BankTierProgressRecord> = {};
    let adaptiveProfile: AdaptiveProfileSummary | null = null;

    try {
      const q = query(collection(db, 'users', uid, 'bankProgress'), where('uid', '==', uid));
      const snap = await getDocs(q);
      snap.forEach((docSnap) => {
        const data = docSnap.data() as BankTierProgressRecord;
        bankProgressMap[data.bankKey] = data;
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, bankProgressPath);
    }

    try {
      const adaptiveSnap = await getDoc(doc(db, 'users', uid, 'adaptiveProfile', 'summary'));
      if (adaptiveSnap.exists()) {
        adaptiveProfile = adaptiveSnap.data() as AdaptiveProfileSummary;
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, adaptivePath);
    }

    return { bankProgressMap, adaptiveProfile };
  },

  async submitBankQuizAttempt(params: {
    uid: string;
    gradeId: GradeId;
    tier: BankDifficultyTier;
    questions: BankQuestion[];
    answers: ({ selectedIndex?: number; writtenValue?: string } | undefined)[];
  }): Promise<BankQuizSubmissionResult> {
    const { uid, gradeId, tier, questions, answers } = params;
    if (questions.length === 0) {
      throw new Error('Cannot submit an empty question bank quiz.');
    }

    const review: BankQuestionReviewItem[] = questions.map((q, idx) => {
      const graded = formatUserDisplayAnswer(q, answers[idx]);
      return {
        question: q,
        userAnswerDisplay: graded.userAnswerDisplay,
        isCorrect: graded.isCorrect,
      };
    });

    const totalQuestions = review.length;
    const correctCount = review.filter((r) => r.isCorrect).length;
    const score = Math.round((correctCount / totalQuestions) * 100);
    const mastered = score >= BANK_MASTERY_THRESHOLD;

    const bankKey = makeBankKey(gradeId, tier);
    const userRef = doc(db, 'users', uid);
    const leaderboardRef = doc(db, 'leaderboard', uid);
    const bankRef = doc(db, 'users', uid, 'bankProgress', bankKey);
    const adaptiveRef = doc(db, 'users', uid, 'adaptiveProfile', 'summary');
    const txPath = `users/${uid}/bankProgress/${bankKey}`;

    let newlyMastered = false;
    let pointsAwarded = 0;
    let rewardAlreadyClaimed = false;
    let unlockedNextTier: BankDifficultyTier | null = null;
    let recommendedGradeNumber = getGradeById(gradeId)?.order ?? 1;
    let recommendedTier: BankDifficultyTier = tier;
    let adaptiveShift: 'upgraded' | 'reinforced' | 'steady' = 'steady';

    try {
      await runTransaction(db, async (transaction) => {
        const userSnap = await transaction.get(userRef);
        const lbSnap = await transaction.get(leaderboardRef);
        const bankSnap = await transaction.get(bankRef);
        const adaptiveSnap = await transaction.get(adaptiveRef);

        if (!userSnap.exists()) {
          throw new Error('User profile does not exist.');
        }

        const userData = userSnap.data() as UserProfile;
        const prevBank = bankSnap.exists() ? (bankSnap.data() as BankTierProgressRecord) : null;
        const prevAdaptive = adaptiveSnap.exists()
          ? (adaptiveSnap.data() as AdaptiveProfileSummary)
          : null;

        const prevMastered = prevBank?.mastered ?? false;
        const prevRewardClaimed = prevBank?.rewardClaimed ?? false;

        newlyMastered = mastered && !prevMastered;
        const grantPoints = mastered && !prevRewardClaimed;
        pointsAwarded = grantPoints ? BANK_TIER_MASTERY_POINTS : 0;
        rewardAlreadyClaimed = mastered && !grantPoints;

        if (newlyMastered) {
          unlockedNextTier = getNextTier(tier);
        }

        const mergedSeen = Array.from(
          new Set([...(prevBank?.seenQuestionIds ?? []), ...questions.map((q) => q.id)]),
        ).slice(-100);

        const nextBankPayload: Record<string, unknown> = {
          uid,
          bankKey,
          gradeId,
          tier,
          attempts: (prevBank?.attempts ?? 0) + 1,
          bestScore: Math.max(prevBank?.bestScore ?? 0, score),
          lastScore: score,
          mastered: prevMastered || mastered,
          rewardClaimed: prevRewardClaimed || mastered,
          correctCount: (prevBank?.correctCount ?? 0) + correctCount,
          totalAnswered: (prevBank?.totalAnswered ?? 0) + totalQuestions,
          seenQuestionIds: mergedSeen,
          updatedAt: serverTimestamp(),
        };

        if (!bankSnap.exists()) {
          transaction.set(bankRef, nextBankPayload);
        } else {
          transaction.update(bankRef, {
            attempts: nextBankPayload.attempts,
            bestScore: nextBankPayload.bestScore,
            lastScore: nextBankPayload.lastScore,
            mastered: nextBankPayload.mastered,
            rewardClaimed: nextBankPayload.rewardClaimed,
            correctCount: nextBankPayload.correctCount,
            totalAnswered: nextBankPayload.totalAnswered,
            seenQuestionIds: nextBankPayload.seenQuestionIds,
            updatedAt: serverTimestamp(),
          });
        }

        // Update Adaptive Recommendation & Topic Accuracy
        const rec = computeNextAdaptiveRecommendation({
          currentGradeNumber: prevAdaptive?.recommendedGradeNumber ?? recommendedGradeNumber,
          currentTier: prevAdaptive?.recommendedTier ?? tier,
          quizGradeId: gradeId,
          quizTier: tier,
          score,
        });
        recommendedGradeNumber = rec.recommendedGradeNumber;
        recommendedTier = rec.recommendedTier;
        adaptiveShift = rec.adaptiveShift;

        const nextTopicStats: Record<string, TopicMasteryStat> = {
          ...(prevAdaptive?.topicStats ?? {}),
        };
        for (const item of review) {
          const prevTopic = nextTopicStats[item.question.topic] ?? { attempted: 0, correct: 0 };
          nextTopicStats[item.question.topic] = {
            attempted: prevTopic.attempted + 1,
            correct: prevTopic.correct + (item.isCorrect ? 1 : 0),
          };
        }

        const adaptivePayload = {
          uid,
          recommendedGradeNumber,
          recommendedTier,
          totalBankQuestionsAnswered:
            (prevAdaptive?.totalBankQuestionsAnswered ?? 0) + totalQuestions,
          totalBankCorrect: (prevAdaptive?.totalBankCorrect ?? 0) + correctCount,
          totalQuizzesCompleted: (prevAdaptive?.totalQuizzesCompleted ?? 0) + 1,
          geniusSolvedCount: prevAdaptive?.geniusSolvedCount ?? 0,
          topicStats: nextTopicStats,
          updatedAt: serverTimestamp(),
        };

        if (!adaptiveSnap.exists()) {
          transaction.set(adaptiveRef, adaptivePayload);
        } else {
          transaction.update(adaptiveRef, adaptivePayload);
        }

        // Award deterministic +50 points on first mastery of this grade difficulty tier
        if (grantPoints) {
          const txId = `bank-tier-${bankKey}`;
          const prevPoints = userData.points ?? 0;
          const prevTotalEarned = userData.totalEarnedPoints ?? prevPoints;
          const newPoints = prevPoints + BANK_TIER_MASTERY_POINTS;
          const newTotalEarned = prevTotalEarned + BANK_TIER_MASTERY_POINTS;

          transaction.set(doc(db, 'users', uid, 'pointTransactions', txId), {
            uid,
            txId,
            type: 'bank_tier_mastery',
            refId: bankKey,
            amount: BANK_TIER_MASTERY_POINTS,
            balanceAfter: newPoints,
            createdAt: serverTimestamp(),
          });

          transaction.update(userRef, {
            points: newPoints,
            totalEarnedPoints: newTotalEarned,
            currentStage: userData.currentStage ?? 1,
            completedStagesCount: userData.completedStagesCount ?? 0,
            completedSectionsCount: userData.completedSectionsCount ?? 0,
            certificatesCount: userData.certificatesCount ?? 0,
            lastLedgerId: txId,
            updatedAt: serverTimestamp(),
          });

          if (lbSnap.exists()) {
            transaction.update(leaderboardRef, {
              totalEarnedPoints: newTotalEarned,
              updatedAt: serverTimestamp(),
            });
          }
        }
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, txPath);
    }

    return {
      bankKey,
      gradeId,
      tier,
      score,
      correctCount,
      totalQuestions,
      mastered,
      newlyMastered,
      unlockedNextTier,
      pointsAwarded,
      rewardAlreadyClaimed,
      adaptiveShift,
      recommendedGradeNumber,
      recommendedTier,
      review,
    };
  },

  async submitGeniusChallengeAttempt(params: {
    uid: string;
    challenge: GeniusChallengeItem;
    answer: { selectedIndex?: number; writtenValue?: string };
  }): Promise<{
    isCorrect: boolean;
    newlySolved: boolean;
    pointsAwarded: number;
    rewardAlreadyClaimed: boolean;
    userAnswerDisplay: string;
  }> {
    const { uid, challenge, answer } = params;
    const q = challenge.question;
    const graded = formatUserDisplayAnswer(q, answer);
    const bankKey = challenge.id.startsWith('genius-')
      ? challenge.id
      : `genius-${challenge.id}`;

    const userRef = doc(db, 'users', uid);
    const leaderboardRef = doc(db, 'leaderboard', uid);
    const bankRef = doc(db, 'users', uid, 'bankProgress', bankKey);
    const adaptiveRef = doc(db, 'users', uid, 'adaptiveProfile', 'summary');
    const txPath = `users/${uid}/bankProgress/${bankKey}`;

    let newlySolved = false;
    let pointsAwarded = 0;
    let rewardAlreadyClaimed = false;

    try {
      await runTransaction(db, async (transaction) => {
        const userSnap = await transaction.get(userRef);
        const lbSnap = await transaction.get(leaderboardRef);
        const bankSnap = await transaction.get(bankRef);
        const adaptiveSnap = await transaction.get(adaptiveRef);

        if (!userSnap.exists()) {
          throw new Error('User profile does not exist.');
        }

        const userData = userSnap.data() as UserProfile;
        const prevBank = bankSnap.exists() ? (bankSnap.data() as BankTierProgressRecord) : null;
        const prevAdaptive = adaptiveSnap.exists()
          ? (adaptiveSnap.data() as AdaptiveProfileSummary)
          : null;

        const prevMastered = prevBank?.mastered ?? false;
        const prevRewardClaimed = prevBank?.rewardClaimed ?? false;

        newlySolved = graded.isCorrect && !prevMastered;
        const grantPoints = graded.isCorrect && !prevRewardClaimed;
        pointsAwarded = grantPoints ? GENIUS_SOLVE_POINTS : 0;
        rewardAlreadyClaimed = graded.isCorrect && !grantPoints;

        const score = graded.isCorrect ? 100 : 0;

        if (!bankSnap.exists()) {
          transaction.set(bankRef, {
            uid,
            bankKey,
            gradeId: q.gradeId,
            tier: q.tier,
            attempts: 1,
            bestScore: score,
            lastScore: score,
            mastered: graded.isCorrect,
            rewardClaimed: graded.isCorrect,
            correctCount: graded.isCorrect ? 1 : 0,
            totalAnswered: 1,
            seenQuestionIds: [q.id],
            updatedAt: serverTimestamp(),
          });
        } else {
          transaction.update(bankRef, {
            attempts: (prevBank?.attempts ?? 0) + 1,
            bestScore: Math.max(prevBank?.bestScore ?? 0, score),
            lastScore: score,
            mastered: prevMastered || graded.isCorrect,
            rewardClaimed: prevRewardClaimed || graded.isCorrect,
            correctCount: (prevBank?.correctCount ?? 0) + (graded.isCorrect ? 1 : 0),
            totalAnswered: (prevBank?.totalAnswered ?? 0) + 1,
            seenQuestionIds: [q.id],
            updatedAt: serverTimestamp(),
          });
        }

        const nextTopicStats: Record<string, TopicMasteryStat> = {
          ...(prevAdaptive?.topicStats ?? {}),
        };
        const prevTopic = nextTopicStats[q.topic] ?? { attempted: 0, correct: 0 };
        nextTopicStats[q.topic] = {
          attempted: prevTopic.attempted + 1,
          correct: prevTopic.correct + (graded.isCorrect ? 1 : 0),
        };

        const adaptivePayload = {
          uid,
          recommendedGradeNumber: prevAdaptive?.recommendedGradeNumber ?? 1,
          recommendedTier: prevAdaptive?.recommendedTier ?? 'very_easy',
          totalBankQuestionsAnswered: (prevAdaptive?.totalBankQuestionsAnswered ?? 0) + 1,
          totalBankCorrect: (prevAdaptive?.totalBankCorrect ?? 0) + (graded.isCorrect ? 1 : 0),
          totalQuizzesCompleted: prevAdaptive?.totalQuizzesCompleted ?? 0,
          geniusSolvedCount: (prevAdaptive?.geniusSolvedCount ?? 0) + (newlySolved ? 1 : 0),
          topicStats: nextTopicStats,
          updatedAt: serverTimestamp(),
        };

        if (!adaptiveSnap.exists()) {
          transaction.set(adaptiveRef, adaptivePayload);
        } else {
          transaction.update(adaptiveRef, adaptivePayload);
        }

        if (grantPoints) {
          const txId = `genius-solve-${bankKey}`;
          const prevPoints = userData.points ?? 0;
          const prevTotalEarned = userData.totalEarnedPoints ?? prevPoints;
          const newPoints = prevPoints + GENIUS_SOLVE_POINTS;
          const newTotalEarned = prevTotalEarned + GENIUS_SOLVE_POINTS;

          transaction.set(doc(db, 'users', uid, 'pointTransactions', txId), {
            uid,
            txId,
            type: 'genius_solve',
            refId: bankKey,
            amount: GENIUS_SOLVE_POINTS,
            balanceAfter: newPoints,
            createdAt: serverTimestamp(),
          });

          transaction.update(userRef, {
            points: newPoints,
            totalEarnedPoints: newTotalEarned,
            currentStage: userData.currentStage ?? 1,
            completedStagesCount: userData.completedStagesCount ?? 0,
            completedSectionsCount: userData.completedSectionsCount ?? 0,
            certificatesCount: userData.certificatesCount ?? 0,
            lastLedgerId: txId,
            updatedAt: serverTimestamp(),
          });

          if (lbSnap.exists()) {
            transaction.update(leaderboardRef, {
              totalEarnedPoints: newTotalEarned,
              updatedAt: serverTimestamp(),
            });
          }
        }
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, txPath);
    }

    return {
      isCorrect: graded.isCorrect,
      newlySolved,
      pointsAwarded,
      rewardAlreadyClaimed,
      userAnswerDisplay: graded.userAnswerDisplay,
    };
  },
};
