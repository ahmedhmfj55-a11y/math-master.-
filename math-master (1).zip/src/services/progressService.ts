import {
  collection,
  doc,
  getDocs,
  query,
  runTransaction,
  serverTimestamp,
  where,
} from 'firebase/firestore';
import { db } from '@/src/config/firebase';
import {
  EXAM_DURATION_SECONDS,
  EXAM_FIRST_WIN_POINTS,
  EXAM_PERFECT_BONUS_POINTS,
  PASS_SCORE_THRESHOLD,
  SECTION_COMPLETE_POINTS,
  STAGE_FIRST_WIN_POINTS,
  STAGE_PERFECT_BONUS_POINTS,
  buildSectionFinalExam,
  getStageDefinition,
} from '@/src/data/curriculum';
import { handleFirestoreError, OperationType } from '@/src/services/firestoreError';
import type { SectionId } from '@/src/types/curriculum';
import type {
  ExamAttemptRecord,
  ExamSubmissionResult,
  QuestionReviewItem,
  SectionProgressRecord,
  StageProgressRecord,
  StageSubmissionResult,
} from '@/src/types/progress';
import type { UserProfile } from '@/src/types/user';

export function calculateStarsForScore(score: number): number {
  if (score < PASS_SCORE_THRESHOLD) return 0;
  if (score >= 90) return 3;
  if (score >= 80) return 2;
  return 1;
}

function generateCertificateId(sectionId: SectionId, uid: string): string {
  const secTag = sectionId.slice(0, 3).toUpperCase();
  const uidTag = uid.slice(0, 6).toUpperCase();
  const timeTag = Date.now().toString(36).toUpperCase().slice(-5);
  return `MM-${secTag}-${uidTag}-${timeTag}`.slice(0, 64);
}

export const progressService = {
  async loadUserProgress(uid: string): Promise<{
    sections: Partial<Record<SectionId, SectionProgressRecord>>;
    stages: Record<string, StageProgressRecord>;
    examAttempts: ExamAttemptRecord[];
  }> {
    const sectionsPath = `users/${uid}/sectionProgress`;
    const stagesPath = `users/${uid}/stageProgress`;
    const attemptsPath = `users/${uid}/examAttempts`;

    const sections: Partial<Record<SectionId, SectionProgressRecord>> = {};
    const stages: Record<string, StageProgressRecord> = {};
    const examAttempts: ExamAttemptRecord[] = [];

    try {
      const secQuery = query(collection(db, 'users', uid, 'sectionProgress'), where('uid', '==', uid));
      const secSnap = await getDocs(secQuery);
      secSnap.forEach((docSnap) => {
        const data = docSnap.data() as SectionProgressRecord;
        sections[data.sectionId] = data;
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, sectionsPath);
    }

    try {
      const stageQuery = query(collection(db, 'users', uid, 'stageProgress'), where('uid', '==', uid));
      const stageSnap = await getDocs(stageQuery);
      stageSnap.forEach((docSnap) => {
        const data = docSnap.data() as StageProgressRecord;
        stages[data.stageId] = data;
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, stagesPath);
    }

    try {
      const attQuery = query(collection(db, 'users', uid, 'examAttempts'), where('uid', '==', uid));
      const attSnap = await getDocs(attQuery);
      attSnap.forEach((docSnap) => {
        examAttempts.push(docSnap.data() as ExamAttemptRecord);
      });
      examAttempts.sort((a, b) => {
        const timeA = a.submittedAt?.toMillis?.() ?? 0;
        const timeB = b.submittedAt?.toMillis?.() ?? 0;
        if (timeB !== timeA) return timeB - timeA;
        return b.attemptNumber - a.attemptNumber;
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, attemptsPath);
    }

    return { sections, stages, examAttempts };
  },

  async submitStageAttempt(params: {
    uid: string;
    sectionId: SectionId;
    stageNumber: number;
    selectedAnswers: number[];
  }): Promise<StageSubmissionResult> {
    const { uid, sectionId, stageNumber, selectedAnswers } = params;
    const stageDef = getStageDefinition(sectionId, stageNumber);
    if (!stageDef) {
      throw new Error(`Invalid stage ${sectionId}-${stageNumber}`);
    }

    const totalQuestions = stageDef.questions.length;
    const review: QuestionReviewItem[] = stageDef.questions.map((q, idx) => {
      const selectedIndex = selectedAnswers[idx] ?? -1;
      const isCorrect = selectedIndex === q.correctIndex;
      return {
        questionId: q.id,
        promptAr: q.promptAr,
        promptEn: q.promptEn,
        options: q.options,
        selectedIndex,
        correctIndex: q.correctIndex,
        isCorrect,
        explanationAr: q.explanationAr,
        explanationEn: q.explanationEn,
      };
    });

    const correctCount = review.filter((item) => item.isCorrect).length;
    const wrongCount = totalQuestions - correctCount;
    const score = Math.round((correctCount / totalQuestions) * 100);
    const passed = score >= PASS_SCORE_THRESHOLD;
    const isPerfect = score === 100;
    const stars = calculateStarsForScore(score);

    const userRef = doc(db, 'users', uid);
    const leaderboardRef = doc(db, 'leaderboard', uid);
    const secRef = doc(db, 'users', uid, 'sectionProgress', sectionId);
    const stageRef = doc(db, 'users', uid, 'stageProgress', stageDef.id);
    const txPath = `users/${uid}/stageProgress/${stageDef.id}`;

    let stageWinPoints = 0;
    let perfectScoreBonusPoints = 0;
    let sectionCompletionBonusPoints = 0;
    let pointsAwarded = 0;
    let rewardAlreadyClaimed = false;
    let unlockedNextStage: number | null = null;

    try {
      await runTransaction(db, async (transaction) => {
        const userSnap = await transaction.get(userRef);
        const lbSnap = await transaction.get(leaderboardRef);
        const secSnap = await transaction.get(secRef);
        const stageSnap = await transaction.get(stageRef);

        if (!userSnap.exists()) {
          throw new Error('User profile does not exist.');
        }

        const userData = userSnap.data() as UserProfile;
        const secData = secSnap.exists() ? (secSnap.data() as SectionProgressRecord) : null;
        const stageData = stageSnap.exists() ? (stageSnap.data() as StageProgressRecord) : null;

        // Server-checked lock enforcement inside transaction
        const prevUnlockedStage = secData?.unlockedStage ?? 1;
        if (stageNumber > 1 && prevUnlockedStage < stageNumber) {
          throw new Error(`Stage ${stageNumber} is locked.`);
        }

        // 1. Stage first-win reward (+100)
        const prevRewardClaimed = stageData?.rewardClaimed ?? false;
        const grantStageWin = passed && !prevRewardClaimed;
        stageWinPoints = grantStageWin ? STAGE_FIRST_WIN_POINTS : 0;

        // 2. Perfect 100/100 bonus (+50, granted once per stage)
        const prevPerfectClaimed = stageData?.perfectRewardClaimed ?? false;
        const grantPerfectBonus = isPerfect && !prevPerfectClaimed;
        perfectScoreBonusPoints = grantPerfectBonus ? STAGE_PERFECT_BONUS_POINTS : 0;

        const prevBestScore = stageData?.bestScore ?? 0;
        const newBestScore = Math.max(prevBestScore, score);
        const prevBestStars = stageData?.bestStars ?? 0;
        const newBestStars = Math.max(prevBestStars, stars);
        const starsDelta = Math.max(0, newBestStars - prevBestStars);

        const prevPassed = stageData?.passed ?? false;
        const newPassed = prevPassed || passed;
        const newRewardClaimed = prevRewardClaimed || passed;
        const newPerfectClaimed = prevPerfectClaimed || isPerfect;

        const prevCompleted = secData?.completedStagesCount ?? 0;
        const newlyCompletedStage = passed && !prevPassed;
        const newCompletedCount = Math.min(30, prevCompleted + (newlyCompletedStage ? 1 : 0));

        // 3. Full section completion bonus (+500 when all 30 stages in section are completed for the first time)
        const prevSectionRewardClaimed = secData?.sectionRewardClaimed ?? false;
        const newlyCompletedSection = newCompletedCount === 30 && prevCompleted < 30;
        const grantSectionBonus = newCompletedCount === 30 && !prevSectionRewardClaimed;
        sectionCompletionBonusPoints = grantSectionBonus ? SECTION_COMPLETE_POINTS : 0;
        const newSectionRewardClaimed = prevSectionRewardClaimed || grantSectionBonus;

        pointsAwarded = stageWinPoints + perfectScoreBonusPoints + sectionCompletionBonusPoints;
        rewardAlreadyClaimed = passed && pointsAwarded === 0;

        let newUnlockedStage = prevUnlockedStage;
        if (passed && stageNumber < 30 && prevUnlockedStage === stageNumber) {
          newUnlockedStage = stageNumber + 1;
          unlockedNextStage = stageNumber + 1;
        }

        const prevTotalStars = secData?.totalStars ?? 0;
        const newTotalStars = Math.min(90, prevTotalStars + starsDelta);

        const hasExistingAnswerCounts =
          typeof stageData?.totalCorrect === 'number' && typeof stageData?.totalWrong === 'number';
        const baseCorrect = hasExistingAnswerCounts
          ? stageData!.totalCorrect!
          : stageData
            ? Math.min(totalQuestions, Math.max(0, Math.round((stageData.lastScore / 100) * totalQuestions)))
            : 0;
        const baseWrong = hasExistingAnswerCounts
          ? stageData!.totalWrong!
          : stageData
            ? totalQuestions - baseCorrect
            : 0;

        // Write StageProgress
        if (!stageSnap.exists()) {
          transaction.set(stageRef, {
            uid,
            stageId: stageDef.id,
            sectionId,
            stageNumber,
            bestScore: score,
            lastScore: score,
            bestStars: stars,
            passed,
            attempts: 1,
            rewardClaimed: passed,
            perfectRewardClaimed: isPerfect,
            totalCorrect: correctCount,
            totalWrong: wrongCount,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } else {
          transaction.update(stageRef, {
            bestScore: newBestScore,
            lastScore: score,
            bestStars: newBestStars,
            passed: newPassed,
            attempts: (stageData?.attempts ?? 0) + 1,
            rewardClaimed: newRewardClaimed,
            perfectRewardClaimed: newPerfectClaimed,
            totalCorrect: baseCorrect + correctCount,
            totalWrong: baseWrong + wrongCount,
            updatedAt: serverTimestamp(),
          });
        }

        // Write SectionProgress
        if (!secSnap.exists()) {
          transaction.set(secRef, {
            uid,
            sectionId,
            unlockedStage: newUnlockedStage,
            completedStagesCount: newCompletedCount,
            totalStars: newTotalStars,
            sectionRewardClaimed: newSectionRewardClaimed,
            examBestScore: 0,
            examLastScore: 0,
            examAttempts: 0,
            examPassed: false,
            examRewardClaimed: false,
            examPerfectRewardClaimed: false,
            certificateId: '',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } else {
          transaction.update(secRef, {
            unlockedStage: newUnlockedStage,
            completedStagesCount: newCompletedCount,
            totalStars: newTotalStars,
            sectionRewardClaimed: newSectionRewardClaimed,
            examBestScore: secData?.examBestScore ?? 0,
            examLastScore: secData?.examLastScore ?? 0,
            examAttempts: secData?.examAttempts ?? 0,
            examPassed: secData?.examPassed ?? false,
            examRewardClaimed: secData?.examRewardClaimed ?? false,
            examPerfectRewardClaimed: secData?.examPerfectRewardClaimed ?? false,
            certificateId: secData?.certificateId ?? '',
            updatedAt: serverTimestamp(),
          });
        }

        // Write immutable deterministic pointTransactions & update user + leaderboard
        if (pointsAwarded > 0) {
          const prevPoints = userData.points ?? 0;
          const prevTotalEarned = userData.totalEarnedPoints ?? prevPoints;
          let runningBalance = prevPoints;
          let primaryLedgerId = '';

          if (grantStageWin) {
            const winTxId = `stage-win-${stageDef.id}`;
            runningBalance += STAGE_FIRST_WIN_POINTS;
            primaryLedgerId = winTxId;
            transaction.set(doc(db, 'users', uid, 'pointTransactions', winTxId), {
              uid,
              txId: winTxId,
              type: 'stage_win',
              refId: stageDef.id,
              amount: STAGE_FIRST_WIN_POINTS,
              balanceAfter: runningBalance,
              createdAt: serverTimestamp(),
            });
          }

          if (grantPerfectBonus) {
            const perfectTxId = `stage-perfect-${stageDef.id}`;
            runningBalance += STAGE_PERFECT_BONUS_POINTS;
            primaryLedgerId = perfectTxId;
            transaction.set(doc(db, 'users', uid, 'pointTransactions', perfectTxId), {
              uid,
              txId: perfectTxId,
              type: 'stage_perfect',
              refId: stageDef.id,
              amount: STAGE_PERFECT_BONUS_POINTS,
              balanceAfter: runningBalance,
              createdAt: serverTimestamp(),
            });
          }

          if (grantSectionBonus) {
            const secTxId = `section-complete-${sectionId}`;
            runningBalance += SECTION_COMPLETE_POINTS;
            primaryLedgerId = secTxId;
            transaction.set(doc(db, 'users', uid, 'pointTransactions', secTxId), {
              uid,
              txId: secTxId,
              type: 'section_complete',
              refId: sectionId,
              amount: SECTION_COMPLETE_POINTS,
              balanceAfter: runningBalance,
              createdAt: serverTimestamp(),
            });
          }

          const newPoints = prevPoints + pointsAwarded;
          const newTotalEarned = prevTotalEarned + pointsAwarded;
          const newCurrentStage = Math.min(
            240,
            Math.max(1, (userData.currentStage ?? 1) + (newlyCompletedStage ? 1 : 0)),
          );
          const newUserCompletedStages = Math.min(
            240,
            (userData.completedStagesCount ?? 0) + (newlyCompletedStage ? 1 : 0),
          );
          const newUserCompletedSections = Math.min(
            8,
            (userData.completedSectionsCount ?? 0) + (newlyCompletedSection || grantSectionBonus ? 1 : 0),
          );

          transaction.update(userRef, {
            points: newPoints,
            totalEarnedPoints: newTotalEarned,
            currentStage: newCurrentStage,
            completedStagesCount: newUserCompletedStages,
            completedSectionsCount: newUserCompletedSections,
            certificatesCount: userData.certificatesCount ?? 0,
            lastLedgerId: primaryLedgerId,
            updatedAt: serverTimestamp(),
          });

          if (lbSnap.exists()) {
            transaction.update(leaderboardRef, {
              totalEarnedPoints: newTotalEarned,
              completedStages: newUserCompletedStages,
              completedSections: newUserCompletedSections,
              certificatesCount: userData.certificatesCount ?? 0,
              updatedAt: serverTimestamp(),
            });
          }
        }
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, txPath);
    }

    return {
      score,
      correctCount,
      totalQuestions,
      stars,
      passed,
      pointsAwarded,
      stageWinPoints,
      perfectScoreBonusPoints,
      sectionCompletionBonusPoints,
      rewardAlreadyClaimed,
      unlockedNextStage,
      review,
    };
  },

  async submitExamAttempt(params: {
    uid: string;
    sectionId: SectionId;
    selectedAnswers: number[];
    durationSeconds?: number;
    timedOut?: boolean;
  }): Promise<ExamSubmissionResult> {
    const {
      uid,
      sectionId,
      selectedAnswers,
      durationSeconds = 0,
      timedOut = false,
    } = params;

    const safeDuration = Math.min(EXAM_DURATION_SECONDS, Math.max(0, Math.round(durationSeconds)));
    const examQuestions = buildSectionFinalExam(sectionId);
    const totalQuestions = examQuestions.length;

    const review: QuestionReviewItem[] = examQuestions.map((q, idx) => {
      const selectedIndex = selectedAnswers[idx] ?? -1;
      const isCorrect = selectedIndex === q.correctIndex;
      return {
        questionId: q.id,
        promptAr: q.promptAr,
        promptEn: q.promptEn,
        options: q.options,
        selectedIndex,
        correctIndex: q.correctIndex,
        isCorrect,
        explanationAr: q.explanationAr,
        explanationEn: q.explanationEn,
      };
    });

    const correctCount = review.filter((item) => item.isCorrect).length;
    const wrongCount = totalQuestions - correctCount;
    const score = Math.round((correctCount / totalQuestions) * 100);
    const passed = score >= PASS_SCORE_THRESHOLD;
    const isPerfect = score === 100;

    const userRef = doc(db, 'users', uid);
    const leaderboardRef = doc(db, 'leaderboard', uid);
    const secRef = doc(db, 'users', uid, 'sectionProgress', sectionId);
    const txPath = `users/${uid}/sectionProgress/${sectionId}`;

    let examPassPoints = 0;
    let perfectScoreBonusPoints = 0;
    let pointsAwarded = 0;
    let rewardAlreadyClaimed = false;
    let certificateId = '';
    let attemptNumber = 1;

    try {
      await runTransaction(db, async (transaction) => {
        const userSnap = await transaction.get(userRef);
        const lbSnap = await transaction.get(leaderboardRef);
        const secSnap = await transaction.get(secRef);

        if (!userSnap.exists() || !secSnap.exists()) {
          throw new Error('Section progress not found.');
        }

        const userData = userSnap.data() as UserProfile;
        const secData = secSnap.data() as SectionProgressRecord;

        if (secData.completedStagesCount < 30) {
          throw new Error('Section final exam is locked until all 30 stages are passed.');
        }

        attemptNumber = (secData.examAttempts ?? 0) + 1;
        const attemptId = `${sectionId}-att-${attemptNumber}`;

        const prevExamRewardClaimed = secData.examRewardClaimed ?? false;
        const grantExamPass = passed && !prevExamRewardClaimed;
        examPassPoints = grantExamPass ? EXAM_FIRST_WIN_POINTS : 0;

        const prevExamPerfectClaimed = secData.examPerfectRewardClaimed ?? false;
        const grantExamPerfect = isPerfect && !prevExamPerfectClaimed;
        perfectScoreBonusPoints = grantExamPerfect ? EXAM_PERFECT_BONUS_POINTS : 0;

        pointsAwarded = examPassPoints + perfectScoreBonusPoints;
        rewardAlreadyClaimed = passed && pointsAwarded === 0;

        const newBestScore = Math.max(secData.examBestScore ?? 0, score);
        const newExamPassed = secData.examPassed || passed;
        const newExamRewardClaimed = prevExamRewardClaimed || passed;
        const newExamPerfectClaimed = prevExamPerfectClaimed || isPerfect;

        const newlyIssuedCert = passed && !secData.certificateId;
        if (secData.certificateId) {
          certificateId = secData.certificateId;
        } else if (passed) {
          certificateId = generateCertificateId(sectionId, uid);
        }

        transaction.update(secRef, {
          unlockedStage: secData.unlockedStage,
          completedStagesCount: secData.completedStagesCount,
          totalStars: secData.totalStars,
          sectionRewardClaimed: secData.sectionRewardClaimed ?? true,
          examBestScore: newBestScore,
          examLastScore: score,
          examAttempts: attemptNumber,
          examPassed: newExamPassed,
          examRewardClaimed: newExamRewardClaimed,
          examPerfectRewardClaimed: newExamPerfectClaimed,
          certificateId,
          lastExamAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        transaction.set(doc(db, 'users', uid, 'examAttempts', attemptId), {
          uid,
          attemptId,
          sectionId,
          attemptNumber,
          score,
          correctCount,
          wrongCount,
          passed,
          durationSeconds: safeDuration,
          pointsAwarded,
          timedOut,
          submittedAt: serverTimestamp(),
        });

        if (pointsAwarded > 0) {
          const prevPoints = userData.points ?? 0;
          const prevTotalEarned = userData.totalEarnedPoints ?? prevPoints;
          let runningBalance = prevPoints;
          let primaryLedgerId = '';

          if (grantExamPass) {
            const examTxId = `exam-pass-${sectionId}`;
            runningBalance += EXAM_FIRST_WIN_POINTS;
            primaryLedgerId = examTxId;
            transaction.set(doc(db, 'users', uid, 'pointTransactions', examTxId), {
              uid,
              txId: examTxId,
              type: 'exam_pass',
              refId: sectionId,
              amount: EXAM_FIRST_WIN_POINTS,
              balanceAfter: runningBalance,
              createdAt: serverTimestamp(),
            });
          }

          if (grantExamPerfect) {
            const perfectTxId = `exam-perfect-${sectionId}`;
            runningBalance += EXAM_PERFECT_BONUS_POINTS;
            primaryLedgerId = perfectTxId;
            transaction.set(doc(db, 'users', uid, 'pointTransactions', perfectTxId), {
              uid,
              txId: perfectTxId,
              type: 'exam_perfect',
              refId: sectionId,
              amount: EXAM_PERFECT_BONUS_POINTS,
              balanceAfter: runningBalance,
              createdAt: serverTimestamp(),
            });
          }

          const newPoints = prevPoints + pointsAwarded;
          const newTotalEarned = prevTotalEarned + pointsAwarded;
          const newCertCount = Math.min(
            8,
            (userData.certificatesCount ?? 0) + (newlyIssuedCert ? 1 : 0),
          );

          transaction.update(userRef, {
            points: newPoints,
            totalEarnedPoints: newTotalEarned,
            currentStage: userData.currentStage ?? 1,
            completedStagesCount: userData.completedStagesCount ?? 0,
            completedSectionsCount: userData.completedSectionsCount ?? 0,
            certificatesCount: newCertCount,
            lastLedgerId: primaryLedgerId,
            updatedAt: serverTimestamp(),
          });

          if (lbSnap.exists()) {
            transaction.update(leaderboardRef, {
              totalEarnedPoints: newTotalEarned,
              certificatesCount: newCertCount,
              updatedAt: serverTimestamp(),
            });
          }
        }
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, txPath);
    }

    return {
      score,
      correctCount,
      wrongCount,
      totalQuestions,
      passed,
      pointsAwarded,
      examPassPoints,
      perfectScoreBonusPoints,
      rewardAlreadyClaimed,
      certificateId,
      durationSeconds: safeDuration,
      timedOut,
      attemptNumber,
      review,
    };
  },
};
