import { updateProfile, type User } from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  runTransaction,
  serverTimestamp,
  updateDoc,
  where,
  writeBatch,
  type DocumentReference,
} from 'firebase/firestore';
import { auth, db } from '@/src/config/firebase';
import { DEFAULT_AVATAR_ID } from '@/src/data/rewardsCatalog';
import { handleFirestoreError, OperationType } from '@/src/services/firestoreError';
import type { Country } from '@/src/types/country';
import type { Language } from '@/src/types/i18n';
import type { SectionProgressRecord } from '@/src/types/progress';
import type { AuthProviderType, UserProfile } from '@/src/types/user';

const MAX_DISPLAY_NAME_LEN = 100;
const MAX_COUNTRY_NAME_LEN = 100;
const MAX_EMAIL_LEN = 254;
const MAX_PHONE_LEN = 32;
const MAX_PHOTO_URL_LEN = 512;

function clampString(value: string, maxLen: number): string {
  return value.trim().slice(0, maxLen);
}

function resolveProvider(user: User): AuthProviderType {
  const providerId = user.providerData[0]?.providerId;
  if (providerId === 'phone' || (user.phoneNumber && !user.email)) {
    return 'phone';
  }
  return 'google.com';
}

function resolveDisplayName(user: User, lang: Language): string {
  const raw =
    user.displayName?.trim() ||
    user.phoneNumber?.trim() ||
    user.email?.split('@')[0] ||
    (lang === 'ar' ? 'متعلم Math Master' : 'Math Master Learner');
  return clampString(raw, MAX_DISPLAY_NAME_LEN) || 'Learner';
}

function resolvePhotoUrl(user: User): string {
  const raw = user.photoURL?.trim() ?? '';
  if (raw.startsWith('https://') && raw.length <= MAX_PHOTO_URL_LEN) {
    return raw;
  }
  return '';
}

export const userService = {
  async getUserProfile(uid: string): Promise<UserProfile | null> {
    const profilePath = `users/${uid}`;
    try {
      const snapshot = await getDoc(doc(db, 'users', uid));
      if (!snapshot.exists()) {
        return null;
      }
      return snapshot.data() as UserProfile;
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, profilePath);
    }
  },

  async syncAuthenticatedUser(
    user: User,
    selectedCountry: Country,
    preferredLang: Language,
  ): Promise<UserProfile> {
    const profileRef = doc(db, 'users', user.uid);
    const privateRef = doc(db, 'users', user.uid, 'private', 'info');
    const leaderboardRef = doc(db, 'leaderboard', user.uid);
    const profilePath = `users/${user.uid}`;

    const existingProfile = await this.getUserProfile(user.uid);
    const preservedExistingName = existingProfile?.displayName?.trim();
    const displayName = clampString(
      preservedExistingName || resolveDisplayName(user, preferredLang),
      MAX_DISPLAY_NAME_LEN,
    );
    const effectivePhotoUrl = existingProfile?.photoUrl || resolvePhotoUrl(user);
    const countryCode = selectedCountry.code.toUpperCase().slice(0, 3);
    const countryNameAr = clampString(selectedCountry.nameAr, MAX_COUNTRY_NAME_LEN);
    const countryNameEn = clampString(selectedCountry.nameEn, MAX_COUNTRY_NAME_LEN);
    const authProvider = resolveProvider(user);
    const photoUrl = effectivePhotoUrl || resolvePhotoUrl(user);

    const privatePayload: Record<string, unknown> = {
      uid: user.uid,
      authProvider,
      updatedAt: serverTimestamp(),
    };
    if (user.email) {
      privatePayload.email = clampString(user.email, MAX_EMAIL_LEN);
    }
    if (user.phoneNumber) {
      privatePayload.phoneNumber = clampString(user.phoneNumber, MAX_PHONE_LEN);
    }

    // Check legacy backfill stats from real sectionProgress if migrating pre-existing account
    let legacyCompletedStages = 0;
    let legacyCompletedSections = 0;
    let legacyCertificates = 0;
    if (existingProfile && existingProfile.totalEarnedPoints === undefined) {
      try {
        const secQuery = query(
          collection(db, 'users', user.uid, 'sectionProgress'),
          where('uid', '==', user.uid),
        );
        const secSnap = await getDocs(secQuery);
        secSnap.forEach((docSnap) => {
          const sec = docSnap.data() as SectionProgressRecord;
          legacyCompletedStages += sec.completedStagesCount ?? 0;
          if ((sec.completedStagesCount ?? 0) >= 30) legacyCompletedSections += 1;
          if (sec.examPassed && sec.certificateId) legacyCertificates += 1;
        });
      } catch {
        // Fallback to 0 if no section progress exists yet
      }
    }

    try {
      await runTransaction(db, async (transaction) => {
        const profileSnap = await transaction.get(profileRef);
        const privateSnap = await transaction.get(privateRef);
        const leaderboardSnap = await transaction.get(leaderboardRef);

        if (!profileSnap.exists()) {
          transaction.set(profileRef, {
            uid: user.uid,
            displayName,
            countryCode,
            countryNameAr,
            countryNameEn,
            preferredLang,
            points: 0,
            totalEarnedPoints: 0,
            currentStage: 1,
            completedStagesCount: 0,
            completedSectionsCount: 0,
            certificatesCount: 0,
            equippedAvatarId: DEFAULT_AVATAR_ID,
            equippedTitleId: '',
            equippedBadgeId: '',
            photoUrl,
            lastLedgerId: 'init',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });

          transaction.set(privateRef, privatePayload);

          transaction.set(leaderboardRef, {
            uid: user.uid,
            displayName,
            countryCode,
            avatarId: DEFAULT_AVATAR_ID,
            photoUrl,
            titleId: '',
            badgeId: '',
            totalEarnedPoints: 0,
            completedStages: 0,
            completedSections: 0,
            certificatesCount: 0,
            updatedAt: serverTimestamp(),
          });
          return;
        }

        const current = profileSnap.data() as UserProfile;
        const isLegacySchema = current.totalEarnedPoints === undefined;
        const effectiveDisplayName = clampString(
          current.displayName?.trim() || displayName,
          MAX_DISPLAY_NAME_LEN,
        );

        const targetTotalEarned = isLegacySchema ? current.points ?? 0 : current.totalEarnedPoints ?? 0;
        const targetCompletedStages = isLegacySchema
          ? legacyCompletedStages
          : current.completedStagesCount ?? 0;
        const targetCompletedSections = isLegacySchema
          ? legacyCompletedSections
          : current.completedSectionsCount ?? 0;
        const targetCertificates = isLegacySchema
          ? legacyCertificates
          : current.certificatesCount ?? 0;
        const targetAvatar = isLegacySchema
          ? DEFAULT_AVATAR_ID
          : current.equippedAvatarId || DEFAULT_AVATAR_ID;
        const targetTitle = isLegacySchema ? '' : current.equippedTitleId ?? '';
        const targetBadge = isLegacySchema ? '' : current.equippedBadgeId ?? '';

        if (isLegacySchema) {
          transaction.update(profileRef, {
            displayName: effectiveDisplayName,
            countryCode,
            countryNameAr,
            countryNameEn,
            preferredLang,
            photoUrl,
            totalEarnedPoints: targetTotalEarned,
            completedStagesCount: targetCompletedStages,
            completedSectionsCount: targetCompletedSections,
            certificatesCount: targetCertificates,
            equippedAvatarId: targetAvatar,
            equippedTitleId: targetTitle,
            equippedBadgeId: targetBadge,
            lastLedgerId: 'init',
            updatedAt: serverTimestamp(),
          });
        } else {
          transaction.update(profileRef, {
            displayName: effectiveDisplayName,
            countryCode,
            countryNameAr,
            countryNameEn,
            preferredLang,
            photoUrl,
            updatedAt: serverTimestamp(),
          });
        }

        if (privateSnap.exists()) {
          transaction.update(privateRef, privatePayload);
        } else {
          transaction.set(privateRef, privatePayload);
        }

        const leaderboardPayload = {
          uid: user.uid,
          displayName: effectiveDisplayName,
          countryCode,
          avatarId: targetAvatar,
          photoUrl,
          titleId: targetTitle,
          badgeId: targetBadge,
          totalEarnedPoints: targetTotalEarned,
          completedStages: targetCompletedStages,
          completedSections: targetCompletedSections,
          certificatesCount: targetCertificates,
          updatedAt: serverTimestamp(),
        };

        if (!leaderboardSnap.exists()) {
          transaction.set(leaderboardRef, leaderboardPayload);
        } else {
          transaction.update(leaderboardRef, {
            displayName: effectiveDisplayName,
            countryCode,
            avatarId: targetAvatar,
            photoUrl,
            titleId: targetTitle,
            badgeId: targetBadge,
            totalEarnedPoints: targetTotalEarned,
            completedStages: targetCompletedStages,
            completedSections: targetCompletedSections,
            certificatesCount: targetCertificates,
            updatedAt: serverTimestamp(),
          });
        }
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, profilePath);
    }

    const updated = await this.getUserProfile(user.uid);
    return (
      updated ?? {
        uid: user.uid,
        displayName,
        countryCode,
        countryNameAr,
        countryNameEn,
        preferredLang,
        points: existingProfile?.points ?? 0,
        totalEarnedPoints: existingProfile?.totalEarnedPoints ?? existingProfile?.points ?? 0,
        currentStage: existingProfile?.currentStage ?? 1,
        completedStagesCount: existingProfile?.completedStagesCount ?? legacyCompletedStages,
        completedSectionsCount: existingProfile?.completedSectionsCount ?? legacyCompletedSections,
        certificatesCount: existingProfile?.certificatesCount ?? legacyCertificates,
        equippedAvatarId: existingProfile?.equippedAvatarId ?? DEFAULT_AVATAR_ID,
        equippedTitleId: existingProfile?.equippedTitleId ?? '',
        equippedBadgeId: existingProfile?.equippedBadgeId ?? '',
        photoUrl,
        lastLedgerId: existingProfile?.lastLedgerId ?? 'init',
      }
    );
  },

  async updateCountryPreference(uid: string, country: Country, preferredLang: Language): Promise<void> {
    const profileRef = doc(db, 'users', uid);
    const leaderboardRef = doc(db, 'leaderboard', uid);
    const profilePath = `users/${uid}`;
    const countryCode = country.code.toUpperCase().slice(0, 3);
    const countryNameAr = clampString(country.nameAr, MAX_COUNTRY_NAME_LEN);
    const countryNameEn = clampString(country.nameEn, MAX_COUNTRY_NAME_LEN);

    try {
      await runTransaction(db, async (transaction) => {
        const lbSnap = await transaction.get(leaderboardRef);
        transaction.update(profileRef, {
          countryCode,
          countryNameAr,
          countryNameEn,
          preferredLang,
          updatedAt: serverTimestamp(),
        });
        if (lbSnap.exists()) {
          transaction.update(leaderboardRef, {
            countryCode,
            updatedAt: serverTimestamp(),
          });
        }
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, profilePath);
    }
  },

  async updateDisplayName(uid: string, rawName: string): Promise<string> {
    const cleanName = clampString(rawName, MAX_DISPLAY_NAME_LEN);
    if (!cleanName) {
      throw new Error('Display name cannot be empty.');
    }

    const profileRef = doc(db, 'users', uid);
    const leaderboardRef = doc(db, 'leaderboard', uid);
    const profilePath = `users/${uid}`;

    try {
      await runTransaction(db, async (transaction) => {
        const profileSnap = await transaction.get(profileRef);
        const lbSnap = await transaction.get(leaderboardRef);
        if (!profileSnap.exists()) {
          throw new Error('User profile does not exist.');
        }

        transaction.update(profileRef, {
          displayName: cleanName,
          updatedAt: serverTimestamp(),
        });

        if (lbSnap.exists()) {
          transaction.update(leaderboardRef, {
            displayName: cleanName,
            updatedAt: serverTimestamp(),
          });
        }
      });

      if (auth.currentUser && auth.currentUser.uid === uid) {
        try {
          await updateProfile(auth.currentUser, { displayName: cleanName });
        } catch {
          // Best-effort Auth profile sync; Firestore holds authoritative student name
        }
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, profilePath);
    }

    return cleanName;
  },

  async updatePreferredLanguage(uid: string, preferredLang: Language): Promise<void> {
    const profileRef = doc(db, 'users', uid);
    const profilePath = `users/${uid}`;
    try {
      await updateDoc(profileRef, {
        preferredLang,
        updatedAt: serverTimestamp(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, profilePath);
    }
  },

  async deleteUserAccountData(uid: string): Promise<void> {
    const profilePath = `users/${uid}`;
    const subcollectionsToQuery = [
      'stageProgress',
      'sectionProgress',
      'examAttempts',
      'dailyChallenges',
      'achievements',
      'purchases',
      'pointTransactions',
      'notifications',
      'bankProgress',
    ] as const;

    const subcollectionRefs: DocumentReference[] = [];

    try {
      // Collect single fixed subcollection documents if present
      const fixedDocRefs = [
        doc(db, 'users', uid, 'private', 'info'),
        doc(db, 'users', uid, 'dailyStats', 'summary'),
        doc(db, 'users', uid, 'masterCertificates', 'all-sections'),
        doc(db, 'users', uid, 'preferences', 'settings'),
        doc(db, 'users', uid, 'adaptiveProfile', 'summary'),
      ];
      const fixedSnaps = await Promise.all(fixedDocRefs.map((ref) => getDoc(ref)));
      fixedSnaps.forEach((snap) => {
        if (snap.exists()) {
          subcollectionRefs.push(snap.ref);
        }
      });

      // Query all multi-doc subcollections using owner filter
      const queryResults = await Promise.all(
        subcollectionsToQuery.map((subName) =>
          getDocs(query(collection(db, 'users', uid, subName), where('uid', '==', uid))),
        ),
      );
      for (const snap of queryResults) {
        snap.forEach((docSnap) => {
          subcollectionRefs.push(docSnap.ref);
        });
      }

      const lbRef = doc(db, 'leaderboard', uid);
      const lbSnap = await getDoc(lbRef);
      const duelStatsRef = doc(db, 'duelStats', uid);
      const duelStatsSnap = await getDoc(duelStatsRef);

      // Batch 1 MUST include /users/{uid} so !existsAfter(/users/{uid}) passes atomically
      const BATCH_LIMIT = 435;
      const firstChunk = subcollectionRefs.slice(0, BATCH_LIMIT);
      const batch1 = writeBatch(db);
      batch1.delete(doc(db, 'users', uid));
      if (lbSnap.exists()) {
        batch1.delete(lbRef);
      }
      if (duelStatsSnap.exists()) {
        batch1.delete(duelStatsRef);
      }
      for (const ref of firstChunk) {
        batch1.delete(ref);
      }
      await batch1.commit();

      // Remaining batches (if > 435 subcollection docs) also pass !existsAfter(/users/{uid})
      for (let i = BATCH_LIMIT; i < subcollectionRefs.length; i += BATCH_LIMIT) {
        const chunk = subcollectionRefs.slice(i, i + BATCH_LIMIT);
        const batch = writeBatch(db);
        for (const ref of chunk) {
          batch.delete(ref);
        }
        await batch.commit();
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, profilePath);
    }
  },
};
