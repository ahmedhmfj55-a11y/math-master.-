import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  runTransaction,
  serverTimestamp,
  where,
} from 'firebase/firestore';
import { db } from '@/src/config/firebase';
import {
  ALL_ACHIEVEMENT_AND_MEDAL_ITEMS,
  evaluateCatalogItemProgress,
} from '@/src/data/achievementsCatalog';
import { CURRICULUM_SECTIONS } from '@/src/data/curriculum';
import { handleFirestoreError, OperationType } from '@/src/services/firestoreError';
import type {
  AchievementCatalogItem,
  EarnedRecordId,
  MasterCertificateRecord,
  UserAchievementRecord,
} from '@/src/types/achievements';
import type { SectionId } from '@/src/types/curriculum';
import type { DailyStreakStatsRecord, SectionProgressRecord } from '@/src/types/progress';

function generateMasterCertId(uid: string): string {
  const uidTag = uid.slice(0, 6).toUpperCase();
  const timeTag = Date.now().toString(36).toUpperCase().slice(-5);
  return `MM-MASTER-${uidTag}-${timeTag}`.slice(0, 64);
}

export const achievementsService = {
  async loadAchievementsAndMasterCert(uid: string): Promise<{
    achievements: Partial<Record<EarnedRecordId, UserAchievementRecord>>;
    masterCertificate: MasterCertificateRecord | null;
  }> {
    const achievementsPath = `users/${uid}/achievements`;
    const masterCertPath = `users/${uid}/masterCertificates/all-sections`;

    const achievements: Partial<Record<EarnedRecordId, UserAchievementRecord>> = {};
    let masterCertificate: MasterCertificateRecord | null = null;

    try {
      const q = query(collection(db, 'users', uid, 'achievements'), where('uid', '==', uid));
      const snap = await getDocs(q);
      snap.forEach((docSnap) => {
        const data = docSnap.data() as UserAchievementRecord;
        achievements[data.achievementId] = data;
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, achievementsPath);
    }

    try {
      const masterSnap = await getDoc(doc(db, 'users', uid, 'masterCertificates', 'all-sections'));
      if (masterSnap.exists()) {
        masterCertificate = masterSnap.data() as MasterCertificateRecord;
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, masterCertPath);
    }

    return { achievements, masterCertificate };
  },

  /**
   * Synchronizes earned achievements, medals, and the all-8-sections Master Certificate
   * against verified Firestore state. Never duplicates existing records.
   */
  async syncEarnedMilestones(params: {
    uid: string;
    completedStagesCount: number;
    completedSectionsCount: number;
    certificatesCount: number;
    sectionProgressMap: Partial<Record<SectionId, SectionProgressRecord>>;
    dailyStats: DailyStreakStatsRecord | null;
    existingAchievements: Partial<Record<EarnedRecordId, UserAchievementRecord>>;
    existingMasterCertificate: MasterCertificateRecord | null;
  }): Promise<{
    newlyUnlocked: AchievementCatalogItem[];
    newlyIssuedMasterCertificate: MasterCertificateRecord | null;
  }> {
    const {
      uid,
      completedStagesCount,
      completedSectionsCount,
      certificatesCount,
      sectionProgressMap,
      dailyStats,
      existingAchievements,
      existingMasterCertificate,
    } = params;

    const candidates = ALL_ACHIEVEMENT_AND_MEDAL_ITEMS.filter((item) => {
      if (existingAchievements[item.id]) return false;
      const evalResult = evaluateCatalogItemProgress(item, {
        completedStagesCount,
        completedSectionsCount,
        certificatesCount,
        sectionProgressMap,
        dailyStats,
      });
      return evalResult.earned;
    });

    const newlyUnlocked: AchievementCatalogItem[] = [];

    for (const item of candidates) {
      const evalResult = evaluateCatalogItemProgress(item, {
        completedStagesCount,
        completedSectionsCount,
        certificatesCount,
        sectionProgressMap,
        dailyStats,
      });
      if (!evalResult.earned) continue;

      const achRef = doc(db, 'users', uid, 'achievements', item.id);
      const achPath = `users/${uid}/achievements/${item.id}`;
      try {
        const created = await runTransaction(db, async (tx) => {
          const snap = await tx.get(achRef);
          if (snap.exists()) return false;
          tx.set(achRef, {
            uid,
            achievementId: item.id,
            kind: item.kind,
            triggerRef: evalResult.triggerRef,
            unlockedAt: serverTimestamp(),
          });
          return true;
        });
        if (created) {
          newlyUnlocked.push(item);
        }
      } catch (error) {
        // Surface permission/integrity errors cleanly while keeping loop resilient
        handleFirestoreError(error, OperationType.WRITE, achPath);
      }
    }

    let newlyIssuedMasterCertificate: MasterCertificateRecord | null = null;
    const eligibleForMaster =
      !existingMasterCertificate &&
      completedSectionsCount === 8 &&
      certificatesCount === 8 &&
      CURRICULUM_SECTIONS.every((sec) => {
        const rec = sectionProgressMap[sec.id];
        return Boolean(rec && rec.completedStagesCount >= 30 && rec.examPassed);
      });

    if (eligibleForMaster) {
      const scores = CURRICULUM_SECTIONS.map(
        (sec) => sectionProgressMap[sec.id]?.examBestScore ?? 70,
      );
      const avgScore = Math.min(
        100,
        Math.max(70, Math.round(scores.reduce((sum, s) => sum + s, 0) / scores.length)),
      );
      const certId = generateMasterCertId(uid);
      const masterRef = doc(db, 'users', uid, 'masterCertificates', 'all-sections');
      const masterPath = `users/${uid}/masterCertificates/all-sections`;

      try {
        const issued = await runTransaction(db, async (tx) => {
          const snap = await tx.get(masterRef);
          if (snap.exists()) return null;
          const payload = {
            uid,
            certDocId: 'all-sections' as const,
            certificateId: certId,
            averageExamScore: avgScore,
            completedSectionsCount: 8,
            totalCompletedStages: 240,
            issuedAt: serverTimestamp(),
          };
          tx.set(masterRef, payload);
          return payload;
        });
        if (issued) {
          newlyIssuedMasterCertificate = {
            uid: issued.uid,
            certDocId: 'all-sections',
            certificateId: issued.certificateId,
            averageExamScore: issued.averageExamScore,
            completedSectionsCount: 8,
            totalCompletedStages: 240,
          };
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, masterPath);
      }
    }

    return { newlyUnlocked, newlyIssuedMasterCertificate };
  },
};
