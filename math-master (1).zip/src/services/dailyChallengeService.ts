import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  runTransaction,
  serverTimestamp,
  where,
} from 'firebase/firestore';
import { db } from '@/src/config/firebase';
import {
  DAILY_CHALLENGE_DURATION_SECONDS,
  DAILY_CHALLENGE_PASS_THRESHOLD,
  DAILY_CHALLENGE_PERFECT_BONUS_POINTS,
  DAILY_CHALLENGE_WIN_POINTS,
  buildDailyChallengeForDate,
  getPreviousDateKey,
  getTodayDateKey,
} from '@/src/data/dailyChallengeGenerator';
import { handleFirestoreError, OperationType } from '@/src/services/firestoreError';
import { storageService } from '@/src/services/storageService';
import type {
  DailyChallengeAttemptRecord,
  DailyChallengeSubmissionResult,
  DailyStreakStatsRecord,
  QuestionReviewItem,
} from '@/src/types/progress';
import type { UserProfile } from '@/src/types/user';

export const dailyChallengeService = {
  async loadDailyChallengeState(uid: string): Promise<{
    history: DailyChallengeAttemptRecord[];
    stats: DailyStreakStatsRecord | null;
  }> {
    const historyPath = `users/${uid}/dailyChallenges`;
    const statsPath = `users/${uid}/dailyStats/summary`;
    const history: DailyChallengeAttemptRecord[] = [];
    let stats: DailyStreakStatsRecord | null = null;

    try {
      const q = query(collection(db, 'users', uid, 'dailyChallenges'), where('uid', '==', uid));
      const snap = await getDocs(q);
      snap.forEach((docSnap) => {
        history.push(docSnap.data() as DailyChallengeAttemptRecord);
      });
      history.sort((a, b) => b.dateKey.localeCompare(a.dateKey));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, historyPath);
    }

    try {
      const statsSnap = await getDoc(doc(db, 'users', uid, 'dailyStats', 'summary'));
      if (statsSnap.exists()) {
        stats = statsSnap.data() as DailyStreakStatsRecord;
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, statsPath);
    }

    return { history, stats };
  },

  async submitDailyChallenge(params: {
    uid: string;
    dateKey?: string;
    selectedAnswers: number[];
    durationSeconds?: number;
    timedOut?: boolean;
  }): Promise<DailyChallengeSubmissionResult> {
    const {
      uid,
      dateKey = getTodayDateKey(),
      selectedAnswers,
      durationSeconds = 0,
      timedOut = false,
    } = params;

    const safeDuration = Math.min(
      DAILY_CHALLENGE_DURATION_SECONDS,
      Math.max(0, Math.round(durationSeconds)),
    );
    const questions = buildDailyChallengeForDate(dateKey);
    const totalQuestions = questions.length;

    const review: QuestionReviewItem[] = questions.map((q, idx) => {
      const selectedIndex = selectedAnswers[idx] ?? -1;
      const isCorrect = selectedIndex === q.correctIndex;
      return {
        questionId: q.id,
        promptAr: q.promptAr,
        promptEn: q.promptEn,
        options: q.options,
        selectedIndex,
        correctIndex: q.correctIndex,
        isCorrect,
        explanationAr: q.explanationAr,
        explanationEn: q.explanationEn,
      };
    });

    const correctCount = review.filter((item) => item.isCorrect).length;
    const wrongCount = totalQuestions - correctCount;
    const score = Math.round((correctCount / totalQuestions) * 100);
    const passed = score >= DAILY_CHALLENGE_PASS_THRESHOLD;
    const perfect = score === 100;

    const dailyWinPoints = passed ? DAILY_CHALLENGE_WIN_POINTS : 0;
    const perfectBonusPoints = perfect ? DAILY_CHALLENGE_PERFECT_BONUS_POINTS : 0;
    const pointsAwarded = dailyWinPoints + perfectBonusPoints;

    const userRef = doc(db, 'users', uid);
    const leaderboardRef = doc(db, 'leaderboard', uid);
    const dailyRef = doc(db, 'users', uid, 'dailyChallenges', dateKey);
    const statsRef = doc(db, 'users', uid, 'dailyStats', 'summary');
    const txPath = `users/${uid}/dailyChallenges/${dateKey}`;

    let updatedStats: DailyStreakStatsRecord = {
      uid,
      currentStreak: passed ? 1 : 0,
      longestStreak: passed ? 1 : 0,
      totalDailyCompleted: passed ? 1 : 0,
      totalDailyAttempted: 1,
      lastWonDate: passed ? dateKey : '',
      lastAttemptDate: dateKey,
      badge7Unlocked: false,
      badge30Unlocked: false,
    };
    let newlyUnlockedBadge7 = false;
    let newlyUnlockedBadge30 = false;

    try {
      await runTransaction(db, async (transaction) => {
        const userSnap = await transaction.get(userRef);
        const lbSnap = await transaction.get(leaderboardRef);
        const dailySnap = await transaction.get(dailyRef);
        const statsSnap = await transaction.get(statsRef);

        if (!userSnap.exists()) {
          throw new Error('User profile does not exist.');
        }

        if (dailySnap.exists()) {
          throw new Error('Daily Challenge for this date has already been completed.');
        }

        const userData = userSnap.data() as UserProfile;
        const prevStats = statsSnap.exists()
          ? (statsSnap.data() as DailyStreakStatsRecord)
          : null;

        // Calculate consecutive calendar streak strictly without double-counting the same day
        const prevDateKey = getPreviousDateKey(dateKey);
        let nextCurrentStreak = 0;
        let nextLastWonDate = prevStats?.lastWonDate ?? '';

        if (passed) {
          if (prevStats && prevStats.lastWonDate === dateKey) {
            nextCurrentStreak = prevStats.currentStreak;
          } else if (prevStats && prevStats.lastWonDate === prevDateKey) {
            nextCurrentStreak = (prevStats.currentStreak ?? 0) + 1;
          } else {
            nextCurrentStreak = 1;
          }
          nextLastWonDate = dateKey;
        } else {
          // If the learner fails today, streak resets to 0
          nextCurrentStreak = 0;
        }

        const prevLongest = prevStats?.longestStreak ?? 0;
        const nextLongestStreak = Math.max(prevLongest, nextCurrentStreak);
        const nextTotalCompleted = (prevStats?.totalDailyCompleted ?? 0) + (passed ? 1 : 0);
        const nextTotalAttempted = (prevStats?.totalDailyAttempted ?? 0) + 1;

        const prevBadge7 = prevStats?.badge7Unlocked ?? false;
        const prevBadge30 = prevStats?.badge30Unlocked ?? false;
        const nextBadge7 = prevBadge7 || nextLongestStreak >= 7;
        const nextBadge30 = prevBadge30 || nextLongestStreak >= 30;

        newlyUnlockedBadge7 = !prevBadge7 && nextBadge7;
        newlyUnlockedBadge30 = !prevBadge30 && nextBadge30;

        updatedStats = {
          uid,
          currentStreak: nextCurrentStreak,
          longestStreak: nextLongestStreak,
          totalDailyCompleted: nextTotalCompleted,
          totalDailyAttempted: nextTotalAttempted,
          lastWonDate: nextLastWonDate,
          lastAttemptDate: dateKey,
          badge7Unlocked: nextBadge7,
          badge30Unlocked: nextBadge30,
        };

        // 1. Write immutable dailyChallenges/{dateKey}
        transaction.set(dailyRef, {
          uid,
          dateKey,
          score,
          correctCount,
          wrongCount,
          passed,
          perfect,
          durationSeconds: safeDuration,
          pointsAwarded,
          timedOut,
          submittedAt: serverTimestamp(),
        });

        // 2. Write or update dailyStats/summary
        if (!statsSnap.exists()) {
          transaction.set(statsRef, {
            ...updatedStats,
            updatedAt: serverTimestamp(),
          });
        } else {
          transaction.update(statsRef, {
            ...updatedStats,
            updatedAt: serverTimestamp(),
          });
        }

        // 3. Grant points + immutable pointTransactions + update users/{uid} & leaderboard/{uid}
        if (pointsAwarded > 0) {
          const prevPoints = userData.points ?? 0;
          const prevTotalEarned = userData.totalEarnedPoints ?? prevPoints;
          let runningBalance = prevPoints;
          let primaryLedgerId = '';

          if (dailyWinPoints > 0) {
            const winTxId = `daily-win-${dateKey}`;
            runningBalance += dailyWinPoints;
            primaryLedgerId = winTxId;
            transaction.set(doc(db, 'users', uid, 'pointTransactions', winTxId), {
              uid,
              txId: winTxId,
              type: 'daily_win',
              refId: dateKey,
              amount: dailyWinPoints,
              balanceAfter: runningBalance,
              createdAt: serverTimestamp(),
            });
          }

          if (perfectBonusPoints > 0) {
            const perfectTxId = `daily-perfect-${dateKey}`;
            runningBalance += perfectBonusPoints;
            primaryLedgerId = perfectTxId;
            transaction.set(doc(db, 'users', uid, 'pointTransactions', perfectTxId), {
              uid,
              txId: perfectTxId,
              type: 'daily_perfect',
              refId: dateKey,
              amount: perfectBonusPoints,
              balanceAfter: runningBalance,
              createdAt: serverTimestamp(),
            });
          }

          const newPoints = prevPoints + pointsAwarded;
          const newTotalEarned = prevTotalEarned + pointsAwarded;

          transaction.update(userRef, {
            points: newPoints,
            totalEarnedPoints: newTotalEarned,
            currentStage: userData.currentStage ?? 1,
            completedStagesCount: userData.completedStagesCount ?? 0,
            completedSectionsCount: userData.completedSectionsCount ?? 0,
            certificatesCount: userData.certificatesCount ?? 0,
            lastLedgerId: primaryLedgerId,
            updatedAt: serverTimestamp(),
          });

          if (lbSnap.exists()) {
            transaction.update(leaderboardRef, {
              totalEarnedPoints: newTotalEarned,
              updatedAt: serverTimestamp(),
            });
          }
        }
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, txPath);
    }

    storageService.clearDailyDraft(uid, dateKey);
    storageService.saveDailyCompletedAnswers(uid, dateKey, selectedAnswers);

    return {
      dateKey,
      score,
      correctCount,
      wrongCount,
      totalQuestions,
      passed,
      perfect,
      pointsAwarded,
      dailyWinPoints,
      perfectBonusPoints,
      durationSeconds: safeDuration,
      timedOut,
      streakStats: updatedStats,
      newlyUnlockedBadge7,
      newlyUnlockedBadge30,
      review,
    };
  },
};
