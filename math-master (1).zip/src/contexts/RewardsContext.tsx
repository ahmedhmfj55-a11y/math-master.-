import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import { useAuth } from '@/src/contexts/AuthContext';
import { rewardsService } from '@/src/services/rewardsService';
import type {
  PointTransactionRecord,
  RewardCategory,
  RewardPurchaseRecord,
} from '@/src/types/rewards';

interface RewardsContextValue {
  purchases: RewardPurchaseRecord[];
  ownedItemIds: Set<string>;
  transactions: PointTransactionRecord[];
  loadingRewards: boolean;
  processingItemId: string | null;
  refreshRewards: () => Promise<void>;
  purchaseReward: (itemId: string) => Promise<void>;
  equipReward: (category: RewardCategory, itemId: string) => Promise<void>;
}

const RewardsContext = createContext<RewardsContextValue | null>(null);

export function RewardsProvider({ children }: { children: ReactNode }) {
  const { firebaseUser, userProfile, refreshUserProfile } = useAuth();
  const [purchases, setPurchases] = useState<RewardPurchaseRecord[]>([]);
  const [transactions, setTransactions] = useState<PointTransactionRecord[]>([]);
  const [loadingRewards, setLoadingRewards] = useState(false);
  const [processingItemId, setProcessingItemId] = useState<string | null>(null);

  const refreshRewards = useCallback(async () => {
    if (!firebaseUser || !userProfile) {
      setPurchases([]);
      setTransactions([]);
      return;
    }
    setLoadingRewards(true);
    try {
      const [loadedPurchases, loadedTx] = await Promise.all([
        rewardsService.loadOwnedRewards(firebaseUser.uid),
        rewardsService.loadPointTransactions(firebaseUser.uid),
      ]);
      setPurchases(loadedPurchases);
      setTransactions(loadedTx);
    } catch (error) {
      console.error('Failed to load rewards and transactions:', error);
    } finally {
      setLoadingRewards(false);
    }
  }, [firebaseUser, userProfile]);

  useEffect(() => {
    void refreshRewards();
  }, [refreshRewards]);

  const ownedItemIds = useMemo(
    () => new Set(purchases.map((p) => p.itemId)),
    [purchases],
  );

  const purchaseReward = useCallback(
    async (itemId: string) => {
      if (!firebaseUser) return;
      setProcessingItemId(itemId);
      try {
        await rewardsService.purchaseReward(firebaseUser.uid, itemId);
        await Promise.all([refreshUserProfile(), refreshRewards()]);
      } finally {
        setProcessingItemId(null);
      }
    },
    [firebaseUser, refreshUserProfile, refreshRewards],
  );

  const equipReward = useCallback(
    async (category: RewardCategory, itemId: string) => {
      if (!firebaseUser) return;
      setProcessingItemId(itemId || `clear-${category}`);
      try {
        await rewardsService.equipReward(firebaseUser.uid, category, itemId);
        await refreshUserProfile();
      } finally {
        setProcessingItemId(null);
      }
    },
    [firebaseUser, refreshUserProfile],
  );

  const value = useMemo<RewardsContextValue>(
    () => ({
      purchases,
      ownedItemIds,
      transactions,
      loadingRewards,
      processingItemId,
      refreshRewards,
      purchaseReward,
      equipReward,
    }),
    [
      purchases,
      ownedItemIds,
      transactions,
      loadingRewards,
      processingItemId,
      refreshRewards,
      purchaseReward,
      equipReward,
    ],
  );

  return <RewardsContext.Provider value={value}>{children}</RewardsContext.Provider>;
}

export function useRewards(): RewardsContextValue {
  const ctx = useContext(RewardsContext);
  if (!ctx) {
    throw new Error('useRewards must be used within a RewardsProvider');
  }
  return ctx;
}
