import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import { useAuth } from '@/src/contexts/AuthContext';
import { useNotifications } from '@/src/contexts/NotificationsContext';
import {
  BANK_DIFFICULTY_TIERS,
  getGradeById,
  getPreviousTier,
  getTierMeta,
} from '@/src/data/questionBank/catalog';
import { makeBankKey } from '@/src/data/questionBank/bankEngine';
import { questionBankService } from '@/src/services/questionBankService';
import type {
  AdaptiveProfileSummary,
  BankDifficultyTier,
  BankQuestion,
  BankQuizSubmissionResult,
  BankTierProgressRecord,
  GeniusChallengeItem,
  GradeId,
} from '@/src/types/questionBank';

interface QuestionBankContextValue {
  bankProgressMap: Record<string, BankTierProgressRecord>;
  adaptiveProfile: AdaptiveProfileSummary | null;
  loadingBank: boolean;
  submittingBank: boolean;
  refreshBankState: () => Promise<void>;
  getTierProgress: (gradeId: GradeId, tier: BankDifficultyTier) => BankTierProgressRecord | null;
  isBankTierUnlocked: (gradeId: GradeId, tier: BankDifficultyTier) => boolean;
  getGradeMasteredTiersCount: (gradeId: GradeId) => number;
  getGeniusProgress: (challengeId: string) => BankTierProgressRecord | null;
  submitBankQuiz: (params: {
    gradeId: GradeId;
    tier: BankDifficultyTier;
    questions: BankQuestion[];
    answers: ({ selectedIndex?: number; writtenValue?: string } | undefined)[];
  }) => Promise<BankQuizSubmissionResult>;
  submitGeniusChallenge: (params: {
    challenge: GeniusChallengeItem;
    answer: { selectedIndex?: number; writtenValue?: string };
  }) => Promise<{
    isCorrect: boolean;
    newlySolved: boolean;
    pointsAwarded: number;
    rewardAlreadyClaimed: boolean;
    userAnswerDisplay: string;
  }>;
}

const QuestionBankContext = createContext<QuestionBankContextValue | null>(null);

export function QuestionBankProvider({ children }: { children: ReactNode }) {
  const { firebaseUser, userProfile, refreshUserProfile } = useAuth();
  const { emitNotification } = useNotifications();
  const [bankProgressMap, setBankProgressMap] = useState<Record<string, BankTierProgressRecord>>({});
  const [adaptiveProfile, setAdaptiveProfile] = useState<AdaptiveProfileSummary | null>(null);
  const [loadingBank, setLoadingBank] = useState(false);
  const [submittingBank, setSubmittingBank] = useState(false);

  const syncBankState = useCallback(async (uid: string) => {
    const res = await questionBankService.loadQuestionBankState(uid);
    setBankProgressMap(res.bankProgressMap);
    setAdaptiveProfile(res.adaptiveProfile);
  }, []);

  const refreshBankState = useCallback(async () => {
    if (!firebaseUser || !userProfile) {
      setBankProgressMap({});
      setAdaptiveProfile(null);
      return;
    }
    setLoadingBank(true);
    try {
      await syncBankState(firebaseUser.uid);
    } catch (error) {
      console.error('Failed to load question bank state:', error);
    } finally {
      setLoadingBank(false);
    }
  }, [firebaseUser, userProfile, syncBankState]);

  useEffect(() => {
    void refreshBankState();
  }, [refreshBankState]);

  const getTierProgress = useCallback(
    (gradeId: GradeId, tier: BankDifficultyTier): BankTierProgressRecord | null => {
      return bankProgressMap[makeBankKey(gradeId, tier)] ?? null;
    },
    [bankProgressMap],
  );

  const isBankTierUnlocked = useCallback(
    (gradeId: GradeId, tier: BankDifficultyTier): boolean => {
      const prev = getPreviousTier(tier);
      if (!prev) return true;
      return Boolean(bankProgressMap[makeBankKey(gradeId, prev)]?.mastered);
    },
    [bankProgressMap],
  );

  const getGradeMasteredTiersCount = useCallback(
    (gradeId: GradeId): number => {
      return BANK_DIFFICULTY_TIERS.filter(
        (t) => bankProgressMap[makeBankKey(gradeId, t.id)]?.mastered,
      ).length;
    },
    [bankProgressMap],
  );

  const getGeniusProgress = useCallback(
    (challengeId: string): BankTierProgressRecord | null => {
      const bankKey = challengeId.startsWith('genius-') ? challengeId : `genius-${challengeId}`;
      return bankProgressMap[bankKey] ?? null;
    },
    [bankProgressMap],
  );

  const submitBankQuiz = useCallback(
    async (params: {
      gradeId: GradeId;
      tier: BankDifficultyTier;
      questions: BankQuestion[];
      answers: ({ selectedIndex?: number; writtenValue?: string } | undefined)[];
    }): Promise<BankQuizSubmissionResult> => {
      if (!firebaseUser) {
        throw new Error('Authentication required to submit question bank quiz.');
      }
      setSubmittingBank(true);
      try {
        const result = await questionBankService.submitBankQuizAttempt({
          uid: firebaseUser.uid,
          ...params,
        });
        await syncBankState(firebaseUser.uid);
        if (result.pointsAwarded > 0) {
          await refreshUserProfile();
        }

        if (result.newlyMastered) {
          const grade = getGradeById(params.gradeId);
          const tierMeta = getTierMeta(params.tier);
          void emitNotification({
            id: `bank-tier-${result.bankKey}`,
            type: result.pointsAwarded > 0 ? 'points_earned' : 'new_challenges',
            titleAr: `إتقان مستوى ${tierMeta.titleAr} — ${grade?.titleAr ?? params.gradeId}`,
            titleEn: `Mastered ${tierMeta.titleEn} — ${grade?.titleEn ?? params.gradeId}`,
            bodyAr: `حققت ${result.score}/100 في بنك الأسئلة العالمي وحصلت على +${result.pointsAwarded} نقطة.`,
            bodyEn: `Scored ${result.score}/100 in the Global Question Bank and earned +${result.pointsAwarded} pts.`,
            refId: result.bankKey,
            targetScreen: 'question-bank',
          });
        }
        return result;
      } finally {
        setSubmittingBank(false);
      }
    },
    [firebaseUser, syncBankState, refreshUserProfile, emitNotification],
  );

  const submitGeniusChallenge = useCallback(
    async (params: {
      challenge: GeniusChallengeItem;
      answer: { selectedIndex?: number; writtenValue?: string };
    }) => {
      if (!firebaseUser) {
        throw new Error('Authentication required to submit genius challenge.');
      }
      setSubmittingBank(true);
      try {
        const result = await questionBankService.submitGeniusChallengeAttempt({
          uid: firebaseUser.uid,
          challenge: params.challenge,
          answer: params.answer,
        });
        await syncBankState(firebaseUser.uid);
        if (result.pointsAwarded > 0) {
          await refreshUserProfile();
          void emitNotification({
            id: `genius-win-${params.challenge.id}`.slice(0, 80),
            type: 'points_earned',
            titleAr: `حللت تحدي العباقرة: ${params.challenge.titleAr}`,
            titleEn: `Genius Challenge Solved: ${params.challenge.titleEn}`,
            bodyAr: `أحسنت! أضيفت +${result.pointsAwarded} نقطة إلى رصيدك وتصنيفك العالمي.`,
            bodyEn: `Brilliant solution! +${result.pointsAwarded} points added to your global rank.`,
            refId: params.challenge.id.slice(0, 64),
            targetScreen: 'genius-challenges',
          });
        }
        return result;
      } finally {
        setSubmittingBank(false);
      }
    },
    [firebaseUser, syncBankState, refreshUserProfile, emitNotification],
  );

  const value = useMemo<QuestionBankContextValue>(
    () => ({
      bankProgressMap,
      adaptiveProfile,
      loadingBank,
      submittingBank,
      refreshBankState,
      getTierProgress,
      isBankTierUnlocked,
      getGradeMasteredTiersCount,
      getGeniusProgress,
      submitBankQuiz,
      submitGeniusChallenge,
    }),
    [
      bankProgressMap,
      adaptiveProfile,
      loadingBank,
      submittingBank,
      refreshBankState,
      getTierProgress,
      isBankTierUnlocked,
      getGradeMasteredTiersCount,
      getGeniusProgress,
      submitBankQuiz,
      submitGeniusChallenge,
    ],
  );

  return <QuestionBankContext.Provider value={value}>{children}</QuestionBankContext.Provider>;
}

export function useQuestionBank(): QuestionBankContextValue {
  const ctx = useContext(QuestionBankContext);
  if (!ctx) {
    throw new Error('useQuestionBank must be used within a QuestionBankProvider');
  }
  return ctx;
}
