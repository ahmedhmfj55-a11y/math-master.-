import { onAuthStateChanged, type User } from 'firebase/auth';
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import { auth } from '@/src/config/firebase';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { findCountryByCode } from '@/src/data/countries';
import { authService } from '@/src/services/authService';
import { storageService } from '@/src/services/storageService';
import { userService } from '@/src/services/userService';
import type { Country } from '@/src/types/country';
import type { Language } from '@/src/types/i18n';
import type { UserProfile } from '@/src/types/user';

interface AuthContextValue {
  authReady: boolean;
  firebaseUser: User | null;
  userProfile: UserProfile | null;
  profileSyncing: boolean;
  selectedCountry: Country | null;
  selectCountry: (country: Country) => Promise<void>;
  updateDisplayName: (newName: string) => Promise<void>;
  syncPreferredLanguage: (lang: Language) => Promise<void>;
  deleteAccount: () => Promise<void>;
  refreshUserProfile: () => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const { language, setLanguage } = useLanguage();
  const [authReady, setAuthReady] = useState(false);
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [profileSyncing, setProfileSyncing] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState<Country | null>(() =>
    findCountryByCode(storageService.getSelectedCountryCode()),
  );
  const languageRef = useRef<Language>(language);

  useEffect(() => {
    languageRef.current = language;
  }, [language]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      if (!user) {
        setUserProfile(null);
        setAuthReady(true);
        return;
      }

      setProfileSyncing(true);
      try {
        const activeLang = languageRef.current;
        const storedCountry = findCountryByCode(storageService.getSelectedCountryCode());
        const existingProfile = await userService.getUserProfile(user.uid);

        if (storedCountry) {
          const synced = await userService.syncAuthenticatedUser(user, storedCountry, activeLang);
          setUserProfile(synced);
        } else if (existingProfile) {
          setUserProfile(existingProfile);
          const profileCountry = findCountryByCode(existingProfile.countryCode);
          if (profileCountry) {
            setSelectedCountry(profileCountry);
            storageService.setSelectedCountryCode(profileCountry.code);
          }
        } else {
          // Fallback only if user authenticated without visiting country picker first
          const defaultCountry = findCountryByCode('SA')!;
          setSelectedCountry(defaultCountry);
          storageService.setSelectedCountryCode(defaultCountry.code);
          const synced = await userService.syncAuthenticatedUser(user, defaultCountry, activeLang);
          setUserProfile(synced);
        }
      } catch (error) {
        console.error('Failed to synchronize user profile:', error);
      } finally {
        setProfileSyncing(false);
        setAuthReady(true);
      }
    });

    return () => unsubscribe();
  }, []);

  const selectCountry = useCallback(
    async (country: Country) => {
      setSelectedCountry(country);
      storageService.setSelectedCountryCode(country.code);
      if (firebaseUser) {
        setProfileSyncing(true);
        try {
          await userService.updateCountryPreference(firebaseUser.uid, country, language);
          const updated = await userService.getUserProfile(firebaseUser.uid);
          if (updated) {
            setUserProfile(updated);
          }
        } finally {
          setProfileSyncing(false);
        }
      }
    },
    [firebaseUser, language],
  );

  const updateDisplayName = useCallback(
    async (newName: string) => {
      if (!firebaseUser) return;
      setProfileSyncing(true);
      try {
        const updatedName = await userService.updateDisplayName(firebaseUser.uid, newName);
        setUserProfile((prev) => (prev ? { ...prev, displayName: updatedName } : prev));
      } finally {
        setProfileSyncing(false);
      }
    },
    [firebaseUser],
  );

  const syncPreferredLanguage = useCallback(
    async (lang: Language) => {
      setLanguage(lang);
      if (!firebaseUser) return;
      try {
        await userService.updatePreferredLanguage(firebaseUser.uid, lang);
        setUserProfile((prev) => (prev ? { ...prev, preferredLang: lang } : prev));
      } catch {
        // Local storage already persisted; ignore transient Firestore sync failure
      }
    },
    [firebaseUser, setLanguage],
  );

  const deleteAccount = useCallback(async () => {
    if (!firebaseUser) return;
    const uid = firebaseUser.uid;
    setProfileSyncing(true);
    try {
      // 1. Ensure fresh auth session BEFORE touching any Firestore documents
      await authService.prepareAccountDeletionReauth(firebaseUser, language);
      // 2. Atomically delete /users/{uid}, /leaderboard/{uid}, and all subcollections
      await userService.deleteUserAccountData(uid);
      // 3. Clear local drafts/caches and delete Firebase Auth user
      storageService.clearUserLocalData(uid);
      await authService.deleteCurrentAuthUser(firebaseUser);
      setUserProfile(null);
      setSelectedCountry(null);
    } finally {
      setProfileSyncing(false);
    }
  }, [firebaseUser, language]);

  const refreshUserProfile = useCallback(async () => {
    if (!firebaseUser) return;
    setProfileSyncing(true);
    try {
      const country = selectedCountry ?? findCountryByCode('SA')!;
      const synced = await userService.syncAuthenticatedUser(firebaseUser, country, language);
      setUserProfile(synced);
    } finally {
      setProfileSyncing(false);
    }
  }, [firebaseUser, selectedCountry, language]);

  const signOut = useCallback(async () => {
    await authService.logout();
    setUserProfile(null);
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({
      authReady,
      firebaseUser,
      userProfile,
      profileSyncing,
      selectedCountry,
      selectCountry,
      updateDisplayName,
      syncPreferredLanguage,
      deleteAccount,
      refreshUserProfile,
      signOut,
    }),
    [
      authReady,
      firebaseUser,
      userProfile,
      profileSyncing,
      selectedCountry,
      selectCountry,
      updateDisplayName,
      syncPreferredLanguage,
      deleteAccount,
      refreshUserProfile,
      signOut,
    ],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used within a LanguageProvider / AuthProvider');
  }
  return ctx;
}
