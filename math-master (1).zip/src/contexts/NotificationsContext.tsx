import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import { useAuth } from '@/src/contexts/AuthContext';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useTheme } from '@/src/contexts/ThemeContext';
import { notificationsService } from '@/src/services/notificationsService';
import {
  DEFAULT_USER_PREFERENCES,
  type CreateNotificationInput,
  type NotificationType,
  type ThemeMode,
  type UserNotificationRecord,
  type UserPreferencesRecord,
} from '@/src/types/notifications';

export type BrowserPushPermission = 'default' | 'granted' | 'denied' | 'unsupported';

interface NotificationsContextValue {
  notifications: UserNotificationRecord[];
  unreadCount: number;
  loadingNotifications: boolean;
  preferences: Omit<UserPreferencesRecord, 'uid' | 'updatedAt'>;
  pushPermissionState: BrowserPushPermission;
  emitNotification: (input: CreateNotificationInput) => Promise<void>;
  markAsRead: (notificationId: string) => Promise<void>;
  markAllAsRead: () => Promise<void>;
  deleteNotification: (notificationId: string) => Promise<void>;
  updatePreferences: (
    patch: Partial<Omit<UserPreferencesRecord, 'uid' | 'updatedAt'>>,
  ) => Promise<void>;
  syncThemePreference: (mode: ThemeMode) => Promise<void>;
  requestPushPermission: () => Promise<BrowserPushPermission>;
  evaluateRankProgress: (currentRank: number | null) => Promise<void>;
}

const NotificationsContext = createContext<NotificationsContextValue | null>(null);

function readPushPermission(): BrowserPushPermission {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }
  return Notification.permission as BrowserPushPermission;
}

function isTypeAllowedByPrefs(
  type: NotificationType,
  prefs: Omit<UserPreferencesRecord, 'uid' | 'updatedAt'>,
): boolean {
  if (!prefs.notificationsEnabled) return false;
  switch (type) {
    case 'daily_reminder':
      return prefs.notifyDailyReminder;
    case 'stage_unlock':
      return prefs.notifyStageUnlock;
    case 'stage_win':
    case 'points_earned':
      return prefs.notifyStageWinPoints;
    case 'medal_earned':
    case 'certificate_earned':
      return prefs.notifyMedalsCerts;
    case 'exam_pass':
    case 'new_challenges':
      return prefs.notifyExamsChallenges;
    case 'rank_up':
      return prefs.notifyRankUp;
  }
}

export function NotificationsProvider({ children }: { children: ReactNode }) {
  const { firebaseUser, userProfile } = useAuth();
  const { language } = useLanguage();
  const { setThemeMode } = useTheme();

  const [notifications, setNotifications] = useState<UserNotificationRecord[]>([]);
  const [loadingNotifications, setLoadingNotifications] = useState(false);
  const [preferences, setPreferences] = useState<Omit<UserPreferencesRecord, 'uid' | 'updatedAt'>>(
    DEFAULT_USER_PREFERENCES,
  );
  const [pushPermissionState, setPushPermissionState] = useState<BrowserPushPermission>(() =>
    readPushPermission(),
  );

  const prefsRef = useRef(preferences);
  const langRef = useRef(language);
  const rankEvalBusyRef = useRef(false);

  useEffect(() => {
    prefsRef.current = preferences;
  }, [preferences]);

  useEffect(() => {
    langRef.current = language;
  }, [language]);

  // Subscribe to real-time owner notifications & load saved preferences
  useEffect(() => {
    if (!firebaseUser || !userProfile) {
      setNotifications([]);
      setPreferences(DEFAULT_USER_PREFERENCES);
      setLoadingNotifications(false);
      return;
    }

    const uid = firebaseUser.uid;
    setLoadingNotifications(true);

    let cancelled = false;
    void notificationsService
      .loadPreferences(uid)
      .then((loaded) => {
        if (cancelled) return;
        const { uid: _uid, updatedAt: _ts, ...rest } = loaded;
        setPreferences(rest);
        setThemeMode(rest.themeMode);
      })
      .catch(() => {
        // Keep local defaults on transient load failure
      });

    const unsubscribe = notificationsService.subscribeNotifications(
      uid,
      (items) => {
        setNotifications(items);
        setLoadingNotifications(false);
      },
      () => {
        setLoadingNotifications(false);
      },
    );

    return () => {
      cancelled = true;
      unsubscribe();
    };
  }, [firebaseUser, userProfile, setThemeMode]);

  const dispatchSystemAlertIfEnabled = useCallback((input: CreateNotificationInput) => {
    if (!prefsRef.current.pushAlertsEnabled) return;
    if (typeof window === 'undefined' || !('Notification' in window)) return;
    if (Notification.permission !== 'granted') return;

    try {
      const lang = langRef.current;
      new Notification(lang === 'ar' ? input.titleAr : input.titleEn, {
        body: lang === 'ar' ? input.bodyAr : input.bodyEn,
        tag: input.id,
      });
    } catch {
      // Safe fallback inside Android WebView / restricted iframes
    }
  }, []);

  const emitNotification = useCallback(
    async (input: CreateNotificationInput) => {
      if (!firebaseUser || !userProfile) return;
      if (!isTypeAllowedByPrefs(input.type, prefsRef.current)) return;

      try {
        const created = await notificationsService.createNotificationIfAbsent(
          firebaseUser.uid,
          input,
        );
        if (created) {
          dispatchSystemAlertIfEnabled(input);
        }
      } catch {
        // Non-blocking notification failure should never break primary gameplay action
      }
    },
    [firebaseUser, userProfile, dispatchSystemAlertIfEnabled],
  );

  const markAsRead = useCallback(
    async (notificationId: string) => {
      if (!firebaseUser) return;
      setNotifications((prev) =>
        prev.map((item) => (item.id === notificationId ? { ...item, read: true } : item)),
      );
      await notificationsService.markAsRead(firebaseUser.uid, notificationId);
    },
    [firebaseUser],
  );

  const markAllAsRead = useCallback(async () => {
    if (!firebaseUser) return;
    const unreadIds = notifications.filter((n) => !n.read).map((n) => n.id);
    if (unreadIds.length === 0) return;
    setNotifications((prev) => prev.map((item) => ({ ...item, read: true })));
    await notificationsService.markAllAsRead(firebaseUser.uid, unreadIds);
  }, [firebaseUser, notifications]);

  const deleteNotification = useCallback(
    async (notificationId: string) => {
      if (!firebaseUser) return;
      setNotifications((prev) => prev.filter((item) => item.id !== notificationId));
      await notificationsService.deleteNotification(firebaseUser.uid, notificationId);
    },
    [firebaseUser],
  );

  const updatePreferences = useCallback(
    async (patch: Partial<Omit<UserPreferencesRecord, 'uid' | 'updatedAt'>>) => {
      const nextLocal = { ...prefsRef.current, ...patch };
      setPreferences(nextLocal);
      prefsRef.current = nextLocal;

      if (patch.themeMode) {
        setThemeMode(patch.themeMode);
      }

      if (!firebaseUser || !userProfile) return;
      try {
        const saved = await notificationsService.savePreferences(firebaseUser.uid, patch);
        const { uid: _uid, updatedAt: _ts, ...rest } = saved;
        setPreferences(rest);
        prefsRef.current = rest;
      } catch {
        // Ignore transient sync error
      }
    },
    [firebaseUser, userProfile, setThemeMode],
  );

  const syncThemePreference = useCallback(
    async (mode: ThemeMode) => {
      setThemeMode(mode);
      await updatePreferences({ themeMode: mode });
    },
    [setThemeMode, updatePreferences],
  );

  const requestPushPermission = useCallback(async (): Promise<BrowserPushPermission> => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      setPushPermissionState('unsupported');
      return 'unsupported';
    }
    try {
      const res = await Notification.requestPermission();
      const mapped = res as BrowserPushPermission;
      setPushPermissionState(mapped);
      if (mapped === 'granted') {
        await updatePreferences({ pushAlertsEnabled: true });
      } else {
        await updatePreferences({ pushAlertsEnabled: false });
      }
      return mapped;
    } catch {
      setPushPermissionState('unsupported');
      return 'unsupported';
    }
  }, [updatePreferences]);

  const evaluateRankProgress = useCallback(
    async (currentRank: number | null) => {
      if (!firebaseUser || !userProfile || !currentRank || currentRank <= 0) return;
      if (rankEvalBusyRef.current) return;
      const previousBest = prefsRef.current.bestGlobalRank;
      if (previousBest === 0) {
        rankEvalBusyRef.current = true;
        try {
          await updatePreferences({ bestGlobalRank: currentRank });
        } finally {
          rankEvalBusyRef.current = false;
        }
        return;
      }

      if (currentRank < previousBest) {
        rankEvalBusyRef.current = true;
        try {
          await updatePreferences({ bestGlobalRank: currentRank });
          await emitNotification({
            id: `rank-up-r${currentRank}`,
            type: 'rank_up',
            titleAr: `تقدمت إلى المركز #${currentRank} عالمياً!`,
            titleEn: `Climbed to Global Rank #${currentRank}!`,
            bodyAr: `أحسنت! ارتفع ترتيبك العالمي من المركز #${previousBest} إلى #${currentRank}.`,
            bodyEn: `Well done! Your global leaderboard rank improved from #${previousBest} to #${currentRank}.`,
            refId: `rank-${currentRank}`,
            targetScreen: 'leaderboard',
          });
        } finally {
          rankEvalBusyRef.current = false;
        }
      }
    },
    [firebaseUser, userProfile, updatePreferences, emitNotification],
  );

  const unreadCount = useMemo(
    () => notifications.filter((item) => !item.read).length,
    [notifications],
  );

  const value = useMemo<NotificationsContextValue>(
    () => ({
      notifications,
      unreadCount,
      loadingNotifications,
      preferences,
      pushPermissionState,
      emitNotification,
      markAsRead,
      markAllAsRead,
      deleteNotification,
      updatePreferences,
      syncThemePreference,
      requestPushPermission,
      evaluateRankProgress,
    }),
    [
      notifications,
      unreadCount,
      loadingNotifications,
      preferences,
      pushPermissionState,
      emitNotification,
      markAsRead,
      markAllAsRead,
      deleteNotification,
      updatePreferences,
      syncThemePreference,
      requestPushPermission,
      evaluateRankProgress,
    ],
  );

  return (
    <NotificationsContext.Provider value={value}>{children}</NotificationsContext.Provider>
  );
}

export function useNotifications(): NotificationsContextValue {
  const ctx = useContext(NotificationsContext);
  if (!ctx) {
    throw new Error('useNotifications must be used within a NotificationsProvider');
  }
  return ctx;
}
