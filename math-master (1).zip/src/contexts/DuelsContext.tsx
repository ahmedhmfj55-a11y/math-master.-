import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import { useAuth } from '@/src/contexts/AuthContext';
import { useNotifications } from '@/src/contexts/NotificationsContext';
import { getSectionById } from '@/src/data/curriculum';
import { duelsService } from '@/src/services/duelsService';
import type { SectionId } from '@/src/types/curriculum';
import {
  DUEL_DRAW_POINTS,
  DUEL_PARTICIPATION_POINTS,
  DUEL_WIN_POINTS,
  type DuelCompetitorStatsRecord,
  type DuelDurationSeconds,
  type DuelMatchRecord,
  type DuelQuestionCount,
} from '@/src/types/duels';
import type { LeaderboardEntry } from '@/src/types/rewards';

interface DuelsContextValue {
  duels: DuelMatchRecord[];
  incomingInvites: DuelMatchRecord[];
  sentInvites: DuelMatchRecord[];
  activeDuels: DuelMatchRecord[];
  completedDuels: DuelMatchRecord[];
  pendingActionCount: number;
  topCompetitors: DuelCompetitorStatsRecord[];
  candidateOpponents: LeaderboardEntry[];
  loadingDuels: boolean;
  loadingCandidates: boolean;
  loadCandidateOpponents: () => Promise<void>;
  createDuel: (params: {
    opponent: LeaderboardEntry;
    sectionId: SectionId;
    questionCount: DuelQuestionCount;
    durationSeconds: DuelDurationSeconds;
  }) => Promise<string>;
  respondToDuel: (duelId: string, action: 'active' | 'declined' | 'cancelled') => Promise<void>;
  submitDuelAnswers: (params: {
    duelId: string;
    selectedAnswers: number[];
    durationSeconds: number;
  }) => Promise<{
    correctCount: number;
    score: number;
    matchCompleted: boolean;
    winnerUid: string;
  }>;
}

const DuelsContext = createContext<DuelsContextValue | null>(null);

export function DuelsProvider({ children }: { children: ReactNode }) {
  const { firebaseUser, userProfile, refreshUserProfile } = useAuth();
  const { emitNotification } = useNotifications();

  const [duels, setDuels] = useState<DuelMatchRecord[]>([]);
  const [topCompetitors, setTopCompetitors] = useState<DuelCompetitorStatsRecord[]>([]);
  const [candidateOpponents, setCandidateOpponents] = useState<LeaderboardEntry[]>([]);
  const [loadingDuels, setLoadingDuels] = useState(false);
  const [loadingCandidates, setLoadingCandidates] = useState(false);

  const claimingIdsRef = useRef<Set<string>>(new Set());
  const notifiedInvitesRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    if (!firebaseUser || !userProfile) {
      setDuels([]);
      setTopCompetitors([]);
      setCandidateOpponents([]);
      setLoadingDuels(false);
      return;
    }

    const uid = firebaseUser.uid;
    setLoadingDuels(true);

    const unsubDuels = duelsService.subscribeUserDuels(
      uid,
      (list) => {
        setDuels(list);
        setLoadingDuels(false);
      },
      () => {
        setLoadingDuels(false);
      },
    );

    const unsubTop = duelsService.subscribeTopCompetitors(
      50,
      (stats) => {
        setTopCompetitors(stats);
      },
      () => {
        // Ignore transient competitor feed failure
      },
    );

    return () => {
      unsubDuels();
      unsubTop();
    };
  }, [firebaseUser, userProfile]);

  // Notify on newly received duel challenges + automatically claim unclaimed completed duel rewards
  useEffect(() => {
    if (!firebaseUser || !userProfile) return;
    const uid = firebaseUser.uid;

    for (const duel of duels) {
      if (
        duel.status === 'pending' &&
        duel.opponentUid === uid &&
        !notifiedInvitesRef.current.has(duel.duelId)
      ) {
        notifiedInvitesRef.current.add(duel.duelId);
        const sec = getSectionById(duel.sectionId);
        void emitNotification({
          id: `duel-inv-${duel.duelId}`,
          type: 'new_challenges',
          titleAr: `دعوة تحدٍ جديدة من ${duel.challengerName}`,
          titleEn: `New Duel Challenge from ${duel.challengerName}`,
          bodyAr: `تحداك في قسم ${sec.titleAr} (${duel.questionCount} أسئلة). اقبل التحدي ونافس الآن!`,
          bodyEn: `Challenged you in ${sec.titleEn} (${duel.questionCount} questions). Accept and compete now!`,
          refId: duel.duelId,
          targetScreen: 'duels',
        });
      }

      if (duel.status === 'completed') {
        const isChallenger = duel.challengerUid === uid;
        const isOpponent = duel.opponentUid === uid;
        const alreadyClaimed = isChallenger
          ? duel.challengerRewardClaimed
          : isOpponent
            ? duel.opponentRewardClaimed
            : true;

        if (!alreadyClaimed && !claimingIdsRef.current.has(duel.duelId)) {
          claimingIdsRef.current.add(duel.duelId);
          void duelsService
            .claimDuelRewardAndSyncStats({ uid, duelId: duel.duelId })
            .then(async (res) => {
              if (!res) return;
              await refreshUserProfile();
              const sec = getSectionById(duel.sectionId);
              const pts =
                res.outcome === 'win'
                  ? DUEL_WIN_POINTS
                  : res.outcome === 'draw'
                    ? DUEL_DRAW_POINTS
                    : DUEL_PARTICIPATION_POINTS;
              await emitNotification({
                id: `duel-res-${duel.duelId}`,
                type: 'points_earned',
                titleAr:
                  res.outcome === 'win'
                    ? `فزت في التحدي التنافسي (+${pts} نقطة)`
                    : res.outcome === 'draw'
                      ? `تعادل في التحدي التنافسي (+${pts} نقطة)`
                      : `انتهى التحدي التنافسي (+${pts} نقطة مشاركة)`,
                titleEn:
                  res.outcome === 'win'
                    ? `Duel Victory (+${pts} pts)`
                    : res.outcome === 'draw'
                      ? `Duel Draw (+${pts} pts)`
                      : `Duel Completed (+${pts} participation pts)`,
                bodyAr: `نتيجة مباراتك في قسم ${sec.titleAr} حُسمت وحُفظت نقاطك في الترتيب العالمي.`,
                bodyEn: `Your ${sec.titleEn} match has concluded and your points were added to your ranking.`,
                refId: duel.duelId,
                targetScreen: 'duels',
              });
            })
            .catch(() => {
              claimingIdsRef.current.delete(duel.duelId);
            });
        }
      }
    }
  }, [duels, firebaseUser, userProfile, emitNotification, refreshUserProfile]);

  const loadCandidateOpponents = useCallback(async () => {
    if (!firebaseUser) return;
    setLoadingCandidates(true);
    try {
      const list = await duelsService.fetchCandidateOpponents(firebaseUser.uid);
      setCandidateOpponents(list);
    } finally {
      setLoadingCandidates(false);
    }
  }, [firebaseUser]);

  const createDuel = useCallback(
    async (params: {
      opponent: LeaderboardEntry;
      sectionId: SectionId;
      questionCount: DuelQuestionCount;
      durationSeconds: DuelDurationSeconds;
    }): Promise<string> => {
      if (!userProfile) {
        throw new Error('User profile required.');
      }
      return duelsService.createDuelChallenge({
        challengerProfile: userProfile,
        opponent: params.opponent,
        sectionId: params.sectionId,
        questionCount: params.questionCount,
        durationSeconds: params.durationSeconds,
      });
    },
    [userProfile],
  );

  const respondToDuel = useCallback(
    async (duelId: string, action: 'active' | 'declined' | 'cancelled') => {
      await duelsService.respondToDuel(duelId, action);
    },
    [],
  );

  const submitDuelAnswers = useCallback(
    async (params: {
      duelId: string;
      selectedAnswers: number[];
      durationSeconds: number;
    }) => {
      if (!firebaseUser) {
        throw new Error('Authentication required.');
      }
      return duelsService.submitDuelAnswers({
        duelId: params.duelId,
        uid: firebaseUser.uid,
        selectedAnswers: params.selectedAnswers,
        durationSeconds: params.durationSeconds,
      });
    },
    [firebaseUser],
  );

  const incomingInvites = useMemo(
    () =>
      duels.filter(
        (d) => d.status === 'pending' && d.opponentUid === firebaseUser?.uid,
      ),
    [duels, firebaseUser?.uid],
  );

  const sentInvites = useMemo(
    () =>
      duels.filter(
        (d) => d.status === 'pending' && d.challengerUid === firebaseUser?.uid,
      ),
    [duels, firebaseUser?.uid],
  );

  const activeDuels = useMemo(
    () => duels.filter((d) => d.status === 'active'),
    [duels],
  );

  const completedDuels = useMemo(
    () =>
      duels.filter(
        (d) =>
          d.status === 'completed' ||
          d.status === 'declined' ||
          d.status === 'cancelled',
      ),
    [duels],
  );

  const pendingActionCount = useMemo(() => {
    const uid = firebaseUser?.uid;
    if (!uid) return 0;
    const myTurnActive = activeDuels.filter((d) => {
      if (d.challengerUid === uid) return !d.challengerSubmitted;
      if (d.opponentUid === uid) return !d.opponentSubmitted;
      return false;
    }).length;
    return incomingInvites.length + myTurnActive;
  }, [incomingInvites.length, activeDuels, firebaseUser?.uid]);

  const value = useMemo<DuelsContextValue>(
    () => ({
      duels,
      incomingInvites,
      sentInvites,
      activeDuels,
      completedDuels,
      pendingActionCount,
      topCompetitors,
      candidateOpponents,
      loadingDuels,
      loadingCandidates,
      loadCandidateOpponents,
      createDuel,
      respondToDuel,
      submitDuelAnswers,
    }),
    [
      duels,
      incomingInvites,
      sentInvites,
      activeDuels,
      completedDuels,
      pendingActionCount,
      topCompetitors,
      candidateOpponents,
      loadingDuels,
      loadingCandidates,
      loadCandidateOpponents,
      createDuel,
      respondToDuel,
      submitDuelAnswers,
    ],
  );

  return <DuelsContext.Provider value={value}>{children}</DuelsContext.Provider>;
}

export function useDuels(): DuelsContextValue {
  const ctx = useContext(DuelsContext);
  if (!ctx) {
    throw new Error('useDuels must be used within a DuelsProvider');
  }
  return ctx;
}
