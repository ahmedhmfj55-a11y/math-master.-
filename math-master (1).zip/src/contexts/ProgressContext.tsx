import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import { useAuth } from '@/src/contexts/AuthContext';
import { useNotifications } from '@/src/contexts/NotificationsContext';
import { CURRICULUM_SECTIONS, getSectionById } from '@/src/data/curriculum';
import { makeStageId } from '@/src/data/curriculum/helpers';
import { getTodayDateKey } from '@/src/data/dailyChallengeGenerator';
import { achievementsService } from '@/src/services/achievementsService';
import { dailyChallengeService } from '@/src/services/dailyChallengeService';
import { progressService } from '@/src/services/progressService';
import type {
  AchievementCatalogItem,
  EarnedRecordId,
  MasterCertificateRecord,
  UserAchievementRecord,
} from '@/src/types/achievements';
import type { SectionId } from '@/src/types/curriculum';
import type {
  DailyChallengeAttemptRecord,
  DailyChallengeSubmissionResult,
  DailyStreakStatsRecord,
  ExamAttemptRecord,
  ExamSubmissionResult,
  SectionProgressRecord,
  StageProgressRecord,
  StageSubmissionResult,
} from '@/src/types/progress';

interface ProgressContextValue {
  sectionProgressMap: Partial<Record<SectionId, SectionProgressRecord>>;
  stageProgressMap: Record<string, StageProgressRecord>;
  examAttempts: ExamAttemptRecord[];
  dailyHistory: DailyChallengeAttemptRecord[];
  dailyStats: DailyStreakStatsRecord | null;
  todayDailyRecord: DailyChallengeAttemptRecord | null;
  achievementsMap: Partial<Record<EarnedRecordId, UserAchievementRecord>>;
  masterCertificate: MasterCertificateRecord | null;
  celebrationItems: AchievementCatalogItem[];
  celebrationMasterCert: boolean;
  dismissCelebration: () => void;
  loadingProgress: boolean;
  submittingAttempt: boolean;
  totalCompletedStages: number;
  totalStars: number;
  totalCertificates: number;
  totalMasteredSections: number;
  refreshProgress: () => Promise<void>;
  getSectionProgress: (sectionId: SectionId) => SectionProgressRecord | null;
  getStageProgress: (sectionId: SectionId, stageNumber: number) => StageProgressRecord | null;
  isStageUnlocked: (sectionId: SectionId, stageNumber: number) => boolean;
  isExamUnlocked: (sectionId: SectionId) => boolean;
  submitStage: (sectionId: SectionId, stageNumber: number, selectedAnswers: number[]) => Promise<StageSubmissionResult>;
  submitExam: (
    sectionId: SectionId,
    selectedAnswers: number[],
    options?: { durationSeconds?: number; timedOut?: boolean },
  ) => Promise<ExamSubmissionResult>;
  submitDailyChallenge: (
    dateKey: string,
    selectedAnswers: number[],
    options?: { durationSeconds?: number; timedOut?: boolean },
  ) => Promise<DailyChallengeSubmissionResult>;
}

const ProgressContext = createContext<ProgressContextValue | null>(null);

function computeSectionCounters(sections: Partial<Record<SectionId, SectionProgressRecord>>) {
  let completedStagesCount = 0;
  let completedSectionsCount = 0;
  let certificatesCount = 0;

  for (const sec of CURRICULUM_SECTIONS) {
    const rec = sections[sec.id];
    if (!rec) continue;
    completedStagesCount += rec.completedStagesCount ?? 0;
    if ((rec.completedStagesCount ?? 0) >= 30) completedSectionsCount += 1;
    if (rec.examPassed && rec.certificateId) certificatesCount += 1;
  }

  return { completedStagesCount, completedSectionsCount, certificatesCount };
}

export function ProgressProvider({ children }: { children: ReactNode }) {
  const { firebaseUser, userProfile, refreshUserProfile } = useAuth();
  const { emitNotification } = useNotifications();
  const [sectionProgressMap, setSectionProgressMap] = useState<
    Partial<Record<SectionId, SectionProgressRecord>>
  >({});
  const [stageProgressMap, setStageProgressMap] = useState<Record<string, StageProgressRecord>>({});
  const [examAttempts, setExamAttempts] = useState<ExamAttemptRecord[]>([]);
  const [dailyHistory, setDailyHistory] = useState<DailyChallengeAttemptRecord[]>([]);
  const [dailyStats, setDailyStats] = useState<DailyStreakStatsRecord | null>(null);
  const [achievementsMap, setAchievementsMap] = useState<
    Partial<Record<EarnedRecordId, UserAchievementRecord>>
  >({});
  const [masterCertificate, setMasterCertificate] = useState<MasterCertificateRecord | null>(null);
  const [celebrationItems, setCelebrationItems] = useState<AchievementCatalogItem[]>([]);
  const [celebrationMasterCert, setCelebrationMasterCert] = useState(false);
  const [loadingProgress, setLoadingProgress] = useState(false);
  const [submittingAttempt, setSubmittingAttempt] = useState(false);

  const dismissCelebration = useCallback(() => {
    setCelebrationItems([]);
    setCelebrationMasterCert(false);
  }, []);

  const syncAllProgress = useCallback(
    async (uid: string, triggerCelebration: boolean) => {
      const [data, dailyData, initialAchData] = await Promise.all([
        progressService.loadUserProgress(uid),
        dailyChallengeService.loadDailyChallengeState(uid),
        achievementsService.loadAchievementsAndMasterCert(uid),
      ]);

      let finalAchData = initialAchData;
      try {
        const { completedStagesCount, completedSectionsCount, certificatesCount } =
          computeSectionCounters(data.sections);

        const syncRes = await achievementsService.syncEarnedMilestones({
          uid,
          completedStagesCount,
          completedSectionsCount,
          certificatesCount,
          sectionProgressMap: data.sections,
          dailyStats: dailyData.stats,
          existingAchievements: initialAchData.achievements,
          existingMasterCertificate: initialAchData.masterCertificate,
        });

        if (syncRes.newlyUnlocked.length > 0 || syncRes.newlyIssuedMasterCertificate) {
          finalAchData = await achievementsService.loadAchievementsAndMasterCert(uid);
          if (triggerCelebration) {
            if (syncRes.newlyUnlocked.length > 0) {
              setCelebrationItems((prev) => {
                const seen = new Set(prev.map((item) => item.id));
                const next = [...prev];
                for (const item of syncRes.newlyUnlocked) {
                  if (!seen.has(item.id)) next.push(item);
                }
                return next;
              });
            }
            if (syncRes.newlyIssuedMasterCertificate) {
              setCelebrationMasterCert(true);
            }
          }

          for (const item of syncRes.newlyUnlocked) {
            void emitNotification({
              id: `ach-${item.id}`,
              type: 'medal_earned',
              titleAr:
                item.kind === 'medal'
                  ? `حصلت على وسام: ${item.titleAr}`
                  : `إنجاز جديد: ${item.titleAr}`,
              titleEn:
                item.kind === 'medal'
                  ? `Medal Unlocked: ${item.titleEn}`
                  : `Achievement Unlocked: ${item.titleEn}`,
              bodyAr: item.descriptionAr,
              bodyEn: item.descriptionEn,
              refId: item.id,
              targetScreen: 'achievements',
            });
          }

          if (syncRes.newlyIssuedMasterCertificate) {
            void emitNotification({
              id: 'cert-master-all-sections',
              type: 'certificate_earned',
              titleAr: 'صدرت الشهادة الكبرى لإتقان الرياضيات!',
              titleEn: 'Grand Master Certificate Issued!',
              bodyAr: `تهانينا! أكملت الأقسام الثمانية بمعدل ${syncRes.newlyIssuedMasterCertificate.averageExamScore}/100.`,
              bodyEn: `Congratulations! You mastered all 8 sections with an average of ${syncRes.newlyIssuedMasterCertificate.averageExamScore}/100.`,
              refId: syncRes.newlyIssuedMasterCertificate.certificateId,
              targetScreen: 'achievements',
            });
          }
        }
      } catch (achError) {
        console.error('Achievement milestone synchronization notice:', achError);
      }

      setSectionProgressMap(data.sections);
      setStageProgressMap(data.stages);
      setExamAttempts(data.examAttempts);
      setDailyHistory(dailyData.history);
      setDailyStats(dailyData.stats);
      setAchievementsMap(finalAchData.achievements);
      setMasterCertificate(finalAchData.masterCertificate);
    },
    [emitNotification],
  );

  const refreshProgress = useCallback(async () => {
    if (!firebaseUser || !userProfile) {
      setSectionProgressMap({});
      setStageProgressMap({});
      setExamAttempts([]);
      setDailyHistory([]);
      setDailyStats(null);
      setAchievementsMap({});
      setMasterCertificate(null);
      setCelebrationItems([]);
      setCelebrationMasterCert(false);
      return;
    }
    setLoadingProgress(true);
    try {
      await syncAllProgress(firebaseUser.uid, false);
    } catch (error) {
      console.error('Failed to load learner progress:', error);
    } finally {
      setLoadingProgress(false);
    }
  }, [firebaseUser, userProfile, syncAllProgress]);

  useEffect(() => {
    void refreshProgress();
  }, [refreshProgress]);

  const getSectionProgress = useCallback(
    (sectionId: SectionId): SectionProgressRecord | null => {
      return sectionProgressMap[sectionId] ?? null;
    },
    [sectionProgressMap],
  );

  const getStageProgress = useCallback(
    (sectionId: SectionId, stageNumber: number): StageProgressRecord | null => {
      return stageProgressMap[makeStageId(sectionId, stageNumber)] ?? null;
    },
    [stageProgressMap],
  );

  const isStageUnlocked = useCallback(
    (sectionId: SectionId, stageNumber: number): boolean => {
      if (stageNumber === 1) return true;
      const sec = sectionProgressMap[sectionId];
      return (sec?.unlockedStage ?? 1) >= stageNumber;
    },
    [sectionProgressMap],
  );

  const isExamUnlocked = useCallback(
    (sectionId: SectionId): boolean => {
      const sec = sectionProgressMap[sectionId];
      return (sec?.completedStagesCount ?? 0) >= 30;
    },
    [sectionProgressMap],
  );

  const submitStage = useCallback(
    async (
      sectionId: SectionId,
      stageNumber: number,
      selectedAnswers: number[],
    ): Promise<StageSubmissionResult> => {
      if (!firebaseUser) {
        throw new Error('Authentication required to save stage progress.');
      }
      setSubmittingAttempt(true);
      try {
        const result = await progressService.submitStageAttempt({
          uid: firebaseUser.uid,
          sectionId,
          stageNumber,
          selectedAnswers,
        });
        await syncAllProgress(firebaseUser.uid, result.passed);
        if (result.pointsAwarded > 0) {
          await refreshUserProfile();
        }

        const sectionDef = getSectionById(sectionId);
        if (result.passed) {
          void emitNotification({
            id: `stage-win-${sectionId}-s${stageNumber}`,
            type: 'stage_win',
            titleAr: `اجتزت المرحلة ${stageNumber} في ${sectionDef.titleAr}`,
            titleEn: `Cleared Stage ${stageNumber} in ${sectionDef.titleEn}`,
            bodyAr: `نتيجتك ${result.score}/100 (${result.stars} نجوم). واصل تقدمك الرائع!`,
            bodyEn: `Score ${result.score}/100 (${result.stars} stars). Keep up your great momentum!`,
            refId: makeStageId(sectionId, stageNumber),
            targetScreen: 'section',
            targetSectionId: sectionId,
          });
        }
        if (result.pointsAwarded > 0) {
          void emitNotification({
            id: `pts-stage-${sectionId}-s${stageNumber}`,
            type: 'points_earned',
            titleAr: `حصلت على +${result.pointsAwarded} نقطة`,
            titleEn: `Earned +${result.pointsAwarded} Points`,
            bodyAr: `تمت إضافة +${result.pointsAwarded} نقطة إلى رصيدك بعد الفوز بالمرحلة ${stageNumber}.`,
            bodyEn: `+${result.pointsAwarded} points have been added to your balance for Stage ${stageNumber}.`,
            refId: makeStageId(sectionId, stageNumber),
            targetScreen: 'leaderboard',
          });
        }
        if (result.unlockedNextStage) {
          void emitNotification({
            id: `stage-unlock-${sectionId}-s${result.unlockedNextStage}`,
            type: 'stage_unlock',
            titleAr: `تم فتح المرحلة ${result.unlockedNextStage} في ${sectionDef.titleAr}`,
            titleEn: `Stage ${result.unlockedNextStage} Unlocked in ${sectionDef.titleEn}`,
            bodyAr: `أصبحت المرحلة ${result.unlockedNextStage} جاهزة الآن للتعلم والاختبار.`,
            bodyEn: `Stage ${result.unlockedNextStage} is now open for lessons and quiz challenges.`,
            refId: makeStageId(sectionId, result.unlockedNextStage),
            targetScreen: 'section',
            targetSectionId: sectionId,
          });
        }
        if (result.sectionCompletionBonusPoints > 0) {
          void emitNotification({
            id: `new-exam-${sectionId}`,
            type: 'new_challenges',
            titleAr: `امتحان ${sectionDef.titleAr} الشامل مفتوح الآن!`,
            titleEn: `${sectionDef.titleEn} Final Exam Unlocked!`,
            bodyAr: `أكملت جميع المراحل الـ30 وحصلت على مكافأة القسم (+${result.sectionCompletionBonusPoints} نقطة). ابدأ الامتحان الشامل الآن!`,
            bodyEn: `All 30 stages completed (+${result.sectionCompletionBonusPoints} pts bonus)! Take the comprehensive final exam now.`,
            refId: sectionId,
            targetScreen: 'exams',
            targetSectionId: sectionId,
          });
        }

        return result;
      } finally {
        setSubmittingAttempt(false);
      }
    },
    [firebaseUser, syncAllProgress, refreshUserProfile, emitNotification],
  );

  const submitExam = useCallback(
    async (
      sectionId: SectionId,
      selectedAnswers: number[],
      options?: { durationSeconds?: number; timedOut?: boolean },
    ): Promise<ExamSubmissionResult> => {
      if (!firebaseUser) {
        throw new Error('Authentication required to save exam results.');
      }
      setSubmittingAttempt(true);
      try {
        const result = await progressService.submitExamAttempt({
          uid: firebaseUser.uid,
          sectionId,
          selectedAnswers,
          durationSeconds: options?.durationSeconds,
          timedOut: options?.timedOut,
        });
        await syncAllProgress(firebaseUser.uid, result.passed);
        if (result.pointsAwarded > 0) {
          await refreshUserProfile();
        }

        const sectionDef = getSectionById(sectionId);
        if (result.passed) {
          void emitNotification({
            id: `exam-pass-${sectionId}`,
            type: 'exam_pass',
            titleAr: `نجحت في الامتحان الشامل لقسم ${sectionDef.titleAr}!`,
            titleEn: `Passed ${sectionDef.titleEn} Final Exam!`,
            bodyAr: `نتيجتك ${result.score}/100 (${result.correctCount}/30). إنجاز متميز!`,
            bodyEn: `Score ${result.score}/100 (${result.correctCount}/30). Outstanding mastery!`,
            refId: sectionId,
            targetScreen: 'exams',
            targetSectionId: sectionId,
          });
          if (result.certificateId) {
            void emitNotification({
              id: `cert-${sectionId}`,
              type: 'certificate_earned',
              titleAr: `صدرت شهادة قسم ${sectionDef.titleAr}`,
              titleEn: `${sectionDef.titleEn} Certificate Issued`,
              bodyAr: `شهادتك الرسمية رقم ${result.certificateId} جاهزة للعرض والطباعة (PDF).`,
              bodyEn: `Your official certificate #${result.certificateId} is ready to view and print (PDF).`,
              refId: result.certificateId,
              targetScreen: 'achievements',
              targetSectionId: sectionId,
            });
          }
        }
        if (result.pointsAwarded > 0) {
          void emitNotification({
            id: `pts-exam-${sectionId}-att${result.attemptNumber}`,
            type: 'points_earned',
            titleAr: `حصلت على +${result.pointsAwarded} نقطة من الامتحان`,
            titleEn: `Earned +${result.pointsAwarded} Exam Points`,
            bodyAr: `أضيفت +${result.pointsAwarded} نقطة إلى رصيدك وتصنيفك العالمي.`,
            bodyEn: `+${result.pointsAwarded} points were added to your balance and global rank.`,
            refId: sectionId,
            targetScreen: 'leaderboard',
          });
        }

        return result;
      } finally {
        setSubmittingAttempt(false);
      }
    },
    [firebaseUser, syncAllProgress, refreshUserProfile, emitNotification],
  );

  const submitDailyChallenge = useCallback(
    async (
      dateKey: string,
      selectedAnswers: number[],
      options?: { durationSeconds?: number; timedOut?: boolean },
    ): Promise<DailyChallengeSubmissionResult> => {
      if (!firebaseUser) {
        throw new Error('Authentication required to submit daily challenge.');
      }
      setSubmittingAttempt(true);
      try {
        const result = await dailyChallengeService.submitDailyChallenge({
          uid: firebaseUser.uid,
          dateKey,
          selectedAnswers,
          durationSeconds: options?.durationSeconds,
          timedOut: options?.timedOut,
        });
        await syncAllProgress(firebaseUser.uid, result.passed);
        if (result.pointsAwarded > 0) {
          await refreshUserProfile();
          void emitNotification({
            id: `pts-daily-${dateKey}`,
            type: 'points_earned',
            titleAr: `حصلت على +${result.pointsAwarded} نقطة من التحدي اليومي`,
            titleEn: `Earned +${result.pointsAwarded} Daily Challenge Points`,
            bodyAr: `سلسلتك الحالية: ${result.streakStats.currentStreak} يوم. استمر بالتألق!`,
            bodyEn: `Current streak: ${result.streakStats.currentStreak} day(s). Keep shining!`,
            refId: dateKey,
            targetScreen: 'daily',
          });
        }
        return result;
      } finally {
        setSubmittingAttempt(false);
      }
    },
    [firebaseUser, syncAllProgress, refreshUserProfile, emitNotification],
  );

  const todayKey = getTodayDateKey();
  const todayDailyRecord = useMemo(
    () => dailyHistory.find((entry) => entry.dateKey === todayKey) ?? null,
    [dailyHistory, todayKey],
  );

  // Automatic non-duplicating Daily Challenge reminder + new challenge availability alert
  useEffect(() => {
    if (!firebaseUser || !userProfile || loadingProgress) return;
    if (todayDailyRecord) return;

    void emitNotification({
      id: `daily-rem-${todayKey}`,
      type: 'daily_reminder',
      titleAr: 'تذكير بالتحدي اليومي',
      titleEn: 'Daily Math Challenge Reminder',
      bodyAr: 'تحدي اليوم جاهز الآن (10 أسئلة خلال 10 دقائق) — حافظ على سلسلة أيامك المتتالية!',
      bodyEn: "Today's 10-question Daily Challenge is live — protect your streak and earn up to +75 pts!",
      refId: todayKey,
      targetScreen: 'daily',
    });
  }, [firebaseUser, userProfile, loadingProgress, todayDailyRecord, todayKey, emitNotification]);

  const { totalCompletedStages, totalStars, totalCertificates, totalMasteredSections } = useMemo(() => {
    let completed = 0;
    let stars = 0;
    let certs = 0;
    let mastered = 0;
    for (const sec of CURRICULUM_SECTIONS) {
      const rec = sectionProgressMap[sec.id];
      if (!rec) continue;
      completed += rec.completedStagesCount ?? 0;
      stars += rec.totalStars ?? 0;
      if (rec.completedStagesCount >= 30) mastered += 1;
      if (rec.examPassed && rec.certificateId) certs += 1;
    }
    return {
      totalCompletedStages: completed,
      totalStars: stars,
      totalCertificates: certs,
      totalMasteredSections: mastered,
    };
  }, [sectionProgressMap]);

  const value = useMemo<ProgressContextValue>(
    () => ({
      sectionProgressMap,
      stageProgressMap,
      examAttempts,
      dailyHistory,
      dailyStats,
      todayDailyRecord,
      achievementsMap,
      masterCertificate,
      celebrationItems,
      celebrationMasterCert,
      dismissCelebration,
      loadingProgress,
      submittingAttempt,
      totalCompletedStages,
      totalStars,
      totalCertificates,
      totalMasteredSections,
      refreshProgress,
      getSectionProgress,
      getStageProgress,
      isStageUnlocked,
      isExamUnlocked,
      submitStage,
      submitExam,
      submitDailyChallenge,
    }),
    [
      sectionProgressMap,
      stageProgressMap,
      examAttempts,
      dailyHistory,
      dailyStats,
      todayDailyRecord,
      achievementsMap,
      masterCertificate,
      celebrationItems,
      celebrationMasterCert,
      dismissCelebration,
      loadingProgress,
      submittingAttempt,
      totalCompletedStages,
      totalStars,
      totalCertificates,
      totalMasteredSections,
      refreshProgress,
      getSectionProgress,
      getStageProgress,
      isStageUnlocked,
      isExamUnlocked,
      submitStage,
      submitExam,
      submitDailyChallenge,
    ],
  );

  return <ProgressContext.Provider value={value}>{children}</ProgressContext.Provider>;
}

export function useProgress(): ProgressContextValue {
  const ctx = useContext(ProgressContext);
  if (!ctx) {
    throw new Error('useProgress must be used within a ProgressProvider');
  }
  return ctx;
}


