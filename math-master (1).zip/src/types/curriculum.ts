export type SectionId =
  | 'arithmetic'
  | 'fractions'
  | 'algebra'
  | 'geometry'
  | 'measurement'
  | 'ratios'
  | 'statistics'
  | 'advanced';

export type DifficultyLevel = 'easy' | 'medium' | 'hard';

export interface WorkedExample {
  problemAr: string;
  problemEn: string;
  solutionAr: string;
  solutionEn: string;
  answer: string;
}

export interface StageLesson {
  summaryAr: string;
  summaryEn: string;
  ruleTitleAr: string;
  ruleTitleEn: string;
  ruleFormula: string;
  examples: [WorkedExample, WorkedExample];
}

export interface QuizQuestion {
  id: string;
  promptAr: string;
  promptEn: string;
  options: [string, string, string, string];
  correctIndex: 0 | 1 | 2 | 3;
  explanationAr: string;
  explanationEn: string;
}

export interface StageDefinition {
  id: string;
  sectionId: SectionId;
  stageNumber: number; // 1..30
  difficulty: DifficultyLevel;
  titleAr: string;
  titleEn: string;
  lesson: StageLesson;
  questions: QuizQuestion[]; // Exactly 10 distinct questions
  examQuestion: QuizQuestion; // Dedicated distinct question for the 30-question Section Final Exam
}

export interface SectionDefinition {
  id: SectionId;
  order: number; // 1..8
  titleAr: string;
  titleEn: string;
  descriptionAr: string;
  descriptionEn: string;
  accentFrom: string;
  accentTo: string;
  symbol: string;
}
