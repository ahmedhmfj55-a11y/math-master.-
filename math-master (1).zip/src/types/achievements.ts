import type { Timestamp } from 'firebase/firestore';

export type AchievementId =
  | 'ach-first-stage'
  | 'ach-10-stages'
  | 'ach-50-stages'
  | 'ach-100-stages'
  | 'ach-section-complete'
  | 'ach-all-sections'
  | 'ach-exam-perfect'
  | 'ach-daily-7'
  | 'ach-daily-30';

export type MedalId =
  | 'medal-bronze'
  | 'medal-silver'
  | 'medal-gold'
  | 'medal-genius'
  | 'medal-math-king'
  | 'medal-challenge'
  | 'medal-excellence';

export type EarnedRecordId = AchievementId | MedalId;

export type EarnedItemKind = 'achievement' | 'medal';

export type MedalIconKey =
  | 'bronze'
  | 'silver'
  | 'gold'
  | 'genius'
  | 'king'
  | 'challenge'
  | 'excellence'
  | 'stage1'
  | 'stage10'
  | 'stage50'
  | 'stage100'
  | 'section1'
  | 'section8'
  | 'perfectExam'
  | 'streak7'
  | 'streak30';

export interface AchievementCatalogItem {
  id: EarnedRecordId;
  kind: EarnedItemKind;
  titleAr: string;
  titleEn: string;
  descriptionAr: string;
  descriptionEn: string;
  conditionAr: string;
  conditionEn: string;
  targetValue: number;
  accentFrom: string;
  accentTo: string;
  ringColor: string;
  iconKey: MedalIconKey;
}

export interface UserAchievementRecord {
  uid: string;
  achievementId: EarnedRecordId;
  kind: EarnedItemKind;
  triggerRef: string;
  unlockedAt?: Timestamp;
}

export interface MasterCertificateRecord {
  uid: string;
  certDocId: 'all-sections';
  certificateId: string;
  averageExamScore: number;
  completedSectionsCount: number;
  totalCompletedStages: number;
  issuedAt?: Timestamp;
}
