import type { Timestamp } from 'firebase/firestore';

export type RewardCategory = 'badge' | 'avatar' | 'title';

export interface ShopRewardItem {
  id: string;
  category: RewardCategory;
  nameAr: string;
  nameEn: string;
  descriptionAr: string;
  descriptionEn: string;
  cost: number;
  accentFrom: string;
  accentTo: string;
  symbol: string;
}

export interface RewardPurchaseRecord {
  uid: string;
  itemId: string;
  category: RewardCategory;
  cost: number;
  purchasedAt?: Timestamp;
}

export type PointTransactionType =
  | 'stage_win'
  | 'stage_perfect'
  | 'section_complete'
  | 'exam_pass'
  | 'exam_perfect'
  | 'daily_win'
  | 'daily_perfect'
  | 'duel_win'
  | 'duel_draw'
  | 'duel_part'
  | 'bank_tier_mastery'
  | 'genius_solve'
  | 'shop_purchase';

export interface PointTransactionRecord {
  uid: string;
  txId: string;
  type: PointTransactionType;
  refId: string;
  amount: number;
  balanceAfter: number;
  createdAt?: Timestamp;
}

export interface LeaderboardEntry {
  uid: string;
  displayName: string;
  countryCode: string;
  avatarId: string;
  photoUrl: string;
  titleId: string;
  badgeId: string;
  totalEarnedPoints: number;
  completedStages: number;
  completedSections: number;
  certificatesCount: number;
  updatedAt?: Timestamp;
}
