import type { Timestamp } from 'firebase/firestore';
import type { Language } from './i18n';

export type AuthProviderType = 'google.com' | 'phone';

export interface UserProfile {
  uid: string;
  displayName: string;
  countryCode: string;
  countryNameAr: string;
  countryNameEn: string;
  preferredLang: Language;
  points: number;
  totalEarnedPoints?: number;
  currentStage: number;
  completedStagesCount?: number;
  completedSectionsCount?: number;
  certificatesCount?: number;
  equippedAvatarId?: string;
  equippedTitleId?: string;
  equippedBadgeId?: string;
  photoUrl?: string;
  lastLedgerId?: string;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface UserPrivateInfo {
  uid: string;
  email?: string;
  phoneNumber?: string;
  authProvider: AuthProviderType;
  updatedAt?: Timestamp;
}

/**
 * Extensible interfaces reserved for curriculum modules
 */
export interface LearningStageDefinition {
  id: string;
  order: number;
  titleAr: string;
  titleEn: string;
  minPointsRequired: number;
}

export interface ExamAttemptRecord {
  id: string;
  stageId: string;
  score: number;
  maxScore: number;
  completedAt: Timestamp;
}
