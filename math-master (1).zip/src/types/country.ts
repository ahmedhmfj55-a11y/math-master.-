export interface Country {
  code: string;
  nameEn: string;
  nameAr: string;
  dialCode: string;
  flag: string;
}
