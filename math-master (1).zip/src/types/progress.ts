import type { Timestamp } from 'firebase/firestore';
import type { SectionId } from './curriculum';

export interface StageProgressRecord {
  uid: string;
  stageId: string;
  sectionId: SectionId;
  stageNumber: number;
  bestScore: number; // 0..100
  lastScore: number; // 0..100
  bestStars: number; // 0..3
  passed: boolean;
  attempts: number;
  rewardClaimed: boolean;
  perfectRewardClaimed?: boolean;
  totalCorrect?: number;
  totalWrong?: number;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface SectionProgressRecord {
  uid: string;
  sectionId: SectionId;
  unlockedStage: number; // 1..30
  completedStagesCount: number; // 0..30
  totalStars: number; // 0..90
  sectionRewardClaimed?: boolean;
  examBestScore: number; // 0..100
  examLastScore: number; // 0..100
  examAttempts: number;
  examPassed: boolean;
  examRewardClaimed: boolean;
  examPerfectRewardClaimed?: boolean;
  certificateId: string;
  lastExamAt?: Timestamp;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface ExamAttemptRecord {
  uid: string;
  attemptId: string;
  sectionId: SectionId;
  attemptNumber: number;
  score: number;
  correctCount: number;
  wrongCount: number;
  passed: boolean;
  durationSeconds: number;
  pointsAwarded: number;
  timedOut: boolean;
  submittedAt?: Timestamp;
}

export interface QuestionReviewItem {
  questionId: string;
  promptAr: string;
  promptEn: string;
  options: [string, string, string, string];
  selectedIndex: number;
  correctIndex: 0 | 1 | 2 | 3;
  isCorrect: boolean;
  explanationAr: string;
  explanationEn: string;
}

export interface StageSubmissionResult {
  score: number;
  correctCount: number;
  totalQuestions: number;
  stars: number;
  passed: boolean;
  pointsAwarded: number;
  stageWinPoints: number;
  perfectScoreBonusPoints: number;
  sectionCompletionBonusPoints: number;
  rewardAlreadyClaimed: boolean;
  unlockedNextStage: number | null;
  review: QuestionReviewItem[];
}

export interface ExamSubmissionResult {
  score: number;
  correctCount: number;
  wrongCount: number;
  totalQuestions: number;
  passed: boolean;
  pointsAwarded: number;
  examPassPoints: number;
  perfectScoreBonusPoints: number;
  rewardAlreadyClaimed: boolean;
  certificateId: string;
  durationSeconds: number;
  timedOut: boolean;
  attemptNumber: number;
  review: QuestionReviewItem[];
}

export interface DailyChallengeQuestion {
  id: string;
  questionNumber: number;
  difficulty: 'easy' | 'medium' | 'hard';
  topicAr: string;
  topicEn: string;
  promptAr: string;
  promptEn: string;
  options: [string, string, string, string];
  correctIndex: 0 | 1 | 2 | 3;
  explanationAr: string;
  explanationEn: string;
}

export interface DailyChallengeAttemptRecord {
  uid: string;
  dateKey: string; // YYYY-MM-DD
  score: number; // 0..100
  correctCount: number; // 0..10
  wrongCount: number; // 0..10
  passed: boolean; // score >= 70
  perfect: boolean; // score === 100
  durationSeconds: number; // 0..600
  pointsAwarded: number; // 0, 50, or 75
  timedOut: boolean;
  submittedAt?: Timestamp;
}

export interface DailyStreakStatsRecord {
  uid: string;
  currentStreak: number;
  longestStreak: number;
  totalDailyCompleted: number;
  totalDailyAttempted: number;
  lastWonDate: string; // '' or YYYY-MM-DD
  lastAttemptDate: string; // YYYY-MM-DD
  badge7Unlocked: boolean;
  badge30Unlocked: boolean;
  updatedAt?: Timestamp;
}

export interface DailyChallengeSubmissionResult {
  dateKey: string;
  score: number;
  correctCount: number;
  wrongCount: number;
  totalQuestions: number;
  passed: boolean;
  perfect: boolean;
  pointsAwarded: number;
  dailyWinPoints: number;
  perfectBonusPoints: number;
  durationSeconds: number;
  timedOut: boolean;
  streakStats: DailyStreakStatsRecord;
  newlyUnlockedBadge7: boolean;
  newlyUnlockedBadge30: boolean;
  review: QuestionReviewItem[];
}

