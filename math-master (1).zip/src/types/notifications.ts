import type { Timestamp } from 'firebase/firestore';
import type { SectionId } from './curriculum';

export type NotificationType =
  | 'stage_unlock'
  | 'stage_win'
  | 'points_earned'
  | 'medal_earned'
  | 'exam_pass'
  | 'certificate_earned'
  | 'daily_reminder'
  | 'rank_up'
  | 'new_challenges';

export type NotificationTargetScreen =
  | 'home'
  | 'sections'
  | 'question-bank'
  | 'genius-challenges'
  | 'daily'
  | 'duels'
  | 'section'
  | 'exams'
  | 'achievements'
  | 'leaderboard'
  | 'profile'
  | 'settings';

export interface UserNotificationRecord {
  uid: string;
  id: string;
  type: NotificationType;
  titleAr: string;
  titleEn: string;
  bodyAr: string;
  bodyEn: string;
  refId: string;
  targetScreen: NotificationTargetScreen;
  targetSectionId: SectionId | '';
  read: boolean;
  createdAt?: Timestamp;
}

export interface CreateNotificationInput {
  id: string;
  type: NotificationType;
  titleAr: string;
  titleEn: string;
  bodyAr: string;
  bodyEn: string;
  refId: string;
  targetScreen: NotificationTargetScreen;
  targetSectionId?: SectionId | '';
}

export type ThemeMode = 'dark' | 'light' | 'auto';

export interface UserPreferencesRecord {
  uid: string;
  themeMode: ThemeMode;
  notificationsEnabled: boolean;
  notifyDailyReminder: boolean;
  notifyStageUnlock: boolean;
  notifyStageWinPoints: boolean;
  notifyMedalsCerts: boolean;
  notifyExamsChallenges: boolean;
  notifyRankUp: boolean;
  pushAlertsEnabled: boolean;
  bestGlobalRank: number;
  updatedAt?: Timestamp;
}

export const DEFAULT_USER_PREFERENCES: Omit<UserPreferencesRecord, 'uid' | 'updatedAt'> = {
  themeMode: 'dark',
  notificationsEnabled: true,
  notifyDailyReminder: true,
  notifyStageUnlock: true,
  notifyStageWinPoints: true,
  notifyMedalsCerts: true,
  notifyExamsChallenges: true,
  notifyRankUp: true,
  pushAlertsEnabled: false,
  bestGlobalRank: 0,
};
