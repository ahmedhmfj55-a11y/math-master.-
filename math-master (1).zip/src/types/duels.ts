import type { Timestamp } from 'firebase/firestore';
import type { SectionId } from './curriculum';

export type DuelStatus = 'pending' | 'active' | 'completed' | 'declined' | 'cancelled';

export type DuelQuestionCount = 5 | 10 | 15;
export type DuelDurationSeconds = 180 | 300 | 600;

export const DUEL_WIN_POINTS = 75;
export const DUEL_DRAW_POINTS = 35;
export const DUEL_PARTICIPATION_POINTS = 15;

export interface DuelMatchRecord {
  duelId: string;
  participantUids: [string, string];
  challengerUid: string;
  challengerName: string;
  challengerCountry: string;
  challengerAvatar: string;
  opponentUid: string;
  opponentName: string;
  opponentCountry: string;
  opponentAvatar: string;
  sectionId: SectionId;
  questionCount: DuelQuestionCount;
  durationSeconds: DuelDurationSeconds;
  questionSeed: number;
  status: DuelStatus;
  challengerSubmitted: boolean;
  challengerCorrect: number;
  challengerScore: number;
  challengerDurationSec: number;
  challengerRewardClaimed: boolean;
  opponentSubmitted: boolean;
  opponentCorrect: number;
  opponentScore: number;
  opponentDurationSec: number;
  opponentRewardClaimed: boolean;
  winnerUid: string; // '' | 'draw' | challengerUid | opponentUid
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface DuelCompetitorStatsRecord {
  uid: string;
  displayName: string;
  countryCode: string;
  avatarId: string;
  photoUrl: string;
  wins: number;
  draws: number;
  losses: number;
  matchesPlayed: number;
  duelPoints: number;
  updatedAt?: Timestamp;
}

export interface DuelQuestionItem {
  id: string;
  questionNumber: number;
  difficulty: 'easy' | 'medium' | 'hard';
  stageTitleAr: string;
  stageTitleEn: string;
  promptAr: string;
  promptEn: string;
  options: [string, string, string, string];
  correctIndex: 0 | 1 | 2 | 3;
  explanationAr: string;
  explanationEn: string;
}
