import type { Timestamp } from 'firebase/firestore';

export type GradeId =
  | 'g01'
  | 'g02'
  | 'g03'
  | 'g04'
  | 'g05'
  | 'g06'
  | 'g07'
  | 'g08'
  | 'g09'
  | 'g10'
  | 'g11'
  | 'g12'
  | 'g13'
  | 'g14'
  | 'g15'
  | 'g16'
  | 'g17'
  | 'g18';

export type GradeStageBand = 'elementary' | 'middle' | 'high' | 'university_research';

export type BankDifficultyTier = 'very_easy' | 'easy' | 'medium' | 'hard' | 'very_hard';

export type BankTopicId =
  | 'arithmetic_ops'
  | 'fractions_decimals'
  | 'ratios_percentages'
  | 'equations'
  | 'advanced_algebra'
  | 'geometry_solids'
  | 'trigonometry'
  | 'statistics_probability'
  | 'sequences_series'
  | 'calculus'
  | 'linear_algebra'
  | 'number_theory'
  | 'discrete_math'
  | 'mathematical_analysis'
  | 'differential_equations'
  | 'logic_puzzles'
  | 'olympiad_problems';

export type BankQuestionFormat = 'mcq' | 'written' | 'multi_step' | 'proof';

export type ProblemVerificationStatus = 'solved_verified' | 'open_research';

export interface BankQuestion {
  id: string;
  gradeId: GradeId;
  tier: BankDifficultyTier;
  topic: BankTopicId;
  format: BankQuestionFormat;
  status: ProblemVerificationStatus;
  promptAr: string;
  promptEn: string;
  /** Present for mcq, multi_step, or proof choices */
  options?: [string, string, string, string];
  correctIndex?: 0 | 1 | 2 | 3;
  /** Present for written input questions */
  acceptedAnswers?: string[];
  displayAnswer: string;
  hintAr: string;
  hintEn: string;
  stepsAr: string[];
  stepsEn: string[];
  explanationAr: string;
  explanationEn: string;
}

export interface GradeLevelDefinition {
  id: GradeId;
  order: number; // 1..18
  band: GradeStageBand;
  titleAr: string;
  titleEn: string;
  subtitleAr: string;
  subtitleEn: string;
  topics: BankTopicId[];
  accentFrom: string;
  accentTo: string;
}

export interface BankTopicDefinition {
  id: BankTopicId;
  titleAr: string;
  titleEn: string;
}

export interface GeniusChallengeItem {
  id: string;
  category: 'olympiad' | 'number_theory' | 'geometry' | 'algebra' | 'analysis' | 'open_research';
  status: ProblemVerificationStatus;
  sourceLabelAr: string;
  sourceLabelEn: string;
  titleAr: string;
  titleEn: string;
  statementAr: string;
  statementEn: string;
  partialProgressAr?: string;
  partialProgressEn?: string;
  question: BankQuestion;
}

export interface BankTierProgressRecord {
  uid: string;
  bankKey: string; // `${gradeId}-${tier}` or `genius-${challengeId}`
  gradeId: GradeId;
  tier: BankDifficultyTier;
  attempts: number;
  bestScore: number; // 0..100
  lastScore: number; // 0..100
  mastered: boolean; // score >= 70
  rewardClaimed: boolean;
  correctCount: number;
  totalAnswered: number;
  seenQuestionIds: string[];
  updatedAt?: Timestamp;
}

export interface TopicMasteryStat {
  attempted: number;
  correct: number;
}

export interface AdaptiveProfileSummary {
  uid: string;
  recommendedGradeNumber: number; // 1..18
  recommendedTier: BankDifficultyTier;
  totalBankQuestionsAnswered: number;
  totalBankCorrect: number;
  totalQuizzesCompleted: number;
  geniusSolvedCount: number;
  topicStats: Record<string, TopicMasteryStat>;
  updatedAt?: Timestamp;
}

export interface BankQuestionReviewItem {
  question: BankQuestion;
  userAnswerDisplay: string;
  isCorrect: boolean;
}

export interface BankQuizSubmissionResult {
  bankKey: string;
  gradeId: GradeId;
  tier: BankDifficultyTier;
  score: number;
  correctCount: number;
  totalQuestions: number;
  mastered: boolean;
  newlyMastered: boolean;
  unlockedNextTier: BankDifficultyTier | null;
  pointsAwarded: number;
  rewardAlreadyClaimed: boolean;
  adaptiveShift: 'upgraded' | 'reinforced' | 'steady';
  recommendedGradeNumber: number;
  recommendedTier: BankDifficultyTier;
  review: BankQuestionReviewItem[];
}
