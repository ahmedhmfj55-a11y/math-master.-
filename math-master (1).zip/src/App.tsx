import { AnimatePresence } from 'motion/react';
import { useCallback, useEffect, useState } from 'react';
import type { HubTab } from '@/src/components/ui/AppTopBar';
import { ErrorBoundary } from '@/src/components/ui/ErrorBoundary';
import { LiquidBackground } from '@/src/components/ui/LiquidBackground';
import { MobileBottomNav } from '@/src/components/ui/MobileBottomNav';
import { OfflineIndicator } from '@/src/components/ui/OfflineIndicator';
import { AuthProvider, useAuth } from '@/src/contexts/AuthContext';
import { DuelsProvider } from '@/src/contexts/DuelsContext';
import { LanguageProvider } from '@/src/contexts/LanguageContext';
import { NotificationsProvider } from '@/src/contexts/NotificationsContext';
import { ProgressProvider, useProgress } from '@/src/contexts/ProgressContext';
import { QuestionBankProvider, useQuestionBank } from '@/src/contexts/QuestionBankContext';
import { RewardsProvider } from '@/src/contexts/RewardsContext';
import { ThemeProvider } from '@/src/contexts/ThemeContext';
import { AchievementUnlockModal } from '@/src/features/achievements/AchievementUnlockModal';
import { AchievementsScreen } from '@/src/features/achievements/AchievementsScreen';
import { AuthScreen } from '@/src/features/auth/AuthScreen';
import { CountrySelectionScreen } from '@/src/features/country/CountrySelectionScreen';
import { DailyChallengeScreen } from '@/src/features/daily/DailyChallengeScreen';
import { DuelsScreen } from '@/src/features/duels/DuelsScreen';
import { ExamsHubScreen } from '@/src/features/exams/ExamsHubScreen';
import { HomeHubScreen } from '@/src/features/home/HomeHubScreen';
import { LeaderboardScreen } from '@/src/features/leaderboard/LeaderboardScreen';
import { CertificateScreen } from '@/src/features/learning/CertificateScreen';
import { MasterCertificateScreen } from '@/src/features/learning/MasterCertificateScreen';
import { SectionDetailScreen } from '@/src/features/learning/SectionDetailScreen';
import { SectionExamScreen } from '@/src/features/learning/SectionExamScreen';
import { StagePlayScreen } from '@/src/features/learning/StagePlayScreen';
import { NotificationsScreen } from '@/src/features/notifications/NotificationsScreen';
import { ProfileScreen } from '@/src/features/profile/ProfileScreen';
import { BankQuizScreen } from '@/src/features/questionBank/BankQuizScreen';
import { GeniusChallengesScreen } from '@/src/features/questionBank/GeniusChallengesScreen';
import { GradeLevelScreen } from '@/src/features/questionBank/GradeLevelScreen';
import { QuestionBankHubScreen } from '@/src/features/questionBank/QuestionBankHubScreen';
import { SectionsHubScreen } from '@/src/features/sections/SectionsHubScreen';
import { SettingsScreen } from '@/src/features/settings/SettingsScreen';
import { RewardsShopScreen } from '@/src/features/shop/RewardsShopScreen';
import { SplashScreen } from '@/src/features/splash/SplashScreen';
import type { SectionId } from '@/src/types/curriculum';
import type { AppScreen } from '@/src/types/navigation';
import type { BankDifficultyTier, BankTopicId, GradeId } from '@/src/types/questionBank';

const AUTHENTICATED_SCREENS: AppScreen[] = [
  'home',
  'sections',
  'question-bank',
  'grade-level',
  'bank-quiz',
  'genius-challenges',
  'duels',
  'daily',
  'section',
  'stage',
  'exams',
  'exam',
  'certificate',
  'achievements',
  'master-certificate',
  'leaderboard',
  'shop',
  'profile',
  'notifications',
  'settings',
];

const BOTTOM_NAV_SCREENS: AppScreen[] = [
  'home',
  'sections',
  'section',
  'question-bank',
  'grade-level',
  'genius-challenges',
  'duels',
  'exams',
  'achievements',
  'leaderboard',
  'shop',
  'profile',
  'notifications',
  'settings',
];

function AppRouter() {
  const { authReady, firebaseUser } = useAuth();
  const {
    isStageUnlocked,
    isExamUnlocked,
    getSectionProgress,
    masterCertificate,
    celebrationItems,
    celebrationMasterCert,
    dismissCelebration,
  } = useProgress();
  const { isBankTierUnlocked } = useQuestionBank();

  const [screen, setScreen] = useState<AppScreen>('splash');
  const [countryReturnTarget, setCountryReturnTarget] = useState<'auth' | 'home' | 'settings'>(
    'auth',
  );
  const [activeSectionId, setActiveSectionId] = useState<SectionId | null>(null);
  const [activeStageNumber, setActiveStageNumber] = useState<number | null>(null);
  const [examReturnTarget, setExamReturnTarget] = useState<'section' | 'exams'>('section');

  // Question Bank active routing state
  const [activeGradeId, setActiveGradeId] = useState<GradeId | null>(null);
  const [activeBankTier, setActiveBankTier] = useState<BankDifficultyTier | null>(null);
  const [activeFocusTopic, setActiveFocusTopic] = useState<BankTopicId | undefined>(undefined);
  const [bankQuizReturnTarget, setBankQuizReturnTarget] = useState<
    'grade-level' | 'question-bank'
  >('grade-level');

  const handleSplashComplete = useCallback(() => {
    setScreen((current) => {
      if (current !== 'splash') return current;
      if (firebaseUser) {
        return 'home';
      }
      setCountryReturnTarget('auth');
      return 'country';
    });
  }, [firebaseUser]);

  useEffect(() => {
    if (!authReady || screen === 'splash') return;
    if (firebaseUser && screen === 'auth') {
      setScreen('home');
    } else if (!firebaseUser && AUTHENTICATED_SCREENS.includes(screen)) {
      setActiveSectionId(null);
      setActiveStageNumber(null);
      setActiveGradeId(null);
      setActiveBankTier(null);
      setActiveFocusTopic(undefined);
      setScreen('auth');
    }
  }, [authReady, firebaseUser, screen]);

  const handleCountryContinue = () => {
    if (!firebaseUser) {
      setScreen('auth');
      return;
    }
    setScreen(countryReturnTarget === 'settings' ? 'settings' : 'home');
  };

  const handleOpenCountrySelection = (origin: 'auth' | 'home' | 'settings') => {
    setCountryReturnTarget(origin);
    setScreen('country');
  };

  const handleNavigateHubTab = (tab: HubTab) => {
    setActiveSectionId(null);
    setActiveStageNumber(null);
    setActiveGradeId(null);
    setActiveBankTier(null);
    setActiveFocusTopic(undefined);
    setScreen(tab);
  };

  const handleSelectSection = (sectionId: SectionId) => {
    setActiveSectionId(sectionId);
    setActiveStageNumber(null);
    setScreen('section');
  };

  const handleSelectStage = (stageNumber: number) => {
    if (!activeSectionId) return;
    if (!isStageUnlocked(activeSectionId, stageNumber)) {
      return;
    }
    setActiveStageNumber(stageNumber);
    setScreen('stage');
  };

  const handleStartExam = (
    sectionIdOverride?: SectionId,
    origin: 'section' | 'exams' = 'section',
  ) => {
    const targetSectionId = sectionIdOverride ?? activeSectionId;
    if (!targetSectionId) return;
    if (!isExamUnlocked(targetSectionId)) {
      return;
    }
    setActiveSectionId(targetSectionId);
    setActiveStageNumber(null);
    setExamReturnTarget(origin);
    setScreen('exam');
  };

  const handleViewCertificate = (sectionIdOverride?: SectionId) => {
    const targetSectionId = sectionIdOverride ?? activeSectionId;
    if (!targetSectionId) return;
    const secProg = getSectionProgress(targetSectionId);
    if (!secProg?.examPassed || !secProg.certificateId) {
      return;
    }
    setActiveSectionId(targetSectionId);
    setScreen('certificate');
  };

  const handleSelectGrade = (gradeId: GradeId) => {
    setActiveGradeId(gradeId);
    setActiveBankTier(null);
    setActiveFocusTopic(undefined);
    setScreen('grade-level');
  };

  const handleStartBankQuiz = (
    gradeId: GradeId,
    tier: BankDifficultyTier,
    origin: 'grade-level' | 'question-bank',
    focusTopicId?: BankTopicId,
  ) => {
    const safeTier = isBankTierUnlocked(gradeId, tier) ? tier : 'very_easy';
    setActiveGradeId(gradeId);
    setActiveBankTier(safeTier);
    setActiveFocusTopic(focusTopicId);
    setBankQuizReturnTarget(origin);
    setScreen('bank-quiz');
  };

  const showMobileBottomNav = Boolean(firebaseUser && BOTTOM_NAV_SCREENS.includes(screen));

  return (
    <div className="relative min-h-dvh w-full overflow-x-clip">
      <LiquidBackground />
      <AnimatePresence mode="wait">
        {screen === 'splash' && (
          <SplashScreen key="splash" onComplete={handleSplashComplete} />
        )}
        {screen === 'country' && (
          <CountrySelectionScreen
            key="country"
            isReturningUser={Boolean(firebaseUser)}
            onContinue={handleCountryContinue}
          />
        )}
        {screen === 'auth' && (
          <AuthScreen
            key="auth"
            onBackToCountry={() => handleOpenCountrySelection('auth')}
          />
        )}
        {screen === 'home' && (
          <HomeHubScreen
            key="home"
            onChangeCountry={() => handleOpenCountrySelection('home')}
            onNavigate={handleNavigateHubTab}
            onOpenDailyChallenge={() => setScreen('daily')}
            onOpenGeniusChallenges={() => setScreen('genius-challenges')}
          />
        )}
        {screen === 'sections' && (
          <SectionsHubScreen
            key="sections"
            onNavigate={handleNavigateHubTab}
            onSelectSection={handleSelectSection}
          />
        )}
        {screen === 'question-bank' && (
          <QuestionBankHubScreen
            key="question-bank"
            onNavigate={handleNavigateHubTab}
            onSelectGrade={handleSelectGrade}
            onStartAdaptiveQuiz={(gradeId, tier, focusTopic) =>
              handleStartBankQuiz(gradeId, tier, 'question-bank', focusTopic)
            }
            onOpenGeniusChallenges={() => setScreen('genius-challenges')}
          />
        )}
        {screen === 'grade-level' && activeGradeId && (
          <GradeLevelScreen
            key={`grade-${activeGradeId}`}
            gradeId={activeGradeId}
            onBack={() => {
              setActiveGradeId(null);
              setScreen('question-bank');
            }}
            onStartQuiz={(gradeId, tier) =>
              handleStartBankQuiz(gradeId, tier, 'grade-level')
            }
          />
        )}
        {screen === 'bank-quiz' && activeGradeId && activeBankTier && (
          <BankQuizScreen
            key={`bank-quiz-${activeGradeId}-${activeBankTier}-${activeFocusTopic ?? 'all'}`}
            gradeId={activeGradeId}
            tier={activeBankTier}
            focusTopicId={activeFocusTopic}
            onBackToGrade={() => {
              setActiveBankTier(null);
              setActiveFocusTopic(undefined);
              setScreen(bankQuizReturnTarget);
            }}
            onNextTier={(nextTier) => {
              if (isBankTierUnlocked(activeGradeId, nextTier)) {
                setActiveBankTier(nextTier);
                setActiveFocusTopic(undefined);
                setScreen('bank-quiz');
              }
            }}
          />
        )}
        {screen === 'genius-challenges' && (
          <GeniusChallengesScreen
            key="genius-challenges"
            onNavigate={handleNavigateHubTab}
            onBackToBank={() => setScreen('question-bank')}
          />
        )}
        {screen === 'duels' && (
          <DuelsScreen key="duels" onNavigate={handleNavigateHubTab} />
        )}
        {screen === 'daily' && (
          <DailyChallengeScreen
            key="daily"
            onBack={() => setScreen('home')}
          />
        )}
        {screen === 'exams' && (
          <ExamsHubScreen
            key="exams"
            onNavigate={handleNavigateHubTab}
            onStartExam={(sectionId) => handleStartExam(sectionId, 'exams')}
            onOpenSection={handleSelectSection}
            onViewCertificate={(sectionId) => handleViewCertificate(sectionId)}
          />
        )}
        {screen === 'achievements' && (
          <AchievementsScreen
            key="achievements"
            onNavigate={handleNavigateHubTab}
            onViewCertificate={(sectionId) => handleViewCertificate(sectionId)}
            onViewMasterCertificate={() => {
              if (masterCertificate) setScreen('master-certificate');
            }}
            onOpenSection={handleSelectSection}
          />
        )}
        {screen === 'leaderboard' && (
          <LeaderboardScreen
            key="leaderboard"
            onNavigate={handleNavigateHubTab}
          />
        )}
        {screen === 'shop' && (
          <RewardsShopScreen
            key="shop"
            onNavigate={handleNavigateHubTab}
          />
        )}
        {screen === 'profile' && (
          <ProfileScreen
            key="profile"
            onNavigate={handleNavigateHubTab}
            onViewCertificate={(sectionId) => handleViewCertificate(sectionId)}
            onViewMasterCertificate={() => {
              if (masterCertificate) setScreen('master-certificate');
            }}
            onOpenDailyChallenge={() => setScreen('daily')}
            onOpenSection={handleSelectSection}
            onOpenCountrySelection={() => handleOpenCountrySelection('settings')}
          />
        )}
        {screen === 'notifications' && (
          <NotificationsScreen
            key="notifications"
            onNavigate={handleNavigateHubTab}
            onOpenSection={handleSelectSection}
            onOpenDailyChallenge={() => setScreen('daily')}
            onOpenGeniusChallenges={() => setScreen('genius-challenges')}
          />
        )}
        {screen === 'settings' && (
          <SettingsScreen
            key="settings"
            onNavigate={handleNavigateHubTab}
            onOpenCountrySelection={() => handleOpenCountrySelection('settings')}
          />
        )}
        {screen === 'section' && activeSectionId && (
          <SectionDetailScreen
            key={`section-${activeSectionId}`}
            sectionId={activeSectionId}
            onBack={() => {
              setActiveSectionId(null);
              setScreen('sections');
            }}
            onSelectStage={handleSelectStage}
            onStartExam={() => handleStartExam(activeSectionId, 'section')}
            onViewCertificate={() => handleViewCertificate()}
          />
        )}
        {screen === 'stage' && activeSectionId && activeStageNumber !== null && (
          <StagePlayScreen
            key={`stage-${activeSectionId}-${activeStageNumber}`}
            sectionId={activeSectionId}
            stageNumber={activeStageNumber}
            onBackToSection={() => {
              setActiveStageNumber(null);
              setScreen('section');
            }}
            onGoToNextStage={(nextStage) => {
              if (isStageUnlocked(activeSectionId, nextStage)) {
                setActiveStageNumber(nextStage);
                setScreen('stage');
              }
            }}
          />
        )}
        {screen === 'exam' && activeSectionId && (
          <SectionExamScreen
            key={`exam-${activeSectionId}`}
            sectionId={activeSectionId}
            backOrigin={examReturnTarget}
            onBack={() => setScreen(examReturnTarget)}
            onViewCertificate={() => handleViewCertificate()}
          />
        )}
        {screen === 'certificate' && activeSectionId && (
          <CertificateScreen
            key={`cert-${activeSectionId}`}
            sectionId={activeSectionId}
            onBackToSection={() => setScreen('section')}
          />
        )}
        {screen === 'master-certificate' && masterCertificate && (
          <MasterCertificateScreen
            key="master-certificate"
            onBack={() => setScreen('achievements')}
          />
        )}
      </AnimatePresence>

      {showMobileBottomNav && (
        <MobileBottomNav activeScreen={screen} onNavigate={handleNavigateHubTab} />
      )}

      <OfflineIndicator />

      <AnimatePresence>
        {firebaseUser && (celebrationItems.length > 0 || celebrationMasterCert) && (
          <AchievementUnlockModal
            key="achievement-unlock-modal"
            items={celebrationItems}
            masterCertificateIssued={celebrationMasterCert}
            onDismiss={dismissCelebration}
            onViewAchievements={() => setScreen('achievements')}
            onViewMasterCertificate={() => {
              if (masterCertificate) setScreen('master-certificate');
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider>
        <LanguageProvider>
          <AuthProvider>
            <NotificationsProvider>
              <ProgressProvider>
                <QuestionBankProvider>
                  <RewardsProvider>
                    <DuelsProvider>
                      <AppRouter />
                    </DuelsProvider>
                  </RewardsProvider>
                </QuestionBankProvider>
              </ProgressProvider>
            </NotificationsProvider>
          </AuthProvider>
        </LanguageProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
