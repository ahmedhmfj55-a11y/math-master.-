import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  Award,
  Calendar,
  CheckCircle2,
  Clock,
  Flame,
  History,
  Lock,
  Save,
  Sparkles,
  Trophy,
  XCircle,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { LanguageSwitcher } from '@/src/components/ui/LanguageSwitcher';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { MathMasterLogo } from '@/src/components/ui/MathMasterLogo';
import { useAuth } from '@/src/contexts/AuthContext';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useProgress } from '@/src/contexts/ProgressContext';
import {
  DAILY_CHALLENGE_DURATION_SECONDS,
  DAILY_CHALLENGE_PERFECT_BONUS_POINTS,
  DAILY_CHALLENGE_WIN_POINTS,
  buildDailyChallengeForDate,
  getEffectiveActiveStreak,
  getTodayDateKey,
} from '@/src/data/dailyChallengeGenerator';
import { WinCelebration } from '@/src/features/learning/WinCelebration';
import { storageService } from '@/src/services/storageService';
import type {
  DailyChallengeSubmissionResult,
  QuestionReviewItem,
} from '@/src/types/progress';

interface DailyChallengeScreenProps {
  onBack: () => void;
}

type ReviewFilter = 'wrong' | 'all';

function formatTimerMMSS(totalSeconds: number): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const mins = Math.floor(safe / 60);
  const secs = safe % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

function getSecondsUntilLocalMidnight(): number {
  const now = new Date();
  const nextMidnight = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate() + 1,
    0,
    0,
    0,
    0,
  );
  return Math.max(0, Math.floor((nextMidnight.getTime() - now.getTime()) / 1000));
}

function formatHHMMSS(totalSeconds: number): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const hrs = Math.floor(safe / 3600);
  const mins = Math.floor((safe % 3600) / 60);
  const secs = safe % 60;
  return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export function DailyChallengeScreen({ onBack }: DailyChallengeScreenProps) {
  const { language, direction, t } = useLanguage();
  const { firebaseUser } = useAuth();
  const {
    dailyStats,
    dailyHistory,
    todayDailyRecord,
    submitDailyChallenge,
    submittingAttempt,
  } = useProgress();

  const uid = firebaseUser?.uid ?? '';
  const todayKey = useMemo(() => getTodayDateKey(), []);
  const questions = useMemo(() => buildDailyChallengeForDate(todayKey), [todayKey]);

  const [currentIdx, setCurrentIdx] = useState(0);
  const [answers, setAnswers] = useState<number[]>(() => Array(questions.length).fill(-1));
  const [startedAtMs, setStartedAtMs] = useState<number>(() => Date.now());
  const [expiresAtMs, setExpiresAtMs] = useState<number>(
    () => Date.now() + DAILY_CHALLENGE_DURATION_SECONDS * 1000,
  );
  const [remainingSeconds, setRemainingSeconds] = useState<number>(
    DAILY_CHALLENGE_DURATION_SECONDS,
  );
  const [nextChallengeSeconds, setNextChallengeSeconds] = useState<number>(() =>
    getSecondsUntilLocalMidnight(),
  );
  const [validationMsg, setValidationMsg] = useState<string | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [freshResult, setFreshResult] = useState<DailyChallengeSubmissionResult | null>(null);
  const [reviewFilter, setReviewFilter] = useState<ReviewFilter>('wrong');

  const autoSubmitTriggeredRef = useRef(false);
  const draftReadyRef = useRef(false);

  const isCompletedToday = Boolean(freshResult || todayDailyRecord);

  // Build effective completed review data (either freshly submitted or restored from Firestore + device answer cache)
  const completedSummary = useMemo(() => {
    if (freshResult) {
      return {
        score: freshResult.score,
        correctCount: freshResult.correctCount,
        wrongCount: freshResult.wrongCount,
        totalQuestions: freshResult.totalQuestions,
        passed: freshResult.passed,
        perfect: freshResult.perfect,
        pointsAwarded: freshResult.pointsAwarded,
        dailyWinPoints: freshResult.dailyWinPoints,
        perfectBonusPoints: freshResult.perfectBonusPoints,
        durationSeconds: freshResult.durationSeconds,
        timedOut: freshResult.timedOut,
        newlyUnlockedBadge7: freshResult.newlyUnlockedBadge7,
        newlyUnlockedBadge30: freshResult.newlyUnlockedBadge30,
        review: freshResult.review,
      };
    }
    if (!todayDailyRecord) return null;

    const cachedAnswers = uid ? storageService.getDailyCompletedAnswers(uid, todayKey) : null;
    const review: QuestionReviewItem[] | null = cachedAnswers
      ? questions.map((q, idx) => {
          const selectedIndex = cachedAnswers[idx] ?? -1;
          return {
            questionId: q.id,
            promptAr: q.promptAr,
            promptEn: q.promptEn,
            options: q.options,
            selectedIndex,
            correctIndex: q.correctIndex,
            isCorrect: selectedIndex === q.correctIndex,
            explanationAr: q.explanationAr,
            explanationEn: q.explanationEn,
          };
        })
      : null;

    return {
      score: todayDailyRecord.score,
      correctCount: todayDailyRecord.correctCount,
      wrongCount: todayDailyRecord.wrongCount,
      totalQuestions: questions.length,
      passed: todayDailyRecord.passed,
      perfect: todayDailyRecord.perfect,
      pointsAwarded: todayDailyRecord.pointsAwarded,
      dailyWinPoints: todayDailyRecord.passed ? DAILY_CHALLENGE_WIN_POINTS : 0,
      perfectBonusPoints: todayDailyRecord.perfect ? DAILY_CHALLENGE_PERFECT_BONUS_POINTS : 0,
      durationSeconds: todayDailyRecord.durationSeconds,
      timedOut: todayDailyRecord.timedOut,
      newlyUnlockedBadge7: false,
      newlyUnlockedBadge30: false,
      review,
    };
  }, [freshResult, todayDailyRecord, uid, todayKey, questions]);

  const performSubmission = useCallback(
    async (answersSnapshot: number[], durationSec: number, timedOut: boolean) => {
      setSubmitError(null);
      try {
        const res = await submitDailyChallenge(todayKey, answersSnapshot, {
          durationSeconds: durationSec,
          timedOut,
        });
        setFreshResult(res);
        setReviewFilter(res.wrongCount > 0 ? 'wrong' : 'all');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } catch {
        autoSubmitTriggeredRef.current = false;
        setSubmitError(t.errorGeneric);
      }
    },
    [submitDailyChallenge, t.errorGeneric, todayKey],
  );

  // Restore saved 10-minute draft or initialize fresh session if not completed today
  useEffect(() => {
    if (isCompletedToday) {
      if (completedSummary) {
        setReviewFilter(completedSummary.wrongCount > 0 ? 'wrong' : 'all');
      }
      return;
    }

    autoSubmitTriggeredRef.current = false;
    draftReadyRef.current = false;
    setValidationMsg(null);
    setSubmitError(null);

    const now = Date.now();
    const existingDraft = uid ? storageService.getDailyDraft(uid, todayKey) : null;

    if (existingDraft) {
      const rem = Math.max(0, Math.ceil((existingDraft.expiresAtMs - now) / 1000));
      setCurrentIdx(existingDraft.currentIdx);
      setAnswers(existingDraft.answers);
      setStartedAtMs(existingDraft.startedAtMs);
      setExpiresAtMs(existingDraft.expiresAtMs);
      setRemainingSeconds(rem);
      draftReadyRef.current = true;

      if (rem <= 0 && !autoSubmitTriggeredRef.current) {
        autoSubmitTriggeredRef.current = true;
        void performSubmission(
          existingDraft.answers,
          DAILY_CHALLENGE_DURATION_SECONDS,
          true,
        );
      }
    } else {
      const freshAnswers = Array(questions.length).fill(-1);
      const freshStart = now;
      const freshExpiry = freshStart + DAILY_CHALLENGE_DURATION_SECONDS * 1000;
      setCurrentIdx(0);
      setAnswers(freshAnswers);
      setStartedAtMs(freshStart);
      setExpiresAtMs(freshExpiry);
      setRemainingSeconds(DAILY_CHALLENGE_DURATION_SECONDS);
      if (uid) {
        storageService.saveDailyDraft({
          uid,
          dateKey: todayKey,
          startedAtMs: freshStart,
          expiresAtMs: freshExpiry,
          currentIdx: 0,
          answers: freshAnswers,
        });
      }
      draftReadyRef.current = true;
    }
  }, [uid, todayKey, isCompletedToday, questions.length, performSubmission]);

  // Continuously save draft changes
  useEffect(() => {
    if (!uid || !draftReadyRef.current || isCompletedToday) return;
    storageService.saveDailyDraft({
      uid,
      dateKey: todayKey,
      startedAtMs,
      expiresAtMs,
      currentIdx,
      answers,
    });
  }, [uid, todayKey, startedAtMs, expiresAtMs, currentIdx, answers, isCompletedToday]);

  // Drift-proof 1-second active countdown + midnight countdown
  useEffect(() => {
    if (isCompletedToday) {
      const timerId = window.setInterval(() => {
        setNextChallengeSeconds(getSecondsUntilLocalMidnight());
      }, 1000);
      return () => window.clearInterval(timerId);
    }

    if (!draftReadyRef.current) return;
    const tick = () => {
      const rem = Math.max(0, Math.ceil((expiresAtMs - Date.now()) / 1000));
      setRemainingSeconds(rem);
      if (rem <= 0 && !autoSubmitTriggeredRef.current) {
        autoSubmitTriggeredRef.current = true;
        void performSubmission(answers, DAILY_CHALLENGE_DURATION_SECONDS, true);
      }
    };

    const intervalId = window.setInterval(tick, 1000);
    return () => window.clearInterval(intervalId);
  }, [expiresAtMs, isCompletedToday, answers, performSubmission]);

  const answeredCount = useMemo(() => answers.filter((a) => a !== -1).length, [answers]);
  const unansweredCount = questions.length - answeredCount;

  const filteredReview = useMemo(() => {
    if (!completedSummary?.review) return [];
    const indexed = completedSummary.review.map((item, idx) => ({ item, idx }));
    if (reviewFilter === 'wrong') {
      return indexed.filter(({ item }) => !item.isCorrect);
    }
    return indexed;
  }, [completedSummary, reviewFilter]);

  const BackArrow = direction === 'rtl' ? ArrowRight : ArrowLeft;
  const ForwardArrow = direction === 'rtl' ? ArrowLeft : ArrowRight;

  const effectiveStreak = freshResult
    ? freshResult.streakStats.currentStreak
    : getEffectiveActiveStreak(
        dailyStats?.currentStreak ?? 0,
        dailyStats?.lastWonDate,
        todayKey,
      );
  const longestStreak = freshResult
    ? freshResult.streakStats.longestStreak
    : (dailyStats?.longestStreak ?? 0);
  const totalDailyCompleted = freshResult
    ? freshResult.streakStats.totalDailyCompleted
    : (dailyStats?.totalDailyCompleted ?? 0);
  const badge7Unlocked = freshResult
    ? freshResult.streakStats.badge7Unlocked
    : (dailyStats?.badge7Unlocked ?? false);
  const badge30Unlocked = freshResult
    ? freshResult.streakStats.badge30Unlocked
    : (dailyStats?.badge30Unlocked ?? false);

  const handleSelectOption = (optionIndex: number) => {
    setValidationMsg(null);
    setAnswers((prev) => {
      const next = [...prev];
      next[currentIdx] = optionIndex;
      return next;
    });
  };

  const handleJumpNextUnanswered = () => {
    const afterCurrent = answers.findIndex((a, i) => i > currentIdx && a === -1);
    const target = afterCurrent !== -1 ? afterCurrent : answers.findIndex((a) => a === -1);
    if (target !== -1) {
      setValidationMsg(null);
      setCurrentIdx(target);
    }
  };

  const handleSubmitChallenge = async () => {
    if (remainingSeconds > 0) {
      const firstUnanswered = answers.findIndex((a) => a === -1);
      if (firstUnanswered !== -1) {
        setCurrentIdx(firstUnanswered);
        setValidationMsg(t.answerAllPrompt);
        return;
      }
    }
    const elapsedSec = Math.min(
      DAILY_CHALLENGE_DURATION_SECONDS,
      Math.max(1, Math.round((Date.now() - startedAtMs) / 1000)),
    );
    await performSubmission(answers, elapsedSec, remainingSeconds <= 0);
  };

  const currentQ = questions[currentIdx];
  const isCriticalTime = remainingSeconds <= 60;
  const isLowTime = remainingSeconds <= 180;

  const getDifficultyStyle = (diff: 'easy' | 'medium' | 'hard') => {
    if (diff === 'easy') {
      return {
        label: t.dailyDiffEasy,
        cls: 'bg-emerald-500/20 border-emerald-400/35 text-emerald-200',
      };
    }
    if (diff === 'medium') {
      return {
        label: t.dailyDiffMedium,
        cls: 'bg-amber-500/20 border-amber-400/35 text-amber-200',
      };
    }
    return {
      label: t.dailyDiffHard,
      cls: 'bg-rose-500/20 border-rose-400/35 text-rose-200',
    };
  };

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="min-h-screen flex flex-col px-4 py-5 sm:px-8 sm:py-7 max-w-4xl mx-auto w-full gap-6 pb-14"
    >
      {/* Top Bar */}
      <header className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={onBack}
          className="liquid-glass-subtle min-h-[44px] px-4 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white hover:bg-white/10 inline-flex items-center gap-2 whitespace-nowrap shrink-0 transition-colors"
        >
          <BackArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{t.backToDashboard}</span>
        </button>

        <div className="hidden sm:flex items-center gap-2.5 shrink-0">
          <MathMasterLogo size="sm" />
          <span className="font-display text-sm font-bold text-white">{t.dailyCardTitle}</span>
        </div>

        <LanguageSwitcher />
      </header>

      {/* Daily Header Card + Live Timer / Midnight Countdown */}
      <LiquidGlassCard className="p-5 sm:p-7 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 border border-white/25 flex items-center justify-center text-white shrink-0 shadow-[0_0_24px_rgba(245,158,11,0.35)]">
            <Flame className="w-6 h-6" aria-hidden="true" />
          </div>
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-amber-200 font-math tabular-nums">
              <Calendar className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              <span>{todayKey}</span>
              <span aria-hidden="true">·</span>
              <span>
                {t.dailyStreakLabel}: {t.dailyStreakDaysValue(effectiveStreak)}
              </span>
            </div>
            <h1 className="font-display text-xl sm:text-2xl font-bold text-white">
              {t.dailyCardTitle}
            </h1>
            {!isCompletedToday && (
              <div className="text-[11px] font-medium text-emerald-300/90 inline-flex items-center gap-1.5">
                <Save className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                <span>{t.examAutoSavedNotice}</span>
              </div>
            )}
          </div>
        </div>

        {!isCompletedToday ? (
          <div
            aria-live="polite"
            className={`px-4 py-2.5 rounded-2xl border flex items-center gap-3 self-start sm:self-center shrink-0 transition-colors ${
              isCriticalTime
                ? 'bg-rose-500/20 border-rose-400/50 text-rose-100 animate-pulse'
                : isLowTime
                  ? 'bg-amber-500/20 border-amber-400/45 text-amber-100'
                  : 'bg-white/[0.06] border-white/15 text-white'
            }`}
          >
            <Clock
              className={`w-5 h-5 shrink-0 ${
                isCriticalTime ? 'text-rose-300' : isLowTime ? 'text-amber-300' : 'text-blue-300'
              }`}
              aria-hidden="true"
            />
            <div>
              <div className="text-[11px] opacity-80 leading-none mb-1">{t.dailyTimerTitle}</div>
              <div dir="ltr" className="font-math text-xl font-extrabold tabular-nums leading-none">
                {formatTimerMMSS(remainingSeconds)}
              </div>
            </div>
          </div>
        ) : (
          <div className="px-4 py-2.5 rounded-2xl bg-white/[0.05] border border-white/15 flex items-center gap-3 self-start sm:self-center shrink-0">
            <Clock className="w-5 h-5 text-blue-300 shrink-0" aria-hidden="true" />
            <div>
              <div className="text-[11px] text-slate-300 leading-none mb-1">
                {t.dailyNextChallengeLabel}
              </div>
              <div dir="ltr" className="font-math text-lg font-extrabold text-white tabular-nums leading-none">
                {formatHHMMSS(nextChallengeSeconds)}
              </div>
            </div>
          </div>
        )}
      </LiquidGlassCard>

      {/* ACTIVE 10-QUESTION DAILY CHALLENGE RUNNER */}
      {!isCompletedToday && currentQ && (
        <div className="space-y-5">
          {/* Question Navigator */}
          <LiquidGlassCard variant="subtle" className="p-4 sm:p-5 space-y-3.5">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-medium">
              <span className="font-math tabular-nums text-slate-200">
                {t.questionCounterLabel(currentIdx + 1, questions.length)}
              </span>

              <div className="flex flex-wrap items-center gap-2">
                <span
                  className={`font-math tabular-nums px-2.5 py-1 rounded-lg border ${
                    unansweredCount > 0
                      ? 'bg-amber-500/15 border-amber-400/35 text-amber-200'
                      : 'bg-emerald-500/15 border-emerald-400/35 text-emerald-200'
                  }`}
                >
                  {t.examUnansweredCountLabel(unansweredCount)}
                </span>

                {unansweredCount > 0 && (
                  <button
                    type="button"
                    onClick={handleJumpNextUnanswered}
                    className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/15 border border-white/15 text-blue-200 font-semibold transition-colors"
                  >
                    {t.examJumpUnansweredBtn}
                  </button>
                )}
              </div>
            </div>

            <div className="grid grid-cols-5 sm:grid-cols-10 gap-2">
              {questions.map((q, idx) => {
                const active = idx === currentIdx;
                const answered = answers[idx] !== -1;
                return (
                  <button
                    key={q.id}
                    type="button"
                    onClick={() => {
                      setValidationMsg(null);
                      setCurrentIdx(idx);
                    }}
                    className={`min-h-[40px] rounded-xl text-xs font-bold font-math tabular-nums border transition-all ${
                      active
                        ? 'bg-gradient-to-br from-blue-500 to-violet-600 border-white/50 text-white shadow-[0_0_12px_rgba(99,102,241,0.45)]'
                        : answered
                          ? 'bg-emerald-500/20 border-emerald-400/40 text-emerald-200 hover:bg-emerald-500/30'
                          : 'bg-amber-500/[0.08] border-amber-400/30 text-amber-100 hover:bg-amber-500/20'
                    }`}
                  >
                    {idx + 1}
                  </button>
                );
              })}
            </div>
          </LiquidGlassCard>

          {/* Active Question Card */}
          <LiquidGlassCard className="p-6 sm:p-8 space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-medium">
              <div className="flex items-center gap-2">
                <span
                  className={`px-2.5 py-1 rounded-lg border font-semibold ${
                    getDifficultyStyle(currentQ.difficulty).cls
                  }`}
                >
                  {getDifficultyStyle(currentQ.difficulty).label}
                </span>
                <span className="text-blue-200 font-semibold">
                  {language === 'ar' ? currentQ.topicAr : currentQ.topicEn}
                </span>
              </div>

              <span className="font-math tabular-nums text-slate-300">
                {t.answeredCountLabel(answeredCount, questions.length)}
              </span>
            </div>

            <h2 className="font-display text-lg sm:text-xl font-bold text-white leading-relaxed">
              {language === 'ar' ? currentQ.promptAr : currentQ.promptEn}
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {currentQ.options.map((opt, optIdx) => {
                const selected = answers[currentIdx] === optIdx;
                const letters = ['A', 'B', 'C', 'D'];
                return (
                  <button
                    key={`${currentQ.id}-opt-${optIdx}`}
                    type="button"
                    onClick={() => handleSelectOption(optIdx)}
                    className={`min-h-[56px] p-4 rounded-2xl border text-start flex items-center gap-3 transition-all ${
                      selected
                        ? 'bg-gradient-to-r from-blue-500/30 to-violet-600/30 border-blue-300/70 text-white shadow-[0_0_24px_rgba(99,102,241,0.3)]'
                        : 'bg-white/[0.045] hover:bg-white/[0.09] border-white/12 text-slate-100'
                    }`}
                  >
                    <span
                      className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold font-math shrink-0 border ${
                        selected
                          ? 'bg-blue-400 text-slate-950 border-white/40'
                          : 'bg-white/10 text-slate-300 border-white/15'
                      }`}
                    >
                      {letters[optIdx]}
                    </span>
                    <span dir="auto" className="text-sm sm:text-base font-semibold font-math break-words">
                      {opt}
                    </span>
                  </button>
                );
              })}
            </div>

            {validationMsg && (
              <div
                role="alert"
                className="p-3.5 rounded-2xl bg-amber-500/15 border border-amber-400/35 text-xs sm:text-sm text-amber-100 flex items-center gap-2"
              >
                <AlertTriangle className="w-4 h-4 text-amber-300 shrink-0" aria-hidden="true" />
                <span>{validationMsg}</span>
              </div>
            )}

            {submitError && (
              <div
                role="alert"
                className="p-3.5 rounded-2xl bg-rose-500/15 border border-rose-400/35 text-xs sm:text-sm text-rose-100 flex items-center justify-between gap-3"
              >
                <span>{submitError}</span>
                <button
                  type="button"
                  onClick={() => void handleSubmitChallenge()}
                  className="px-3 py-1.5 rounded-xl bg-rose-500/30 hover:bg-rose-500/40 text-xs font-semibold text-white shrink-0"
                >
                  {t.retryStageBtn}
                </button>
              </div>
            )}

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-white/10">
              <button
                type="button"
                disabled={currentIdx === 0}
                onClick={() => setCurrentIdx((i) => Math.max(0, i - 1))}
                className="liquid-glass-subtle min-h-[44px] px-4 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white disabled:opacity-40 disabled:cursor-not-allowed inline-flex items-center gap-2 whitespace-nowrap shrink-0"
              >
                <BackArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{t.prevQuestionBtn}</span>
              </button>

              {currentIdx < questions.length - 1 ? (
                <button
                  type="button"
                  onClick={() => setCurrentIdx((i) => Math.min(questions.length - 1, i + 1))}
                  className="liquid-glass-button min-h-[44px] px-5 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center gap-2 whitespace-nowrap shrink-0"
                >
                  <span>{t.nextQuestionBtn}</span>
                  <ForwardArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
                </button>
              ) : (
                <button
                  type="button"
                  disabled={submittingAttempt}
                  onClick={() => void handleSubmitChallenge()}
                  className="liquid-glass-button min-h-[46px] px-6 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white disabled:opacity-60 inline-flex items-center gap-2 whitespace-nowrap shrink-0"
                >
                  <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>{submittingAttempt ? t.submittingQuizBtn : t.submitQuizBtn}</span>
                </button>
              )}
            </div>
          </LiquidGlassCard>
        </div>
      )}

      {/* DAILY CHALLENGE RESULT + CELEBRATION + MISTAKE EXPLANATIONS */}
      {isCompletedToday && completedSummary && (
        <div className="space-y-6">
          {completedSummary.timedOut && (
            <LiquidGlassCard
              variant="subtle"
              className="p-4 border-amber-400/40 bg-amber-500/10 flex items-center gap-3 text-xs sm:text-sm text-amber-100"
            >
              <Clock className="w-5 h-5 text-amber-300 shrink-0" aria-hidden="true" />
              <span>{t.dailyTimeoutAutoSubmittedMsg}</span>
            </LiquidGlassCard>
          )}

          <LiquidGlassCard
            className={`p-6 sm:p-9 text-center space-y-6 ${
              completedSummary.passed
                ? 'ring-1 ring-emerald-400/45 shadow-[0_0_40px_rgba(16,185,129,0.22)]'
                : 'ring-1 ring-rose-400/35'
            }`}
          >
            <WinCelebration
              stars={completedSummary.perfect ? 3 : completedSummary.passed ? 2 : 0}
              passed={completedSummary.passed}
            />

            <div className="space-y-2">
              <div
                className={`inline-flex items-center gap-2 text-sm font-bold ${
                  completedSummary.passed ? 'text-emerald-300' : 'text-rose-300'
                }`}
              >
                {completedSummary.passed ? (
                  <CheckCircle2 className="w-5 h-5 shrink-0" aria-hidden="true" />
                ) : (
                  <XCircle className="w-5 h-5 shrink-0" aria-hidden="true" />
                )}
                <span>{completedSummary.passed ? t.dailyPassedTitle : t.dailyFailedTitle}</span>
              </div>

              <div className="font-math text-4xl sm:text-5xl font-extrabold text-white tabular-nums">
                {completedSummary.score} <span className="text-xl text-slate-400">/ 100</span>
              </div>

              <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto">
                {completedSummary.passed ? t.dailyPassedSubtitle : t.dailyFailedSubtitle}
              </p>
            </div>

            {/* Correct / Wrong / Duration Tiles */}
            <div className="grid grid-cols-3 gap-3 max-w-lg mx-auto">
              <div className="p-3 rounded-2xl bg-emerald-500/12 border border-emerald-400/30">
                <div className="text-[11px] text-emerald-200">{t.examCorrectCountLabel}</div>
                <div className="font-math text-xl font-extrabold text-white tabular-nums mt-0.5">
                  {completedSummary.correctCount}
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-rose-500/12 border border-rose-400/30">
                <div className="text-[11px] text-rose-200">{t.examWrongCountLabel}</div>
                <div className="font-math text-xl font-extrabold text-white tabular-nums mt-0.5">
                  {completedSummary.wrongCount}
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-white/[0.05] border border-white/15">
                <div className="text-[11px] text-slate-300">{t.examTimeSpentLabel}</div>
                <div dir="ltr" className="font-math text-xl font-extrabold text-blue-200 tabular-nums mt-0.5">
                  {formatTimerMMSS(completedSummary.durationSeconds)}
                </div>
              </div>
            </div>

            {/* Rewards & Milestone Badges Earned */}
            <div className="flex flex-wrap items-center justify-center gap-2.5">
              {completedSummary.dailyWinPoints > 0 && (
                <div className="px-4 py-2 rounded-2xl bg-emerald-500/20 border border-emerald-400/35 text-xs font-semibold text-emerald-200 inline-flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-emerald-300" aria-hidden="true" />
                  <span>{t.dailyRewardWinBadge(completedSummary.dailyWinPoints)}</span>
                </div>
              )}

              {completedSummary.perfectBonusPoints > 0 && (
                <div className="px-4 py-2 rounded-2xl bg-amber-500/20 border border-amber-400/40 text-xs font-semibold text-amber-100 inline-flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-300" aria-hidden="true" />
                  <span>{t.dailyRewardPerfectBadge(completedSummary.perfectBonusPoints)}</span>
                </div>
              )}

              {completedSummary.newlyUnlockedBadge7 && (
                <div className="px-4 py-2 rounded-2xl bg-violet-500/25 border border-violet-300/50 text-xs font-bold text-violet-100 inline-flex items-center gap-1.5">
                  <Award className="w-4 h-4 text-amber-300" aria-hidden="true" />
                  <span>{t.dailyBadge7Title}</span>
                </div>
              )}

              {completedSummary.newlyUnlockedBadge30 && (
                <div className="px-4 py-2 rounded-2xl bg-amber-500/25 border border-amber-300/60 text-xs font-bold text-amber-100 inline-flex items-center gap-1.5">
                  <Trophy className="w-4 h-4 text-amber-300" aria-hidden="true" />
                  <span>{t.dailyBadge30Title}</span>
                </div>
              )}
            </div>

            <div className="p-3.5 rounded-2xl bg-white/[0.04] border border-white/10 text-xs sm:text-sm text-blue-100 max-w-xl mx-auto">
              {t.dailyAlreadyDoneNotice}
            </div>
          </LiquidGlassCard>

          {/* Answer Review & Wrong Question Explanations */}
          {completedSummary.review ? (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-1">
                <h2 className="font-display text-lg font-bold text-white">
                  {t.resultReviewHeading}
                </h2>

                <div
                  role="tablist"
                  aria-label="Daily challenge review filter"
                  className="inline-flex items-center gap-1.5 p-1 rounded-2xl liquid-glass-subtle self-start sm:self-auto"
                >
                  <button
                    type="button"
                    role="tab"
                    aria-selected={reviewFilter === 'wrong'}
                    onClick={() => setReviewFilter('wrong')}
                    className={`min-h-[36px] px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                      reviewFilter === 'wrong'
                        ? 'bg-rose-500/75 text-white shadow-sm'
                        : 'text-slate-300 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    {t.examReviewFilterWrong(completedSummary.wrongCount)}
                  </button>
                  <button
                    type="button"
                    role="tab"
                    aria-selected={reviewFilter === 'all'}
                    onClick={() => setReviewFilter('all')}
                    className={`min-h-[36px] px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                      reviewFilter === 'all'
                        ? 'bg-gradient-to-r from-blue-500/80 to-violet-600/80 text-white shadow-sm'
                        : 'text-slate-300 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    {t.examReviewFilterAll(completedSummary.totalQuestions)}
                  </button>
                </div>
              </div>

              {filteredReview.length === 0 ? (
                <LiquidGlassCard variant="subtle" className="p-6 text-center space-y-2 border-emerald-400/35">
                  <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" aria-hidden="true" />
                  <div className="font-display text-base font-bold text-white">
                    {t.examReviewNoWrongTitle}
                  </div>
                </LiquidGlassCard>
              ) : (
                filteredReview.map(({ item, idx }) => {
                  const qMeta = questions[idx];
                  const diff = qMeta ? getDifficultyStyle(qMeta.difficulty) : null;
                  return (
                    <LiquidGlassCard
                      key={item.questionId}
                      variant="subtle"
                      className={`p-5 space-y-3 ${
                        item.isCorrect ? 'border-emerald-400/30' : 'border-rose-400/30'
                      }`}
                    >
                      <div className="flex items-start gap-2.5">
                        <span className="mt-0.5 shrink-0">
                          {item.isCorrect ? (
                            <CheckCircle2 className="w-5 h-5 text-emerald-400" aria-hidden="true" />
                          ) : (
                            <XCircle className="w-5 h-5 text-rose-400" aria-hidden="true" />
                          )}
                        </span>
                        <div className="space-y-1.5">
                          <div className="flex flex-wrap items-center gap-2 text-[11px]">
                            {diff && (
                              <span className={`px-2 py-0.5 rounded-md border font-semibold ${diff.cls}`}>
                                {diff.label}
                              </span>
                            )}
                            {qMeta && (
                              <span className="text-blue-200 font-medium">
                                {language === 'ar' ? qMeta.topicAr : qMeta.topicEn}
                              </span>
                            )}
                          </div>
                          <p className="text-sm sm:text-base font-semibold text-white leading-relaxed">
                            <span className="font-math text-slate-400 me-1.5">{idx + 1}.</span>
                            {language === 'ar' ? item.promptAr : item.promptEn}
                          </p>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs sm:text-sm">
                        <div
                          className={`p-3 rounded-xl border ${
                            item.isCorrect
                              ? 'bg-emerald-500/15 border-emerald-400/30 text-emerald-100'
                              : 'bg-rose-500/15 border-rose-400/30 text-rose-100'
                          }`}
                        >
                          <span className="block text-[11px] opacity-80 mb-0.5">
                            {t.resultYourAnswerLabel}
                          </span>
                          <span dir="auto" className="font-math font-bold">
                            {item.selectedIndex >= 0
                              ? item.options[item.selectedIndex]
                              : t.examNotAnsweredLabel}
                          </span>
                        </div>

                        <div className="p-3 rounded-xl bg-emerald-500/12 border border-emerald-400/25 text-emerald-100">
                          <span className="block text-[11px] opacity-80 mb-0.5">
                            {t.resultCorrectAnswerLabel}
                          </span>
                          <span dir="auto" className="font-math font-bold">
                            {item.options[item.correctIndex]}
                          </span>
                        </div>
                      </div>

                      <div className="p-3.5 rounded-xl bg-white/[0.035] border border-white/10 text-xs sm:text-sm text-slate-200 leading-relaxed">
                        <span className="font-semibold text-blue-200 me-1.5">
                          {t.resultExplanationLabel}:
                        </span>
                        {language === 'ar' ? item.explanationAr : item.explanationEn}
                      </div>
                    </LiquidGlassCard>
                  );
                })
              )}
            </div>
          ) : (
            <LiquidGlassCard variant="subtle" className="p-5 text-xs sm:text-sm text-slate-300">
              {t.dailyNoReviewCacheNotice}
            </LiquidGlassCard>
          )}
        </div>
      )}

      {/* Streak Stats & Milestone Badges (7-Day & 30-Day) */}
      <LiquidGlassCard variant="subtle" className="p-5 sm:p-6 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="font-display text-lg font-bold text-white flex items-center gap-2">
            <Flame className="w-5 h-5 text-amber-400" aria-hidden="true" />
            <span>{t.dailyStreakTitle}</span>
          </h2>

          <div className="flex flex-wrap items-center gap-3 text-xs sm:text-sm">
            <span className="px-3 py-1.5 rounded-xl bg-amber-500/15 border border-amber-400/30 text-amber-200 font-semibold font-math tabular-nums">
              {t.dailyStreakLabel}: {t.dailyStreakDaysValue(effectiveStreak)}
            </span>
            <span className="px-3 py-1.5 rounded-xl bg-white/[0.05] border border-white/15 text-slate-200 font-semibold font-math tabular-nums">
              {t.dailyLongestStreakLabel}: {t.dailyStreakDaysValue(longestStreak)}
            </span>
            <span className="px-3 py-1.5 rounded-xl bg-blue-500/15 border border-blue-400/30 text-blue-200 font-semibold font-math tabular-nums">
              {t.dailyTotalCompletedLabel}: {totalDailyCompleted}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* 7-Day Milestone Badge */}
          <div
            className={`p-4 rounded-2xl border flex items-start gap-3.5 ${
              badge7Unlocked
                ? 'bg-gradient-to-br from-violet-500/20 to-blue-500/20 border-violet-300/45'
                : 'bg-white/[0.03] border-white/10'
            }`}
          >
            <div
              className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 border ${
                badge7Unlocked
                  ? 'bg-violet-500/30 border-violet-300/60 text-amber-300'
                  : 'bg-white/5 border-white/15 text-slate-500'
              }`}
            >
              {badge7Unlocked ? <Award className="w-5 h-5" /> : <Lock className="w-5 h-5" />}
            </div>
            <div className="space-y-1.5 flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <h3 className="text-sm font-bold text-white truncate">{t.dailyBadge7Title}</h3>
                <span
                  className={`text-[11px] font-semibold shrink-0 ${
                    badge7Unlocked ? 'text-emerald-300' : 'text-slate-400'
                  }`}
                >
                  {badge7Unlocked
                    ? t.dailyBadgeUnlockedLabel
                    : t.dailyBadgeLockedProgress(longestStreak, 7)}
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">{t.dailyBadge7Desc}</p>
              <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-violet-400 to-blue-400 transition-all"
                  style={{ width: `${Math.min(100, Math.round((longestStreak / 7) * 100))}%` }}
                />
              </div>
            </div>
          </div>

          {/* 30-Day Milestone Badge */}
          <div
            className={`p-4 rounded-2xl border flex items-start gap-3.5 ${
              badge30Unlocked
                ? 'bg-gradient-to-br from-amber-500/25 to-orange-500/20 border-amber-300/50'
                : 'bg-white/[0.03] border-white/10'
            }`}
          >
            <div
              className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 border ${
                badge30Unlocked
                  ? 'bg-amber-500/30 border-amber-300/60 text-amber-200'
                  : 'bg-white/5 border-white/15 text-slate-500'
              }`}
            >
              {badge30Unlocked ? <Trophy className="w-5 h-5" /> : <Lock className="w-5 h-5" />}
            </div>
            <div className="space-y-1.5 flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <h3 className="text-sm font-bold text-white truncate">{t.dailyBadge30Title}</h3>
                <span
                  className={`text-[11px] font-semibold shrink-0 ${
                    badge30Unlocked ? 'text-emerald-300' : 'text-slate-400'
                  }`}
                >
                  {badge30Unlocked
                    ? t.dailyBadgeUnlockedLabel
                    : t.dailyBadgeLockedProgress(longestStreak, 30)}
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">{t.dailyBadge30Desc}</p>
              <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-amber-400 to-orange-400 transition-all"
                  style={{ width: `${Math.min(100, Math.round((longestStreak / 30) * 100))}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </LiquidGlassCard>

      {/* Past Daily Challenges History */}
      <div className="space-y-3">
        <h2 className="font-display text-lg font-bold text-white flex items-center gap-2 px-1">
          <History className="w-5 h-5 text-blue-300" aria-hidden="true" />
          <span>{t.dailyHistoryTitle}</span>
        </h2>

        {dailyHistory.length === 0 ? (
          <LiquidGlassCard variant="subtle" className="p-6 text-sm text-slate-300">
            {t.dailyHistoryEmpty}
          </LiquidGlassCard>
        ) : (
          <LiquidGlassCard variant="subtle" className="divide-y divide-white/10 overflow-hidden">
            {dailyHistory.slice(0, 30).map((record) => (
              <div
                key={record.dateKey}
                className="p-4 flex flex-wrap items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3 min-w-0">
                  {record.passed ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" aria-hidden="true" />
                  ) : (
                    <XCircle className="w-5 h-5 text-rose-400 shrink-0" aria-hidden="true" />
                  )}
                  <div className="space-y-0.5">
                    <div className="text-sm font-bold text-white font-math tabular-nums">
                      {record.dateKey}
                    </div>
                    <div className="text-xs text-slate-400 font-math tabular-nums">
                      {t.resultCorrectOutOf(record.correctCount, 10)} · {formatTimerMMSS(record.durationSeconds)}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 font-math tabular-nums">
                  {record.pointsAwarded > 0 && (
                    <span className="px-2.5 py-1 rounded-lg bg-emerald-500/20 border border-emerald-400/35 text-xs font-bold text-emerald-200">
                      +{record.pointsAwarded} {t.leaderboardPointsUnit}
                    </span>
                  )}
                  <span
                    className={`text-base font-extrabold ${
                      record.passed ? 'text-emerald-300' : 'text-rose-300'
                    }`}
                  >
                    {record.score}/100
                  </span>
                </div>
              </div>
            ))}
          </LiquidGlassCard>
        )}
      </div>
    </motion.section>
  );
}
