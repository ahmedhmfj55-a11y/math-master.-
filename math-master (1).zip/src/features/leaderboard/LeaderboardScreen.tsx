import { Award, CheckCircle2, Crown, Medal, Radio, Sparkles, Trophy } from 'lucide-react';
import { motion } from 'motion/react';
import { useEffect, useMemo, useState } from 'react';
import { AppTopBar, type HubTab } from '@/src/components/ui/AppTopBar';
import { AvatarDisplay } from '@/src/components/ui/AvatarDisplay';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { useAuth } from '@/src/contexts/AuthContext';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useNotifications } from '@/src/contexts/NotificationsContext';
import { findCountryByCode } from '@/src/data/countries';
import { getRewardById } from '@/src/data/rewardsCatalog';
import { leaderboardService } from '@/src/services/leaderboardService';
import type { LeaderboardEntry } from '@/src/types/rewards';

interface LeaderboardScreenProps {
  onNavigate: (tab: HubTab) => void;
}

export function LeaderboardScreen({ onNavigate }: LeaderboardScreenProps) {
  const { language, t } = useLanguage();
  const { firebaseUser, userProfile } = useAuth();
  const { evaluateRankProgress } = useNotifications();
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [fallbackRank, setFallbackRank] = useState<number | null>(null);

  useEffect(() => {
    if (!firebaseUser) return;
    setLoading(true);
    setErrorMsg(null);

    const unsubscribe = leaderboardService.subscribeTopLeaderboard(
      100,
      (data) => {
        setEntries(data);
        setLoading(false);
      },
      () => {
        setErrorMsg(t.errorGeneric);
        setLoading(false);
      },
    );

    return () => unsubscribe();
  }, [firebaseUser, t.errorGeneric]);

  const currentUserEarned = userProfile?.totalEarnedPoints ?? userProfile?.points ?? 0;

  const userIndexInTop100 = useMemo(() => {
    if (!firebaseUser) return -1;
    return entries.findIndex((e) => e.uid === firebaseUser.uid);
  }, [entries, firebaseUser]);

  useEffect(() => {
    if (!firebaseUser) return;
    if (userIndexInTop100 !== -1) {
      setFallbackRank(userIndexInTop100 + 1);
      return;
    }
    let cancelled = false;
    void leaderboardService
      .fetchUserGlobalRank(currentUserEarned)
      .then((rank) => {
        if (!cancelled) setFallbackRank(rank);
      })
      .catch(() => {
        if (!cancelled) setFallbackRank(null);
      });
    return () => {
      cancelled = true;
    };
  }, [firebaseUser, userIndexInTop100, currentUserEarned]);

  const currentRank = userIndexInTop100 !== -1 ? userIndexInTop100 + 1 : fallbackRank;

  useEffect(() => {
    if (currentRank && currentRank > 0) {
      void evaluateRankProgress(currentRank);
    }
  }, [currentRank, evaluateRankProgress]);

  const topThree = entries.slice(0, 3);
  const restEntries = entries.slice(3);

  const renderPodiumOrder = () => {
    if (topThree.length === 3) {
      // Visual podium order on md+: Rank 2 (left), Rank 1 (center elevated), Rank 3 (right)
      return [
        { entry: topThree[1], rank: 2, orderClass: 'md:order-1 md:mt-6' },
        { entry: topThree[0], rank: 1, orderClass: 'md:order-2' },
        { entry: topThree[2], rank: 3, orderClass: 'md:order-3 md:mt-8' },
      ];
    }
    return topThree.map((entry, idx) => ({
      entry,
      rank: idx + 1,
      orderClass: '',
    }));
  };

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="min-h-dvh flex flex-col px-4 py-5 sm:px-8 sm:py-7 max-w-6xl mx-auto w-full gap-6 safe-pb-nav"
    >
      <AppTopBar activeTab="leaderboard" onNavigate={onNavigate} />

      {/* Header & Current User Global Standing */}
      <LiquidGlassCard className="p-6 sm:p-8 space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-blue-200">
              <Radio className="w-4 h-4 text-emerald-300 shrink-0" aria-hidden="true" />
              <span>{t.leaderboardLiveBadge}</span>
            </div>
            <h1 className="font-display text-2xl sm:text-3xl font-bold text-white text-balance">
              {t.leaderboardTitle}
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              {t.leaderboardSubtitle}
            </p>
          </div>

          {/* Current User Rank Highlight Box */}
          {userProfile && (
            <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-blue-500/20 to-violet-600/20 border border-blue-400/35 flex items-center gap-4 shrink-0">
              <AvatarDisplay
                avatarId={userProfile.equippedAvatarId}
                photoUrl={userProfile.photoUrl}
                displayName={userProfile.displayName}
                size="md"
              />
              <div className="space-y-0.5 min-w-0">
                <div className="text-[11px] font-medium text-blue-200">
                  {t.leaderboardYourRankLabel}
                </div>
                <div className="flex items-baseline gap-2.5">
                  <span className="font-math text-2xl font-extrabold text-white tabular-nums">
                    {currentRank ? `#${currentRank}` : '—'}
                  </span>
                  <span className="text-xs text-slate-300 font-math tabular-nums">
                    {currentUserEarned} {t.leaderboardPointsUnit}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      </LiquidGlassCard>

      {errorMsg && (
        <LiquidGlassCard variant="subtle" className="p-5 border-rose-400/35 text-sm text-rose-200">
          {errorMsg}
        </LiquidGlassCard>
      )}

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[1, 2, 3].map((n) => (
            <div
              key={n}
              className="h-48 rounded-3xl liquid-glass-subtle animate-pulse bg-white/[0.04]"
            />
          ))}
        </div>
      ) : entries.length === 0 ? (
        <LiquidGlassCard variant="subtle" className="p-10 text-center space-y-3">
          <Trophy className="w-10 h-10 text-amber-300 mx-auto" aria-hidden="true" />
          <h2 className="font-display text-lg font-bold text-white">{t.leaderboardEmptyTitle}</h2>
          <p className="text-sm text-slate-300 max-w-md mx-auto">{t.leaderboardEmptySubtitle}</p>
        </LiquidGlassCard>
      ) : (
        <div className="space-y-6">
          {/* Top 3 Luminous Podium */}
          <div className="space-y-3">
            <h2 className="font-display text-lg font-bold text-white flex items-center gap-2 px-1">
              <Crown className="w-5 h-5 text-amber-300" aria-hidden="true" />
              <span>{t.leaderboardPodiumTitle}</span>
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-stretch">
              {renderPodiumOrder().map(({ entry, rank, orderClass }) => {
                const country = findCountryByCode(entry.countryCode);
                const equippedTitle = getRewardById(entry.titleId);
                const equippedBadge = getRewardById(entry.badgeId);
                const isCurrentUser = firebaseUser?.uid === entry.uid;

                const rankStyles =
                  rank === 1
                    ? 'border-amber-300/50 bg-gradient-to-b from-amber-500/20 via-violet-500/10 to-blue-600/15 shadow-[0_0_40px_rgba(251,191,36,0.22)]'
                    : rank === 2
                      ? 'border-sky-300/40 bg-gradient-to-b from-sky-400/15 to-blue-600/10 shadow-[0_0_28px_rgba(56,189,248,0.16)]'
                      : 'border-violet-300/40 bg-gradient-to-b from-violet-500/15 to-indigo-600/10 shadow-[0_0_28px_rgba(139,92,246,0.16)]';

                const rankBadgeColor =
                  rank === 1
                    ? 'bg-amber-400/25 text-amber-200 border-amber-300/50'
                    : rank === 2
                      ? 'bg-sky-400/20 text-sky-200 border-sky-300/40'
                      : 'bg-violet-400/20 text-violet-200 border-violet-300/40';

                return (
                  <LiquidGlassCard
                    key={entry.uid}
                    className={`p-6 flex flex-col items-center text-center gap-3.5 ${rankStyles} ${
                      isCurrentUser ? 'ring-2 ring-blue-300/60' : ''
                    } ${orderClass}`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span
                        className={`px-3 py-1 rounded-xl text-xs font-bold font-math border inline-flex items-center gap-1.5 ${rankBadgeColor}`}
                      >
                        {rank === 1 ? (
                          <Crown className="w-3.5 h-3.5" aria-hidden="true" />
                        ) : (
                          <Medal className="w-3.5 h-3.5" aria-hidden="true" />
                        )}
                        <span>#{rank}</span>
                      </span>

                      {country && (
                        <span className="text-lg" title={language === 'ar' ? country.nameAr : country.nameEn}>
                          {country.flag}
                        </span>
                      )}
                    </div>

                    <div className="relative">
                      <AvatarDisplay
                        avatarId={entry.avatarId}
                        photoUrl={entry.photoUrl}
                        displayName={entry.displayName}
                        size="lg"
                      />
                      {equippedBadge && (
                        <span
                          title={language === 'ar' ? equippedBadge.nameAr : equippedBadge.nameEn}
                          className={`absolute -bottom-1 -end-1 w-7 h-7 rounded-xl bg-gradient-to-br ${equippedBadge.accentFrom} ${equippedBadge.accentTo} border border-white/40 flex items-center justify-center text-xs font-bold text-white shadow-lg`}
                        >
                          {equippedBadge.symbol}
                        </span>
                      )}
                    </div>

                    <div className="space-y-1 min-w-0 w-full">
                      <div className="flex items-center justify-center gap-1.5">
                        <h3 className="font-display text-base sm:text-lg font-bold text-white truncate">
                          {entry.displayName}
                        </h3>
                        {isCurrentUser && (
                          <span className="text-[11px] font-semibold text-blue-200">
                            ({t.leaderboardYouTag})
                          </span>
                        )}
                      </div>

                      {equippedTitle && (
                        <p className="text-xs font-medium text-violet-200 truncate">
                          {language === 'ar' ? equippedTitle.nameAr : equippedTitle.nameEn}
                        </p>
                      )}
                    </div>

                    <div className="w-full pt-3 border-t border-white/10 flex items-center justify-between text-xs">
                      <span className="text-slate-300 font-math tabular-nums">
                        {t.leaderboardStagesProgress(entry.completedStages)}
                      </span>
                      <span className="font-math text-base font-extrabold text-white tabular-nums inline-flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5 text-amber-300" aria-hidden="true" />
                        {entry.totalEarnedPoints} {t.leaderboardPointsUnit}
                      </span>
                    </div>
                  </LiquidGlassCard>
                );
              })}
            </div>
          </div>

          {/* Ranks 4..100 */}
          {restEntries.length > 0 && (
            <div className="space-y-3">
              <h2 className="font-display text-lg font-bold text-white px-1">
                {t.leaderboardTop100Heading}
              </h2>

              <LiquidGlassCard variant="subtle" className="divide-y divide-white/10 overflow-hidden">
                {restEntries.map((entry, idx) => {
                  const rank = idx + 4;
                  const country = findCountryByCode(entry.countryCode);
                  const equippedTitle = getRewardById(entry.titleId);
                  const equippedBadge = getRewardById(entry.badgeId);
                  const isCurrentUser = firebaseUser?.uid === entry.uid;

                  return (
                    <div
                      key={entry.uid}
                      className={`p-4 sm:px-6 flex items-center justify-between gap-3 transition-colors ${
                        isCurrentUser
                          ? 'bg-gradient-to-r from-blue-500/20 to-violet-600/15'
                          : 'hover:bg-white/[0.03]'
                      }`}
                    >
                      <div className="flex items-center gap-3 sm:gap-4 min-w-0">
                        <span className="w-9 text-center font-math text-sm font-bold text-slate-300 tabular-nums shrink-0">
                          #{rank}
                        </span>

                        <div className="relative shrink-0">
                          <AvatarDisplay
                            avatarId={entry.avatarId}
                            photoUrl={entry.photoUrl}
                            displayName={entry.displayName}
                            size="sm"
                          />
                          {equippedBadge && (
                            <span
                              title={language === 'ar' ? equippedBadge.nameAr : equippedBadge.nameEn}
                              className={`absolute -bottom-1 -end-1 w-5 h-5 rounded-lg bg-gradient-to-br ${equippedBadge.accentFrom} ${equippedBadge.accentTo} border border-white/40 flex items-center justify-center text-[10px] font-bold text-white`}
                            >
                              {equippedBadge.symbol}
                            </span>
                          )}
                        </div>

                        <div className="min-w-0 space-y-0.5">
                          <div className="flex items-center gap-2">
                            {country && (
                              <span
                                className="text-base shrink-0"
                                title={language === 'ar' ? country.nameAr : country.nameEn}
                              >
                                {country.flag}
                              </span>
                            )}
                            <span className="font-semibold text-sm sm:text-base text-white truncate">
                              {entry.displayName}
                            </span>
                            {isCurrentUser && (
                              <CheckCircle2
                                className="w-4 h-4 text-blue-300 shrink-0"
                                aria-hidden="true"
                              />
                            )}
                          </div>
                          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
                            {equippedTitle && (
                              <span className="text-violet-200 font-medium">
                                {language === 'ar' ? equippedTitle.nameAr : equippedTitle.nameEn}
                              </span>
                            )}
                            {equippedTitle && <span aria-hidden="true">·</span>}
                            <span className="font-math tabular-nums">
                              {t.leaderboardStagesProgress(entry.completedStages)}
                            </span>
                            {entry.certificatesCount > 0 && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span className="inline-flex items-center gap-1 text-emerald-300 font-math tabular-nums">
                                  <Award className="w-3 h-3" aria-hidden="true" />
                                  {entry.certificatesCount}
                                </span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="font-math text-sm sm:text-base font-bold text-white tabular-nums shrink-0">
                        {entry.totalEarnedPoints}{' '}
                        <span className="text-xs font-normal text-slate-400">
                          {t.leaderboardPointsUnit}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </LiquidGlassCard>
            </div>
          )}
        </div>
      )}
    </motion.section>
  );
}
