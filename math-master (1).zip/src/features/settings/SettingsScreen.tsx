import { ArrowLeft, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';
import { AppTopBar, type HubTab } from '@/src/components/ui/AppTopBar';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { AccountSettingsPanel } from '@/src/features/profile/AccountSettingsPanel';

interface SettingsScreenProps {
  onNavigate: (tab: HubTab) => void;
  onOpenCountrySelection?: () => void;
}

export function SettingsScreen({
  onNavigate,
  onOpenCountrySelection,
}: SettingsScreenProps) {
  const { direction, t } = useLanguage();
  const BackArrow = direction === 'rtl' ? ArrowRight : ArrowLeft;

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="min-h-dvh flex flex-col px-4 py-5 sm:px-8 sm:py-7 max-w-5xl mx-auto w-full gap-6 safe-pb-nav"
    >
      <AppTopBar activeTab="settings" onNavigate={onNavigate} />

      <div>
        <button
          type="button"
          onClick={() => onNavigate('home')}
          className="liquid-glass-subtle min-h-[40px] px-3.5 py-1.5 rounded-2xl text-xs font-semibold text-white hover:bg-white/10 inline-flex items-center gap-2 transition-colors"
        >
          <BackArrow className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
          <span>{t.backToHomeBtn}</span>
        </button>
      </div>

      <AccountSettingsPanel
        onNavigate={onNavigate}
        onOpenCountrySelection={onOpenCountrySelection}
      />
    </motion.section>
  );
}
