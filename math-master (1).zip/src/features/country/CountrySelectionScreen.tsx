import { Check, ChevronLeft, ChevronRight, Globe2, Search, X } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useMemo, useState } from 'react';
import { LanguageSwitcher } from '@/src/components/ui/LanguageSwitcher';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { MathMasterLogo } from '@/src/components/ui/MathMasterLogo';
import { useAuth } from '@/src/contexts/AuthContext';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { COUNTRIES, searchCountries } from '@/src/data/countries';
import type { Country } from '@/src/types/country';

interface CountrySelectionScreenProps {
  onContinue: () => void;
  isReturningUser?: boolean;
}

export function CountrySelectionScreen({
  onContinue,
  isReturningUser = false,
}: CountrySelectionScreenProps) {
  const { language, isRtl, t } = useLanguage();
  const { selectedCountry, selectCountry } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [saving, setSaving] = useState(false);

  const filteredCountries = useMemo(() => {
    const matches = searchCountries(searchQuery);
    return [...matches].sort((a, b) => {
      if (selectedCountry) {
        if (a.code === selectedCountry.code) return -1;
        if (b.code === selectedCountry.code) return 1;
      }
      return language === 'ar'
        ? a.nameAr.localeCompare(b.nameAr, 'ar')
        : a.nameEn.localeCompare(b.nameEn, 'en');
    });
  }, [searchQuery, language, selectedCountry]);

  const handleSelect = async (country: Country) => {
    setSaving(true);
    try {
      await selectCountry(country);
    } finally {
      setSaving(false);
    }
  };

  const handleProceed = async () => {
    if (!selectedCountry || saving) return;
    onContinue();
  };

  const ArrowIcon = isRtl ? ChevronLeft : ChevronRight;

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
      className="min-h-screen flex flex-col justify-between px-4 py-5 sm:px-8 sm:py-7 max-w-6xl mx-auto w-full"
    >
      {/* Top Bar */}
      <header className="flex items-center justify-between gap-6 mb-5">
        <div className="flex items-center gap-3 shrink-0">
          <MathMasterLogo size="sm" />
          <span className="font-display text-lg font-bold tracking-tight text-white whitespace-nowrap" dir="ltr">
            {t.brandName}
          </span>
        </div>
        <LanguageSwitcher />
      </header>

      {/* Main Glass Directory */}
      <main className="flex-1 flex flex-col min-h-0">
        <LiquidGlassCard className="p-5 sm:p-8 flex flex-col flex-1 min-h-0">
          {/* Header & Search */}
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4 pb-5 border-b border-white/10">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-xs font-medium text-blue-200/80">
                <Globe2 className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{t.countryCountLabel(filteredCountries.length)}</span>
                <span aria-hidden="true">·</span>
                <span className="font-math">{COUNTRIES.length}</span>
              </div>
              <h1 className="font-display text-2xl sm:text-3xl font-bold text-white text-balance">
                {t.countryTitle}
              </h1>
              <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
                {t.countrySubtitle}
              </p>
            </div>

            {/* Search Box */}
            <div className="w-full lg:w-[24rem] shrink-0">
              <label htmlFor="country-search" className="sr-only">
                {t.countrySearchPlaceholder}
              </label>
              <div className="liquid-glass-input rounded-2xl flex items-center gap-2.5 px-3.5 min-h-[48px] transition-shadow">
                <Search className="w-4 h-4 text-slate-400 shrink-0" aria-hidden="true" />
                <input
                  id="country-search"
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={t.countrySearchPlaceholder}
                  className="w-full bg-transparent text-sm text-white placeholder:text-slate-400 focus:outline-none"
                  autoComplete="off"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    aria-label={t.countryClearSearch}
                    className="min-w-[32px] min-h-[32px] rounded-xl flex items-center justify-center text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Country Grid */}
          <div className="flex-1 overflow-y-auto glass-scroll py-5 max-h-[54vh] sm:max-h-[58vh]">
            {filteredCountries.length === 0 ? (
              <div className="py-16 text-center space-y-3">
                <p className="text-base font-semibold text-white">{t.countryEmptyTitle}</p>
                <p className="text-sm text-slate-400">{t.countryEmptySubtitle}</p>
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="liquid-glass-subtle min-h-[44px] px-5 py-2 rounded-2xl text-sm font-medium text-blue-200 hover:text-white transition-colors"
                >
                  {t.countryClearSearch}
                </button>
              </div>
            ) : (
              <div
                className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3"
                role="listbox"
                aria-label={t.countryTitle}
              >
                {filteredCountries.map((country) => {
                  const isSelected = selectedCountry?.code === country.code;
                  const primaryName = language === 'ar' ? country.nameAr : country.nameEn;
                  const secondaryName = language === 'ar' ? country.nameEn : country.nameAr;

                  return (
                    <button
                      key={country.code}
                      type="button"
                      role="option"
                      aria-selected={isSelected}
                      onClick={() => void handleSelect(country)}
                      className={`group text-start min-h-[64px] px-4 py-3 rounded-2xl flex items-center justify-between gap-3 transition-all duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-400 ${
                        isSelected
                          ? 'bg-gradient-to-br from-blue-500/25 to-violet-600/25 border border-blue-400/60 shadow-[0_8px_28px_-8px_rgba(99,102,241,0.55)]'
                          : 'bg-white/[0.04] border border-white/[0.09] hover:bg-white/[0.08] hover:border-white/20'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <span
                          className="w-10 h-10 rounded-xl bg-white/[0.07] border border-white/10 flex items-center justify-center text-2xl shrink-0"
                          aria-hidden="true"
                        >
                          {country.flag}
                        </span>
                        <div className="min-w-0">
                          <div className="text-sm font-semibold text-white truncate">
                            {primaryName}
                          </div>
                          <div className="text-xs text-slate-400 truncate">
                            {secondaryName}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span className="font-math text-xs text-slate-300" dir="ltr">
                          {country.dialCode}
                        </span>
                        {isSelected && (
                          <span className="w-6 h-6 rounded-full bg-blue-500 text-white flex items-center justify-center shadow-sm">
                            <Check className="w-3.5 h-3.5" strokeWidth={2.75} />
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Bottom Confirmation Footer — Continue button smoothly appears only after selecting a country */}
          <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 min-h-[64px]">
            <div className="flex items-center gap-3 min-h-[44px]">
              {selectedCountry ? (
                <motion.div
                  key={selectedCountry.code}
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.25 }}
                  className="flex items-center gap-3 text-sm"
                >
                  <span className="text-2xl" aria-hidden="true">
                    {selectedCountry.flag}
                  </span>
                  <div>
                    <div className="text-xs text-slate-400">{t.countrySelectedLabel}</div>
                    <div className="font-semibold text-white flex items-center gap-2">
                      <span>{language === 'ar' ? selectedCountry.nameAr : selectedCountry.nameEn}</span>
                      <span className="text-slate-400 font-math text-xs" dir="ltr">
                        ({selectedCountry.dialCode})
                      </span>
                    </div>
                  </div>
                </motion.div>
              ) : (
                <p className="text-sm text-slate-300 flex items-center gap-2">
                  <Globe2 className="w-4 h-4 text-sky-300 shrink-0" aria-hidden="true" />
                  <span>{t.countrySelectPrompt}</span>
                </p>
              )}
            </div>

            <AnimatePresence mode="wait">
              {selectedCountry && (
                <motion.button
                  key="country-continue-btn"
                  type="button"
                  disabled={saving}
                  onClick={() => void handleProceed()}
                  initial={{ opacity: 0, scale: 0.94, y: 6 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.94, y: 6 }}
                  transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
                  className="liquid-glass-button min-h-[48px] px-6 py-3 rounded-2xl text-sm font-semibold text-white inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0 transition-transform duration-150 disabled:opacity-50 active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-400"
                >
                  <span>{isReturningUser ? t.countrySaveAndReturn : t.countryContinue}</span>
                  <ArrowIcon className="w-4 h-4" aria-hidden="true" />
                </motion.button>
              )}
            </AnimatePresence>
          </div>
        </LiquidGlassCard>
      </main>
    </motion.section>
  );
}
