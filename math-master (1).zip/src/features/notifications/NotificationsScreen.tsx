import {
  Award,
  Bell,
  BellOff,
  BookOpen,
  Check,
  CheckCheck,
  ClipboardCheck,
  Flame,
  Settings,
  Sparkles,
  Swords,
  Trash2,
  TrendingUp,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useMemo, useState } from 'react';
import { AppTopBar, type HubTab } from '@/src/components/ui/AppTopBar';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useNotifications } from '@/src/contexts/NotificationsContext';
import type { SectionId } from '@/src/types/curriculum';
import type {
  NotificationTargetScreen,
  NotificationType,
  UserNotificationRecord,
} from '@/src/types/notifications';

interface NotificationsScreenProps {
  onNavigate: (tab: HubTab) => void;
  onOpenSection: (sectionId: SectionId) => void;
  onOpenDailyChallenge: () => void;
  onOpenGeniusChallenges?: () => void;
}

type NotifFilter = 'all' | 'unread';

function getTypeMeta(type: NotificationType) {
  switch (type) {
    case 'stage_unlock':
      return {
        Icon: BookOpen,
        bgClass: 'bg-sky-500/20 border-sky-400/35 text-sky-300',
      };
    case 'stage_win':
      return {
        Icon: Check,
        bgClass: 'bg-emerald-500/20 border-emerald-400/35 text-emerald-300',
      };
    case 'points_earned':
      return {
        Icon: Sparkles,
        bgClass: 'bg-violet-500/20 border-violet-400/35 text-violet-300',
      };
    case 'medal_earned':
      return {
        Icon: Award,
        bgClass: 'bg-amber-500/20 border-amber-400/35 text-amber-300',
      };
    case 'exam_pass':
      return {
        Icon: ClipboardCheck,
        bgClass: 'bg-teal-500/20 border-teal-400/35 text-teal-300',
      };
    case 'certificate_earned':
      return {
        Icon: Award,
        bgClass: 'bg-emerald-500/25 border-emerald-300/45 text-emerald-200',
      };
    case 'daily_reminder':
      return {
        Icon: Flame,
        bgClass: 'bg-orange-500/20 border-orange-400/35 text-orange-300',
      };
    case 'rank_up':
      return {
        Icon: TrendingUp,
        bgClass: 'bg-blue-500/20 border-blue-400/35 text-blue-300',
      };
    case 'new_challenges':
      return {
        Icon: Swords,
        bgClass: 'bg-fuchsia-500/20 border-fuchsia-400/35 text-fuchsia-300',
      };
  }
}

export function NotificationsScreen({
  onNavigate,
  onOpenSection,
  onOpenDailyChallenge,
  onOpenGeniusChallenges,
}: NotificationsScreenProps) {
  const { language, t } = useLanguage();
  const {
    notifications,
    unreadCount,
    loadingNotifications,
    markAsRead,
    markAllAsRead,
    deleteNotification,
  } = useNotifications();
  const [filter, setFilter] = useState<NotifFilter>('all');

  const filtered = useMemo(() => {
    if (filter === 'unread') {
      return notifications.filter((n) => !n.read);
    }
    return notifications;
  }, [notifications, filter]);

  const formatTimestamp = (item: UserNotificationRecord): string => {
    const date = item.createdAt?.toDate?.();
    if (!date || Number.isNaN(date.getTime())) return '—';
    return new Intl.DateTimeFormat(language === 'ar' ? 'ar-SA' : 'en-US', {
      dateStyle: 'medium',
      timeStyle: 'short',
    }).format(date);
  };

  const getTypeLabel = (type: NotificationType): string => {
    switch (type) {
      case 'stage_unlock':
        return t.notifTypeStageUnlock;
      case 'stage_win':
        return t.notifTypeStageWin;
      case 'points_earned':
        return t.notifTypePointsEarned;
      case 'medal_earned':
        return t.notifTypeMedalEarned;
      case 'exam_pass':
        return t.notifTypeExamPass;
      case 'certificate_earned':
        return t.notifTypeCertificateEarned;
      case 'daily_reminder':
        return t.notifTypeDailyReminder;
      case 'rank_up':
        return t.notifTypeRankUp;
      case 'new_challenges':
        return t.notifTypeNewChallenges;
    }
  };

  const handleOpenDestination = (item: UserNotificationRecord) => {
    if (!item.read) {
      void markAsRead(item.id);
    }
    const target: NotificationTargetScreen = item.targetScreen ?? 'home';
    if (target === 'section' && item.targetSectionId) {
      onOpenSection(item.targetSectionId as SectionId);
      return;
    }
    if (target === 'daily') {
      onOpenDailyChallenge();
      return;
    }
    if (target === 'genius-challenges') {
      if (onOpenGeniusChallenges) {
        onOpenGeniusChallenges();
      } else {
        onNavigate('question-bank');
      }
      return;
    }
    if (
      target === 'home' ||
      target === 'sections' ||
      target === 'question-bank' ||
      target === 'duels' ||
      target === 'exams' ||
      target === 'achievements' ||
      target === 'leaderboard' ||
      target === 'profile' ||
      target === 'settings'
    ) {
      onNavigate(target);
      return;
    }
    onNavigate('home');
  };

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="min-h-dvh flex flex-col px-4 py-5 sm:px-8 sm:py-7 max-w-5xl mx-auto w-full gap-6 safe-pb-nav"
    >
      <AppTopBar activeTab="notifications" onNavigate={onNavigate} />

      {/* Header & Controls */}
      <LiquidGlassCard className="p-5 sm:p-8 space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-blue-200">
              <Bell className="w-4 h-4 text-sky-300 shrink-0" aria-hidden="true" />
              <span className="font-math tabular-nums">{t.notifUnreadBadge(unreadCount)}</span>
            </div>
            <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">
              {t.notifTitle}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              {t.notifSubtitle}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => onNavigate('settings')}
              className="liquid-glass-subtle min-h-[42px] px-4 py-2 rounded-2xl text-xs font-semibold text-white hover:bg-white/10 inline-flex items-center gap-2 whitespace-nowrap"
            >
              <Settings className="w-4 h-4 text-sky-300 shrink-0" aria-hidden="true" />
              <span>{t.notifPrefsShortcutBtn}</span>
            </button>

            {unreadCount > 0 && (
              <button
                type="button"
                onClick={() => void markAllAsRead()}
                className="liquid-glass-button min-h-[42px] px-4 py-2 rounded-2xl text-xs font-semibold text-white inline-flex items-center gap-2 whitespace-nowrap"
              >
                <CheckCheck className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{t.notifMarkAllReadBtn}</span>
              </button>
            )}
          </div>
        </div>

        {/* All / Unread Filter Tabs */}
        <div
          role="tablist"
          aria-label={t.notifTitle}
          className="inline-flex items-center gap-1.5 p-1 rounded-2xl liquid-glass-subtle"
        >
          {(
            [
              { id: 'all', label: `${t.notifFilterAll} (${notifications.length})` },
              { id: 'unread', label: `${t.notifFilterUnread} (${unreadCount})` },
            ] as const
          ).map((tab) => {
            const active = filter === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => setFilter(tab.id)}
                className={`min-h-[38px] px-4 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  active
                    ? 'bg-gradient-to-r from-blue-500/85 to-violet-600/85 text-white shadow-sm'
                    : 'text-slate-300 hover:text-white hover:bg-white/[0.06]'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </LiquidGlassCard>

      {/* Notifications List */}
      {loadingNotifications ? (
        <div className="space-y-3">
          {[1, 2, 3].map((n) => (
            <div key={n} className="h-24 rounded-3xl liquid-glass-subtle animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <LiquidGlassCard variant="subtle" className="p-10 text-center space-y-3">
          <BellOff className="w-10 h-10 text-slate-400 mx-auto" aria-hidden="true" />
          <h2 className="font-display text-lg font-bold text-white">
            {filter === 'unread' ? t.notifEmptyUnreadTitle : t.notifEmptyAllTitle}
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
            {filter === 'unread' ? t.notifEmptyUnreadSubtitle : t.notifEmptyAllSubtitle}
          </p>
        </LiquidGlassCard>
      ) : (
        <div className="space-y-3">
          {filtered.map((item) => {
            const { Icon, bgClass } = getTypeMeta(item.type);
            return (
              <LiquidGlassCard
                key={item.id}
                variant="subtle"
                className={`p-4 sm:p-5 transition-all ${
                  !item.read
                    ? 'border-blue-400/50 bg-blue-500/[0.09] shadow-[0_6px_24px_rgba(59,130,246,0.16)]'
                    : 'opacity-85'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                  <div className="flex items-start gap-3.5 min-w-0 flex-1">
                    <div
                      className={`w-11 h-11 rounded-2xl border flex items-center justify-center shrink-0 ${bgClass}`}
                    >
                      <Icon className="w-5 h-5" aria-hidden="true" />
                    </div>

                    <div className="space-y-1 min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        {!item.read && (
                          <span
                            className="w-2.5 h-2.5 rounded-full bg-blue-400 shadow-[0_0_8px_rgba(96,165,250,0.9)] shrink-0"
                            aria-hidden="true"
                          />
                        )}
                        <span className="text-[11px] font-semibold text-blue-200">
                          {getTypeLabel(item.type)}
                        </span>
                        <span className="text-slate-500 text-xs" aria-hidden="true">
                          ·
                        </span>
                        <span className="text-[11px] text-slate-400 font-math tabular-nums">
                          {formatTimestamp(item)}
                        </span>
                      </div>

                      <h3 className="font-display text-sm sm:text-base font-bold text-white leading-snug">
                        {language === 'ar' ? item.titleAr : item.titleEn}
                      </h3>
                      <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                        {language === 'ar' ? item.bodyAr : item.bodyEn}
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0 self-end sm:self-center">
                    {item.targetScreen && (
                      <button
                        type="button"
                        onClick={() => handleOpenDestination(item)}
                        className="liquid-glass-button min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-semibold text-white whitespace-nowrap"
                      >
                        {t.notifOpenTargetBtn}
                      </button>
                    )}

                    {!item.read && (
                      <button
                        type="button"
                        onClick={() => void markAsRead(item.id)}
                        className="liquid-glass-subtle min-h-[38px] px-3 py-1.5 rounded-xl text-xs font-semibold text-sky-200 hover:bg-white/10 inline-flex items-center gap-1.5 whitespace-nowrap"
                      >
                        <Check className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>{t.notifMarkReadBtn}</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => void deleteNotification(item.id)}
                      aria-label={t.notifDeleteBtn}
                      title={t.notifDeleteBtn}
                      className="min-h-[38px] min-w-[38px] px-2.5 py-1.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-400/30 text-rose-200 inline-flex items-center justify-center transition-colors"
                    >
                      <Trash2 className="w-4 h-4" aria-hidden="true" />
                    </button>
                  </div>
                </div>
              </LiquidGlassCard>
            );
          })}
        </div>
      )}
    </motion.section>
  );
}
