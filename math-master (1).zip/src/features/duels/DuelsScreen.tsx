import {
  ArrowLeft,
  ArrowRight,
  Check,
  Clock,
  Crown,
  Flame,
  PlusCircle,
  Search,
  Sparkles,
  Swords,
  Trophy,
  Users,
  X,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AppTopBar, type HubTab } from '@/src/components/ui/AppTopBar';
import { AvatarDisplay } from '@/src/components/ui/AvatarDisplay';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { useAuth } from '@/src/contexts/AuthContext';
import { useDuels } from '@/src/contexts/DuelsContext';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { findCountryByCode } from '@/src/data/countries';
import { CURRICULUM_SECTIONS, getSectionById } from '@/src/data/curriculum';
import { buildDuelQuestions } from '@/src/data/duelQuestionGenerator';
import type { SectionId } from '@/src/types/curriculum';
import type {
  DuelDurationSeconds,
  DuelMatchRecord,
  DuelQuestionCount,
} from '@/src/types/duels';
import type { LeaderboardEntry } from '@/src/types/rewards';

interface DuelsScreenProps {
  onNavigate: (tab: HubTab) => void;
}

type DuelsTab = 'matches' | 'create' | 'rankings';

function formatTimer(seconds: number): string {
  const safe = Math.max(0, seconds);
  const mins = Math.floor(safe / 60);
  const secs = safe % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export function DuelsScreen({ onNavigate }: DuelsScreenProps) {
  const { language, direction, t } = useLanguage();
  const { firebaseUser } = useAuth();
  const {
    incomingInvites,
    sentInvites,
    activeDuels,
    completedDuels,
    topCompetitors,
    candidateOpponents,
    loadingDuels,
    loadingCandidates,
    loadCandidateOpponents,
    createDuel,
    respondToDuel,
    submitDuelAnswers,
  } = useDuels();

  const [activeTab, setActiveTab] = useState<DuelsTab>('matches');
  const [playingDuelId, setPlayingDuelId] = useState<string | null>(null);

  // Create Duel Form State
  const [opponentSearch, setOpponentSearch] = useState('');
  const [selectedOpponent, setSelectedOpponent] = useState<LeaderboardEntry | null>(null);
  const [selectedSectionId, setSelectedSectionId] = useState<SectionId>(CURRICULUM_SECTIONS[0].id);
  const [selectedCount, setSelectedCount] = useState<DuelQuestionCount>(10);
  const [selectedDuration, setSelectedDuration] = useState<DuelDurationSeconds>(300);
  const [creating, setCreating] = useState(false);
  const [createError, setCreateError] = useState<string | null>(null);
  const [createSuccess, setCreateSuccess] = useState(false);
  const [busyDuelId, setBusyDuelId] = useState<string | null>(null);

  // Active Match Play State
  const [qIndex, setQIndex] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [secondsLeft, setSecondsLeft] = useState(0);
  const [submittingPlay, setSubmittingPlay] = useState(false);
  const playStartedAtRef = useRef<number>(0);
  const autoSubmittedRef = useRef(false);

  const BackArrow = direction === 'rtl' ? ArrowRight : ArrowLeft;
  const ForwardArrow = direction === 'rtl' ? ArrowLeft : ArrowRight;

  useEffect(() => {
    if (activeTab === 'create' && candidateOpponents.length === 0) {
      void loadCandidateOpponents();
    }
  }, [activeTab, candidateOpponents.length, loadCandidateOpponents]);

  const activePlayingDuel: DuelMatchRecord | null = useMemo(
    () => activeDuels.find((d) => d.duelId === playingDuelId) ?? null,
    [activeDuels, playingDuelId],
  );

  const playingQuestions = useMemo(() => {
    if (!activePlayingDuel) return [];
    return buildDuelQuestions(
      activePlayingDuel.sectionId,
      activePlayingDuel.questionCount,
      activePlayingDuel.questionSeed,
    );
  }, [activePlayingDuel]);

  const startPlayingMatch = (duel: DuelMatchRecord) => {
    setPlayingDuelId(duel.duelId);
    setQIndex(0);
    setAnswers(new Array(duel.questionCount).fill(-1));
    setSecondsLeft(duel.durationSeconds);
    playStartedAtRef.current = Date.now();
    autoSubmittedRef.current = false;
  };

  const handleFinishPlay = useCallback(async () => {
    if (!activePlayingDuel || submittingPlay) return;
    setSubmittingPlay(true);
    const elapsedSec = Math.max(
      1,
      Math.min(
        activePlayingDuel.durationSeconds,
        Math.round((Date.now() - playStartedAtRef.current) / 1000),
      ),
    );
    try {
      await submitDuelAnswers({
        duelId: activePlayingDuel.duelId,
        selectedAnswers: answers,
        durationSeconds: elapsedSec,
      });
      setPlayingDuelId(null);
    } finally {
      setSubmittingPlay(false);
    }
  }, [activePlayingDuel, answers, submittingPlay, submitDuelAnswers]);

  // Countdown tick while inside a live duel match
  useEffect(() => {
    if (!activePlayingDuel) return;
    const timer = window.setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          if (!autoSubmittedRef.current) {
            autoSubmittedRef.current = true;
            void handleFinishPlay();
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => window.clearInterval(timer);
  }, [activePlayingDuel, handleFinishPlay]);

  const filteredOpponents = useMemo(() => {
    const q = opponentSearch.trim().toLowerCase();
    if (!q) return candidateOpponents;
    return candidateOpponents.filter((c) => c.displayName.toLowerCase().includes(q));
  }, [candidateOpponents, opponentSearch]);

  const handleSendChallenge = async () => {
    if (!selectedOpponent) return;
    setCreating(true);
    setCreateError(null);
    setCreateSuccess(false);
    try {
      await createDuel({
        opponent: selectedOpponent,
        sectionId: selectedSectionId,
        questionCount: selectedCount,
        durationSeconds: selectedDuration,
      });
      setCreateSuccess(true);
      setSelectedOpponent(null);
      setActiveTab('matches');
    } catch {
      setCreateError(t.errorGeneric);
    } finally {
      setCreating(false);
    }
  };

  const handleAcceptInvite = async (duel: DuelMatchRecord) => {
    setBusyDuelId(duel.duelId);
    try {
      await respondToDuel(duel.duelId, 'active');
      startPlayingMatch({ ...duel, status: 'active' });
    } finally {
      setBusyDuelId(null);
    }
  };

  const handleDeclineOrCancel = async (duelId: string, action: 'declined' | 'cancelled') => {
    setBusyDuelId(duelId);
    try {
      await respondToDuel(duelId, action);
    } finally {
      setBusyDuelId(null);
    }
  };

  // LIVE DUEL ARENA PLAY VIEW
  if (activePlayingDuel && playingQuestions.length > 0) {
    const currentQ = playingQuestions[qIndex] ?? playingQuestions[0];
    const secInfo = getSectionById(activePlayingDuel.sectionId);
    const answeredCount = answers.filter((a) => a >= 0).length;
    const isUrgent = secondsLeft <= 30;
    const opponentName =
      firebaseUser?.uid === activePlayingDuel.challengerUid
        ? activePlayingDuel.opponentName
        : activePlayingDuel.challengerName;

    return (
      <motion.section
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="min-h-dvh flex flex-col px-4 py-5 sm:px-8 sm:py-7 max-w-4xl mx-auto w-full gap-5 safe-pb-nav"
      >
        {/* Top Match Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => setPlayingDuelId(null)}
            className="liquid-glass-subtle min-h-[42px] px-4 py-2 rounded-2xl text-xs font-semibold text-white inline-flex items-center gap-2"
          >
            <BackArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>{t.duelsBackToArenaBtn}</span>
          </button>

          <div
            className={`min-h-[42px] px-4 py-2 rounded-2xl border font-math text-sm font-extrabold tabular-nums inline-flex items-center gap-2 ${
              isUrgent
                ? 'bg-rose-500/25 border-rose-400/50 text-rose-200 animate-pulse'
                : 'liquid-glass-subtle text-sky-200'
            }`}
          >
            <Clock className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>{formatTimer(secondsLeft)}</span>
          </div>
        </div>

        {/* Question Card */}
        <LiquidGlassCard className="p-5 sm:p-8 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-white/10">
            <div className="space-y-0.5">
              <div className="text-xs font-semibold text-violet-200">
                {language === 'ar' ? secInfo.titleAr : secInfo.titleEn} · vs {opponentName}
              </div>
              <div className="text-xs text-slate-400 font-math tabular-nums">
                {t.questionCounterLabel(qIndex + 1, playingQuestions.length)} ·{' '}
                {t.answeredCountLabel(answeredCount, playingQuestions.length)}
              </div>
            </div>

            <span className="px-3 py-1 rounded-xl bg-white/[0.06] border border-white/10 text-xs font-semibold text-amber-200">
              {currentQ.difficulty === 'easy'
                ? t.dailyDiffEasy
                : currentQ.difficulty === 'medium'
                  ? t.dailyDiffMedium
                  : t.dailyDiffHard}
            </span>
          </div>

          <h2 className="font-display text-lg sm:text-2xl font-bold text-white leading-relaxed">
            {language === 'ar' ? currentQ.promptAr : currentQ.promptEn}
          </h2>

          <div className="grid grid-cols-1 gap-3">
            {currentQ.options.map((option, idx) => {
              const selected = answers[qIndex] === idx;
              return (
                <button
                  key={`${currentQ.id}-${idx}`}
                  type="button"
                  onClick={() =>
                    setAnswers((prev) => {
                      const next = [...prev];
                      next[qIndex] = idx;
                      return next;
                    })
                  }
                  className={`min-h-[54px] px-4 py-3 rounded-2xl border text-start text-sm sm:text-base font-medium transition-all flex items-center justify-between gap-3 ${
                    selected
                      ? 'bg-gradient-to-r from-blue-500/85 to-violet-600/85 border-blue-300/70 text-white shadow-[0_6px_22px_rgba(99,102,241,0.35)]'
                      : 'bg-white/[0.04] border-white/15 text-slate-200 hover:bg-white/[0.08]'
                  }`}
                >
                  <span className="font-math">{option}</span>
                  {selected && <Check className="w-4 h-4 shrink-0" aria-hidden="true" />}
                </button>
              );
            })}
          </div>

          {/* Navigation Footer */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-white/10">
            <button
              type="button"
              disabled={qIndex === 0}
              onClick={() => setQIndex((i) => Math.max(0, i - 1))}
              className="liquid-glass-subtle min-h-[44px] px-4 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white disabled:opacity-40 inline-flex items-center gap-1.5"
            >
              <BackArrow className="w-4 h-4" aria-hidden="true" />
              <span>{t.prevQuestionBtn}</span>
            </button>

            {qIndex < playingQuestions.length - 1 ? (
              <button
                type="button"
                onClick={() => setQIndex((i) => Math.min(playingQuestions.length - 1, i + 1))}
                className="liquid-glass-button min-h-[44px] px-5 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center gap-1.5"
              >
                <span>{t.nextQuestionBtn}</span>
                <ForwardArrow className="w-4 h-4" aria-hidden="true" />
              </button>
            ) : (
              <button
                type="button"
                disabled={submittingPlay || answeredCount < playingQuestions.length}
                onClick={() => void handleFinishPlay()}
                className="liquid-glass-button min-h-[46px] px-6 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white disabled:opacity-50 inline-flex items-center gap-2"
              >
                <Check className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{submittingPlay ? t.duelsSubmittingBtn : t.duelsSubmitAnswersBtn}</span>
              </button>
            )}
          </div>
        </LiquidGlassCard>
      </motion.section>
    );
  }

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="min-h-dvh flex flex-col px-4 py-5 sm:px-8 sm:py-7 max-w-6xl mx-auto w-full gap-6 safe-pb-nav"
    >
      <AppTopBar activeTab="duels" onNavigate={onNavigate} />

      {/* Header Banner */}
      <LiquidGlassCard className="p-5 sm:p-8 space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-violet-200">
              <Swords className="w-4 h-4 text-fuchsia-300 shrink-0" aria-hidden="true" />
              <span>{t.duelsTieBreakerNote}</span>
            </div>
            <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">
              {t.duelsTitle}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              {t.duelsSubtitle}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs font-math shrink-0">
            <span className="px-3 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-400/35 text-emerald-200 font-semibold">
              {t.duelsRewardWinLabel}
            </span>
            <span className="px-3 py-1.5 rounded-xl bg-sky-500/20 border border-sky-400/35 text-sky-200 font-semibold">
              {t.duelsRewardDrawLabel}
            </span>
            <span className="px-3 py-1.5 rounded-xl bg-white/[0.06] border border-white/15 text-slate-200 font-semibold">
              {t.duelsRewardPartLabel}
            </span>
          </div>
        </div>

        {/* Workspace Tabs */}
        <div
          role="tablist"
          aria-label={t.duelsTitle}
          className="liquid-glass-subtle p-1.5 rounded-2xl grid grid-cols-3 gap-1.5"
        >
          {(
            [
              { id: 'matches', label: t.duelsTabMatches, Icon: Swords },
              { id: 'create', label: t.duelsTabCreate, Icon: PlusCircle },
              { id: 'rankings', label: t.duelsTabRankings, Icon: Trophy },
            ] as const
          ).map(({ id, label, Icon }) => {
            const active = activeTab === id;
            return (
              <button
                key={id}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => setActiveTab(id)}
                className={`min-h-[44px] px-2.5 py-2 rounded-xl text-xs sm:text-sm font-semibold inline-flex items-center justify-center gap-1.5 transition-all ${
                  active
                    ? 'bg-gradient-to-r from-blue-500/85 to-violet-600/85 text-white shadow-[0_4px_16px_rgba(99,102,241,0.35)]'
                    : 'text-slate-300 hover:text-white hover:bg-white/[0.06]'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span className="truncate">{label}</span>
              </button>
            );
          })}
        </div>
      </LiquidGlassCard>

      {createSuccess && (
        <LiquidGlassCard variant="subtle" className="p-4 border-emerald-400/40 text-xs sm:text-sm text-emerald-200 flex items-center gap-2">
          <Check className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{t.duelsSentSuccessMsg}</span>
        </LiquidGlassCard>
      )}

      {/* TAB 1: MATCHES & INVITES */}
      {activeTab === 'matches' && (
        <div className="space-y-6">
          {loadingDuels ? (
            <div className="space-y-3">
              {[1, 2].map((n) => (
                <div key={n} className="h-28 rounded-3xl liquid-glass-subtle animate-pulse" />
              ))}
            </div>
          ) : incomingInvites.length === 0 &&
            activeDuels.length === 0 &&
            sentInvites.length === 0 &&
            completedDuels.length === 0 ? (
            <LiquidGlassCard variant="subtle" className="p-10 text-center space-y-4">
              <Swords className="w-11 h-11 text-violet-300 mx-auto" aria-hidden="true" />
              <h2 className="font-display text-lg font-bold text-white">
                {t.duelsNoMatchesTitle}
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
                {t.duelsNoMatchesSubtitle}
              </p>
              <button
                type="button"
                onClick={() => setActiveTab('create')}
                className="liquid-glass-button min-h-[46px] px-6 py-2.5 rounded-2xl text-sm font-semibold text-white inline-flex items-center gap-2"
              >
                <PlusCircle className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{t.duelsCreateFirstBtn}</span>
              </button>
            </LiquidGlassCard>
          ) : (
            <>
              {/* Incoming Invites */}
              {incomingInvites.length > 0 && (
                <div className="space-y-3">
                  <h2 className="font-display text-lg font-bold text-white px-1 flex items-center gap-2">
                    <Flame className="w-5 h-5 text-amber-300" aria-hidden="true" />
                    <span>{t.duelsIncomingTitle}</span>
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {incomingInvites.map((duel) => {
                      const sec = getSectionById(duel.sectionId);
                      const country = findCountryByCode(duel.challengerCountry);
                      const busy = busyDuelId === duel.duelId;
                      return (
                        <LiquidGlassCard
                          key={duel.duelId}
                          className="p-5 border-amber-400/40 space-y-4"
                        >
                          <div className="flex items-center justify-between gap-3">
                            <div className="flex items-center gap-3 min-w-0">
                              <AvatarDisplay
                                avatarId={duel.challengerAvatar}
                                displayName={duel.challengerName}
                                size="md"
                              />
                              <div className="min-w-0">
                                <div className="text-sm font-bold text-white truncate">
                                  {country?.flag} {duel.challengerName}
                                </div>
                                <div className="text-xs text-blue-200 truncate">
                                  {language === 'ar' ? sec.titleAr : sec.titleEn}
                                </div>
                              </div>
                            </div>
                            <span className="text-xs font-math text-slate-300 shrink-0">
                              {t.duelsQuestionsUnit(duel.questionCount)} ·{' '}
                              {t.duelsMinutesUnit(Math.round(duel.durationSeconds / 60))}
                            </span>
                          </div>

                          <div className="flex items-center gap-2.5">
                            <button
                              type="button"
                              disabled={busy}
                              onClick={() => void handleAcceptInvite(duel)}
                              className="liquid-glass-button flex-1 min-h-[42px] px-4 py-2 rounded-xl text-xs font-semibold text-white inline-flex items-center justify-center gap-1.5"
                            >
                              <Check className="w-4 h-4 shrink-0" aria-hidden="true" />
                              <span>{t.duelsAcceptBtn}</span>
                            </button>
                            <button
                              type="button"
                              disabled={busy}
                              onClick={() => void handleDeclineOrCancel(duel.duelId, 'declined')}
                              className="min-h-[42px] px-4 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-400/35 text-xs font-semibold text-rose-200 inline-flex items-center justify-center gap-1.5"
                            >
                              <X className="w-4 h-4 shrink-0" aria-hidden="true" />
                              <span>{t.duelsDeclineBtn}</span>
                            </button>
                          </div>
                        </LiquidGlassCard>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Active Matches */}
              {activeDuels.length > 0 && (
                <div className="space-y-3">
                  <h2 className="font-display text-lg font-bold text-white px-1 flex items-center gap-2">
                    <Swords className="w-5 h-5 text-sky-300" aria-hidden="true" />
                    <span>{t.duelsActiveTitle}</span>
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {activeDuels.map((duel) => {
                      const sec = getSectionById(duel.sectionId);
                      const isChallenger = firebaseUser?.uid === duel.challengerUid;
                      const iSubmitted = isChallenger
                        ? duel.challengerSubmitted
                        : duel.opponentSubmitted;
                      const oppName = isChallenger ? duel.opponentName : duel.challengerName;
                      const oppAvatar = isChallenger ? duel.opponentAvatar : duel.challengerAvatar;

                      return (
                        <LiquidGlassCard
                          key={duel.duelId}
                          className="p-5 border-blue-400/40 space-y-4"
                        >
                          <div className="flex items-center justify-between gap-3">
                            <div className="flex items-center gap-3 min-w-0">
                              <AvatarDisplay
                                avatarId={oppAvatar}
                                displayName={oppName}
                                size="md"
                              />
                              <div className="min-w-0">
                                <div className="text-sm font-bold text-white truncate">
                                  vs {oppName}
                                </div>
                                <div className="text-xs text-slate-300 truncate">
                                  {language === 'ar' ? sec.titleAr : sec.titleEn} ·{' '}
                                  {t.duelsQuestionsUnit(duel.questionCount)}
                                </div>
                              </div>
                            </div>
                            <span
                              className={`px-2.5 py-1 rounded-xl text-[11px] font-semibold border shrink-0 ${
                                iSubmitted
                                  ? 'bg-amber-500/15 border-amber-400/35 text-amber-200'
                                  : 'bg-emerald-500/20 border-emerald-400/35 text-emerald-200'
                              }`}
                            >
                              {iSubmitted ? t.duelsWaitingOpponentBadge : t.duelsYourTurnBadge}
                            </span>
                          </div>

                          {!iSubmitted && (
                            <button
                              type="button"
                              onClick={() => startPlayingMatch(duel)}
                              className="liquid-glass-button w-full min-h-[44px] px-4 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center justify-center gap-2"
                            >
                              <Swords className="w-4 h-4 shrink-0" aria-hidden="true" />
                              <span>{t.duelsStartPlayBtn}</span>
                            </button>
                          )}
                        </LiquidGlassCard>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Outgoing Sent Invites */}
              {sentInvites.length > 0 && (
                <div className="space-y-3">
                  <h2 className="font-display text-lg font-bold text-white px-1">
                    {t.duelsSentTitle}
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {sentInvites.map((duel) => {
                      const sec = getSectionById(duel.sectionId);
                      const busy = busyDuelId === duel.duelId;
                      return (
                        <LiquidGlassCard
                          key={duel.duelId}
                          variant="subtle"
                          className="p-4 flex items-center justify-between gap-3"
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            <AvatarDisplay
                              avatarId={duel.opponentAvatar}
                              displayName={duel.opponentName}
                              size="sm"
                            />
                            <div className="min-w-0">
                              <div className="text-sm font-bold text-white truncate">
                                {duel.opponentName}
                              </div>
                              <div className="text-xs text-slate-300 truncate">
                                {language === 'ar' ? sec.titleAr : sec.titleEn} · {t.duelsStatusPending}
                              </div>
                            </div>
                          </div>

                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => void handleDeclineOrCancel(duel.duelId, 'cancelled')}
                            className="min-h-[38px] px-3 py-1.5 rounded-xl bg-white/[0.06] hover:bg-rose-500/20 border border-white/15 text-xs font-semibold text-slate-200 shrink-0"
                          >
                            {t.duelsCancelBtn}
                          </button>
                        </LiquidGlassCard>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Completed Match History */}
              {completedDuels.length > 0 && (
                <div className="space-y-3">
                  <h2 className="font-display text-lg font-bold text-white px-1">
                    {t.duelsHistoryTitle}
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {completedDuels.map((duel) => {
                      const sec = getSectionById(duel.sectionId);
                      const uid = firebaseUser?.uid ?? '';
                      const isChallenger = duel.challengerUid === uid;
                      const oppName = isChallenger ? duel.opponentName : duel.challengerName;
                      const oppAvatar = isChallenger ? duel.opponentAvatar : duel.challengerAvatar;
                      const myScore = isChallenger ? duel.challengerScore : duel.opponentScore;
                      const oppScore = isChallenger ? duel.opponentScore : duel.challengerScore;
                      const myTime = isChallenger
                        ? duel.challengerDurationSec
                        : duel.opponentDurationSec;
                      const oppTime = isChallenger
                        ? duel.opponentDurationSec
                        : duel.challengerDurationSec;

                      const statusBadge =
                        duel.status === 'completed'
                          ? duel.winnerUid === uid
                            ? t.duelsYouWonBadge
                            : duel.winnerUid === 'draw'
                              ? t.duelsDrawBadge
                              : t.duelsYouLostBadge
                          : duel.status === 'declined'
                            ? t.duelsStatusDeclined
                            : t.duelsStatusCancelled;

                      const badgeTone =
                        duel.status === 'completed'
                          ? duel.winnerUid === uid
                            ? 'bg-emerald-500/20 border-emerald-400/40 text-emerald-200'
                            : duel.winnerUid === 'draw'
                              ? 'bg-sky-500/20 border-sky-400/40 text-sky-200'
                              : 'bg-white/[0.06] border-white/15 text-slate-300'
                          : 'bg-white/[0.05] border-white/10 text-slate-400';

                      return (
                        <LiquidGlassCard key={duel.duelId} variant="subtle" className="p-4 sm:p-5 space-y-3">
                          <div className="flex items-center justify-between gap-2">
                            <div className="flex items-center gap-3 min-w-0">
                              <AvatarDisplay avatarId={oppAvatar} displayName={oppName} size="sm" />
                              <div className="min-w-0">
                                <div className="text-sm font-bold text-white truncate">
                                  vs {oppName}
                                </div>
                                <div className="text-xs text-slate-400 truncate">
                                  {language === 'ar' ? sec.titleAr : sec.titleEn}
                                </div>
                              </div>
                            </div>

                            <span className={`px-2.5 py-1 rounded-xl border text-[11px] font-semibold shrink-0 ${badgeTone}`}>
                              {statusBadge}
                            </span>
                          </div>

                          {duel.status === 'completed' && (
                            <div className="grid grid-cols-2 gap-2 text-xs font-math tabular-nums pt-2 border-t border-white/10">
                              <div className="p-2.5 rounded-xl bg-white/[0.04]">
                                <div className="text-[11px] text-slate-400">{t.leaderboardYouTag}</div>
                                <div className="font-bold text-white">
                                  {myScore}/100 · {myTime}s
                                </div>
                              </div>
                              <div className="p-2.5 rounded-xl bg-white/[0.04]">
                                <div className="text-[11px] text-slate-400 truncate">{oppName}</div>
                                <div className="font-bold text-white">
                                  {oppScore}/100 · {oppTime}s
                                </div>
                              </div>
                            </div>
                          )}
                        </LiquidGlassCard>
                      );
                    })}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* TAB 2: CREATE NEW CHALLENGE */}
      {activeTab === 'create' && (
        <LiquidGlassCard className="p-5 sm:p-8 space-y-6">
          {/* 1. Pick Real Learner Opponent */}
          <div className="space-y-3">
            <h2 className="font-display text-base sm:text-lg font-bold text-white flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-300 shrink-0" aria-hidden="true" />
              <span>{t.duelsSelectOpponentTitle}</span>
            </h2>

            <div className="relative">
              <Search
                className="w-4 h-4 text-slate-400 absolute top-1/2 -translate-y-1/2 start-4 pointer-events-none"
                aria-hidden="true"
              />
              <input
                type="search"
                value={opponentSearch}
                onChange={(e) => setOpponentSearch(e.target.value)}
                placeholder={t.duelsSearchOpponentPlaceholder}
                className="w-full min-h-[44px] ps-11 pe-4 rounded-2xl liquid-glass-input text-sm text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-400"
              />
            </div>

            {loadingCandidates ? (
              <div className="h-32 rounded-2xl bg-white/[0.04] animate-pulse" />
            ) : filteredOpponents.length === 0 ? (
              <div className="p-5 rounded-2xl bg-white/[0.04] border border-white/10 text-xs sm:text-sm text-slate-300">
                {t.duelsNoOpponentsFound}
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 max-h-[260px] overflow-y-auto glass-scroll pe-1">
                {filteredOpponents.map((student) => {
                  const chosen = selectedOpponent?.uid === student.uid;
                  const country = findCountryByCode(student.countryCode);
                  return (
                    <button
                      key={student.uid}
                      type="button"
                      onClick={() => setSelectedOpponent(student)}
                      className={`p-3 rounded-2xl border flex items-center justify-between gap-2.5 text-start transition-all ${
                        chosen
                          ? 'bg-blue-500/25 border-blue-300/65 ring-1 ring-blue-300/40'
                          : 'bg-white/[0.04] border-white/10 hover:bg-white/[0.08]'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <AvatarDisplay
                          avatarId={student.avatarId}
                          photoUrl={student.photoUrl}
                          displayName={student.displayName}
                          size="sm"
                        />
                        <div className="min-w-0">
                          <div className="text-xs sm:text-sm font-bold text-white truncate">
                            {country?.flag} {student.displayName}
                          </div>
                          <div className="text-[11px] text-slate-400 font-math tabular-nums">
                            {student.totalEarnedPoints} {t.leaderboardPointsUnit}
                          </div>
                        </div>
                      </div>
                      {chosen && <Check className="w-4 h-4 text-sky-300 shrink-0" />}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* 2. Section Topic */}
          <div className="space-y-3">
            <h2 className="font-display text-base sm:text-lg font-bold text-white">
              {t.duelsSelectSectionTitle}
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
              {CURRICULUM_SECTIONS.map((sec) => {
                const chosen = selectedSectionId === sec.id;
                return (
                  <button
                    key={sec.id}
                    type="button"
                    onClick={() => setSelectedSectionId(sec.id)}
                    className={`p-3 rounded-2xl border flex items-center gap-2.5 text-start transition-all ${
                      chosen
                        ? 'bg-gradient-to-r from-blue-500/80 to-violet-600/80 border-blue-300/65 text-white'
                        : 'bg-white/[0.04] border-white/10 text-slate-200 hover:bg-white/[0.08]'
                    }`}
                  >
                    <span
                      className={`w-8 h-8 rounded-xl bg-gradient-to-br ${sec.accentFrom} ${sec.accentTo} flex items-center justify-center text-sm font-bold text-white font-math shrink-0`}
                    >
                      {sec.symbol}
                    </span>
                    <span className="text-xs font-semibold truncate">
                      {language === 'ar' ? sec.titleAr : sec.titleEn}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 3. Question Count & 4. Duration */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="space-y-2.5">
              <h3 className="font-display text-sm sm:text-base font-bold text-white">
                {t.duelsSelectCountTitle}
              </h3>
              <div className="grid grid-cols-3 gap-2">
                {([5, 10, 15] as const).map((cnt) => (
                  <button
                    key={cnt}
                    type="button"
                    onClick={() => setSelectedCount(cnt)}
                    className={`min-h-[44px] rounded-2xl border text-xs sm:text-sm font-semibold font-math transition-all ${
                      selectedCount === cnt
                        ? 'bg-gradient-to-r from-blue-500/85 to-violet-600/85 border-blue-300/65 text-white'
                        : 'bg-white/[0.04] border-white/10 text-slate-200 hover:bg-white/[0.08]'
                    }`}
                  >
                    {t.duelsQuestionsUnit(cnt)}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2.5">
              <h3 className="font-display text-sm sm:text-base font-bold text-white">
                {t.duelsSelectDurationTitle}
              </h3>
              <div className="grid grid-cols-3 gap-2">
                {([180, 300, 600] as const).map((dur) => (
                  <button
                    key={dur}
                    type="button"
                    onClick={() => setSelectedDuration(dur)}
                    className={`min-h-[44px] rounded-2xl border text-xs sm:text-sm font-semibold font-math transition-all ${
                      selectedDuration === dur
                        ? 'bg-gradient-to-r from-blue-500/85 to-violet-600/85 border-blue-300/65 text-white'
                        : 'bg-white/[0.04] border-white/10 text-slate-200 hover:bg-white/[0.08]'
                    }`}
                  >
                    {t.duelsMinutesUnit(dur / 60)}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {createError && (
            <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-400/35 text-xs text-rose-200">
              {createError}
            </div>
          )}

          <button
            type="button"
            disabled={!selectedOpponent || creating}
            onClick={() => void handleSendChallenge()}
            className="liquid-glass-button w-full sm:w-auto min-h-[48px] px-7 py-3 rounded-2xl text-sm font-semibold text-white disabled:opacity-45 inline-flex items-center justify-center gap-2"
          >
            <Swords className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>{creating ? t.duelsSendingBtn : t.duelsSendChallengeBtn}</span>
          </button>
        </LiquidGlassCard>
      )}

      {/* TAB 3: TOP COMPETITORS RANKING */}
      {activeTab === 'rankings' && (
        <div className="space-y-4">
          <div className="px-1 space-y-1">
            <h2 className="font-display text-lg font-bold text-white flex items-center gap-2">
              <Crown className="w-5 h-5 text-amber-300 shrink-0" aria-hidden="true" />
              <span>{t.duelsTopCompetitorsTitle}</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-300">{t.duelsTopCompetitorsSubtitle}</p>
          </div>

          {topCompetitors.length === 0 ? (
            <LiquidGlassCard variant="subtle" className="p-10 text-center space-y-3">
              <Trophy className="w-10 h-10 text-amber-300 mx-auto" aria-hidden="true" />
              <p className="text-sm text-slate-300 max-w-md mx-auto">{t.duelsNoRankingsYet}</p>
            </LiquidGlassCard>
          ) : (
            <LiquidGlassCard variant="subtle" className="divide-y divide-white/10 overflow-hidden">
              {topCompetitors.map((stat, idx) => {
                const rank = idx + 1;
                const country = findCountryByCode(stat.countryCode);
                const isMe = stat.uid === firebaseUser?.uid;
                return (
                  <div
                    key={stat.uid}
                    className={`p-4 sm:px-6 flex items-center justify-between gap-3 ${
                      isMe ? 'bg-blue-500/15' : ''
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span
                        className={`w-8 text-center font-math text-sm font-extrabold tabular-nums shrink-0 ${
                          rank === 1
                            ? 'text-amber-300'
                            : rank === 2
                              ? 'text-sky-300'
                              : rank === 3
                                ? 'text-violet-300'
                                : 'text-slate-400'
                        }`}
                      >
                        #{rank}
                      </span>
                      <AvatarDisplay
                        avatarId={stat.avatarId}
                        photoUrl={stat.photoUrl}
                        displayName={stat.displayName}
                        size="sm"
                      />
                      <div className="min-w-0 space-y-0.5">
                        <div className="text-sm font-bold text-white truncate">
                          {country?.flag} {stat.displayName}
                        </div>
                        <div className="text-xs text-slate-400 font-math tabular-nums flex flex-wrap items-center gap-2">
                          <span className="text-emerald-300">
                            {stat.wins} {t.duelsWinsShort}
                          </span>
                          <span>·</span>
                          <span className="text-sky-300">
                            {stat.draws} {t.duelsDrawsShort}
                          </span>
                          <span>·</span>
                          <span className="text-rose-300">
                            {stat.losses} {t.duelsLossesShort}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="text-end font-math text-sm font-extrabold text-white tabular-nums shrink-0 inline-flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-amber-300" aria-hidden="true" />
                      <span>
                        {stat.duelPoints} {t.duelsPointsLabel}
                      </span>
                    </div>
                  </div>
                );
              })}
            </LiquidGlassCard>
          )}
        </div>
      )}
    </motion.section>
  );
}
