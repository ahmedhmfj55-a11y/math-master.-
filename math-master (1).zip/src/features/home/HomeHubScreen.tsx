import {
  ArrowLeft,
  ArrowRight,
  Award,
  BookOpen,
  Calendar,
  CheckCircle2,
  ClipboardCheck,
  Crown,
  Flame,
  Globe2,
  GraduationCap,
  Layers,
  ShoppingBag,
  Sparkles,
  Star,
  Swords,
  Trophy,
} from 'lucide-react';
import { motion } from 'motion/react';
import { AppTopBar, type HubTab } from '@/src/components/ui/AppTopBar';
import { AvatarDisplay } from '@/src/components/ui/AvatarDisplay';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { useAuth } from '@/src/contexts/AuthContext';
import { useDuels } from '@/src/contexts/DuelsContext';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useProgress } from '@/src/contexts/ProgressContext';
import { useQuestionBank } from '@/src/contexts/QuestionBankContext';
import { ALL_ACHIEVEMENT_AND_MEDAL_ITEMS } from '@/src/data/achievementsCatalog';
import {
  getEffectiveActiveStreak,
  getTodayDateKey,
} from '@/src/data/dailyChallengeGenerator';
import { GRADE_LEVELS, getGradeByOrder, getTierMeta } from '@/src/data/questionBank/catalog';
import { getTotalVerifiedQuestionCount } from '@/src/data/questionBank/bankEngine';
import { getRewardById } from '@/src/data/rewardsCatalog';
import { storageService } from '@/src/services/storageService';

interface HomeHubScreenProps {
  onChangeCountry: () => void;
  onNavigate: (tab: HubTab) => void;
  onOpenDailyChallenge: () => void;
  onOpenGeniusChallenges?: () => void;
}

export function HomeHubScreen({
  onChangeCountry,
  onNavigate,
  onOpenDailyChallenge,
  onOpenGeniusChallenges,
}: HomeHubScreenProps) {
  const { language, direction, t } = useLanguage();
  const { firebaseUser, userProfile, selectedCountry } = useAuth();
  const {
    totalCompletedStages,
    totalStars,
    totalCertificates,
    totalMasteredSections,
    dailyStats,
    todayDailyRecord,
    achievementsMap,
  } = useProgress();
  const { pendingActionCount } = useDuels();
  const { adaptiveProfile, getGradeMasteredTiersCount } = useQuestionBank();

  const totalBankQuestions = getTotalVerifiedQuestionCount();
  const masteredBankTiers = GRADE_LEVELS.reduce(
    (sum, g) => sum + getGradeMasteredTiersCount(g.id),
    0,
  );
  const recGrade = getGradeByOrder(adaptiveProfile?.recommendedGradeNumber ?? 1) ?? GRADE_LEVELS[0];
  const recTierMeta = getTierMeta(adaptiveProfile?.recommendedTier ?? 'very_easy');

  const ForwardArrow = direction === 'rtl' ? ArrowLeft : ArrowRight;

  const displayName =
    userProfile?.displayName ||
    firebaseUser?.displayName ||
    firebaseUser?.phoneNumber ||
    firebaseUser?.email ||
    'Math Master';

  const countryLabel = selectedCountry
    ? language === 'ar'
      ? selectedCountry.nameAr
      : selectedCountry.nameEn
    : userProfile
      ? language === 'ar'
        ? userProfile.countryNameAr
        : userProfile.countryNameEn
      : '—';

  const spendablePoints = userProfile?.points ?? 0;
  const equippedTitle = getRewardById(userProfile?.equippedTitleId);
  const equippedBadge = getRewardById(userProfile?.equippedBadgeId);

  const todayKey = getTodayDateKey();
  const activeDailyStreak = getEffectiveActiveStreak(
    dailyStats?.currentStreak ?? 0,
    dailyStats?.lastWonDate,
    todayKey,
  );
  const hasDailyDraft =
    !todayDailyRecord &&
    Boolean(firebaseUser?.uid && storageService.getDailyDraft(firebaseUser.uid, todayKey));

  const sectionsCompletionPct = Math.round((totalCompletedStages / 240) * 100);

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
      className="min-h-dvh flex flex-col px-4 py-5 sm:px-8 sm:py-7 max-w-6xl mx-auto w-full gap-6 safe-pb-nav"
    >
      <AppTopBar activeTab="home" onNavigate={onNavigate} />

      <main className="space-y-6 flex-1">
        {/* Learner Welcome + Real Stats Overview */}
        <LiquidGlassCard className="p-5 sm:p-8">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5 pb-6 border-b border-white/10">
            <div className="flex items-start sm:items-center gap-4 min-w-0">
              <button
                type="button"
                onClick={() => onNavigate('profile')}
                className="relative shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 rounded-3xl"
                aria-label={t.navProfile}
              >
                <AvatarDisplay
                  avatarId={userProfile?.equippedAvatarId}
                  photoUrl={userProfile?.photoUrl}
                  displayName={displayName}
                  size="lg"
                />
                {equippedBadge && (
                  <span
                    className={`absolute -bottom-1 -end-1 w-7 h-7 rounded-xl bg-gradient-to-br ${equippedBadge.accentFrom} ${equippedBadge.accentTo} border border-white/40 flex items-center justify-center text-xs font-bold text-white shadow-lg`}
                  >
                    {equippedBadge.symbol}
                  </span>
                )}
              </button>

              <div className="space-y-1.5 min-w-0">
                <div className="flex items-center gap-2 text-xs font-medium text-emerald-300">
                  <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>{t.homeReadyBadge}</span>
                </div>
                <h1 className="font-display text-2xl sm:text-3xl font-bold text-white text-balance truncate">
                  {t.homeWelcome(displayName)}
                </h1>
                <div className="flex flex-wrap items-center gap-2 text-xs sm:text-sm text-slate-300">
                  {equippedTitle && (
                    <>
                      <span className="font-semibold text-violet-200">
                        {language === 'ar' ? equippedTitle.nameAr : equippedTitle.nameEn}
                      </span>
                      <span aria-hidden="true">·</span>
                    </>
                  )}
                  <span className="truncate">{firebaseUser?.email || firebaseUser?.phoneNumber}</span>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={onChangeCountry}
              className="liquid-glass-subtle min-h-[44px] px-4 py-2 rounded-2xl text-sm font-medium text-white hover:bg-white/10 inline-flex items-center gap-2.5 self-start lg:self-auto shrink-0 transition-colors"
            >
              {selectedCountry ? (
                <span className="text-xl" aria-hidden="true">
                  {selectedCountry.flag}
                </span>
              ) : (
                <Globe2 className="w-4 h-4 text-blue-300" aria-hidden="true" />
              )}
              <span>{countryLabel}</span>
              <span className="text-slate-400" aria-hidden="true">·</span>
              <span className="text-xs text-blue-200">{t.homeChangeCountry}</span>
            </button>
          </div>

          {/* 4 Verified Core Metrics */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 pt-5">
            <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 space-y-1">
              <div className="text-xs text-slate-400 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-blue-300 shrink-0" aria-hidden="true" />
                <span>{t.homePointsLabel}</span>
              </div>
              <div className="text-2xl font-bold text-white font-math tabular-nums">
                {spendablePoints}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 space-y-1">
              <div className="text-xs text-slate-400 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-violet-300 shrink-0" aria-hidden="true" />
                <span>{t.statsCompletedStages}</span>
              </div>
              <div className="text-2xl font-bold text-white font-math tabular-nums">
                {totalCompletedStages} <span className="text-sm font-normal text-slate-400">/ 240</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 space-y-1">
              <div className="text-xs text-slate-400 flex items-center gap-1.5">
                <Star className="w-3.5 h-3.5 text-amber-300 shrink-0" aria-hidden="true" />
                <span>{t.statsStarsEarned}</span>
              </div>
              <div className="text-2xl font-bold text-amber-200 font-math tabular-nums">
                {totalStars} <span className="text-sm font-normal text-slate-400">/ 720</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 space-y-1">
              <div className="text-xs text-slate-400 flex items-center gap-1.5">
                <Award className="w-3.5 h-3.5 text-emerald-300 shrink-0" aria-hidden="true" />
                <span>{t.statsCertificatesEarned}</span>
              </div>
              <div className="text-2xl font-bold text-emerald-200 font-math tabular-nums">
                {totalCertificates} <span className="text-sm font-normal text-slate-400">/ 8</span>
              </div>
            </div>
          </div>
        </LiquidGlassCard>

        {/* Primary Focal Actions: Learning Sections Hub + Competitive 1v1 Duels */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Primary Card 1: Learning Sections -> Dedicated Standalone 8-Section Page */}
          <LiquidGlassCard className="p-6 sm:p-7 border-blue-400/35 bg-gradient-to-br from-blue-500/18 via-indigo-500/12 to-violet-600/18 flex flex-col justify-between gap-5">
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-500 to-violet-600 border border-white/30 flex items-center justify-center text-white shrink-0 shadow-[0_10px_28px_rgba(59,130,246,0.38)]">
                <BookOpen className="w-7 h-7" aria-hidden="true" />
              </div>
              <div className="space-y-1.5 min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2 text-xs font-math tabular-nums text-blue-200 font-semibold">
                  <span>{totalCompletedStages} / 240</span>
                  <span aria-hidden="true">·</span>
                  <span>{sectionsCompletionPct}%</span>
                </div>
                <h2 className="font-display text-xl sm:text-2xl font-bold text-white">
                  {t.homeSectionsCardTitle}
                </h2>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {t.homeSectionsCardDesc}
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <div className="h-2 w-full rounded-full bg-white/10 overflow-hidden">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-blue-400 to-violet-500 transition-all duration-500"
                  style={{ width: `${sectionsCompletionPct}%` }}
                />
              </div>

              <button
                type="button"
                onClick={() => onNavigate('sections')}
                className="liquid-glass-button w-full min-h-[48px] px-5 py-3 rounded-2xl text-sm font-semibold text-white inline-flex items-center justify-center gap-2 whitespace-nowrap"
              >
                <BookOpen className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{t.homeSectionsCardCta}</span>
                <ForwardArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
              </button>
            </div>
          </LiquidGlassCard>

          {/* Primary Card 2: Real-Time Competitive 1v1 Duels */}
          <LiquidGlassCard className="p-6 sm:p-7 border-violet-400/35 bg-gradient-to-br from-violet-500/16 via-fuchsia-500/10 to-sky-500/16 flex flex-col justify-between gap-5">
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-600 border border-white/30 flex items-center justify-center text-white shrink-0 shadow-[0_10px_28px_rgba(139,92,246,0.38)]">
                <Swords className="w-7 h-7" aria-hidden="true" />
              </div>
              <div className="space-y-1.5 min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2 text-xs font-semibold">
                  <span className="text-emerald-300 font-math">{t.duelsRewardWinLabel}</span>
                  {pendingActionCount > 0 && (
                    <span className="px-2 py-0.5 rounded-lg bg-rose-500/85 text-white text-[11px] font-bold font-math keep-white">
                      {pendingActionCount}
                    </span>
                  )}
                </div>
                <h2 className="font-display text-xl sm:text-2xl font-bold text-white">
                  {t.homeDuelsCardTitle}
                </h2>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {t.homeDuelsCardDesc}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onNavigate('duels')}
              className="liquid-glass-button w-full min-h-[48px] px-5 py-3 rounded-2xl text-sm font-semibold text-white inline-flex items-center justify-center gap-2 whitespace-nowrap"
            >
              <Swords className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>{t.homeDuelsCardCta}</span>
              <ForwardArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
            </button>
          </LiquidGlassCard>
        </div>

        {/* Global Progressive Question Bank & World Genius Featured Card */}
        <LiquidGlassCard className="p-6 sm:p-7 border-sky-400/35 bg-gradient-to-br from-sky-500/14 via-indigo-500/10 to-violet-600/16">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
            <div className="flex items-start gap-4 min-w-0">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-sky-500 to-indigo-600 border border-white/30 flex items-center justify-center text-white shrink-0 shadow-[0_10px_28px_rgba(56,189,248,0.35)]">
                <GraduationCap className="w-7 h-7" aria-hidden="true" />
              </div>
              <div className="space-y-1.5 min-w-0">
                <div className="flex flex-wrap items-center gap-2 text-xs font-math tabular-nums">
                  <span className="px-2.5 py-0.5 rounded-lg bg-sky-500/20 border border-sky-400/35 text-sky-200 font-semibold">
                    {totalBankQuestions.toLocaleString()} {language === 'ar' ? 'سؤال' : 'Q'}
                  </span>
                  <span className="px-2.5 py-0.5 rounded-lg bg-white/[0.07] border border-white/15 text-slate-200 font-semibold">
                    {masteredBankTiers} / {GRADE_LEVELS.length * 5}
                  </span>
                  <span className="text-blue-200 font-medium">
                    {language === 'ar' ? recGrade.titleAr : recGrade.titleEn} ·{' '}
                    {language === 'ar' ? recTierMeta.titleAr : recTierMeta.titleEn}
                  </span>
                </div>
                <h2 className="font-display text-lg sm:text-xl font-bold text-white">
                  {t.homeBankCardTitle}
                </h2>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-2xl">
                  {t.homeBankCardDesc}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 shrink-0">
              {onOpenGeniusChallenges && (
                <button
                  type="button"
                  onClick={onOpenGeniusChallenges}
                  className="liquid-glass-subtle min-h-[46px] px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-amber-200 hover:bg-white/10 inline-flex items-center gap-2 whitespace-nowrap"
                >
                  <Crown className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>{t.homeGeniusQuickBtn}</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => onNavigate('question-bank')}
                className="liquid-glass-button min-h-[46px] px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center gap-2 whitespace-nowrap"
              >
                <GraduationCap className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{t.homeBankCardCta}</span>
                <ForwardArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
              </button>
            </div>
          </div>
        </LiquidGlassCard>

        {/* Daily Challenges Featured Card */}
        <LiquidGlassCard className="p-6 sm:p-7 border-amber-400/30 bg-gradient-to-br from-amber-500/12 via-blue-500/10 to-violet-600/15">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
            <div className="flex items-start gap-4">
              <div className="w-13 h-13 rounded-2xl bg-gradient-to-br from-amber-500 to-orange-600 border border-white/25 flex items-center justify-center text-white shrink-0 shadow-[0_0_24px_rgba(245,158,11,0.35)]">
                <Flame className="w-6 h-6" aria-hidden="true" />
              </div>
              <div className="space-y-1.5">
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  <span
                    className={`px-2.5 py-0.5 rounded-lg border font-semibold inline-flex items-center gap-1.5 ${
                      todayDailyRecord
                        ? 'bg-emerald-500/20 border-emerald-400/35 text-emerald-200'
                        : hasDailyDraft
                          ? 'bg-sky-500/20 border-sky-400/35 text-sky-200'
                          : 'bg-amber-500/20 border-amber-400/35 text-amber-200'
                    }`}
                  >
                    <Calendar className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                    <span>
                      {todayDailyRecord
                        ? `${t.dailyCompletedTodayBadge} · ${todayDailyRecord.score}/100`
                        : hasDailyDraft
                          ? t.dailyInProgressBadge
                          : t.dailyTodayBadge}
                    </span>
                  </span>

                  <span className="px-2.5 py-0.5 rounded-lg bg-white/[0.06] border border-white/15 text-slate-200 font-semibold font-math tabular-nums inline-flex items-center gap-1">
                    <Flame className="w-3.5 h-3.5 text-amber-300" aria-hidden="true" />
                    <span>
                      {t.dailyStreakLabel}: {t.dailyStreakDaysValue(activeDailyStreak)}
                    </span>
                  </span>
                </div>

                <h2 className="font-display text-lg sm:text-xl font-bold text-white">
                  {t.dailyCardTitle}
                </h2>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-2xl">
                  {t.dailyCardDesc}
                </p>
                <div className="text-xs font-medium text-blue-200 font-math tabular-nums">
                  {t.dailyMetaSummary}
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 shrink-0">
              <button
                type="button"
                onClick={onOpenDailyChallenge}
                className="liquid-glass-button min-h-[48px] px-6 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center gap-2 whitespace-nowrap shrink-0"
              >
                <Flame className="w-4 h-4 text-amber-300 shrink-0" aria-hidden="true" />
                <span>
                  {todayDailyRecord
                    ? t.dailyViewResultBtn
                    : hasDailyDraft
                      ? t.dailyResumeBtn
                      : t.dailyStartBtn}
                </span>
              </button>
            </div>
          </div>
        </LiquidGlassCard>

        {/* Secondary Modules Grid (Clean & Balanced) */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
          <button
            type="button"
            onClick={() => onNavigate('exams')}
            className="liquid-glass-subtle p-4 rounded-2xl flex items-center gap-3 text-start hover:bg-white/[0.08] transition-colors"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-300 shrink-0">
              <ClipboardCheck className="w-5 h-5" aria-hidden="true" />
            </div>
            <div className="min-w-0">
              <div className="text-sm font-bold text-white truncate">{t.navExams}</div>
              <div className="text-xs text-slate-400 font-math tabular-nums truncate">
                {totalMasteredSections} / 8
              </div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('achievements')}
            className="liquid-glass-subtle p-4 rounded-2xl flex items-center gap-3 text-start hover:bg-white/[0.08] transition-colors"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-400/20 border border-amber-300/35 flex items-center justify-center text-amber-200 shrink-0">
              <Award className="w-5 h-5" aria-hidden="true" />
            </div>
            <div className="min-w-0">
              <div className="text-sm font-bold text-white truncate">{t.navAchievements}</div>
              <div className="text-xs text-slate-400 font-math tabular-nums truncate">
                {Object.keys(achievementsMap).length} / {ALL_ACHIEVEMENT_AND_MEDAL_ITEMS.length}
              </div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('leaderboard')}
            className="liquid-glass-subtle p-4 rounded-2xl flex items-center gap-3 text-start hover:bg-white/[0.08] transition-colors"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-300 shrink-0">
              <Trophy className="w-5 h-5" aria-hidden="true" />
            </div>
            <div className="min-w-0">
              <div className="text-sm font-bold text-white truncate">{t.navLeaderboard}</div>
              <div className="text-xs text-slate-400 truncate">{t.leaderboardLiveBadge}</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigate('shop')}
            className="liquid-glass-subtle p-4 rounded-2xl flex items-center gap-3 text-start hover:bg-white/[0.08] transition-colors"
          >
            <div className="w-10 h-10 rounded-xl bg-violet-500/20 border border-violet-400/30 flex items-center justify-center text-violet-300 shrink-0">
              <ShoppingBag className="w-5 h-5" aria-hidden="true" />
            </div>
            <div className="min-w-0">
              <div className="text-sm font-bold text-white truncate">{t.navShop}</div>
              <div className="text-xs text-slate-400 font-math tabular-nums truncate">
                {spendablePoints} {t.leaderboardPointsUnit}
              </div>
            </div>
          </button>
        </div>
      </main>
    </motion.section>
  );
}

