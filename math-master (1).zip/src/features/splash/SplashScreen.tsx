import { motion } from 'motion/react';
import { useEffect, useState } from 'react';
import { LanguageSwitcher } from '@/src/components/ui/LanguageSwitcher';
import { MathMasterLogo } from '@/src/components/ui/MathMasterLogo';
import { useLanguage } from '@/src/contexts/LanguageContext';

interface SplashScreenProps {
  onComplete: () => void;
}

interface OrbitGlyph {
  symbol: string;
  x: string;
  y: string;
  delay: number;
  duration: number;
  sizeClass: string;
}

const ORBIT_GLYPHS: OrbitGlyph[] = [
  { symbol: '∑', x: '16%', y: '22%', delay: 0.1, duration: 5.5, sizeClass: 'text-2xl sm:text-3xl' },
  { symbol: 'π', x: '82%', y: '20%', delay: 0.25, duration: 6.2, sizeClass: 'text-2xl sm:text-3xl' },
  { symbol: '∫', x: '12%', y: '56%', delay: 0.35, duration: 6.8, sizeClass: 'text-2xl sm:text-4xl' },
  { symbol: '∞', x: '86%', y: '54%', delay: 0.15, duration: 5.8, sizeClass: 'text-2xl sm:text-3xl' },
  { symbol: 'e^{iπ}+1=0', x: '20%', y: '80%', delay: 0.45, duration: 7.2, sizeClass: 'text-xs sm:text-sm' },
  { symbol: 'a² + b² = c²', x: '76%', y: '78%', delay: 0.3, duration: 6.5, sizeClass: 'text-xs sm:text-sm' },
  { symbol: '√2', x: '34%', y: '14%', delay: 0.2, duration: 5.2, sizeClass: 'text-lg sm:text-xl' },
  { symbol: 'Δθ', x: '67%', y: '13%', delay: 0.4, duration: 6.0, sizeClass: 'text-lg sm:text-xl' },
  { symbol: 'f(x)', x: '26%', y: '38%', delay: 0.5, duration: 6.4, sizeClass: 'text-sm sm:text-base' },
  { symbol: '∇·E', x: '74%', y: '37%', delay: 0.55, duration: 5.9, sizeClass: 'text-sm sm:text-base' },
  { symbol: 'φ ≈ 1.618', x: '50%', y: '85%', delay: 0.35, duration: 7.0, sizeClass: 'text-xs sm:text-sm' },
  { symbol: '∈ ℝ', x: '10%', y: '38%', delay: 0.6, duration: 6.6, sizeClass: 'text-xs sm:text-sm' },
];

const SPLASH_DURATION_MS = 3400;

export function SplashScreen({ onComplete }: SplashScreenProps) {
  const { t } = useLanguage();
  const [exiting, setExiting] = useState(false);

  useEffect(() => {
    const exitTimer = window.setTimeout(() => {
      setExiting(true);
    }, SPLASH_DURATION_MS - 450);

    const completeTimer = window.setTimeout(() => {
      onComplete();
    }, SPLASH_DURATION_MS);

    return () => {
      window.clearTimeout(exitTimer);
      window.clearTimeout(completeTimer);
    };
  }, [onComplete]);

  const handleSkip = () => {
    setExiting(true);
    window.setTimeout(onComplete, 220);
  };

  return (
    <motion.section
      initial={{ opacity: 0 }}
      animate={{ opacity: exiting ? 0 : 1 }}
      transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
      className="relative min-h-screen w-full flex flex-col justify-between p-5 sm:p-8 overflow-hidden"
      aria-label="Math Master Splash Screen"
    >
      {/* Top minimal controls */}
      <header className="relative z-20 flex items-center justify-between gap-4 max-w-6xl w-full mx-auto">
        <LanguageSwitcher />
        <button
          type="button"
          onClick={handleSkip}
          className="liquid-glass-subtle min-h-[40px] px-4 py-2 rounded-2xl text-xs sm:text-sm font-medium text-slate-200 hover:text-white hover:bg-white/10 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-400"
        >
          {t.skipToCountry}
        </button>
      </header>

      {/* Ambient orbiting mathematical symbols & equations */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
        {/* Subtle orbital rings centered behind logo */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 48, repeat: Infinity, ease: 'linear' }}
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] sm:w-[460px] sm:h-[460px] rounded-full border border-white/[0.07]"
        />
        <motion.div
          animate={{ rotate: -360 }}
          transition={{ duration: 64, repeat: Infinity, ease: 'linear' }}
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[440px] h-[440px] sm:w-[660px] sm:h-[660px] rounded-full border border-dashed border-violet-300/[0.08]"
        />

        {ORBIT_GLYPHS.map((glyph) => (
          <motion.span
            key={glyph.symbol}
            style={{ left: glyph.x, top: glyph.y }}
            initial={{ opacity: 0, scale: 0.75 }}
            animate={{
              opacity: [0, 0.72, 0.48, 0.75],
              scale: [0.85, 1, 0.96, 1],
              y: [0, -10, 4, 0],
            }}
            transition={{
              delay: glyph.delay,
              duration: glyph.duration,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            className={`absolute -translate-x-1/2 -translate-y-1/2 font-math font-medium text-blue-100/75 select-none px-3 py-1.5 rounded-2xl bg-white/[0.03] border border-white/[0.07] backdrop-blur-sm shadow-sm ${glyph.sizeClass}`}
          >
            {glyph.symbol}
          </motion.span>
        ))}
      </div>

      {/* Central Liquid Glass Brand Focal Stage */}
      <main className="relative z-10 flex-1 flex items-center justify-center px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9, y: 16 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="liquid-glass rounded-[36px] px-7 py-10 sm:px-14 sm:py-14 max-w-xl w-full text-center relative overflow-hidden"
        >
          {/* Specular top glow */}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute -top-24 left-1/2 -translate-x-1/2 w-64 h-40 rounded-full bg-gradient-to-b from-blue-400/25 to-violet-500/5 blur-2xl"
          />

          <motion.div
            initial={{ scale: 0.7, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.15, duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
            className="relative flex justify-center mb-7"
          >
            <MathMasterLogo size="lg" />
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.55 }}
            className="font-display text-3xl sm:text-5xl font-bold tracking-tight text-white mb-4"
            dir="ltr"
          >
            {t.brandName}
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.45, duration: 0.55 }}
            className="text-lg sm:text-xl font-semibold text-blue-100 leading-relaxed text-balance mb-2.5"
          >
            {t.splashTagline}
          </motion.p>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6, duration: 0.55 }}
            className="text-sm text-slate-300 leading-relaxed text-balance"
          >
            {t.splashSubtext}
          </motion.p>

          {/* Subtle progress bar indicating smooth auto-transition */}
          <div className="mt-8 mx-auto w-40 h-1 rounded-full bg-white/10 overflow-hidden" aria-hidden="true">
            <motion.div
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ duration: (SPLASH_DURATION_MS - 300) / 1000, ease: 'easeInOut' }}
              className="h-full w-full origin-left bg-gradient-to-r from-blue-400 via-indigo-400 to-violet-400"
            />
          </div>
        </motion.div>
      </main>

      <div className="h-6" aria-hidden="true" />
    </motion.section>
  );
}
