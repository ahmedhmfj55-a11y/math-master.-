import { Loader2 } from 'lucide-react';
import { useState } from 'react';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { AuthServiceError, authService } from '@/src/services/authService';

interface GoogleAuthButtonProps {
  onError: (message: string) => void;
  disabled?: boolean;
}

export function GoogleAuthButton({ onError, disabled = false }: GoogleAuthButtonProps) {
  const { language, t } = useLanguage();
  const [loading, setLoading] = useState(false);

  const handleGoogleLogin = async () => {
    if (loading || disabled) return;
    onError('');
    setLoading(true);
    try {
      await authService.signInWithGoogle(language);
    } catch (error) {
      if (error instanceof AuthServiceError) {
        switch (error.code) {
          case 'popup-blocked':
            onError(t.errorPopupBlocked);
            break;
          case 'popup-closed':
            onError(t.errorPopupClosed);
            break;
          case 'network-error':
            onError(t.errorNetwork);
            break;
          default:
            onError(t.errorGeneric);
        }
      } else {
        onError(t.errorGeneric);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <button
      type="button"
      disabled={loading || disabled}
      onClick={() => void handleGoogleLogin()}
      className="w-full min-h-[52px] px-5 py-3.5 rounded-2xl bg-white/[0.94] hover:bg-white text-slate-900 font-semibold text-sm flex items-center justify-center gap-3 shadow-[0_12px_32px_-8px_rgba(255,255,255,0.28)] border border-white transition-all duration-150 active:scale-[0.98] disabled:opacity-60 disabled:cursor-not-allowed focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-400"
    >
      {loading ? (
        <>
          <Loader2 className="w-5 h-5 animate-spin text-indigo-600 shrink-0" aria-hidden="true" />
          <span>{t.authGoogleLoading}</span>
        </>
      ) : (
        <>
          <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
            <path
              fill="#4285F4"
              d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17Z"
            />
            <path
              fill="#34A853"
              d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.11-6.72-4.96H1.29v3.14C3.26 21.3 7.31 24 12 24Z"
            />
            <path
              fill="#FBBC05"
              d="M5.28 14.24c-.24-.72-.38-1.49-.38-2.24s.14-1.52.38-2.24V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.99-3.14Z"
            />
            <path
              fill="#EA4335"
              d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.99 3.14c.95-2.85 3.6-4.96 6.72-4.96Z"
            />
          </svg>
          <span>{t.authGoogleButton}</span>
        </>
      )}
    </button>
  );
}
