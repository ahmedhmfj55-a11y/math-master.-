import { AlertCircle, ArrowLeft, ArrowRight, CheckCircle2, Globe2, Layers, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';
import { useState } from 'react';
import { LanguageSwitcher } from '@/src/components/ui/LanguageSwitcher';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { MathMasterLogo } from '@/src/components/ui/MathMasterLogo';
import { useAuth } from '@/src/contexts/AuthContext';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { GoogleAuthButton } from '@/src/features/auth/GoogleAuthButton';
import { PhoneAuthForm } from '@/src/features/auth/PhoneAuthForm';

interface AuthScreenProps {
  onBackToCountry: () => void;
}

export function AuthScreen({ onBackToCountry }: AuthScreenProps) {
  const { language, isRtl, t } = useLanguage();
  const { selectedCountry } = useAuth();
  const [errorMessage, setErrorMessage] = useState('');

  const BackIcon = isRtl ? ArrowRight : ArrowLeft;
  const countryDisplay = selectedCountry
    ? language === 'ar'
      ? selectedCountry.nameAr
      : selectedCountry.nameEn
    : '';

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
      className="min-h-screen flex flex-col justify-between px-4 py-5 sm:px-8 sm:py-7 max-w-6xl mx-auto w-full"
    >
      {/* Top Bar */}
      <header className="flex items-center justify-between gap-4 mb-6">
        <button
          type="button"
          onClick={onBackToCountry}
          className="liquid-glass-subtle min-h-[42px] px-4 py-2 rounded-2xl text-xs sm:text-sm font-medium text-slate-200 hover:text-white inline-flex items-center gap-2 whitespace-nowrap shrink-0 transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-400"
        >
          <BackIcon className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{t.authBackToCountry}</span>
        </button>

        <LanguageSwitcher />
      </header>

      {/* Main Responsive Split Showcase + Liquid Glass Auth Card */}
      <main className="flex-1 flex items-center justify-center py-2">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 w-full items-stretch">
          {/* Brand & Educational Promise Panel (visible cleanly on desktop/tablet, compact summary on mobile) */}
          <LiquidGlassCard
            variant="subtle"
            className="lg:col-span-6 p-6 sm:p-10 flex flex-col justify-between gap-8"
          >
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <MathMasterLogo size="md" />
                <div>
                  <div className="font-display text-2xl font-bold text-white" dir="ltr">
                    {t.brandName}
                  </div>
                  <p className="text-xs sm:text-sm text-blue-200/85 mt-0.5">
                    {t.splashTagline}
                  </p>
                </div>
              </div>

              <div className="space-y-3 pt-2 border-t border-white/10">
                <div className="flex items-start gap-3 text-sm text-slate-200">
                  <Layers className="w-5 h-5 text-blue-300 shrink-0 mt-0.5" aria-hidden="true" />
                  <span className="leading-relaxed">{t.authFeatureStages}</span>
                </div>
                <div className="flex items-start gap-3 text-sm text-slate-200">
                  <CheckCircle2 className="w-5 h-5 text-violet-300 shrink-0 mt-0.5" aria-hidden="true" />
                  <span className="leading-relaxed">{t.authFeatureAdaptive}</span>
                </div>
                <div className="flex items-start gap-3 text-sm text-slate-200">
                  <ShieldCheck className="w-5 h-5 text-indigo-300 shrink-0 mt-0.5" aria-hidden="true" />
                  <span className="leading-relaxed">{t.authFeatureGlobal}</span>
                </div>
              </div>
            </div>

            {/* Selected Country Interactive Switcher */}
            {selectedCountry && (
              <div className="pt-5 border-t border-white/10 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <span
                    className="w-10 h-10 rounded-xl bg-white/[0.08] border border-white/10 flex items-center justify-center text-2xl shrink-0"
                    aria-hidden="true"
                  >
                    {selectedCountry.flag}
                  </span>
                  <div className="min-w-0">
                    <div className="text-xs text-slate-400">{t.countrySelectedLabel}</div>
                    <div className="text-sm font-semibold text-white truncate">
                      {countryDisplay}
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={onBackToCountry}
                  className="min-h-[40px] px-3.5 py-2 rounded-xl bg-white/[0.07] hover:bg-white/[0.14] border border-white/15 text-xs font-medium text-blue-100 whitespace-nowrap shrink-0 inline-flex items-center gap-1.5 transition-colors"
                >
                  <Globe2 className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>{t.authChangeCountry}</span>
                </button>
              </div>
            )}
          </LiquidGlassCard>

          {/* Luxury Liquid Glass Sign-In Card */}
          <LiquidGlassCard className="lg:col-span-6 p-6 sm:p-10 flex flex-col justify-center relative overflow-hidden">
            <div
              aria-hidden="true"
              className="pointer-events-none absolute -top-24 -end-20 w-56 h-56 rounded-full bg-violet-500/20 blur-3xl"
            />

            <div className="relative space-y-6">
              <div className="space-y-2">
                <h1 className="font-display text-2xl sm:text-3xl font-bold text-white text-balance">
                  {t.authTitle}
                </h1>
                <p className="text-sm text-slate-300 leading-relaxed">
                  {t.authSubtitle}
                </p>
              </div>

              {errorMessage && (
                <div
                  role="alert"
                  className="rounded-2xl p-3.5 bg-rose-500/15 border border-rose-400/35 text-rose-100 text-xs sm:text-sm flex items-start gap-2.5"
                >
                  <AlertCircle className="w-4 h-4 text-rose-300 shrink-0 mt-0.5" aria-hidden="true" />
                  <span className="leading-relaxed">{errorMessage}</span>
                </div>
              )}

              {/* Google Sign-In */}
              <GoogleAuthButton onError={setErrorMessage} />

              {/* Divider */}
              <div className="relative flex items-center gap-3 py-1" aria-hidden="true">
                <div className="h-px flex-1 bg-white/15" />
                <span className="text-xs font-medium text-slate-300">{t.authDivider}</span>
                <div className="h-px flex-1 bg-white/15" />
              </div>

              {/* Phone Sign-In */}
              <PhoneAuthForm
                selectedCountry={selectedCountry}
                onError={setErrorMessage}
              />
            </div>
          </LiquidGlassCard>
        </div>
      </main>

      <div className="h-4" aria-hidden="true" />
    </motion.section>
  );
}
