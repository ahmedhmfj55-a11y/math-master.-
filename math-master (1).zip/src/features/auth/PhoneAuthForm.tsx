import type { ConfirmationResult } from 'firebase/auth';
import { ExternalLink, KeyRound, Loader2, Phone, RotateCcw } from 'lucide-react';
import { useEffect, useState, type FormEvent } from 'react';
import { firebaseProjectId } from '@/src/config/firebase';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { COUNTRIES } from '@/src/data/countries';
import {
  AuthServiceError,
  authService,
  clearRecaptchaVerifier,
} from '@/src/services/authService';
import type { Country } from '@/src/types/country';

interface PhoneAuthFormProps {
  selectedCountry: Country | null;
  onError: (message: string) => void;
  disabled?: boolean;
}

const RECAPTCHA_CONTAINER_ID = 'math-master-recaptcha';

export function PhoneAuthForm({
  selectedCountry,
  onError,
  disabled = false,
}: PhoneAuthFormProps) {
  const { language, t } = useLanguage();
  const [dialCode, setDialCode] = useState<string>(selectedCountry?.dialCode ?? '+966');
  const [localNumber, setLocalNumber] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);
  const [sentPhoneDisplay, setSentPhoneDisplay] = useState('');
  const [sending, setSending] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [resendSeconds, setResendSeconds] = useState(0);
  const [showPhoneSetupHelp, setShowPhoneSetupHelp] = useState(false);

  useEffect(() => {
    if (selectedCountry?.dialCode && !confirmationResult) {
      setDialCode(selectedCountry.dialCode);
    }
  }, [selectedCountry, confirmationResult]);

  useEffect(() => {
    if (resendSeconds <= 0) return;
    const timer = window.setInterval(() => {
      setResendSeconds((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => window.clearInterval(timer);
  }, [resendSeconds]);

  useEffect(() => {
    return () => {
      clearRecaptchaVerifier();
    };
  }, []);

  const formatE164 = (rawInput: string, code: string): string => {
    const cleaned = rawInput.replace(/[\s\-()]/g, '');
    if (cleaned.startsWith('+')) {
      return cleaned;
    }
    const withoutLeadingZero = cleaned.replace(/^0+/, '');
    return `${code}${withoutLeadingZero}`;
  };

  const handleSendCode = async (e?: FormEvent) => {
    e?.preventDefault();
    if (sending || disabled) return;

    onError('');
    setShowPhoneSetupHelp(false);

    const e164 = formatE164(localNumber, dialCode);
    if (!/^\+[1-9]\d{6,14}$/.test(e164)) {
      onError(t.errorInvalidPhone);
      return;
    }

    setSending(true);
    try {
      const result = await authService.sendPhoneVerificationCode(
        e164,
        RECAPTCHA_CONTAINER_ID,
        language,
      );
      setConfirmationResult(result);
      setSentPhoneDisplay(e164);
      setResendSeconds(60);
    } catch (error) {
      if (error instanceof AuthServiceError) {
        switch (error.code) {
          case 'operation-not-allowed':
            setShowPhoneSetupHelp(true);
            break;
          case 'invalid-phone':
            onError(t.errorInvalidPhone);
            break;
          case 'too-many-requests':
            onError(t.errorTooManyRequests);
            break;
          case 'network-error':
            onError(t.errorNetwork);
            break;
          default:
            onError(t.errorGeneric);
        }
      } else {
        onError(t.errorGeneric);
      }
    } finally {
      setSending(false);
    }
  };

  const handleVerifyOtp = async (e: FormEvent) => {
    e.preventDefault();
    if (!confirmationResult || verifying || disabled) return;

    onError('');
    const trimmed = otpCode.trim();
    if (trimmed.length < 4) {
      onError(t.errorInvalidOtp);
      return;
    }

    setVerifying(true);
    try {
      await authService.confirmPhoneCode(confirmationResult, trimmed);
    } catch (error) {
      if (error instanceof AuthServiceError) {
        switch (error.code) {
          case 'invalid-otp':
            onError(t.errorInvalidOtp);
            break;
          case 'too-many-requests':
            onError(t.errorTooManyRequests);
            break;
          case 'network-error':
            onError(t.errorNetwork);
            break;
          default:
            onError(t.errorGeneric);
        }
      } else {
        onError(t.errorGeneric);
      }
    } finally {
      setVerifying(false);
    }
  };

  const handleResetToPhoneEntry = () => {
    clearRecaptchaVerifier();
    setConfirmationResult(null);
    setOtpCode('');
    onError('');
  };

  return (
    <div className="space-y-4">
      {/* Hidden container for Firebase invisible reCAPTCHA */}
      <div id={RECAPTCHA_CONTAINER_ID} />

      {!confirmationResult ? (
        <form onSubmit={(e) => void handleSendCode(e)} className="space-y-3.5" noValidate>
          <label
            htmlFor="phone-local-input"
            className="block text-xs font-semibold text-slate-200"
          >
            {t.authPhoneLabel}
          </label>

          <div className="flex items-stretch gap-2" dir="ltr">
            <select
              aria-label="Country dial code"
              value={dialCode}
              onChange={(e) => setDialCode(e.target.value)}
              className="liquid-glass-input rounded-2xl px-3 min-h-[50px] text-sm font-math text-white bg-[#0a0f26]/80 focus:outline-none max-w-[122px] shrink-0"
            >
              {COUNTRIES.map((country) => (
                <option
                  key={country.code}
                  value={country.dialCode}
                  className="bg-[#0d1433] text-white"
                >
                  {country.flag} {country.dialCode}
                </option>
              ))}
            </select>

            <div className="liquid-glass-input rounded-2xl flex items-center gap-2.5 px-3.5 min-h-[50px] flex-1">
              <Phone className="w-4 h-4 text-slate-400 shrink-0" aria-hidden="true" />
              <input
                id="phone-local-input"
                type="tel"
                inputMode="tel"
                autoComplete="tel-national"
                value={localNumber}
                onChange={(e) => setLocalNumber(e.target.value)}
                placeholder={t.authPhonePlaceholder}
                className="w-full bg-transparent text-sm font-math text-white placeholder:text-slate-400 focus:outline-none"
                dir="ltr"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={sending || disabled || localNumber.trim().length < 5}
            className="liquid-glass-button w-full min-h-[52px] px-5 py-3 rounded-2xl text-sm font-semibold text-white flex items-center justify-center gap-2.5 transition-all duration-150 active:scale-[0.98] disabled:opacity-45 disabled:cursor-not-allowed focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-400"
          >
            {sending ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin shrink-0" aria-hidden="true" />
                <span>{t.authPhoneSending}</span>
              </>
            ) : (
              <span>{t.authPhoneSendCode}</span>
            )}
          </button>
        </form>
      ) : (
        <form onSubmit={(e) => void handleVerifyOtp(e)} className="space-y-4" noValidate>
          <div className="space-y-1">
            <h2 className="text-base font-semibold text-white">{t.authOtpTitle}</h2>
            <p className="text-xs text-slate-300 leading-relaxed" dir="auto">
              {t.authOtpSubtitle(sentPhoneDisplay)}
            </p>
          </div>

          <div className="liquid-glass-input rounded-2xl flex items-center gap-3 px-4 min-h-[52px]">
            <KeyRound className="w-4 h-4 text-violet-300 shrink-0" aria-hidden="true" />
            <input
              id="otp-code-input"
              type="text"
              inputMode="numeric"
              autoComplete="one-time-code"
              maxLength={6}
              value={otpCode}
              onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
              placeholder={t.authOtpPlaceholder}
              className="w-full bg-transparent text-lg tracking-[0.35em] font-math text-white placeholder:text-slate-500 focus:outline-none text-center"
              dir="ltr"
            />
          </div>

          <button
            type="submit"
            disabled={verifying || disabled || otpCode.trim().length < 4}
            className="liquid-glass-button w-full min-h-[52px] px-5 py-3 rounded-2xl text-sm font-semibold text-white flex items-center justify-center gap-2.5 transition-all duration-150 active:scale-[0.98] disabled:opacity-45 disabled:cursor-not-allowed focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-400"
          >
            {verifying ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin shrink-0" aria-hidden="true" />
                <span>{t.authOtpVerifying}</span>
              </>
            ) : (
              <span>{t.authOtpVerify}</span>
            )}
          </button>

          <div className="flex items-center justify-between gap-3 pt-1">
            <button
              type="button"
              onClick={handleResetToPhoneEntry}
              className="min-h-[40px] px-2 text-xs font-medium text-slate-300 hover:text-white transition-colors"
            >
              {t.authOtpEditNumber}
            </button>

            <button
              type="button"
              disabled={resendSeconds > 0 || sending}
              onClick={() => void handleSendCode()}
              className="min-h-[40px] px-2 inline-flex items-center gap-1.5 text-xs font-medium text-blue-200 hover:text-white disabled:text-slate-500 disabled:cursor-not-allowed transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
              <span>
                {resendSeconds > 0
                  ? t.authOtpResendCountdown(resendSeconds)
                  : t.authOtpResend}
              </span>
            </button>
          </div>
        </form>
      )}

      {showPhoneSetupHelp && (
        <div
          role="status"
          className="rounded-2xl p-4 bg-amber-500/10 border border-amber-400/30 space-y-2.5 text-xs leading-relaxed"
        >
          <p className="font-semibold text-amber-200">{t.authPhoneSetupHelpTitle}</p>
          <p className="text-slate-200">{t.authPhoneSetupHelpBody}</p>
          <a
            href={`https://console.firebase.google.com/project/${firebaseProjectId}/authentication/providers`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 font-semibold text-blue-200 hover:text-white underline underline-offset-4"
          >
            <span>{t.authPhoneSetupOpenConsole}</span>
            <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
          </a>
        </div>
      )}
    </div>
  );
}
