import {
  Award,
  CheckCircle2,
  Crown,
  Lock,
  Medal,
  Printer,
  Sparkles,
  Trophy,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useState } from 'react';
import { AppTopBar, type HubTab } from '@/src/components/ui/AppTopBar';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { MedalEmblem } from '@/src/components/ui/MedalEmblem';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useProgress } from '@/src/contexts/ProgressContext';
import {
  ACHIEVEMENTS_CATALOG,
  ALL_ACHIEVEMENT_AND_MEDAL_ITEMS,
  MEDALS_CATALOG,
  evaluateCatalogItemProgress,
} from '@/src/data/achievementsCatalog';
import { CURRICULUM_SECTIONS } from '@/src/data/curriculum';
import type { AchievementCatalogItem } from '@/src/types/achievements';
import type { SectionId } from '@/src/types/curriculum';

type AchievementsTab = 'all' | 'medals' | 'completed' | 'locked' | 'certificates';

interface AchievementsScreenProps {
  onNavigate: (tab: HubTab) => void;
  onViewCertificate: (sectionId: SectionId) => void;
  onViewMasterCertificate: () => void;
  onOpenSection: (sectionId: SectionId) => void;
}

export function AchievementsScreen({
  onNavigate,
  onViewCertificate,
  onViewMasterCertificate,
  onOpenSection,
}: AchievementsScreenProps) {
  const { language, t } = useLanguage();
  const {
    sectionProgressMap,
    dailyStats,
    achievementsMap,
    masterCertificate,
    totalCompletedStages,
    totalMasteredSections,
    totalCertificates,
  } = useProgress();

  const [activeTab, setActiveTab] = useState<AchievementsTab>('all');

  const snapshot = {
    completedStagesCount: totalCompletedStages,
    completedSectionsCount: totalMasteredSections,
    certificatesCount: totalCertificates,
    sectionProgressMap,
    dailyStats,
  };

  const isItemUnlocked = (item: AchievementCatalogItem): boolean => {
    if (achievementsMap[item.id]) return true;
    return evaluateCatalogItemProgress(item, snapshot).earned;
  };

  const formatTimestamp = (ts?: { toDate?: () => Date }): string => {
    const date = ts?.toDate ? ts.toDate() : new Date();
    return date.toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const totalCatalogItems = ALL_ACHIEVEMENT_AND_MEDAL_ITEMS.length;
  const earnedTotalCount = ALL_ACHIEVEMENT_AND_MEDAL_ITEMS.filter(isItemUnlocked).length;
  const earnedMedalsCount = MEDALS_CATALOG.filter(isItemUnlocked).length;
  const completionPct = Math.round((earnedTotalCount / totalCatalogItems) * 100);

  const visibleMedals = MEDALS_CATALOG.filter((item) => {
    const unlocked = isItemUnlocked(item);
    if (activeTab === 'completed') return unlocked;
    if (activeTab === 'locked') return !unlocked;
    return activeTab === 'all' || activeTab === 'medals';
  });

  const visibleAchievements = ACHIEVEMENTS_CATALOG.filter((item) => {
    const unlocked = isItemUnlocked(item);
    if (activeTab === 'completed') return unlocked;
    if (activeTab === 'locked') return !unlocked;
    return activeTab === 'all';
  });

  const showMedalsBlock = activeTab === 'all' || activeTab === 'medals' || activeTab === 'completed' || activeTab === 'locked';
  const showAchievementsBlock = activeTab === 'all' || activeTab === 'completed' || activeTab === 'locked';
  const showCertificatesBlock = activeTab === 'all' || activeTab === 'certificates';

  const tabs: { id: AchievementsTab; label: string }[] = [
    { id: 'all', label: t.achievementsTabAll },
    { id: 'medals', label: t.achievementsTabMedals },
    { id: 'completed', label: t.achievementsTabCompleted },
    { id: 'locked', label: t.achievementsTabLocked },
    { id: 'certificates', label: t.achievementsTabCertificates },
  ];

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="min-h-dvh flex flex-col px-4 py-5 sm:px-8 sm:py-7 max-w-6xl mx-auto w-full gap-6 safe-pb-nav"
    >
      <AppTopBar activeTab="achievements" onNavigate={onNavigate} />

      {/* Hero Summary & Overall Completion Progress */}
      <LiquidGlassCard className="p-6 sm:p-8 space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-300">
              <Trophy className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>{t.achievementsCompletionRateLabel}</span>
            </div>
            <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">
              {t.achievementsTitle}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              {t.achievementsSubtitle}
            </p>
          </div>

          <div className="grid grid-cols-3 gap-3 shrink-0">
            <div className="p-3.5 rounded-2xl bg-white/[0.04] border border-white/10 text-center space-y-0.5">
              <div className="font-math text-xl sm:text-2xl font-extrabold text-white tabular-nums">
                {earnedTotalCount} <span className="text-xs font-normal text-slate-400">/ {totalCatalogItems}</span>
              </div>
              <div className="text-[11px] text-slate-300">
                {t.achievementsEarnedCountLabel(earnedTotalCount, totalCatalogItems)}
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-amber-500/12 border border-amber-400/30 text-center space-y-0.5">
              <div className="font-math text-xl sm:text-2xl font-extrabold text-amber-200 tabular-nums">
                {earnedMedalsCount} <span className="text-xs font-normal text-amber-200/70">/ 7</span>
              </div>
              <div className="text-[11px] text-amber-100">
                {t.achievementsMedalsEarnedLabel(earnedMedalsCount, 7)}
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-emerald-500/12 border border-emerald-400/30 text-center space-y-0.5">
              <div className="font-math text-xl sm:text-2xl font-extrabold text-emerald-200 tabular-nums">
                {totalCertificates} <span className="text-xs font-normal text-emerald-200/70">/ 8</span>
              </div>
              <div className="text-[11px] text-emerald-100">
                {t.achievementsCertsEarnedLabel(totalCertificates, 8)}
              </div>
            </div>
          </div>
        </div>

        {/* Completion Progress Bar */}
        <div className="space-y-2 pt-2 border-t border-white/10">
          <div className="flex items-center justify-between text-xs sm:text-sm font-semibold">
            <span className="text-slate-200 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-blue-300" aria-hidden="true" />
              <span>{t.achievementsCompletionRateLabel}</span>
            </span>
            <span className="font-math text-base font-extrabold text-white tabular-nums">
              {completionPct}%
            </span>
          </div>
          <div className="h-3 rounded-full bg-white/10 overflow-hidden p-0.5 border border-white/10">
            <div
              className="h-full rounded-full bg-gradient-to-r from-blue-500 via-violet-500 to-amber-400 transition-all duration-500"
              style={{ width: `${Math.max(completionPct, earnedTotalCount > 0 ? 4 : 0)}%` }}
            />
          </div>
        </div>

        {/* Filter Segmented Tabs */}
        <div
          role="tablist"
          aria-label={t.achievementsTitle}
          className="flex flex-wrap items-center gap-2 pt-1"
        >
          {tabs.map((tab) => {
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                role="tab"
                aria-selected={active}
                onClick={() => setActiveTab(tab.id)}
                className={`min-h-[40px] px-4 py-1.5 rounded-xl text-xs font-semibold transition-all whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-gradient-to-r from-blue-500 to-violet-600 text-white shadow-[0_4px_16px_rgba(99,102,241,0.35)]'
                    : 'liquid-glass-subtle text-slate-300 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </LiquidGlassCard>

      {/* Honorary Medals Showcase */}
      {showMedalsBlock && (
        <div className="space-y-4">
          <h2 className="font-display text-lg sm:text-xl font-bold text-white flex items-center gap-2 px-1">
            <Medal className="w-5 h-5 text-amber-300 shrink-0" aria-hidden="true" />
            <span>{t.achievementsMedalsHeading}</span>
          </h2>

          {visibleMedals.length === 0 ? (
            <LiquidGlassCard variant="subtle" className="p-6 text-sm text-slate-300">
              {activeTab === 'completed' ? t.achievementsEmptyCompleted : t.achievementsEmptyLocked}
            </LiquidGlassCard>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {visibleMedals.map((medal) => {
                const record = achievementsMap[medal.id];
                const evalState = evaluateCatalogItemProgress(medal, snapshot);
                const unlocked = Boolean(record) || evalState.earned;
                const progressPct = Math.round((evalState.current / evalState.target) * 100);

                return (
                  <LiquidGlassCard
                    key={medal.id}
                    variant="subtle"
                    className={`p-5 flex flex-col justify-between gap-4 transition-all ${
                      unlocked
                        ? `border ${medal.ringColor} bg-white/[0.06]`
                        : 'opacity-90 border-white/10'
                    }`}
                  >
                    <div className="flex items-start gap-4">
                      <MedalEmblem
                        iconKey={medal.iconKey}
                        accentFrom={medal.accentFrom}
                        accentTo={medal.accentTo}
                        unlocked={unlocked}
                        size="lg"
                      />
                      <div className="space-y-1.5 min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <h3 className="font-display text-base font-bold text-white truncate">
                            {language === 'ar' ? medal.titleAr : medal.titleEn}
                          </h3>
                        </div>
                        <p className="text-xs text-slate-300 leading-relaxed">
                          {language === 'ar' ? medal.descriptionAr : medal.descriptionEn}
                        </p>
                        <div className="text-[11px] font-medium text-blue-200">
                          {language === 'ar' ? medal.conditionAr : medal.conditionEn}
                        </div>
                      </div>
                    </div>

                    {unlocked ? (
                      <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-2 text-xs">
                        <span className="inline-flex items-center gap-1.5 font-semibold text-emerald-300">
                          <CheckCircle2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                          <span>{t.achievementsUnlockedStatus}</span>
                        </span>
                        <span className="text-[11px] text-slate-400">
                          {t.achievementsEarnedDateLabel(formatTimestamp(record?.unlockedAt))}
                        </span>
                      </div>
                    ) : (
                      <div className="pt-3 border-t border-white/10 space-y-1.5">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="text-slate-400 inline-flex items-center gap-1">
                            <Lock className="w-3 h-3 shrink-0" aria-hidden="true" />
                            <span>{t.achievementsLockedStatus}</span>
                          </span>
                          <span className="font-math font-bold text-slate-200 tabular-nums">
                            {t.achievementsProgressOf(evalState.current, evalState.target)}
                          </span>
                        </div>
                        <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-blue-400 to-violet-500 transition-all"
                            style={{ width: `${progressPct}%` }}
                          />
                        </div>
                      </div>
                    )}
                  </LiquidGlassCard>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Progression & Streak Achievements */}
      {showAchievementsBlock && (
        <div className="space-y-4">
          <h2 className="font-display text-lg sm:text-xl font-bold text-white flex items-center gap-2 px-1">
            <Sparkles className="w-5 h-5 text-blue-300 shrink-0" aria-hidden="true" />
            <span>{t.achievementsMilestonesHeading}</span>
          </h2>

          {visibleAchievements.length === 0 ? (
            <LiquidGlassCard variant="subtle" className="p-6 text-sm text-slate-300">
              {activeTab === 'completed' ? t.achievementsEmptyCompleted : t.achievementsEmptyLocked}
            </LiquidGlassCard>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {visibleAchievements.map((ach) => {
                const record = achievementsMap[ach.id];
                const evalState = evaluateCatalogItemProgress(ach, snapshot);
                const unlocked = Boolean(record) || evalState.earned;
                const progressPct = Math.round((evalState.current / evalState.target) * 100);

                return (
                  <LiquidGlassCard
                    key={ach.id}
                    variant="subtle"
                    className={`p-5 flex flex-col justify-between gap-4 ${
                      unlocked ? `border ${ach.ringColor} bg-white/[0.055]` : 'border-white/10'
                    }`}
                  >
                    <div className="flex items-start gap-3.5">
                      <MedalEmblem
                        iconKey={ach.iconKey}
                        accentFrom={ach.accentFrom}
                        accentTo={ach.accentTo}
                        unlocked={unlocked}
                        size="md"
                      />
                      <div className="min-w-0 flex-1 space-y-1">
                        <h3 className="font-display text-sm sm:text-base font-bold text-white">
                          {language === 'ar' ? ach.titleAr : ach.titleEn}
                        </h3>
                        <p className="text-xs text-slate-300 leading-relaxed">
                          {language === 'ar' ? ach.descriptionAr : ach.descriptionEn}
                        </p>
                        <div className="text-[11px] font-medium text-blue-200">
                          {language === 'ar' ? ach.conditionAr : ach.conditionEn}
                        </div>
                      </div>
                    </div>

                    {unlocked ? (
                      <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-2 text-xs">
                        <span className="inline-flex items-center gap-1.5 font-semibold text-emerald-300">
                          <CheckCircle2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                          <span>{t.achievementsUnlockedStatus}</span>
                        </span>
                        <span className="text-[11px] text-slate-400">
                          {t.achievementsEarnedDateLabel(formatTimestamp(record?.unlockedAt))}
                        </span>
                      </div>
                    ) : (
                      <div className="pt-3 border-t border-white/10 space-y-1.5">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="text-slate-400">{t.achievementsLockedStatus}</span>
                          <span className="font-math font-bold text-slate-200 tabular-nums">
                            {t.achievementsProgressOf(evalState.current, evalState.target)}
                          </span>
                        </div>
                        <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-sky-400 to-indigo-500 transition-all"
                            style={{ width: `${progressPct}%` }}
                          />
                        </div>
                      </div>
                    )}
                  </LiquidGlassCard>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Official PDF Certificates Showcase + Grand All-Sections Master Certificate */}
      {showCertificatesBlock && (
        <div className="space-y-4">
          <h2 className="font-display text-lg sm:text-xl font-bold text-white flex items-center gap-2 px-1">
            <Award className="w-5 h-5 text-emerald-300 shrink-0" aria-hidden="true" />
            <span>{t.achievementsCertificatesHeading}</span>
          </h2>

          {/* Grand Master Certificate Card */}
          <LiquidGlassCard
            className={`p-6 sm:p-7 border transition-all ${
              masterCertificate
                ? 'border-amber-300/65 bg-gradient-to-br from-amber-500/20 via-slate-900/60 to-emerald-500/15 shadow-[0_0_50px_rgba(251,191,36,0.22)]'
                : 'border-white/15 bg-white/[0.04]'
            }`}
          >
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
              <div className="flex items-start gap-4">
                <div
                  className={`w-16 h-16 rounded-3xl flex items-center justify-center shrink-0 border ${
                    masterCertificate
                      ? 'bg-gradient-to-br from-amber-300 to-orange-600 border-white/50 text-white shadow-[0_0_28px_rgba(251,191,36,0.45)]'
                      : 'bg-white/[0.05] border-white/15 text-slate-500'
                  }`}
                >
                  {masterCertificate ? (
                    <Crown className="w-8 h-8" aria-hidden="true" />
                  ) : (
                    <Lock className="w-7 h-7" aria-hidden="true" />
                  )}
                </div>

                <div className="space-y-1.5">
                  <div className="text-xs font-bold flex items-center gap-1.5">
                    {masterCertificate ? (
                      <span className="text-amber-300 inline-flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
                        <span>{t.masterCertUnlockedBadge}</span>
                      </span>
                    ) : (
                      <span className="text-slate-400">{t.achievementsLockedStatus}</span>
                    )}
                  </div>
                  <h3 className="font-display text-lg sm:text-xl font-bold text-white">
                    {t.masterCertTitle}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-2xl">
                    {masterCertificate
                      ? `${t.masterCertAvgScoreLabel}: ${masterCertificate.averageExamScore}/100 · ${masterCertificate.certificateId}`
                      : t.masterCertLockedDesc(totalCertificates)}
                  </p>

                  {!masterCertificate && (
                    <div className="max-w-md pt-1 space-y-1">
                      <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-amber-400 to-emerald-400 transition-all"
                          style={{ width: `${Math.round((totalCertificates / 8) * 100)}%` }}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {masterCertificate && (
                <button
                  type="button"
                  onClick={onViewMasterCertificate}
                  className="liquid-glass-button min-h-[48px] px-6 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0"
                >
                  <Printer className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>{t.masterCertOpenBtn}</span>
                </button>
              )}
            </div>
          </LiquidGlassCard>

          {/* 8 Individual Section Certificates */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {CURRICULUM_SECTIONS.map((sec) => {
              const prog = sectionProgressMap[sec.id];
              const unlocked = Boolean(prog?.examPassed && prog?.certificateId);
              const completedStages = prog?.completedStagesCount ?? 0;

              return (
                <LiquidGlassCard
                  key={sec.id}
                  variant="subtle"
                  className={`p-5 flex items-center justify-between gap-4 ${
                    unlocked ? 'border-emerald-400/35 bg-emerald-500/5' : 'border-white/10'
                  }`}
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div
                      className={`w-12 h-12 rounded-2xl flex items-center justify-center font-math text-lg font-bold shrink-0 border ${
                        unlocked
                          ? `bg-gradient-to-br ${sec.accentFrom} ${sec.accentTo} border-white/35 text-white`
                          : 'bg-white/[0.04] border-white/10 text-slate-400'
                      }`}
                    >
                      {sec.symbol}
                    </div>
                    <div className="min-w-0 space-y-1">
                      <h4 className="font-display text-sm sm:text-base font-bold text-white truncate">
                        {language === 'ar' ? sec.titleAr : sec.titleEn}
                      </h4>
                      {unlocked && prog ? (
                        <div className="text-xs text-emerald-300 font-math tabular-nums flex flex-wrap items-center gap-2">
                          <span>
                            {t.certScoreLabel}: {prog.examBestScore}/100
                          </span>
                          <span aria-hidden="true">·</span>
                          <span dir="ltr" className="text-slate-300">
                            {prog.certificateId}
                          </span>
                        </div>
                      ) : (
                        <div className="text-xs text-slate-400 font-math tabular-nums">
                          {t.sectionProgressLabel(completedStages, 30)}
                        </div>
                      )}
                    </div>
                  </div>

                  {unlocked ? (
                    <button
                      type="button"
                      onClick={() => onViewCertificate(sec.id)}
                      className="liquid-glass-button min-h-[42px] px-4 py-2 rounded-xl text-xs font-semibold text-white inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
                    >
                      <Printer className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                      <span>{t.profileViewCertBtn}</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => onOpenSection(sec.id)}
                      className="liquid-glass-subtle min-h-[42px] px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-200 hover:text-white hover:bg-white/10 whitespace-nowrap shrink-0 transition-colors"
                    >
                      {t.enterSection}
                    </button>
                  )}
                </LiquidGlassCard>
              );
            })}
          </div>
        </div>
      )}
    </motion.section>
  );
}
