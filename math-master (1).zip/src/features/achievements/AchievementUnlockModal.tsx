import { Award, Crown, Sparkles, X } from 'lucide-react';
import { motion, useReducedMotion } from 'motion/react';
import { useEffect } from 'react';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { MedalEmblem } from '@/src/components/ui/MedalEmblem';
import { useLanguage } from '@/src/contexts/LanguageContext';
import type { AchievementCatalogItem } from '@/src/types/achievements';

interface AchievementUnlockModalProps {
  items: AchievementCatalogItem[];
  masterCertificateIssued: boolean;
  onDismiss: () => void;
  onViewAchievements: () => void;
  onViewMasterCertificate: () => void;
}

export function AchievementUnlockModal({
  items,
  masterCertificateIssued,
  onDismiss,
  onViewAchievements,
  onViewMasterCertificate,
}: AchievementUnlockModalProps) {
  const { language, t } = useLanguage();
  const shouldReduceMotion = useReducedMotion();

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onDismiss();
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [onDismiss]);

  if (items.length === 0 && !masterCertificateIssued) {
    return null;
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="achievement-unlock-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-950/75 backdrop-blur-md overflow-y-auto print:hidden"
      onClick={onDismiss}
    >
      <motion.div
        initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0, scale: 0.92, y: 18 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={shouldReduceMotion ? { opacity: 0 } : { opacity: 0, scale: 0.94, y: 10 }}
        transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-xl my-auto"
      >
        <LiquidGlassCard className="relative p-6 sm:p-8 ring-1 ring-amber-300/60 shadow-[0_0_80px_rgba(251,191,36,0.3)] bg-gradient-to-br from-amber-500/15 via-slate-900/90 to-violet-600/20 space-y-6 overflow-hidden">
          <button
            type="button"
            onClick={onDismiss}
            aria-label={t.medalCelebrationDismissBtn}
            className="absolute top-4 end-4 w-9 h-9 rounded-xl liquid-glass-subtle flex items-center justify-center text-slate-300 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" aria-hidden="true" />
          </button>

          {/* Header Crest */}
          <div className="flex flex-col items-center text-center space-y-3 pt-1">
            <motion.div
              animate={
                shouldReduceMotion
                  ? undefined
                  : { rotate: [0, -6, 6, -3, 0], scale: [1, 1.06, 1] }
              }
              transition={{ duration: 0.9, ease: 'easeOut' }}
              className="w-16 h-16 rounded-3xl bg-gradient-to-br from-amber-300 via-yellow-500 to-orange-600 border border-white/50 flex items-center justify-center text-white shadow-[0_0_36px_rgba(251,191,36,0.5)]"
            >
              {masterCertificateIssued ? (
                <Crown className="w-8 h-8" aria-hidden="true" />
              ) : (
                <Sparkles className="w-8 h-8" aria-hidden="true" />
              )}
            </motion.div>

            <h2
              id="achievement-unlock-title"
              className="font-display text-2xl sm:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-white to-amber-100"
            >
              {t.medalCelebrationTitle}
            </h2>
            <p className="text-xs sm:text-sm text-slate-200 max-w-md leading-relaxed">
              {t.medalCelebrationSubtitle}
            </p>
          </div>

          {/* Newly Unlocked Items */}
          {items.length > 0 && (
            <div className="space-y-3 max-h-[42vh] overflow-y-auto pe-1">
              {items.map((item) => (
                <div
                  key={item.id}
                  className={`p-3.5 sm:p-4 rounded-2xl bg-white/[0.06] border ${item.ringColor} flex items-center gap-4`}
                >
                  <MedalEmblem
                    iconKey={item.iconKey}
                    accentFrom={item.accentFrom}
                    accentTo={item.accentTo}
                    unlocked={true}
                    size="md"
                  />
                  <div className="min-w-0 flex-1 space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-display text-base font-bold text-white">
                        {language === 'ar' ? item.titleAr : item.titleEn}
                      </span>
                      <span className="px-2 py-0.5 rounded-lg text-[10px] font-bold bg-amber-400/20 border border-amber-300/40 text-amber-200">
                        {item.kind === 'medal'
                          ? language === 'ar'
                            ? 'وسام شرف'
                            : 'Honorary Medal'
                          : language === 'ar'
                            ? 'إنجاز'
                            : 'Achievement'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {language === 'ar' ? item.descriptionAr : item.descriptionEn}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Grand Master Certificate Banner */}
          {masterCertificateIssued && (
            <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-400/20 via-yellow-500/15 to-emerald-500/20 border border-amber-300/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-amber-400/25 border border-amber-200/50 flex items-center justify-center text-amber-200 shrink-0">
                  <Award className="w-6 h-6" aria-hidden="true" />
                </div>
                <div className="space-y-0.5">
                  <div className="text-xs font-bold text-amber-200">
                    {t.masterCertUnlockedBadge}
                  </div>
                  <div className="text-sm font-bold text-white">{t.masterCertTitle}</div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  onDismiss();
                  onViewMasterCertificate();
                }}
                className="min-h-[40px] px-4 py-2 rounded-xl bg-gradient-to-r from-amber-400 to-orange-500 text-slate-950 text-xs font-extrabold whitespace-nowrap shrink-0 hover:brightness-105 transition-all"
              >
                {t.masterCertOpenBtn}
              </button>
            </div>
          )}

          {/* Footer Actions */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-end gap-3 pt-2 border-t border-white/10">
            <button
              type="button"
              onClick={() => {
                onDismiss();
                onViewAchievements();
              }}
              className="liquid-glass-subtle min-h-[46px] px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white hover:bg-white/10 transition-colors"
            >
              {t.medalCelebrationViewAllBtn}
            </button>

            <button
              type="button"
              onClick={onDismiss}
              className="liquid-glass-button min-h-[46px] px-6 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white"
            >
              {t.medalCelebrationDismissBtn}
            </button>
          </div>
        </LiquidGlassCard>
      </motion.div>
    </div>
  );
}
