import { Check, CheckCircle2, Lock, ShoppingBag, Sparkles, Tag, User } from 'lucide-react';
import { motion } from 'motion/react';
import { useMemo, useState } from 'react';
import { AppTopBar, type HubTab } from '@/src/components/ui/AppTopBar';
import { AvatarDisplay } from '@/src/components/ui/AvatarDisplay';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { useAuth } from '@/src/contexts/AuthContext';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useRewards } from '@/src/contexts/RewardsContext';
import { REWARDS_CATALOG } from '@/src/data/rewardsCatalog';
import type { RewardCategory, ShopRewardItem } from '@/src/types/rewards';

interface RewardsShopScreenProps {
  onNavigate: (tab: HubTab) => void;
}

type ShopFilter = 'all' | RewardCategory;

export function RewardsShopScreen({ onNavigate }: RewardsShopScreenProps) {
  const { language, t } = useLanguage();
  const { userProfile } = useAuth();
  const { ownedItemIds, processingItemId, purchaseReward, equipReward } = useRewards();

  const [filter, setFilter] = useState<ShopFilter>('all');
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(
    null,
  );

  const spendablePoints = userProfile?.points ?? 0;
  const totalEarnedPoints = userProfile?.totalEarnedPoints ?? spendablePoints;

  const filteredItems = useMemo(() => {
    if (filter === 'all') return REWARDS_CATALOG;
    return REWARDS_CATALOG.filter((item) => item.category === filter);
  }, [filter]);

  const isEquipped = (item: ShopRewardItem): boolean => {
    if (!userProfile) return false;
    if (item.category === 'badge') return userProfile.equippedBadgeId === item.id;
    if (item.category === 'avatar') return userProfile.equippedAvatarId === item.id;
    return userProfile.equippedTitleId === item.id;
  };

  const handlePurchase = async (item: ShopRewardItem) => {
    setFeedbackMsg(null);
    if (spendablePoints < item.cost || ownedItemIds.has(item.id)) return;

    try {
      await purchaseReward(item.id);
      const name = language === 'ar' ? item.nameAr : item.nameEn;
      setFeedbackMsg({ type: 'success', text: t.shopPurchaseSuccess(name) });
    } catch {
      setFeedbackMsg({ type: 'error', text: t.errorGeneric });
    }
  };

  const handleEquipToggle = async (item: ShopRewardItem) => {
    setFeedbackMsg(null);
    const equipped = isEquipped(item);
    try {
      if (equipped) {
        // Avatars revert to default; badges and titles clear to ''
        const nextId = item.category === 'avatar' ? 'avatar-classic' : '';
        await equipReward(item.category, nextId);
      } else {
        await equipReward(item.category, item.id);
      }
    } catch {
      setFeedbackMsg({ type: 'error', text: t.errorGeneric });
    }
  };

  const tabs: { id: ShopFilter; label: string }[] = [
    { id: 'all', label: t.shopTabAll },
    { id: 'badge', label: t.shopTabBadges },
    { id: 'avatar', label: t.shopTabAvatars },
    { id: 'title', label: t.shopTabTitles },
  ];

  const renderPreview = (item: ShopRewardItem) => {
    if (item.category === 'avatar') {
      return <AvatarDisplay avatarId={item.id} size="lg" />;
    }
    if (item.category === 'badge') {
      return (
        <div
          className={`w-16 h-16 rounded-3xl bg-gradient-to-br ${item.accentFrom} ${item.accentTo} border border-white/30 flex items-center justify-center text-2xl font-bold text-white shadow-[0_10px_28px_rgba(99,102,241,0.3)] shrink-0`}
        >
          {item.symbol}
        </div>
      );
    }
    return (
      <div
        className={`w-16 h-16 rounded-3xl bg-gradient-to-br ${item.accentFrom} ${item.accentTo} border border-white/30 flex items-center justify-center text-white shadow-[0_10px_28px_rgba(139,92,246,0.28)] shrink-0`}
      >
        <Tag className="w-7 h-7" aria-hidden="true" />
      </div>
    );
  };

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="min-h-dvh flex flex-col px-4 py-5 sm:px-8 sm:py-7 max-w-6xl mx-auto w-full gap-6 safe-pb-nav"
    >
      <AppTopBar activeTab="shop" onNavigate={onNavigate} />

      {/* Shop Hero & Points Balance */}
      <LiquidGlassCard className="p-6 sm:p-8 space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-violet-200">
              <ShoppingBag className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span className="font-math tabular-nums">
                {t.shopOwnedCountLabel(ownedItemIds.size, REWARDS_CATALOG.length)}
              </span>
            </div>
            <h1 className="font-display text-2xl sm:text-3xl font-bold text-white text-balance">
              {t.shopTitle}
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">{t.shopSubtitle}</p>
          </div>

          <div className="grid grid-cols-2 gap-3 shrink-0">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-500/20 to-violet-600/20 border border-blue-400/35 space-y-1">
              <div className="text-xs text-blue-200 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-300 shrink-0" aria-hidden="true" />
                <span>{t.shopAvailableBalanceLabel}</span>
              </div>
              <div className="font-math text-2xl font-extrabold text-white tabular-nums">
                {spendablePoints}
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 space-y-1">
              <div className="text-xs text-slate-400 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-violet-300 shrink-0" aria-hidden="true" />
                <span>{t.shopTotalEarnedLabel}</span>
              </div>
              <div className="font-math text-2xl font-bold text-slate-200 tabular-nums">
                {totalEarnedPoints}
              </div>
            </div>
          </div>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex flex-wrap items-center gap-2 pt-4 border-t border-white/10">
          {tabs.map((tab) => {
            const active = filter === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setFilter(tab.id)}
                className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
                  active
                    ? 'bg-gradient-to-r from-blue-500/85 to-violet-600/85 text-white shadow-[0_4px_16px_rgba(99,102,241,0.35)]'
                    : 'liquid-glass-subtle text-slate-300 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </LiquidGlassCard>

      {feedbackMsg && (
        <div
          role="status"
          className={`p-4 rounded-2xl border text-xs sm:text-sm font-medium flex items-center gap-2.5 ${
            feedbackMsg.type === 'success'
              ? 'bg-emerald-500/15 border-emerald-400/35 text-emerald-100'
              : 'bg-rose-500/15 border-rose-400/35 text-rose-100'
          }`}
        >
          <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{feedbackMsg.text}</span>
        </div>
      )}

      {/* Catalog Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
        {filteredItems.map((item) => {
          const owned = ownedItemIds.has(item.id);
          const equipped = isEquipped(item);
          const affordable = spendablePoints >= item.cost;
          const missing = Math.max(0, item.cost - spendablePoints);
          const isBusy = processingItemId === item.id;

          return (
            <LiquidGlassCard
              key={item.id}
              variant={equipped ? 'default' : 'subtle'}
              className={`p-5 sm:p-6 flex flex-col justify-between gap-5 ${
                equipped
                  ? 'ring-1 ring-blue-300/60 shadow-[0_0_28px_rgba(59,130,246,0.22)]'
                  : owned
                    ? 'border-emerald-400/30'
                    : ''
              }`}
            >
              <div className="space-y-4">
                <div className="flex items-start justify-between gap-3">
                  {renderPreview(item)}
                  <div className="text-end space-y-1">
                    <div className="font-math text-sm font-bold text-amber-200 tabular-nums">
                      {item.cost} {t.leaderboardPointsUnit}
                    </div>
                    {equipped ? (
                      <div className="text-[11px] font-semibold text-blue-200 inline-flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>{t.shopEquippedBadge}</span>
                      </div>
                    ) : owned ? (
                      <div className="text-[11px] font-semibold text-emerald-300 inline-flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>{t.shopOwnedBadge}</span>
                      </div>
                    ) : null}
                  </div>
                </div>

                <div className="space-y-1">
                  <h2 className="font-display text-lg font-bold text-white">
                    {language === 'ar' ? item.nameAr : item.nameEn}
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    {language === 'ar' ? item.descriptionAr : item.descriptionEn}
                  </p>
                </div>
              </div>

              <div className="pt-2 border-t border-white/10">
                {owned ? (
                  <button
                    type="button"
                    disabled={isBusy}
                    onClick={() => void handleEquipToggle(item)}
                    className={`w-full min-h-[44px] px-4 py-2 rounded-2xl text-xs sm:text-sm font-semibold inline-flex items-center justify-center gap-2 transition-all ${
                      equipped
                        ? 'liquid-glass-subtle text-slate-200 hover:bg-white/10'
                        : 'liquid-glass-button text-white'
                    }`}
                  >
                    {equipped ? (
                      <span>{t.shopUnequipBtn}</span>
                    ) : (
                      <span>{t.shopEquipBtn}</span>
                    )}
                  </button>
                ) : affordable ? (
                  <button
                    type="button"
                    disabled={isBusy}
                    onClick={() => void handlePurchase(item)}
                    className="liquid-glass-button w-full min-h-[44px] px-4 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white disabled:opacity-60 inline-flex items-center justify-center gap-2 transition-all"
                  >
                    <Sparkles className="w-4 h-4 shrink-0" aria-hidden="true" />
                    <span>{isBusy ? t.shopPurchasingBtn : t.shopBuyBtn(item.cost)}</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    disabled
                    aria-disabled="true"
                    className="w-full min-h-[44px] px-4 py-2 rounded-2xl text-xs font-semibold bg-white/[0.04] border border-white/10 text-slate-400 cursor-not-allowed inline-flex items-center justify-center gap-2"
                  >
                    <Lock className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                    <span className="font-math tabular-nums">{t.shopNeedMorePoints(missing)}</span>
                  </button>
                )}
              </div>
            </LiquidGlassCard>
          );
        })}
      </div>
    </motion.section>
  );
}
