import { ArrowLeft, ArrowRight, Award, Layers, Star } from 'lucide-react';
import { motion } from 'motion/react';
import { AppTopBar, type HubTab } from '@/src/components/ui/AppTopBar';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useProgress } from '@/src/contexts/ProgressContext';
import { SectionDashboardGrid } from '@/src/features/learning/SectionDashboardGrid';
import type { SectionId } from '@/src/types/curriculum';

interface SectionsHubScreenProps {
  onNavigate: (tab: HubTab) => void;
  onSelectSection: (sectionId: SectionId) => void;
}

export function SectionsHubScreen({ onNavigate, onSelectSection }: SectionsHubScreenProps) {
  const { direction, t } = useLanguage();
  const { totalCompletedStages, totalStars, totalCertificates } = useProgress();
  const BackArrow = direction === 'rtl' ? ArrowRight : ArrowLeft;

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="min-h-dvh flex flex-col px-4 py-5 sm:px-8 sm:py-7 max-w-6xl mx-auto w-full gap-6 safe-pb-nav"
    >
      <AppTopBar activeTab="sections" onNavigate={onNavigate} />

      <LiquidGlassCard className="p-5 sm:p-7 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="space-y-1.5">
          <button
            type="button"
            onClick={() => onNavigate('home')}
            className="text-xs font-semibold text-blue-200 hover:text-white inline-flex items-center gap-1.5 mb-1 transition-colors"
          >
            <BackArrow className="w-3.5 h-3.5" aria-hidden="true" />
            <span>{t.backToHomeBtn}</span>
          </button>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">
            {t.sectionsHubTitle}
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
            {t.sectionsHubSubtitle}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <div className="px-4 py-2.5 rounded-2xl bg-white/[0.05] border border-white/10 text-center">
            <div className="text-[11px] text-slate-400 flex items-center justify-center gap-1">
              <Layers className="w-3.5 h-3.5 text-violet-300" aria-hidden="true" />
              <span>{t.statsCompletedStages}</span>
            </div>
            <div className="text-base sm:text-lg font-bold text-white font-math tabular-nums">
              {totalCompletedStages} / 240
            </div>
          </div>

          <div className="px-4 py-2.5 rounded-2xl bg-white/[0.05] border border-white/10 text-center">
            <div className="text-[11px] text-slate-400 flex items-center justify-center gap-1">
              <Star className="w-3.5 h-3.5 text-amber-300" aria-hidden="true" />
              <span>{t.statsStarsEarned}</span>
            </div>
            <div className="text-base sm:text-lg font-bold text-amber-300 font-math tabular-nums">
              {totalStars} / 720
            </div>
          </div>

          <div className="px-4 py-2.5 rounded-2xl bg-white/[0.05] border border-white/10 text-center">
            <div className="text-[11px] text-slate-400 flex items-center justify-center gap-1">
              <Award className="w-3.5 h-3.5 text-emerald-300" aria-hidden="true" />
              <span>{t.statsCertificatesEarned}</span>
            </div>
            <div className="text-base sm:text-lg font-bold text-emerald-300 font-math tabular-nums">
              {totalCertificates} / 8
            </div>
          </div>
        </div>
      </LiquidGlassCard>

      <SectionDashboardGrid onSelectSection={onSelectSection} />
    </motion.section>
  );
}
