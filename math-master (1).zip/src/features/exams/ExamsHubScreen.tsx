import {
  ArrowLeft,
  ArrowRight,
  Award,
  Calendar,
  CheckCircle2,
  ClipboardCheck,
  Clock,
  History,
  Lock,
  Play,
  RotateCcw,
  Sparkles,
  TrendingUp,
  XCircle,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useMemo } from 'react';
import { AppTopBar, type HubTab } from '@/src/components/ui/AppTopBar';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { useAuth } from '@/src/contexts/AuthContext';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useProgress } from '@/src/contexts/ProgressContext';
import { CURRICULUM_SECTIONS, getSectionById } from '@/src/data/curriculum';
import { storageService } from '@/src/services/storageService';
import type { SectionId } from '@/src/types/curriculum';

interface ExamsHubScreenProps {
  onNavigate: (tab: HubTab) => void;
  onStartExam: (sectionId: SectionId) => void;
  onOpenSection: (sectionId: SectionId) => void;
  onViewCertificate: (sectionId: SectionId) => void;
}

function formatDurationMMSS(totalSeconds: number): string {
  const safe = Math.max(0, Math.round(totalSeconds));
  const mins = Math.floor(safe / 60);
  const secs = safe % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export function ExamsHubScreen({
  onNavigate,
  onStartExam,
  onOpenSection,
  onViewCertificate,
}: ExamsHubScreenProps) {
  const { language, direction, t } = useLanguage();
  const { firebaseUser } = useAuth();
  const { sectionProgressMap, examAttempts, isExamUnlocked } = useProgress();

  const ForwardArrow = direction === 'rtl' ? ArrowLeft : ArrowRight;

  const formatDate = (ms: number | undefined): string => {
    if (!ms) return t.examNoAttemptYet;
    return new Intl.DateTimeFormat(language === 'ar' ? 'ar-SA' : 'en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    }).format(new Date(ms));
  };

  const formatDateTime = (ms: number | undefined): string => {
    if (!ms) return '—';
    return new Intl.DateTimeFormat(language === 'ar' ? 'ar-SA' : 'en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(ms));
  };

  const summary = useMemo(() => {
    let unlocked = 0;
    let passed = 0;
    let bestScoreSum = 0;
    let attemptedSections = 0;

    for (const sec of CURRICULUM_SECTIONS) {
      const prog = sectionProgressMap[sec.id];
      if ((prog?.completedStagesCount ?? 0) >= 30) {
        unlocked += 1;
      }
      if (prog?.examPassed) {
        passed += 1;
      }
      if ((prog?.examAttempts ?? 0) > 0 && prog) {
        attemptedSections += 1;
        bestScoreSum += prog.examBestScore ?? 0;
      }
    }

    const avgBest = attemptedSections > 0 ? Math.round(bestScoreSum / attemptedSections) : 0;
    return {
      unlocked,
      passed,
      avgBest,
      totalAttempts: examAttempts.length,
    };
  }, [sectionProgressMap, examAttempts.length]);

  const latestAttemptTimeBySection = useMemo(() => {
    const map: Partial<Record<SectionId, number>> = {};
    for (const att of examAttempts) {
      const ms = att.submittedAt?.toMillis?.();
      if (ms && (!map[att.sectionId] || ms > (map[att.sectionId] ?? 0))) {
        map[att.sectionId] = ms;
      }
    }
    return map;
  }, [examAttempts]);

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="min-h-dvh flex flex-col px-4 py-5 sm:px-8 sm:py-7 max-w-6xl mx-auto w-full gap-6 safe-pb-nav"
    >
      <AppTopBar activeTab="exams" onNavigate={onNavigate} />

      {/* Exams Center Hero Summary */}
      <LiquidGlassCard className="p-6 sm:p-8 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-white/10">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-br from-blue-500/30 to-violet-600/30 border border-blue-300/35 flex items-center justify-center text-blue-200 shrink-0 shadow-lg">
              <ClipboardCheck className="w-6 h-6 sm:w-7 sm:h-7" aria-hidden="true" />
            </div>
            <div className="space-y-1">
              <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">
                {t.examsHubTitle}
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-2xl">
                {t.examsHubSubtitle}
              </p>
            </div>
          </div>

          <div className="text-xs font-medium text-blue-200 bg-blue-500/10 border border-blue-400/25 rounded-2xl px-3.5 py-2 self-start md:self-center shrink-0">
            {t.resultPassingRule}
          </div>
        </div>

        {/* 4 Summary Metrics */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
          <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 space-y-1">
            <div className="text-xs text-slate-400 flex items-center gap-1.5">
              <ClipboardCheck className="w-3.5 h-3.5 text-blue-300 shrink-0" aria-hidden="true" />
              <span>{t.examsSummaryUnlocked}</span>
            </div>
            <div className="font-math text-2xl font-extrabold text-white tabular-nums">
              {summary.unlocked} <span className="text-sm font-normal text-slate-400">/ 8</span>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 space-y-1">
            <div className="text-xs text-slate-400 flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-emerald-300 shrink-0" aria-hidden="true" />
              <span>{t.examsSummaryPassed}</span>
            </div>
            <div className="font-math text-2xl font-extrabold text-emerald-200 tabular-nums">
              {summary.passed} <span className="text-sm font-normal text-slate-400">/ 8</span>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 space-y-1">
            <div className="text-xs text-slate-400 flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-violet-300 shrink-0" aria-hidden="true" />
              <span>{t.examsSummaryAvgScore}</span>
            </div>
            <div className="font-math text-2xl font-extrabold text-violet-200 tabular-nums">
              {summary.avgBest}
              <span className="text-sm font-normal text-slate-400">/100</span>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 space-y-1">
            <div className="text-xs text-slate-400 flex items-center gap-1.5">
              <History className="w-3.5 h-3.5 text-amber-300 shrink-0" aria-hidden="true" />
              <span>{t.examsSummaryAttempts}</span>
            </div>
            <div className="font-math text-2xl font-extrabold text-amber-200 tabular-nums">
              {summary.totalAttempts}
            </div>
          </div>
        </div>
      </LiquidGlassCard>

      {/* All 8 Section Exams Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {CURRICULUM_SECTIONS.map((section) => {
          const prog = sectionProgressMap[section.id];
          const completedStages = prog?.completedStagesCount ?? 0;
          const unlocked = isExamUnlocked(section.id);
          const examPassed = Boolean(prog?.examPassed);
          const attemptsCount = prog?.examAttempts ?? 0;
          const bestScore = prog?.examBestScore ?? 0;
          const lastScore = prog?.examLastScore ?? 0;
          const hasDraft =
            unlocked && firebaseUser
              ? Boolean(storageService.getExamDraft(firebaseUser.uid, section.id))
              : false;

          const lastExamMs =
            prog?.lastExamAt?.toMillis?.() ?? latestAttemptTimeBySection[section.id];

          const statusLabel = examPassed
            ? t.examStatusCompleted
            : unlocked
              ? t.examStatusAvailable
              : t.examStatusLocked;

          return (
            <LiquidGlassCard
              key={section.id}
              variant={unlocked ? 'default' : 'subtle'}
              className={`p-5 sm:p-6 flex flex-col justify-between gap-4 ${
                examPassed
                  ? 'border-emerald-400/35 bg-emerald-500/[0.06]'
                  : unlocked
                    ? 'border-blue-400/40 shadow-[0_0_24px_rgba(99,102,241,0.16)]'
                    : 'opacity-85'
              }`}
            >
              <div className="space-y-4">
                {/* Header: Icon + Section Title + Status */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div
                      className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${section.accentFrom} ${section.accentTo} border border-white/25 flex items-center justify-center text-xl font-bold text-white font-math shrink-0 shadow-md`}
                      aria-hidden="true"
                    >
                      {section.symbol}
                    </div>
                    <div className="min-w-0">
                      <div className="text-[11px] font-medium text-blue-200/90 font-math">
                        {language === 'ar'
                          ? `امتحان القسم ${section.order}`
                          : `Section ${section.order} Final Exam`}
                      </div>
                      <h2 className="font-display text-base sm:text-lg font-bold text-white truncate">
                        {language === 'ar' ? section.titleAr : section.titleEn}
                      </h2>
                    </div>
                  </div>

                  {/* Paired Icon + Text Status */}
                  <div
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 shrink-0 border ${
                      examPassed
                        ? 'bg-emerald-500/20 border-emerald-400/35 text-emerald-200'
                        : unlocked
                          ? 'bg-blue-500/20 border-blue-400/35 text-blue-200'
                          : 'bg-white/[0.05] border-white/10 text-slate-400'
                    }`}
                  >
                    {examPassed ? (
                      <CheckCircle2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                    ) : unlocked ? (
                      <Sparkles className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                    ) : (
                      <Lock className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                    )}
                    <span>{statusLabel}</span>
                  </div>
                </div>

                {/* Stage Unlock Progress if Locked */}
                {!unlocked && (
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs text-slate-300">
                      <span>{t.examLockedNotice(completedStages)}</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-white/10 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-blue-500 to-violet-500 transition-all duration-500"
                        style={{ width: `${Math.round((completedStages / 30) * 100)}%` }}
                      />
                    </div>
                  </div>
                )}

                {/* Draft In-Progress Alert */}
                {hasDraft && (
                  <div className="px-3 py-2 rounded-xl bg-amber-500/15 border border-amber-400/30 text-xs font-medium text-amber-100 inline-flex items-center gap-2">
                    <Clock className="w-3.5 h-3.5 text-amber-300 shrink-0" aria-hidden="true" />
                    <span>{t.examStatusInProgress}</span>
                  </div>
                )}

                {/* Real Exam Statistics Row */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
                  <div className="p-2.5 rounded-xl bg-white/[0.04] border border-white/10">
                    <div className="text-[11px] text-slate-400">{t.examLastScoreLabel}</div>
                    <div className="font-math font-bold text-white tabular-nums mt-0.5">
                      {attemptsCount > 0 ? `${lastScore}/100` : '—'}
                    </div>
                  </div>

                  <div className="p-2.5 rounded-xl bg-white/[0.04] border border-white/10">
                    <div className="text-[11px] text-slate-400">{t.examBestScoreLabel}</div>
                    <div className="font-math font-bold text-emerald-200 tabular-nums mt-0.5">
                      {attemptsCount > 0 ? `${bestScore}/100` : '—'}
                    </div>
                  </div>

                  <div className="p-2.5 rounded-xl bg-white/[0.04] border border-white/10">
                    <div className="text-[11px] text-slate-400">{t.examAttemptsCountLabel}</div>
                    <div className="font-math font-bold text-white tabular-nums mt-0.5">
                      {attemptsCount}
                    </div>
                  </div>

                  <div className="p-2.5 rounded-xl bg-white/[0.04] border border-white/10">
                    <div className="text-[11px] text-slate-400 flex items-center gap-1">
                      <Calendar className="w-3 h-3 shrink-0" aria-hidden="true" />
                      <span className="truncate">{t.examLastDateLabel}</span>
                    </div>
                    <div className="font-medium text-slate-200 truncate mt-0.5">
                      {attemptsCount > 0 ? formatDate(lastExamMs) : '—'}
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-2.5 pt-2 border-t border-white/10">
                {!unlocked ? (
                  <button
                    type="button"
                    onClick={() => onOpenSection(section.id)}
                    className="liquid-glass-subtle w-full min-h-[44px] px-4 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-blue-100 hover:bg-white/10 inline-flex items-center justify-center gap-2 whitespace-nowrap transition-colors"
                  >
                    <span>{t.examOpenSectionToUnlockBtn}</span>
                    <ForwardArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
                  </button>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={() => onStartExam(section.id)}
                      className="liquid-glass-button flex-1 min-h-[44px] px-4 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center justify-center gap-2 whitespace-nowrap"
                    >
                      {hasDraft ? (
                        <Play className="w-4 h-4 shrink-0" aria-hidden="true" />
                      ) : attemptsCount > 0 ? (
                        <RotateCcw className="w-4 h-4 shrink-0" aria-hidden="true" />
                      ) : (
                        <Play className="w-4 h-4 shrink-0" aria-hidden="true" />
                      )}
                      <span>
                        {hasDraft
                          ? t.examResumeBtn
                          : attemptsCount > 0
                            ? t.examRetakeBtn
                            : t.examStartBtn}
                      </span>
                    </button>

                    {examPassed && prog?.certificateId && (
                      <button
                        type="button"
                        onClick={() => onViewCertificate(section.id)}
                        className="min-h-[44px] px-4 py-2 rounded-2xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-300/40 text-xs sm:text-sm font-semibold text-emerald-100 inline-flex items-center gap-2 whitespace-nowrap shrink-0 transition-colors"
                      >
                        <Award className="w-4 h-4 shrink-0" aria-hidden="true" />
                        <span>{t.profileViewCertBtn}</span>
                      </button>
                    )}
                  </>
                )}
              </div>
            </LiquidGlassCard>
          );
        })}
      </div>

      {/* Independent Attempt History Log */}
      <div className="space-y-3">
        <h2 className="font-display text-lg font-bold text-white flex items-center gap-2 px-1">
          <History className="w-5 h-5 text-blue-300" aria-hidden="true" />
          <span>{t.examHistoryHeading}</span>
        </h2>

        {examAttempts.length === 0 ? (
          <LiquidGlassCard variant="subtle" className="p-6 text-sm text-slate-300">
            {t.examHistoryEmpty}
          </LiquidGlassCard>
        ) : (
          <LiquidGlassCard variant="subtle" className="divide-y divide-white/10 overflow-hidden">
            {examAttempts.slice(0, 30).map((att) => {
              const sec = getSectionById(att.sectionId);
              const submittedMs = att.submittedAt?.toMillis?.();
              return (
                <div
                  key={att.attemptId}
                  className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="flex items-start gap-3 min-w-0">
                    <span className="mt-0.5 shrink-0">
                      {att.passed ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-400" aria-hidden="true" />
                      ) : (
                        <XCircle className="w-5 h-5 text-rose-400" aria-hidden="true" />
                      )}
                    </span>
                    <div className="space-y-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-display text-sm sm:text-base font-bold text-white truncate">
                          {language === 'ar' ? sec.titleAr : sec.titleEn}
                        </span>
                        <span className="text-xs font-math text-blue-200">
                          {t.examAttemptNumberLabel(att.attemptNumber)}
                        </span>
                        {att.timedOut && (
                          <span className="text-[11px] font-semibold text-amber-300">
                            · {t.examTimedOutBadge}
                          </span>
                        )}
                      </div>
                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-300 font-math tabular-nums">
                        <span>
                          {t.examCorrectCountLabel}: {att.correctCount}
                        </span>
                        <span>·</span>
                        <span>
                          {t.examWrongCountLabel}: {att.wrongCount}
                        </span>
                        <span>·</span>
                        <span>
                          {t.examTimeSpentLabel}: {formatDurationMMSS(att.durationSeconds)}
                        </span>
                        <span>·</span>
                        <span className="font-sans text-slate-400">{formatDateTime(submittedMs)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 self-end sm:self-center shrink-0">
                    {att.pointsAwarded > 0 && (
                      <span
                        dir="ltr"
                        className="px-2.5 py-1 rounded-xl bg-emerald-500/20 border border-emerald-400/35 text-xs font-bold font-math text-emerald-200 tabular-nums"
                      >
                        +{att.pointsAwarded}
                      </span>
                    )}
                    <div
                      dir="ltr"
                      className={`font-math text-lg font-extrabold tabular-nums ${
                        att.passed ? 'text-emerald-300' : 'text-rose-300'
                      }`}
                    >
                      {att.score}/100
                    </div>
                  </div>
                </div>
              );
            })}
          </LiquidGlassCard>
        )}
      </div>
    </motion.section>
  );
}
