import { BarChart3, CheckCircle2, PieChart, TrendingUp, XCircle } from 'lucide-react';
import { motion, useReducedMotion } from 'motion/react';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { useLanguage } from '@/src/contexts/LanguageContext';
import type { SectionId } from '@/src/types/curriculum';
import type {
  PointsProgressionNode,
  SectionAnalyticsItem,
  StudentAnalyticsSummary,
} from '@/src/utils/studentStats';

interface ProgressChartsProps {
  analytics: StudentAnalyticsSummary;
  sectionItems: SectionAnalyticsItem[];
  pointsSeries: PointsProgressionNode[];
  onOpenSection?: (sectionId: SectionId) => void;
}

export function ProgressCharts({
  analytics,
  sectionItems,
  pointsSeries,
  onOpenSection,
}: ProgressChartsProps) {
  const { language, t } = useLanguage();
  const shouldReduceMotion = useReducedMotion();

  // --- Chart 1: Cumulative Points Curve Coordinates ---
  const chartW = 560;
  const chartH = 190;
  const padX = 24;
  const padY = 20;
  const innerW = chartW - padX * 2;
  const innerH = chartH - padY * 2;

  const seriesWithOrigin =
    pointsSeries.length === 0
      ? []
      : [
          {
            id: 'origin',
            stepIndex: 0,
            cumulativeEarned: 0,
            delta: 0,
            type: pointsSeries[0].type,
            timestampMs: pointsSeries[0].timestampMs,
          },
          ...pointsSeries,
        ];

  const maxEarned =
    seriesWithOrigin.length > 0
      ? Math.max(100, seriesWithOrigin[seriesWithOrigin.length - 1].cumulativeEarned)
      : 100;

  const curvePoints = seriesWithOrigin.map((pt, index) => {
    const ratioX = seriesWithOrigin.length > 1 ? index / (seriesWithOrigin.length - 1) : 1;
    const ratioY = pt.cumulativeEarned / maxEarned;
    const x = padX + ratioX * innerW;
    const y = padY + innerH - ratioY * innerH;
    return { x, y, pt };
  });

  const linePath =
    curvePoints.length >= 2
      ? curvePoints
          .map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`)
          .join(' ')
      : '';

  const areaPath =
    curvePoints.length >= 2
      ? `${linePath} L ${curvePoints[curvePoints.length - 1].x.toFixed(1)} ${(padY + innerH).toFixed(1)} L ${curvePoints[0].x.toFixed(1)} ${(padY + innerH).toFixed(1)} Z`
      : '';

  // --- Chart 3: Accuracy Circular Ring ---
  const ringRadius = 52;
  const ringCircumference = 2 * Math.PI * ringRadius;
  const accuracyOffset =
    ringCircumference - (analytics.overallPassRate / 100) * ringCircumference;

  return (
    <div className="space-y-5">
      {/* Row 1: Points & Level Growth Curve + Accuracy Ring */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <LiquidGlassCard variant="subtle" className="lg:col-span-2 p-5 sm:p-6 space-y-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="space-y-1">
              <h3 className="font-display text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-sky-300 shrink-0" aria-hidden="true" />
                <span>{t.profileChartsLevelTitle}</span>
              </h3>
              <p className="text-xs text-slate-300">
                {t.profileChartsLevelSubtitle(pointsSeries.length)}
              </p>
            </div>

            <div className="text-end">
              <div className="font-math text-xl font-extrabold text-sky-200 tabular-nums">
                {analytics.levelInfo.totalXp}{' '}
                <span className="text-xs font-normal text-slate-300">{t.profilePointsUnit}</span>
              </div>
              <div className="text-[11px] font-semibold text-violet-200">
                {t.profileLevelLabel(analytics.levelInfo.level)}
              </div>
            </div>
          </div>

          {pointsSeries.length === 0 ? (
            <div className="h-[190px] rounded-2xl border border-dashed border-white/15 bg-white/[0.02] flex items-center justify-center p-6 text-center text-sm text-slate-300">
              {t.profileNoChartData}
            </div>
          ) : (
            <div className="space-y-2" dir="ltr">
              <svg
                viewBox={`0 0 ${chartW} ${chartH}`}
                className="w-full h-[190px] overflow-visible"
                role="img"
                aria-label={t.profileChartsLevelTitle}
              >
                <defs>
                  <linearGradient id="pointsCurveStroke" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#38bdf8" />
                    <stop offset="55%" stopColor="#818cf8" />
                    <stop offset="100%" stopColor="#c084fc" />
                  </linearGradient>
                  <linearGradient id="pointsCurveFill" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="rgba(99, 102, 241, 0.42)" />
                    <stop offset="100%" stopColor="rgba(56, 189, 248, 0.02)" />
                  </linearGradient>
                </defs>

                {[0.25, 0.5, 0.75, 1].map((step) => {
                  const yPos = padY + innerH - step * innerH;
                  return (
                    <line
                      key={step}
                      x1={padX}
                      y1={yPos}
                      x2={chartW - padX}
                      y2={yPos}
                      stroke="rgba(255,255,255,0.08)"
                      strokeDasharray="4 4"
                    />
                  );
                })}

                <motion.path
                  d={areaPath}
                  fill="url(#pointsCurveFill)"
                  initial={shouldReduceMotion ? { opacity: 1 } : { opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.6 }}
                />

                <motion.path
                  d={linePath}
                  fill="none"
                  stroke="url(#pointsCurveStroke)"
                  strokeWidth={3.5}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  initial={shouldReduceMotion ? { pathLength: 1 } : { pathLength: 0 }}
                  animate={{ pathLength: 1 }}
                  transition={{ duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
                />

                {curvePoints.map((node, index) => {
                  const isLast = index === curvePoints.length - 1;
                  const showDot = isLast || curvePoints.length <= 16;
                  if (!showDot) return null;
                  return (
                    <motion.circle
                      key={node.pt.id}
                      cx={node.x}
                      cy={node.y}
                      r={isLast ? 5.5 : 3.2}
                      fill={isLast ? '#38bdf8' : '#a78bfa'}
                      stroke="#0f172a"
                      strokeWidth={1.5}
                      initial={shouldReduceMotion ? { scale: 1 } : { scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ duration: 0.3, delay: isLast ? 0.55 : 0.2 }}
                    />
                  );
                })}
              </svg>

              <div className="flex items-center justify-between text-[11px] font-math tabular-nums text-slate-400 px-2">
                <span>0 {t.profilePointsUnit}</span>
                <span>{Math.round(maxEarned / 2)} {t.profilePointsUnit}</span>
                <span className="text-sky-200 font-semibold">
                  {maxEarned} {t.profilePointsUnit}
                </span>
              </div>
            </div>
          )}
        </LiquidGlassCard>

        {/* Chart 3: Answer Accuracy & Exam Performance Ring */}
        <LiquidGlassCard variant="subtle" className="p-5 sm:p-6 flex flex-col justify-between gap-4">
          <h3 className="font-display text-base sm:text-lg font-bold text-white flex items-center gap-2">
            <PieChart className="w-5 h-5 text-violet-300 shrink-0" aria-hidden="true" />
            <span>{t.profileChartsAccuracyTitle}</span>
          </h3>

          <div className="flex items-center justify-center py-2">
            <div className="relative w-36 h-36 flex items-center justify-center">
              <svg viewBox="0 0 132 132" className="w-full h-full -rotate-90">
                <defs>
                  <linearGradient id="accuracyRingGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#34d399" />
                    <stop offset="60%" stopColor="#38bdf8" />
                    <stop offset="100%" stopColor="#818cf8" />
                  </linearGradient>
                </defs>
                <circle
                  cx="66"
                  cy="66"
                  r={ringRadius}
                  fill="none"
                  stroke="rgba(255,255,255,0.1)"
                  strokeWidth="12"
                />
                <motion.circle
                  cx="66"
                  cy="66"
                  r={ringRadius}
                  fill="none"
                  stroke="url(#accuracyRingGrad)"
                  strokeWidth="12"
                  strokeLinecap="round"
                  strokeDasharray={ringCircumference}
                  initial={
                    shouldReduceMotion
                      ? { strokeDashoffset: accuracyOffset }
                      : { strokeDashoffset: ringCircumference }
                  }
                  animate={{ strokeDashoffset: accuracyOffset }}
                  transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                <span className="font-math text-2xl font-extrabold text-white tabular-nums">
                  {analytics.overallPassRate}%
                </span>
                <span className="text-[11px] text-slate-300">{t.profileStatPassRate}</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2.5 text-xs">
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-400/25 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-300 shrink-0" aria-hidden="true" />
              <div className="min-w-0">
                <div className="text-[11px] text-emerald-200 truncate">{t.profileCorrectShort}</div>
                <div className="font-math text-sm font-bold text-white tabular-nums">
                  {analytics.totalCorrect}
                </div>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-400/25 flex items-center gap-2">
              <XCircle className="w-4 h-4 text-rose-300 shrink-0" aria-hidden="true" />
              <div className="min-w-0">
                <div className="text-[11px] text-rose-200 truncate">{t.profileWrongShort}</div>
                <div className="font-math text-sm font-bold text-white tabular-nums">
                  {analytics.totalWrong}
                </div>
              </div>
            </div>
          </div>
        </LiquidGlassCard>
      </div>

      {/* Row 2: Animated 8-Section Mastery Bar Chart */}
      <LiquidGlassCard variant="subtle" className="p-5 sm:p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="font-display text-base sm:text-lg font-bold text-white flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-blue-300 shrink-0" aria-hidden="true" />
            <span>{t.profileChartsSectionsTitle}</span>
          </h3>
          <span className="text-xs font-math tabular-nums text-slate-300">
            {analytics.completedStages} / {analytics.totalStages}
          </span>
        </div>

        <div className="space-y-3">
          {sectionItems.map((item, idx) => {
            const title = language === 'ar' ? item.section.titleAr : item.section.titleEn;
            const scaleRatio = Math.max(0.02, item.completionPct / 100);
            return (
              <div key={item.section.id} className="space-y-1.5">
                <div className="flex items-center justify-between gap-3 text-xs sm:text-sm">
                  <button
                    type="button"
                    onClick={() => onOpenSection?.(item.section.id)}
                    className="font-semibold text-white hover:text-sky-200 transition-colors truncate text-start"
                  >
                    {idx + 1}. {title}
                  </button>
                  <div className="flex items-center gap-2.5 shrink-0 font-math tabular-nums text-xs">
                    {item.examBestScore > 0 && (
                      <span className={item.examPassed ? 'text-emerald-300' : 'text-amber-300'}>
                        {item.examBestScore}/100
                      </span>
                    )}
                    <span className="text-slate-300">{item.completedStages}/30</span>
                    <span className="text-sky-200 font-bold w-10 text-end">
                      {item.completionPct}%
                    </span>
                  </div>
                </div>

                <div
                  className="h-3 rounded-full bg-white/[0.06] border border-white/10 overflow-hidden"
                  dir="ltr"
                >
                  <motion.div
                    className={`h-full rounded-full bg-gradient-to-r ${item.section.accentFrom} ${item.section.accentTo} origin-left`}
                    initial={shouldReduceMotion ? { scaleX: scaleRatio } : { scaleX: 0 }}
                    animate={{ scaleX: item.completionPct === 0 ? 0.015 : scaleRatio }}
                    transition={{ duration: 0.65, delay: idx * 0.04, ease: [0.16, 1, 0.3, 1] }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </LiquidGlassCard>
    </div>
  );
}
