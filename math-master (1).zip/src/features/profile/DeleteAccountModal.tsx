import { AlertTriangle, Trash2, X } from 'lucide-react';
import { motion } from 'motion/react';
import { useState } from 'react';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { useLanguage } from '@/src/contexts/LanguageContext';

interface DeleteAccountModalProps {
  isDeleting: boolean;
  errorMessage: string | null;
  onConfirm: () => Promise<void>;
  onClose: () => void;
}

export function DeleteAccountModal({
  isDeleting,
  errorMessage,
  onConfirm,
  onClose,
}: DeleteAccountModalProps) {
  const { t } = useLanguage();
  const [confirmInput, setConfirmInput] = useState('');

  const keyword = t.deleteModalKeyword;
  const canConfirm = confirmInput.trim().toUpperCase() === keyword && !isDeleting;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-md"
      role="dialog"
      aria-modal="true"
      aria-labelledby="delete-account-modal-title"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 8 }}
        transition={{ duration: 0.2 }}
        className="w-full max-w-md"
      >
        <LiquidGlassCard className="p-6 sm:p-7 space-y-5 border-rose-400/40 shadow-[0_24px_70px_rgba(225,29,72,0.28)]">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-rose-500/20 border border-rose-400/40 flex items-center justify-center text-rose-300 shrink-0">
                <AlertTriangle className="w-5 h-5" aria-hidden="true" />
              </div>
              <h3
                id="delete-account-modal-title"
                className="font-display text-lg font-bold text-white"
              >
                {t.deleteModalTitle}
              </h3>
            </div>

            <button
              type="button"
              onClick={onClose}
              disabled={isDeleting}
              aria-label={t.deleteModalCancelBtn}
              className="w-9 h-9 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white flex items-center justify-center transition-colors shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <p className="text-sm text-rose-100/90 leading-relaxed bg-rose-500/10 border border-rose-400/25 rounded-2xl p-4">
            {t.deleteModalWarning}
          </p>

          <div className="space-y-2">
            <label
              htmlFor="delete-confirm-keyword-input"
              className="block text-xs font-semibold text-slate-200"
            >
              {t.deleteModalKeywordPrompt(keyword)}
            </label>
            <input
              id="delete-confirm-keyword-input"
              type="text"
              dir="ltr"
              autoComplete="off"
              disabled={isDeleting}
              value={confirmInput}
              onChange={(e) => setConfirmInput(e.target.value)}
              placeholder={keyword}
              className="w-full min-h-[46px] px-4 rounded-2xl bg-slate-950/60 border border-white/15 text-sm font-math font-bold tracking-widest text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-rose-400"
            />
          </div>

          {errorMessage && (
            <div
              role="alert"
              className="p-3.5 rounded-2xl bg-rose-500/15 border border-rose-400/40 text-xs text-rose-200 leading-relaxed"
            >
              {errorMessage}
            </div>
          )}

          <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-2.5 pt-1">
            <button
              type="button"
              onClick={onClose}
              disabled={isDeleting}
              className="liquid-glass-subtle min-h-[44px] px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-slate-200 hover:text-white hover:bg-white/10 transition-colors"
            >
              {t.deleteModalCancelBtn}
            </button>
            <button
              type="button"
              disabled={!canConfirm}
              onClick={() => void onConfirm()}
              className={`min-h-[44px] px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold inline-flex items-center justify-center gap-2 transition-all ${
                canConfirm
                  ? 'bg-gradient-to-r from-rose-500 to-red-600 text-white shadow-[0_8px_24px_rgba(225,29,72,0.4)] hover:brightness-110'
                  : 'bg-rose-500/20 text-rose-300/50 border border-rose-400/20 cursor-not-allowed'
              }`}
            >
              <Trash2 className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>{isDeleting ? t.deleteModalDeletingBtn : t.deleteModalConfirmBtn}</span>
            </button>
          </div>
        </LiquidGlassCard>
      </motion.div>
    </div>
  );
}
