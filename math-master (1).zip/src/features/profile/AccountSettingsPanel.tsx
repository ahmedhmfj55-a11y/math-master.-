import {
  Bell,
  Check,
  Globe,
  Info,
  Languages,
  LogOut,
  Monitor,
  Moon,
  Search,
  Settings,
  ShoppingBag,
  Sun,
  Trash2,
  UserPen,
} from 'lucide-react';
import { AnimatePresence } from 'motion/react';
import { useEffect, useMemo, useState } from 'react';
import type { HubTab } from '@/src/components/ui/AppTopBar';
import { AvatarDisplay } from '@/src/components/ui/AvatarDisplay';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { PWAInstallButton } from '@/src/components/ui/PWAInstallButton';
import { useAuth } from '@/src/contexts/AuthContext';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useNotifications } from '@/src/contexts/NotificationsContext';
import { useRewards } from '@/src/contexts/RewardsContext';
import { useTheme } from '@/src/contexts/ThemeContext';
import { searchCountries } from '@/src/data/countries';
import { FREE_AVATAR_PRESETS, getRewardById } from '@/src/data/rewardsCatalog';
import { DeleteAccountModal } from '@/src/features/profile/DeleteAccountModal';
import { AuthServiceError } from '@/src/services/authService';
import type { ThemeMode } from '@/src/types/notifications';
import type { ShopRewardItem } from '@/src/types/rewards';

interface AccountSettingsPanelProps {
  onNavigate: (tab: HubTab) => void;
  onOpenCountrySelection?: () => void;
}

export function AccountSettingsPanel({
  onNavigate,
  onOpenCountrySelection,
}: AccountSettingsPanelProps) {
  const { language, t } = useLanguage();
  const {
    userProfile,
    selectedCountry,
    selectCountry,
    updateDisplayName,
    syncPreferredLanguage,
    signOut,
    deleteAccount,
  } = useAuth();
  const { purchases, equipReward, processingItemId } = useRewards();
  const { themeMode } = useTheme();
  const {
    preferences,
    pushPermissionState,
    updatePreferences,
    syncThemePreference,
    requestPushPermission,
  } = useNotifications();

  const [nameInput, setNameInput] = useState(userProfile?.displayName ?? '');
  const [savingName, setSavingName] = useState(false);
  const [nameFeedback, setNameFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(
    null,
  );

  const [avatarSavedNotice, setAvatarSavedNotice] = useState(false);

  const [countrySearch, setCountrySearch] = useState('');
  const [savingCountryCode, setSavingCountryCode] = useState<string | null>(null);
  const [countrySavedNotice, setCountrySavedNotice] = useState(false);
  const [notifSavedNotice, setNotifSavedNotice] = useState(false);

  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [deletingAccount, setDeletingAccount] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  useEffect(() => {
    if (userProfile?.displayName) {
      setNameInput(userProfile.displayName);
    }
  }, [userProfile?.displayName]);

  const ownedAvatarItems = useMemo(
    () =>
      purchases
        .map((p) => getRewardById(p.itemId))
        .filter((item): item is ShopRewardItem => Boolean(item && item.category === 'avatar')),
    [purchases],
  );

  const filteredCountries = useMemo(
    () => searchCountries(countrySearch).slice(0, 18),
    [countrySearch],
  );

  const handleSaveName = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = nameInput.trim();
    if (trimmed.length < 2 || trimmed.length > 100) {
      setNameFeedback({ type: 'err', text: t.settingsNameInvalidMsg });
      return;
    }
    setSavingName(true);
    setNameFeedback(null);
    try {
      await updateDisplayName(trimmed);
      setNameFeedback({ type: 'ok', text: t.settingsNameSavedMsg });
    } catch {
      setNameFeedback({ type: 'err', text: t.errorGeneric });
    } finally {
      setSavingName(false);
    }
  };

  const handleEquipAvatar = async (avatarId: string) => {
    setAvatarSavedNotice(false);
    try {
      await equipReward('avatar', avatarId);
      setAvatarSavedNotice(true);
    } catch {
      // Handled gracefully
    }
  };

  const handlePickCountry = async (country: (typeof filteredCountries)[number]) => {
    setSavingCountryCode(country.code);
    setCountrySavedNotice(false);
    try {
      await selectCountry(country);
      setCountrySavedNotice(true);
    } finally {
      setSavingCountryCode(null);
    }
  };

  const handleToggleNotifPref = async (
    key:
      | 'notificationsEnabled'
      | 'notifyDailyReminder'
      | 'notifyMedalsCerts'
      | 'notifyStageWinPoints'
      | 'notifyStageUnlock'
      | 'notifyRankUp'
      | 'notifyExamsChallenges',
    nextValue: boolean,
  ) => {
    setNotifSavedNotice(false);
    await updatePreferences({ [key]: nextValue });
    setNotifSavedNotice(true);
  };

  const handleConfirmDeleteAccount = async () => {
    setDeletingAccount(true);
    setDeleteError(null);
    try {
      await deleteAccount();
      setDeleteModalOpen(false);
    } catch (error) {
      if (error instanceof AuthServiceError) {
        if (error.code === 'requires-recent-login') {
          setDeleteError(t.deleteModalReauthError);
        } else if (error.code === 'popup-closed') {
          setDeleteError(t.errorPopupClosed);
        } else if (error.code === 'popup-blocked') {
          setDeleteError(t.errorPopupBlocked);
        } else {
          setDeleteError(t.errorGeneric);
        }
      } else {
        setDeleteError(t.errorGeneric);
      }
    } finally {
      setDeletingAccount(false);
    }
  };

  const activeAvatarId = userProfile?.equippedAvatarId ?? 'avatar-classic';
  const activeCountryCode = selectedCountry?.code ?? userProfile?.countryCode ?? '';

  const themeOptions: { id: ThemeMode; label: string; Icon: typeof Moon }[] = [
    { id: 'dark', label: t.themeDark, Icon: Moon },
    { id: 'light', label: t.themeLight, Icon: Sun },
    { id: 'auto', label: t.themeAuto, Icon: Monitor },
  ];

  const notifToggles: {
    key:
      | 'notificationsEnabled'
      | 'notifyDailyReminder'
      | 'notifyMedalsCerts'
      | 'notifyStageWinPoints'
      | 'notifyStageUnlock'
      | 'notifyRankUp'
      | 'notifyExamsChallenges';
    label: string;
    value: boolean;
  }[] = [
    {
      key: 'notificationsEnabled',
      label: t.settingsNotifMasterLabel,
      value: preferences.notificationsEnabled,
    },
    {
      key: 'notifyDailyReminder',
      label: t.settingsNotifDailyLabel,
      value: preferences.notifyDailyReminder,
    },
    {
      key: 'notifyMedalsCerts',
      label: t.settingsNotifAchievementsLabel,
      value: preferences.notifyMedalsCerts,
    },
    {
      key: 'notifyStageWinPoints',
      label: t.settingsNotifPointsLabel,
      value: preferences.notifyStageWinPoints,
    },
    {
      key: 'notifyStageUnlock',
      label: t.settingsNotifStageUnlockLabel,
      value: preferences.notifyStageUnlock,
    },
    {
      key: 'notifyRankUp',
      label: t.settingsNotifRankUpLabel,
      value: preferences.notifyRankUp,
    },
    {
      key: 'notifyExamsChallenges',
      label: t.settingsNotifChallengesLabel,
      value: preferences.notifyExamsChallenges,
    },
  ];

  return (
    <div className="space-y-5">
      <LiquidGlassCard variant="subtle" className="p-5 sm:p-6 space-y-1.5">
        <h2 className="font-display text-lg sm:text-xl font-bold text-white flex items-center gap-2">
          <Settings className="w-5 h-5 text-sky-300 shrink-0" aria-hidden="true" />
          <span>{t.settingsTitle}</span>
        </h2>
        <p className="text-xs sm:text-sm text-slate-300">{t.settingsSubtitle}</p>
      </LiquidGlassCard>

      {/* 1. Language & 2. Theme Appearance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <LiquidGlassCard variant="subtle" className="p-5 sm:p-6 space-y-4">
          <h3 className="font-display text-base font-bold text-white flex items-center gap-2">
            <Languages className="w-4 h-4 text-violet-300 shrink-0" aria-hidden="true" />
            <span>{t.settingsLanguageSectionTitle}</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <button
              type="button"
              onClick={() => void syncPreferredLanguage('ar')}
              aria-pressed={language === 'ar'}
              className={`min-h-[52px] px-4 py-3 rounded-2xl border text-sm font-semibold flex items-center justify-between transition-all ${
                language === 'ar'
                  ? 'bg-gradient-to-r from-blue-500/85 to-violet-600/85 border-blue-300/60 text-white shadow-[0_6px_20px_rgba(59,130,246,0.25)]'
                  : 'bg-white/[0.04] border-white/10 text-slate-300 hover:bg-white/[0.08] hover:text-white'
              }`}
            >
              <span>{t.settingsLanguageArabic}</span>
              {language === 'ar' && <Check className="w-4 h-4 text-white shrink-0" />}
            </button>

            <button
              type="button"
              onClick={() => void syncPreferredLanguage('en')}
              aria-pressed={language === 'en'}
              className={`min-h-[52px] px-4 py-3 rounded-2xl border text-sm font-semibold flex items-center justify-between transition-all ${
                language === 'en'
                  ? 'bg-gradient-to-r from-blue-500/85 to-violet-600/85 border-blue-300/60 text-white shadow-[0_6px_20px_rgba(59,130,246,0.25)]'
                  : 'bg-white/[0.04] border-white/10 text-slate-300 hover:bg-white/[0.08] hover:text-white'
              }`}
            >
              <span>{t.settingsLanguageEnglish}</span>
              {language === 'en' && <Check className="w-4 h-4 text-white shrink-0" />}
            </button>
          </div>
        </LiquidGlassCard>

        <LiquidGlassCard variant="subtle" className="p-5 sm:p-6 space-y-4">
          <div className="space-y-1">
            <h3 className="font-display text-base font-bold text-white flex items-center gap-2">
              <Sun className="w-4 h-4 text-amber-300 shrink-0" aria-hidden="true" />
              <span>{t.themeSectionTitle}</span>
            </h3>
            <p className="text-xs text-slate-300">{t.themeSectionSubtitle}</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {themeOptions.map(({ id, label, Icon }) => {
              const active = themeMode === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => void syncThemePreference(id)}
                  aria-pressed={active}
                  className={`min-h-[48px] px-3 py-2.5 rounded-2xl border text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
                    active
                      ? 'bg-gradient-to-r from-blue-500/85 to-violet-600/85 border-blue-300/60 text-white shadow-[0_6px_18px_rgba(59,130,246,0.25)]'
                      : 'bg-white/[0.04] border-white/10 text-slate-300 hover:bg-white/[0.08] hover:text-white'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span className="truncate">{label}</span>
                </button>
              );
            })}
          </div>
        </LiquidGlassCard>
      </div>

      {/* 3. Edit Display Name */}
      <LiquidGlassCard variant="subtle" className="p-5 sm:p-6 space-y-4">
        <h3 className="font-display text-base font-bold text-white flex items-center gap-2">
          <UserPen className="w-4 h-4 text-blue-300 shrink-0" aria-hidden="true" />
          <span>{t.settingsNameSectionTitle}</span>
        </h3>

        <form onSubmit={(e) => void handleSaveName(e)} className="space-y-3 max-w-2xl">
          <input
            type="text"
            maxLength={100}
            value={nameInput}
            onChange={(e) => {
              setNameInput(e.target.value);
              if (nameFeedback) setNameFeedback(null);
            }}
            placeholder={t.settingsNamePlaceholder}
            className="w-full min-h-[46px] px-4 rounded-2xl liquid-glass-input text-sm text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-400"
          />
          <div className="flex flex-wrap items-center justify-between gap-3">
            <button
              type="submit"
              disabled={savingName}
              className="liquid-glass-button min-h-[44px] px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center gap-2"
            >
              <Check className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>{savingName ? t.settingsNameSavingBtn : t.settingsNameSaveBtn}</span>
            </button>

            {nameFeedback && (
              <span
                className={`text-xs font-medium ${
                  nameFeedback.type === 'ok' ? 'text-emerald-300' : 'text-rose-300'
                }`}
              >
                {nameFeedback.text}
              </span>
            )}
          </div>
        </form>
      </LiquidGlassCard>

      {/* 4. Change Personal Photo or Avatar */}
      <LiquidGlassCard variant="subtle" className="p-5 sm:p-6 space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="space-y-1">
            <h3 className="font-display text-base font-bold text-white">
              {t.settingsAvatarSectionTitle}
            </h3>
            <p className="text-xs text-slate-300">{t.settingsAvatarSubtitle}</p>
          </div>

          <div className="flex items-center gap-3">
            {avatarSavedNotice && (
              <span className="text-xs font-medium text-emerald-300">
                {t.settingsAvatarSavedMsg}
              </span>
            )}
            <button
              type="button"
              onClick={() => onNavigate('shop')}
              className="liquid-glass-subtle min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-semibold text-white hover:bg-white/10 inline-flex items-center gap-1.5"
            >
              <ShoppingBag className="w-3.5 h-3.5 text-sky-300" aria-hidden="true" />
              <span>{t.profileGoToShopBtn}</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
          {userProfile?.photoUrl && (
            <button
              type="button"
              disabled={processingItemId === 'avatar-google'}
              onClick={() => void handleEquipAvatar('avatar-google')}
              className={`p-3 rounded-2xl border flex flex-col items-center gap-2 transition-all ${
                activeAvatarId === 'avatar-google'
                  ? 'bg-blue-500/20 border-blue-300/65 ring-1 ring-blue-300/40'
                  : 'bg-white/[0.03] border-white/10 hover:bg-white/[0.08]'
              }`}
            >
              <AvatarDisplay
                avatarId="avatar-google"
                photoUrl={userProfile.photoUrl}
                displayName={userProfile.displayName}
                size="md"
              />
              <span className="text-[11px] font-semibold text-white text-center truncate w-full">
                {t.profileGoogleAvatarBtn}
              </span>
            </button>
          )}

          {FREE_AVATAR_PRESETS.map((preset) => {
            const active = activeAvatarId === preset.id;
            return (
              <button
                key={preset.id}
                type="button"
                disabled={processingItemId === preset.id}
                onClick={() => void handleEquipAvatar(preset.id)}
                className={`p-3 rounded-2xl border flex flex-col items-center gap-2 transition-all ${
                  active
                    ? 'bg-blue-500/20 border-blue-300/65 ring-1 ring-blue-300/40'
                    : 'bg-white/[0.03] border-white/10 hover:bg-white/[0.08]'
                }`}
              >
                <AvatarDisplay avatarId={preset.id} size="md" />
                <span className="text-[11px] font-semibold text-white text-center truncate w-full">
                  {language === 'ar' ? preset.nameAr : preset.nameEn}
                </span>
              </button>
            );
          })}

          {ownedAvatarItems.map((item) => {
            const active = activeAvatarId === item.id;
            return (
              <button
                key={item.id}
                type="button"
                disabled={processingItemId === item.id}
                onClick={() => void handleEquipAvatar(item.id)}
                className={`p-3 rounded-2xl border flex flex-col items-center gap-2 transition-all ${
                  active
                    ? 'bg-violet-500/25 border-violet-300/65 ring-1 ring-violet-300/40'
                    : 'bg-white/[0.03] border-white/10 hover:bg-white/[0.08]'
                }`}
              >
                <AvatarDisplay avatarId={item.id} size="md" />
                <span className="text-[11px] font-semibold text-white text-center truncate w-full">
                  {language === 'ar' ? item.nameAr : item.nameEn}
                </span>
              </button>
            );
          })}
        </div>
      </LiquidGlassCard>

      {/* 5. Change Country */}
      <LiquidGlassCard variant="subtle" className="p-5 sm:p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="font-display text-base font-bold text-white flex items-center gap-2">
            <Globe className="w-4 h-4 text-emerald-300 shrink-0" aria-hidden="true" />
            <span>{t.settingsCountrySectionTitle}</span>
          </h3>

          <div className="flex flex-wrap items-center gap-2.5 text-xs">
            {countrySavedNotice && (
              <span className="text-emerald-300 font-medium">{t.settingsCountrySavedMsg}</span>
            )}
            {selectedCountry && (
              <span className="text-slate-200 font-semibold">
                {selectedCountry.flag}{' '}
                {language === 'ar' ? selectedCountry.nameAr : selectedCountry.nameEn}
              </span>
            )}
            {onOpenCountrySelection && (
              <button
                type="button"
                onClick={onOpenCountrySelection}
                className="liquid-glass-subtle min-h-[36px] px-3 py-1.5 rounded-xl text-xs font-semibold text-sky-200 hover:bg-white/10 inline-flex items-center gap-1.5"
              >
                <Globe className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                <span>{t.settingsCountryOpenFullBtn}</span>
              </button>
            )}
          </div>
        </div>

        <div className="relative">
          <Search
            className="w-4 h-4 text-slate-400 absolute top-1/2 -translate-y-1/2 start-4 pointer-events-none"
            aria-hidden="true"
          />
          <input
            type="search"
            value={countrySearch}
            onChange={(e) => setCountrySearch(e.target.value)}
            placeholder={t.settingsCountrySearchPlaceholder}
            className="w-full min-h-[44px] ps-11 pe-4 rounded-2xl liquid-glass-input text-sm text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-400"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 max-h-[240px] overflow-y-auto glass-scroll pe-1">
          {filteredCountries.map((country) => {
            const active = activeCountryCode === country.code;
            const busy = savingCountryCode === country.code;
            return (
              <button
                key={country.code}
                type="button"
                disabled={Boolean(savingCountryCode)}
                onClick={() => void handlePickCountry(country)}
                className={`min-h-[46px] px-3.5 py-2 rounded-2xl border flex items-center justify-between gap-2 text-start transition-all ${
                  active
                    ? 'bg-blue-500/25 border-blue-300/60 text-white'
                    : 'bg-white/[0.03] border-white/10 text-slate-200 hover:bg-white/[0.08]'
                }`}
              >
                <span className="flex items-center gap-2 min-w-0">
                  <span className="text-lg shrink-0">{country.flag}</span>
                  <span className="text-xs font-semibold truncate">
                    {language === 'ar' ? country.nameAr : country.nameEn}
                  </span>
                </span>
                {busy ? (
                  <span className="text-[10px] text-sky-300 shrink-0">...</span>
                ) : active ? (
                  <Check className="w-4 h-4 text-sky-300 shrink-0" />
                ) : null}
              </button>
            );
          })}
        </div>
      </LiquidGlassCard>

      {/* 6. Granular Notification Controls */}
      <LiquidGlassCard variant="subtle" className="p-5 sm:p-6 space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="space-y-1">
            <h3 className="font-display text-base font-bold text-white flex items-center gap-2">
              <Bell className="w-4 h-4 text-amber-300 shrink-0" aria-hidden="true" />
              <span>{t.settingsNotifSectionTitle}</span>
            </h3>
            <p className="text-xs text-slate-300">{t.settingsNotifSectionSubtitle}</p>
          </div>
          {notifSavedNotice && (
            <span className="text-xs font-semibold text-emerald-300">{t.settingsNotifSavedMsg}</span>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {notifToggles.map(({ key, label, value }) => {
            const disabled = key !== 'notificationsEnabled' && !preferences.notificationsEnabled;
            return (
              <label
                key={key}
                className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 cursor-pointer transition-all ${
                  disabled
                    ? 'bg-white/[0.02] border-white/10 opacity-50 cursor-not-allowed'
                    : 'bg-white/[0.04] border-white/10 hover:bg-white/[0.07]'
                }`}
              >
                <span className="text-xs sm:text-sm font-medium text-white">{label}</span>
                <button
                  type="button"
                  role="switch"
                  aria-checked={value}
                  disabled={disabled}
                  onClick={() => void handleToggleNotifPref(key, !value)}
                  className={`relative w-12 h-7 rounded-full transition-colors shrink-0 ${
                    value ? 'bg-blue-500' : 'bg-slate-600/60'
                  }`}
                >
                  <span
                    className={`absolute top-1 start-1 w-5 h-5 rounded-full bg-white shadow transition-transform ${
                      value ? 'translate-x-5 rtl:-translate-x-5' : ''
                    }`}
                  />
                </button>
              </label>
            );
          })}
        </div>

        {/* Guarded Web Push Alerts Opt-In */}
        <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-0.5">
            <div className="text-xs sm:text-sm font-bold text-white">{t.settingsPushTitle}</div>
            <p className="text-xs text-slate-300">{t.settingsPushDesc}</p>
            {pushPermissionState === 'denied' && (
              <p className="text-[11px] text-amber-300">{t.settingsPushBlockedNotice}</p>
            )}
            {pushPermissionState === 'unsupported' && (
              <p className="text-[11px] text-slate-400">{t.settingsPushUnsupportedNotice}</p>
            )}
          </div>

          {pushPermissionState === 'granted' ? (
            <span className="px-3.5 py-2 rounded-xl bg-emerald-500/20 border border-emerald-400/35 text-xs font-semibold text-emerald-200 whitespace-nowrap shrink-0">
              {t.settingsPushEnabledBadge}
            </span>
          ) : (
            <button
              type="button"
              disabled={pushPermissionState === 'unsupported' || pushPermissionState === 'denied'}
              onClick={() => void requestPushPermission()}
              className={`min-h-[40px] px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 ${
                pushPermissionState === 'unsupported' || pushPermissionState === 'denied'
                  ? 'bg-white/5 border border-white/10 text-slate-400 cursor-not-allowed'
                  : 'liquid-glass-button text-white'
              }`}
            >
              {t.settingsPushEnableBtn}
            </button>
          )}
        </div>
      </LiquidGlassCard>

      {/* 7. Session & Account Deletion */}
      <LiquidGlassCard variant="subtle" className="p-5 sm:p-6 space-y-4">
        <h3 className="font-display text-base font-bold text-white">
          {t.settingsSessionSectionTitle}
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 flex flex-col justify-between gap-4">
            <div className="space-y-1">
              <div className="text-sm font-bold text-white">{t.settingsSignOutTitle}</div>
              <p className="text-xs text-slate-300 leading-relaxed">{t.settingsSignOutDesc}</p>
            </div>
            <button
              type="button"
              onClick={() => void signOut()}
              className="liquid-glass-subtle min-h-[44px] px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white hover:bg-white/10 inline-flex items-center justify-center gap-2 self-start"
            >
              <LogOut className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>{t.homeSignOut}</span>
            </button>
          </div>

          <div className="p-4 rounded-2xl bg-rose-500/[0.08] border border-rose-400/30 flex flex-col justify-between gap-4">
            <div className="space-y-1">
              <div className="text-sm font-bold text-rose-200">{t.settingsDeleteSectionTitle}</div>
              <p className="text-xs text-slate-300 leading-relaxed">{t.settingsDeleteDesc}</p>
            </div>
            <button
              type="button"
              onClick={() => {
                setDeleteError(null);
                setDeleteModalOpen(true);
              }}
              className="min-h-[44px] px-4 py-2.5 rounded-2xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-400/45 text-xs sm:text-sm font-semibold text-rose-200 inline-flex items-center justify-center gap-2 self-start transition-colors"
            >
              <Trash2 className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>{t.settingsDeleteOpenBtn}</span>
            </button>
          </div>
        </div>
      </LiquidGlassCard>

      {/* 8. App Information & Mobile Install */}
      <LiquidGlassCard variant="subtle" className="p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-400/30 flex items-center justify-center text-blue-300 shrink-0">
            <Info className="w-5 h-5" aria-hidden="true" />
          </div>
          <div className="space-y-0.5">
            <div className="text-sm font-bold text-white">
              {t.appInfoTitle} · <span dir="ltr">{t.brandName}</span>
            </div>
            <div className="text-xs text-slate-300">{t.appVersionLabel}</div>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <PWAInstallButton variant="full" />
          <div className="text-xs text-slate-400">{t.appCopyrightText}</div>
        </div>
      </LiquidGlassCard>

      <AnimatePresence>
        {deleteModalOpen && (
          <DeleteAccountModal
            isDeleting={deletingAccount}
            errorMessage={deleteError}
            onConfirm={handleConfirmDeleteAccount}
            onClose={() => {
              if (!deletingAccount) {
                setDeleteModalOpen(false);
              }
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
