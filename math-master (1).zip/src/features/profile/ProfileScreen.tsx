import {
  Activity,
  Award,
  BarChart3,
  Calendar,
  CheckCircle2,
  ClipboardCheck,
  Crown,
  Flame,
  History,
  Layers,
  Lock,
  Medal,
  Percent,
  Settings,
  ShoppingBag,
  Sparkles,
  Target,
  Trophy,
  UserCheck,
  XCircle,
} from 'lucide-react';
import { motion, useReducedMotion } from 'motion/react';
import { useEffect, useMemo, useState } from 'react';
import { AppTopBar, type HubTab } from '@/src/components/ui/AppTopBar';
import { AvatarDisplay } from '@/src/components/ui/AvatarDisplay';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { MedalEmblem } from '@/src/components/ui/MedalEmblem';
import { useAuth } from '@/src/contexts/AuthContext';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useProgress } from '@/src/contexts/ProgressContext';
import { useRewards } from '@/src/contexts/RewardsContext';
import { ALL_ACHIEVEMENT_AND_MEDAL_ITEMS, MEDALS_CATALOG } from '@/src/data/achievementsCatalog';
import { CURRICULUM_SECTIONS, getSectionById } from '@/src/data/curriculum';
import {
  getEffectiveActiveStreak,
  getTodayDateKey,
} from '@/src/data/dailyChallengeGenerator';
import { DEFAULT_AVATAR_ID, getRewardById } from '@/src/data/rewardsCatalog';
import { AccountSettingsPanel } from '@/src/features/profile/AccountSettingsPanel';
import { ProgressCharts } from '@/src/features/profile/ProgressCharts';
import { leaderboardService } from '@/src/services/leaderboardService';
import type { SectionId } from '@/src/types/curriculum';
import type { PointTransactionRecord, ShopRewardItem } from '@/src/types/rewards';
import {
  buildPointsProgressionSeries,
  buildRecentActivityFeed,
  computeSectionBreakdown,
  computeStudentAnalytics,
} from '@/src/utils/studentStats';

interface ProfileScreenProps {
  onNavigate: (tab: HubTab) => void;
  onViewCertificate: (sectionId: SectionId) => void;
  onViewMasterCertificate: () => void;
  onOpenDailyChallenge: () => void;
  onOpenSection?: (sectionId: SectionId) => void;
  onOpenCountrySelection?: () => void;
}

type ProfileWorkspaceTab = 'overview' | 'progress' | 'settings';

export function ProfileScreen({
  onNavigate,
  onViewCertificate,
  onViewMasterCertificate,
  onOpenDailyChallenge,
  onOpenSection,
  onOpenCountrySelection,
}: ProfileScreenProps) {
  const { language, t } = useLanguage();
  const shouldReduceMotion = useReducedMotion();
  const { firebaseUser, userProfile, selectedCountry } = useAuth();
  const {
    sectionProgressMap,
    stageProgressMap,
    examAttempts,
    dailyHistory,
    dailyStats,
    achievementsMap,
    masterCertificate,
  } = useProgress();
  const { purchases, transactions, equipReward, processingItemId } = useRewards();

  const [activeTab, setActiveTab] = useState<ProfileWorkspaceTab>('overview');
  const [globalRank, setGlobalRank] = useState<number | null>(null);

  const spendablePoints = userProfile?.points ?? 0;
  const totalEarnedPoints = userProfile?.totalEarnedPoints ?? spendablePoints;

  useEffect(() => {
    if (!firebaseUser) return;
    let cancelled = false;
    void leaderboardService
      .fetchUserGlobalRank(totalEarnedPoints)
      .then((rank) => {
        if (!cancelled) setGlobalRank(rank);
      })
      .catch(() => {
        if (!cancelled) setGlobalRank(null);
      });
    return () => {
      cancelled = true;
    };
  }, [firebaseUser, totalEarnedPoints]);

  const analytics = useMemo(
    () =>
      computeStudentAnalytics({
        totalEarnedPoints,
        sectionProgressMap,
        stageProgressMap,
        examAttempts,
        dailyHistory,
        dailyStats,
      }),
    [
      totalEarnedPoints,
      sectionProgressMap,
      stageProgressMap,
      examAttempts,
      dailyHistory,
      dailyStats,
    ],
  );

  const sectionBreakdown = useMemo(
    () => computeSectionBreakdown(sectionProgressMap),
    [sectionProgressMap],
  );

  const pointsSeries = useMemo(
    () => buildPointsProgressionSeries(transactions),
    [transactions],
  );

  const recentActivity = useMemo(
    () =>
      buildRecentActivityFeed({
        transactions,
        examAttempts,
        dailyHistory,
        achievementsMap,
      }),
    [transactions, examAttempts, dailyHistory, achievementsMap],
  );

  const displayName =
    userProfile?.displayName ||
    firebaseUser?.displayName ||
    firebaseUser?.phoneNumber ||
    firebaseUser?.email ||
    'Math Master';

  const countryLabel = selectedCountry
    ? language === 'ar'
      ? selectedCountry.nameAr
      : selectedCountry.nameEn
    : userProfile
      ? language === 'ar'
        ? userProfile.countryNameAr
        : userProfile.countryNameEn
      : '—';

  const memberSinceLabel = useMemo(() => {
    const rawDate =
      userProfile?.createdAt?.toDate?.() ??
      (firebaseUser?.metadata.creationTime ? new Date(firebaseUser.metadata.creationTime) : null);
    if (!rawDate || Number.isNaN(rawDate.getTime())) return '—';
    return new Intl.DateTimeFormat(language === 'ar' ? 'ar-SA' : 'en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    }).format(rawDate);
  }, [userProfile?.createdAt, firebaseUser?.metadata.creationTime, language]);

  const equippedTitle = getRewardById(userProfile?.equippedTitleId);
  const equippedBadge = getRewardById(userProfile?.equippedBadgeId);

  const ownedItems = purchases
    .map((p) => getRewardById(p.itemId))
    .filter((item): item is ShopRewardItem => Boolean(item));

  const earnedCertificates = CURRICULUM_SECTIONS.filter((sec) => {
    const rec = sectionProgressMap[sec.id];
    return Boolean(rec?.examPassed && rec?.certificateId);
  }).map((sec) => ({
    section: sec,
    progress: sectionProgressMap[sec.id]!,
  }));

  const formatTxTitle = (tx: PointTransactionRecord): string => {
    switch (tx.type) {
      case 'stage_win':
        return `${t.txStageWinLabel} (${tx.refId.toUpperCase()})`;
      case 'stage_perfect':
        return `${t.txStagePerfectLabel} (${tx.refId.toUpperCase()})`;
      case 'section_complete': {
        const sec = getSectionById(tx.refId as SectionId);
        return `${t.txSectionCompleteLabel} · ${language === 'ar' ? sec.titleAr : sec.titleEn}`;
      }
      case 'exam_pass': {
        const sec = getSectionById(tx.refId as SectionId);
        return `${t.txExamPassLabel} · ${language === 'ar' ? sec.titleAr : sec.titleEn}`;
      }
      case 'exam_perfect': {
        const sec = getSectionById(tx.refId as SectionId);
        return `${t.txExamPerfectLabel} · ${language === 'ar' ? sec.titleAr : sec.titleEn}`;
      }
      case 'daily_win':
        return `${t.txDailyWinLabel} (${tx.refId})`;
      case 'daily_perfect':
        return `${t.txDailyPerfectLabel} (${tx.refId})`;
      case 'shop_purchase': {
        const item = getRewardById(tx.refId);
        const itemName = item ? (language === 'ar' ? item.nameAr : item.nameEn) : tx.refId;
        return `${t.txShopPurchaseLabel}: ${itemName}`;
      }
      case 'duel_win':
        return t.txDuelWinLabel;
      case 'duel_draw':
        return t.txDuelDrawLabel;
      case 'duel_part':
        return t.txDuelPartLabel;
      case 'bank_tier_mastery':
        return `${t.txBankTierMasteryLabel} (${tx.refId.toUpperCase()})`;
      case 'genius_solve':
        return t.txGeniusSolveLabel;
    }
  };

  const isEquipped = (item: ShopRewardItem): boolean => {
    if (!userProfile) return false;
    if (item.category === 'badge') return userProfile.equippedBadgeId === item.id;
    if (item.category === 'avatar') return userProfile.equippedAvatarId === item.id;
    return userProfile.equippedTitleId === item.id;
  };

  const todayKey = getTodayDateKey();
  const activeStreak = getEffectiveActiveStreak(
    dailyStats?.currentStreak ?? 0,
    dailyStats?.lastWonDate,
    todayKey,
  );
  const longestStreak = dailyStats?.longestStreak ?? 0;
  const badge7 = dailyStats?.badge7Unlocked ?? false;
  const badge30 = dailyStats?.badge30Unlocked ?? false;

  const levelScale = Math.max(0.02, analytics.levelInfo.progressPct / 100);

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="min-h-dvh flex flex-col px-4 py-5 sm:px-8 sm:py-7 max-w-6xl mx-auto w-full gap-6 safe-pb-nav"
    >
      <AppTopBar activeTab="profile" onNavigate={onNavigate} />

      {/* Identity & Core Metrics Hero */}
      <LiquidGlassCard className="p-6 sm:p-8 space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-white/10">
          <div className="flex items-start sm:items-center gap-4 sm:gap-5 min-w-0">
            <button
              type="button"
              onClick={() => setActiveTab('settings')}
              title={t.settingsAvatarSectionTitle}
              className="relative shrink-0 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 rounded-3xl"
            >
              <AvatarDisplay
                avatarId={userProfile?.equippedAvatarId}
                photoUrl={userProfile?.photoUrl}
                displayName={displayName}
                size="xl"
              />
              {equippedBadge && (
                <span
                  title={language === 'ar' ? equippedBadge.nameAr : equippedBadge.nameEn}
                  className={`absolute -bottom-1.5 -end-1.5 w-8 h-8 rounded-2xl bg-gradient-to-br ${equippedBadge.accentFrom} ${equippedBadge.accentTo} border border-white/40 flex items-center justify-center text-sm font-bold text-white shadow-lg`}
                >
                  {equippedBadge.symbol}
                </span>
              )}
            </button>

            <div className="space-y-2 min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2 text-xs font-semibold">
                <span className="text-sky-300 inline-flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-300 shrink-0" aria-hidden="true" />
                  <span>{t.profileLevelLabel(analytics.levelInfo.level)}</span>
                </span>
                <span className="text-slate-500" aria-hidden="true">
                  ·
                </span>
                <span className="text-violet-200">
                  {language === 'ar'
                    ? analytics.levelInfo.titleAr
                    : analytics.levelInfo.titleEn}
                </span>
              </div>

              <h1 className="font-display text-2xl sm:text-3xl font-bold text-white truncate">
                {displayName}
              </h1>

              <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs sm:text-sm text-slate-300">
                {equippedTitle && (
                  <>
                    <span className="font-semibold text-violet-200 inline-flex items-center gap-1">
                      <Crown className="w-3.5 h-3.5 text-amber-300" aria-hidden="true" />
                      {language === 'ar' ? equippedTitle.nameAr : equippedTitle.nameEn}
                    </span>
                    <span className="text-slate-500" aria-hidden="true">
                      ·
                    </span>
                  </>
                )}
                <span>
                  {selectedCountry?.flag} {countryLabel}
                </span>
                <span className="text-slate-500" aria-hidden="true">
                  ·
                </span>
                <span className="inline-flex items-center gap-1 text-slate-300">
                  <Calendar className="w-3.5 h-3.5 text-sky-300 shrink-0" aria-hidden="true" />
                  <span>
                    {t.profileMemberSinceLabel}: {memberSinceLabel}
                  </span>
                </span>
                {(firebaseUser?.email || firebaseUser?.phoneNumber) && (
                  <>
                    <span className="text-slate-500" aria-hidden="true">
                      ·
                    </span>
                    <span className="text-slate-400 truncate max-w-[220px]" dir="ltr">
                      {firebaseUser?.email || firebaseUser?.phoneNumber}
                    </span>
                  </>
                )}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => onNavigate('leaderboard')}
              className="liquid-glass-subtle min-h-[46px] px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white hover:bg-white/10 inline-flex items-center gap-2 shrink-0"
            >
              <Trophy className="w-4 h-4 text-amber-300 shrink-0" aria-hidden="true" />
              <span>{t.profileGlobalRankLabel}:</span>
              <span className="font-math text-base font-extrabold tabular-nums text-amber-200">
                {globalRank ? `#${globalRank}` : '—'}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('settings')}
              className="liquid-glass-button min-h-[46px] px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center gap-2 shrink-0"
            >
              <Settings className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>{t.profileEditQuickBtn}</span>
            </button>
          </div>
        </div>

        {/* Level XP Progress + Primary Points Summary */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 items-center">
          <div className="lg:col-span-2 p-4 rounded-2xl bg-white/[0.04] border border-white/10 space-y-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <span className="font-semibold text-white">
                {t.profileNextLevelLabel} ({t.profileLevelLabel(analytics.levelInfo.level + 1)})
              </span>
              <span className="font-math tabular-nums text-sky-200 font-semibold">
                {t.profileLevelProgressLabel(
                  analytics.levelInfo.xpIntoLevel,
                  analytics.levelInfo.xpSpanForLevel,
                )}{' '}
                · {analytics.levelInfo.progressPct}%
              </span>
            </div>
            <div
              className="h-3 rounded-full bg-slate-950/60 border border-white/10 overflow-hidden"
              dir="ltr"
            >
              <motion.div
                className="h-full rounded-full bg-gradient-to-r from-sky-400 via-blue-500 to-violet-500 origin-left"
                initial={shouldReduceMotion ? { scaleX: levelScale } : { scaleX: 0 }}
                animate={{ scaleX: levelScale }}
                transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="p-3.5 rounded-2xl bg-gradient-to-br from-blue-500/15 to-violet-600/15 border border-blue-400/30 space-y-0.5">
              <div className="text-[11px] text-blue-200 truncate">{t.profileTotalEarnedLabel}</div>
              <div className="font-math text-xl font-extrabold text-white tabular-nums">
                {totalEarnedPoints}
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-white/[0.04] border border-white/10 space-y-0.5">
              <div className="text-[11px] text-slate-300 truncate">
                {t.profileAvailablePointsLabel}
              </div>
              <div className="font-math text-xl font-bold text-sky-200 tabular-nums">
                {spendablePoints}
              </div>
            </div>
          </div>
        </div>
      </LiquidGlassCard>

      {/* Profile Workspace Sub-Navigation */}
      <div
        className="liquid-glass-subtle p-1.5 rounded-2xl grid grid-cols-3 gap-1.5"
        role="tablist"
        aria-label={t.profileTitle}
      >
        {(
          [
            { id: 'overview', label: t.profileTabOverview, Icon: UserCheck },
            { id: 'progress', label: t.profileTabProgress, Icon: BarChart3 },
            { id: 'settings', label: t.profileTabSettings, Icon: Settings },
          ] as const
        ).map(({ id, label, Icon }) => {
          const active = activeTab === id;
          return (
            <button
              key={id}
              type="button"
              role="tab"
              aria-selected={active}
              onClick={() => setActiveTab(id)}
              className={`min-h-[44px] px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold inline-flex items-center justify-center gap-2 transition-all ${
                active
                  ? 'bg-gradient-to-r from-blue-500/85 to-violet-600/85 text-white shadow-[0_4px_16px_rgba(99,102,241,0.35)]'
                  : 'text-slate-300 hover:text-white hover:bg-white/[0.06]'
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span className="truncate">{label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: OVERVIEW & STUDENT STATISTICS */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Comprehensive 8+ Real Student Statistics Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
            <LiquidGlassCard variant="subtle" className="p-4 space-y-1.5">
              <div className="text-xs text-slate-300 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-sky-300 shrink-0" aria-hidden="true" />
                <span className="truncate">{t.profileStatCompletedStages}</span>
              </div>
              <div className="font-math text-2xl font-extrabold text-white tabular-nums">
                {analytics.completedStages}{' '}
                <span className="text-xs font-normal text-slate-400">/ {analytics.totalStages}</span>
              </div>
            </LiquidGlassCard>

            <LiquidGlassCard variant="subtle" className="p-4 space-y-1.5">
              <div className="text-xs text-slate-300 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-slate-400 shrink-0" aria-hidden="true" />
                <span className="truncate">{t.profileStatLockedStages}</span>
              </div>
              <div className="font-math text-2xl font-extrabold text-slate-200 tabular-nums">
                {analytics.lockedStages}
              </div>
            </LiquidGlassCard>

            <LiquidGlassCard variant="subtle" className="p-4 space-y-1.5">
              <div className="text-xs text-slate-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300 shrink-0" aria-hidden="true" />
                <span className="truncate">{t.profileStatCompletedSections}</span>
              </div>
              <div className="font-math text-2xl font-extrabold text-emerald-200 tabular-nums">
                {analytics.completedSections}{' '}
                <span className="text-xs font-normal text-slate-400">
                  / {analytics.totalSections}
                </span>
              </div>
            </LiquidGlassCard>

            <LiquidGlassCard variant="subtle" className="p-4 space-y-1.5">
              <div className="text-xs text-slate-300 flex items-center gap-1.5">
                <Percent className="w-3.5 h-3.5 text-violet-300 shrink-0" aria-hidden="true" />
                <span className="truncate">{t.profileStatPassRate}</span>
              </div>
              <div className="font-math text-2xl font-extrabold text-violet-200 tabular-nums">
                {analytics.overallPassRate}%
              </div>
            </LiquidGlassCard>

            <LiquidGlassCard variant="subtle" className="p-4 space-y-1.5">
              <div className="text-xs text-slate-300 flex items-center gap-1.5">
                <ClipboardCheck
                  className="w-3.5 h-3.5 text-emerald-300 shrink-0"
                  aria-hidden="true"
                />
                <span className="truncate">{t.profileStatExamsPassed}</span>
              </div>
              <div className="font-math text-2xl font-extrabold text-emerald-300 tabular-nums">
                {analytics.examsPassed}
              </div>
            </LiquidGlassCard>

            <LiquidGlassCard variant="subtle" className="p-4 space-y-1.5">
              <div className="text-xs text-slate-300 flex items-center gap-1.5">
                <XCircle className="w-3.5 h-3.5 text-rose-300 shrink-0" aria-hidden="true" />
                <span className="truncate">{t.profileStatExamsFailed}</span>
              </div>
              <div className="font-math text-2xl font-extrabold text-rose-200 tabular-nums">
                {analytics.examsFailed}
              </div>
            </LiquidGlassCard>

            <LiquidGlassCard variant="subtle" className="p-4 space-y-1.5">
              <div className="text-xs text-slate-300 flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5 text-amber-300 shrink-0" aria-hidden="true" />
                <span className="truncate">{t.profileStatDailyCompleted}</span>
              </div>
              <div className="font-math text-2xl font-extrabold text-amber-200 tabular-nums">
                {analytics.dailyCompleted}
              </div>
            </LiquidGlassCard>

            <LiquidGlassCard variant="subtle" className="p-4 space-y-1.5">
              <div className="text-xs text-slate-300 flex items-center gap-1.5">
                <Target className="w-3.5 h-3.5 text-sky-300 shrink-0" aria-hidden="true" />
                <span className="truncate">{t.profileStatCorrectWrong}</span>
              </div>
              <div className="font-math text-lg sm:text-xl font-extrabold tabular-nums flex items-center gap-1.5">
                <span className="text-emerald-300">{analytics.totalCorrect}</span>
                <span className="text-slate-500 text-sm">/</span>
                <span className="text-rose-300">{analytics.totalWrong}</span>
              </div>
            </LiquidGlassCard>
          </div>

          {/* Daily Challenge Streak & Milestone Badges (7-Day & 30-Day) */}
          <LiquidGlassCard variant="subtle" className="p-5 sm:p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="font-display text-lg font-bold text-white flex items-center gap-2">
                <Flame className="w-5 h-5 text-amber-400" aria-hidden="true" />
                <span>{t.dailyStreakTitle}</span>
              </h2>

              <button
                type="button"
                onClick={onOpenDailyChallenge}
                className="liquid-glass-button min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-semibold text-white inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
              >
                <Flame className="w-3.5 h-3.5 text-amber-300" aria-hidden="true" />
                <span>{t.dailyCardTitle}</span>
              </button>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="p-3.5 rounded-2xl bg-amber-500/12 border border-amber-400/25">
                <div className="text-[11px] text-amber-200">{t.dailyStreakLabel}</div>
                <div className="font-math text-xl font-extrabold text-white tabular-nums mt-0.5">
                  {t.dailyStreakDaysValue(activeStreak)}
                </div>
              </div>
              <div className="p-3.5 rounded-2xl bg-white/[0.04] border border-white/10">
                <div className="text-[11px] text-slate-300">{t.dailyLongestStreakLabel}</div>
                <div className="font-math text-xl font-extrabold text-white tabular-nums mt-0.5">
                  {t.dailyStreakDaysValue(longestStreak)}
                </div>
              </div>
              <div className="p-3.5 rounded-2xl bg-blue-500/12 border border-blue-400/25">
                <div className="text-[11px] text-blue-200">{t.profileStatBestExam}</div>
                <div className="font-math text-xl font-extrabold text-white tabular-nums mt-0.5">
                  {analytics.bestExamScore}/100
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              <div
                className={`p-4 rounded-2xl border flex items-start gap-3 ${
                  badge7
                    ? 'bg-gradient-to-br from-violet-500/20 to-blue-500/20 border-violet-300/45'
                    : 'bg-white/[0.03] border-white/10'
                }`}
              >
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border ${
                    badge7
                      ? 'bg-violet-500/30 border-violet-300/60 text-amber-300'
                      : 'bg-white/5 border-white/15 text-slate-500'
                  }`}
                >
                  {badge7 ? <Award className="w-5 h-5" /> : <Lock className="w-4 h-4" />}
                </div>
                <div className="space-y-1 flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-bold text-white truncate">
                      {t.dailyBadge7Title}
                    </span>
                    <span
                      className={`text-[11px] font-semibold shrink-0 ${
                        badge7 ? 'text-emerald-300' : 'text-slate-400'
                      }`}
                    >
                      {badge7
                        ? t.dailyBadgeUnlockedLabel
                        : t.dailyBadgeLockedProgress(longestStreak, 7)}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300">{t.dailyBadge7Desc}</p>
                </div>
              </div>

              <div
                className={`p-4 rounded-2xl border flex items-start gap-3 ${
                  badge30
                    ? 'bg-gradient-to-br from-amber-500/25 to-orange-500/20 border-amber-300/50'
                    : 'bg-white/[0.03] border-white/10'
                }`}
              >
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border ${
                    badge30
                      ? 'bg-amber-500/30 border-amber-300/60 text-amber-200'
                      : 'bg-white/5 border-white/15 text-slate-500'
                  }`}
                >
                  {badge30 ? <Trophy className="w-5 h-5" /> : <Lock className="w-4 h-4" />}
                </div>
                <div className="space-y-1 flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-bold text-white truncate">
                      {t.dailyBadge30Title}
                    </span>
                    <span
                      className={`text-[11px] font-semibold shrink-0 ${
                        badge30 ? 'text-emerald-300' : 'text-slate-400'
                      }`}
                    >
                      {badge30
                        ? t.dailyBadgeUnlockedLabel
                        : t.dailyBadgeLockedProgress(longestStreak, 30)}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300">{t.dailyBadge30Desc}</p>
                </div>
              </div>
            </div>
          </LiquidGlassCard>

          {/* Earned Honorary Medals & Achievements Strip */}
          <LiquidGlassCard variant="subtle" className="p-5 sm:p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="space-y-0.5">
                <h2 className="font-display text-lg font-bold text-white flex items-center gap-2">
                  <Medal className="w-5 h-5 text-amber-300 shrink-0" aria-hidden="true" />
                  <span>{t.achievementsTitle}</span>
                </h2>
                <p className="text-xs text-slate-300 font-math tabular-nums">
                  {t.achievementsEarnedCountLabel(
                    Object.keys(achievementsMap).length,
                    ALL_ACHIEVEMENT_AND_MEDAL_ITEMS.length,
                  )}
                </p>
              </div>

              <button
                type="button"
                onClick={() => onNavigate('achievements')}
                className="liquid-glass-button min-h-[38px] px-4 py-1.5 rounded-xl text-xs font-semibold text-white whitespace-nowrap shrink-0"
              >
                {t.medalCelebrationViewAllBtn}
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              {MEDALS_CATALOG.map((medal) => {
                const unlocked = Boolean(achievementsMap[medal.id]);
                return (
                  <div
                    key={medal.id}
                    title={language === 'ar' ? medal.titleAr : medal.titleEn}
                    className="flex items-center gap-2.5 px-3 py-2 rounded-2xl bg-white/[0.04] border border-white/10"
                  >
                    <MedalEmblem
                      iconKey={medal.iconKey}
                      accentFrom={medal.accentFrom}
                      accentTo={medal.accentTo}
                      unlocked={unlocked}
                      size="sm"
                    />
                    <span
                      className={`text-xs font-semibold ${
                        unlocked ? 'text-white' : 'text-slate-400'
                      }`}
                    >
                      {language === 'ar' ? medal.titleAr : medal.titleEn}
                    </span>
                  </div>
                );
              })}
            </div>
          </LiquidGlassCard>

          {/* Certificates Section */}
          <div className="space-y-3">
            <h2 className="font-display text-lg font-bold text-white flex items-center gap-2 px-1">
              <Award className="w-5 h-5 text-emerald-300" aria-hidden="true" />
              <span>{t.profileCertificatesTitle}</span>
            </h2>

            {masterCertificate && (
              <LiquidGlassCard className="p-5 border-amber-300/60 bg-gradient-to-r from-amber-500/20 via-slate-900/60 to-emerald-500/15 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3.5 min-w-0">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-300 to-orange-600 border border-white/45 flex items-center justify-center text-white shrink-0">
                    <Crown className="w-6 h-6" aria-hidden="true" />
                  </div>
                  <div className="space-y-0.5 min-w-0">
                    <h3 className="font-display text-base font-bold text-white truncate">
                      {t.masterCertTitle}
                    </h3>
                    <div className="text-xs text-amber-200 font-math tabular-nums">
                      {t.masterCertAvgScoreLabel}: {masterCertificate.averageExamScore}/100 ·{' '}
                      {masterCertificate.certificateId}
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={onViewMasterCertificate}
                  className="liquid-glass-button min-h-[40px] px-4 py-2 rounded-xl text-xs font-semibold text-white whitespace-nowrap shrink-0"
                >
                  {t.masterCertOpenBtn}
                </button>
              </LiquidGlassCard>
            )}

            {earnedCertificates.length === 0 ? (
              <LiquidGlassCard variant="subtle" className="p-6 text-sm text-slate-300">
                {t.profileNoCertificates}
              </LiquidGlassCard>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {earnedCertificates.map(({ section, progress }) => (
                  <LiquidGlassCard
                    key={section.id}
                    variant="subtle"
                    className="p-5 flex items-center justify-between gap-4 border-emerald-400/30"
                  >
                    <div className="space-y-1 min-w-0">
                      <h3 className="font-display text-base font-bold text-white truncate">
                        {language === 'ar' ? section.titleAr : section.titleEn}
                      </h3>
                      <div className="text-xs text-slate-300 font-math tabular-nums">
                        {t.certScoreLabel}: {progress.examBestScore}/100 · {progress.certificateId}
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => onViewCertificate(section.id)}
                      className="liquid-glass-button min-h-[40px] px-4 py-2 rounded-xl text-xs font-semibold text-white whitespace-nowrap shrink-0"
                    >
                      {t.profileViewCertBtn}
                    </button>
                  </LiquidGlassCard>
                ))}
              </div>
            )}
          </div>

          {/* Owned Badges, Avatars & Titles Wardrobe */}
          <div className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3 px-1">
              <h2 className="font-display text-lg font-bold text-white flex items-center gap-2">
                <Medal className="w-5 h-5 text-violet-300" aria-hidden="true" />
                <span>{t.profileCollectionTitle}</span>
              </h2>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  disabled={processingItemId === DEFAULT_AVATAR_ID}
                  onClick={() => void equipReward('avatar', DEFAULT_AVATAR_ID)}
                  className={`min-h-[36px] px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    userProfile?.equippedAvatarId === DEFAULT_AVATAR_ID
                      ? 'bg-blue-500/30 border border-blue-300/50 text-white'
                      : 'liquid-glass-subtle text-slate-300 hover:text-white'
                  }`}
                >
                  {t.profileDefaultAvatarBtn}
                </button>
                {userProfile?.photoUrl && (
                  <button
                    type="button"
                    disabled={processingItemId === 'avatar-google'}
                    onClick={() => void equipReward('avatar', 'avatar-google')}
                    className={`min-h-[36px] px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                      userProfile.equippedAvatarId === 'avatar-google'
                        ? 'bg-blue-500/30 border border-blue-300/50 text-white'
                        : 'liquid-glass-subtle text-slate-300 hover:text-white'
                    }`}
                  >
                    {t.profileGoogleAvatarBtn}
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => onNavigate('shop')}
                  className="liquid-glass-button min-h-[36px] px-3.5 py-1.5 rounded-xl text-xs font-semibold text-white inline-flex items-center gap-1.5"
                >
                  <ShoppingBag className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>{t.profileGoToShopBtn}</span>
                </button>
              </div>
            </div>

            {ownedItems.length === 0 ? (
              <LiquidGlassCard variant="subtle" className="p-6 text-sm text-slate-300">
                {t.profileNoRewardsOwned}
              </LiquidGlassCard>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {ownedItems.map((item) => {
                  const equipped = isEquipped(item);
                  const busy = processingItemId === item.id;
                  return (
                    <LiquidGlassCard
                      key={item.id}
                      variant="subtle"
                      className={`p-4 flex items-center justify-between gap-3 ${
                        equipped ? 'ring-1 ring-blue-300/60 bg-blue-500/10' : ''
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        {item.category === 'avatar' ? (
                          <AvatarDisplay avatarId={item.id} size="md" />
                        ) : (
                          <div
                            className={`w-11 h-11 rounded-2xl bg-gradient-to-br ${item.accentFrom} ${item.accentTo} border border-white/25 flex items-center justify-center text-lg font-bold text-white shrink-0`}
                          >
                            {item.symbol}
                          </div>
                        )}
                        <div className="min-w-0">
                          <div className="text-sm font-bold text-white truncate">
                            {language === 'ar' ? item.nameAr : item.nameEn}
                          </div>
                          <div className="text-[11px] text-slate-400">
                            {equipped ? t.shopEquippedBadge : t.shopOwnedBadge}
                          </div>
                        </div>
                      </div>

                      <button
                        type="button"
                        disabled={busy}
                        onClick={() =>
                          void equipReward(
                            item.category,
                            equipped
                              ? item.category === 'avatar'
                                ? DEFAULT_AVATAR_ID
                                : ''
                              : item.id,
                          )
                        }
                        className={`min-h-[36px] px-3 py-1.5 rounded-xl text-xs font-semibold shrink-0 transition-all ${
                          equipped
                            ? 'bg-white/10 text-slate-200 hover:bg-white/15'
                            : 'liquid-glass-button text-white'
                        }`}
                      >
                        {equipped ? t.shopUnequipBtn : t.shopEquipBtn}
                      </button>
                    </LiquidGlassCard>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: PROGRESS TRACKING, CHARTS & ACTIVITY */}
      {activeTab === 'progress' && (
        <div className="space-y-6">
          <ProgressCharts
            analytics={analytics}
            sectionItems={sectionBreakdown}
            pointsSeries={pointsSeries}
            onOpenSection={onOpenSection}
          />

          {/* Independent Per-Section Progress Cards */}
          <div className="space-y-3">
            <h2 className="font-display text-lg font-bold text-white flex items-center gap-2 px-1">
              <Layers className="w-5 h-5 text-sky-300" aria-hidden="true" />
              <span>{t.profileSectionProgressTitle}</span>
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {sectionBreakdown.map((item) => (
                <LiquidGlassCard
                  key={item.section.id}
                  variant="subtle"
                  className="p-4 sm:p-5 flex items-center justify-between gap-4"
                >
                  <div className="space-y-1.5 min-w-0">
                    <div className="flex items-center gap-2">
                      <span
                        className={`w-3 h-3 rounded-full bg-gradient-to-br ${item.section.accentFrom} ${item.section.accentTo} shrink-0`}
                        aria-hidden="true"
                      />
                      <h3 className="font-display text-sm sm:text-base font-bold text-white truncate">
                        {language === 'ar' ? item.section.titleAr : item.section.titleEn}
                      </h3>
                    </div>
                    <div className="text-xs text-slate-300 font-math tabular-nums">
                      {t.profileSectionStageProgress(item.completedStages, item.unlockedStage)}
                    </div>
                    <div className="text-[11px] text-slate-400 font-math tabular-nums flex flex-wrap items-center gap-2">
                      <span>{t.sectionStarsLabel(item.totalStars, 90)}</span>
                      <span aria-hidden="true">·</span>
                      <span className={item.examPassed ? 'text-emerald-300' : 'text-slate-300'}>
                        {t.profileSectionExamBest(item.examBestScore)}
                      </span>
                    </div>
                  </div>

                  {onOpenSection && (
                    <button
                      type="button"
                      onClick={() => onOpenSection(item.section.id)}
                      className="liquid-glass-subtle min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-semibold text-white hover:bg-white/10 shrink-0 whitespace-nowrap"
                    >
                      {t.profileSectionOpenBtn}
                    </button>
                  )}
                </LiquidGlassCard>
              ))}
            </div>
          </div>

          {/* Recent Activities & Achievements Feed */}
          <div className="space-y-3">
            <h2 className="font-display text-lg font-bold text-white flex items-center gap-2 px-1">
              <Activity className="w-5 h-5 text-violet-300" aria-hidden="true" />
              <span>{t.profileRecentActivitiesTitle}</span>
            </h2>

            {recentActivity.length === 0 ? (
              <LiquidGlassCard variant="subtle" className="p-6 text-sm text-slate-300">
                {t.profileNoRecentActivities}
              </LiquidGlassCard>
            ) : (
              <LiquidGlassCard variant="subtle" className="divide-y divide-white/10 overflow-hidden">
                {recentActivity.map((item) => {
                  const toneClass =
                    item.tone === 'emerald'
                      ? 'text-emerald-300'
                      : item.tone === 'amber'
                        ? 'text-amber-300'
                        : item.tone === 'rose'
                          ? 'text-rose-300'
                          : item.tone === 'violet'
                            ? 'text-violet-300'
                            : 'text-sky-300';
                  return (
                    <div key={item.id} className="p-4 flex items-center justify-between gap-4">
                      <div className="space-y-0.5 min-w-0">
                        <div className="text-sm font-semibold text-white truncate">
                          {language === 'ar' ? item.titleAr : item.titleEn}
                        </div>
                        <div className="text-xs text-slate-400 truncate">
                          {language === 'ar' ? item.subtitleAr : item.subtitleEn}
                        </div>
                      </div>
                      {item.badgeText && (
                        <div
                          dir="ltr"
                          className={`font-math text-sm font-extrabold tabular-nums shrink-0 ${toneClass}`}
                        >
                          {item.badgeText}
                        </div>
                      )}
                    </div>
                  );
                })}
              </LiquidGlassCard>
            )}
          </div>

          {/* Verified Point Operations Ledger */}
          <div className="space-y-3">
            <h2 className="font-display text-lg font-bold text-white flex items-center gap-2 px-1">
              <History className="w-5 h-5 text-blue-300" aria-hidden="true" />
              <span>{t.profileActivityTitle}</span>
            </h2>

            {transactions.length === 0 ? (
              <LiquidGlassCard variant="subtle" className="p-6 text-sm text-slate-300">
                {t.profileNoActivity}
              </LiquidGlassCard>
            ) : (
              <LiquidGlassCard variant="subtle" className="divide-y divide-white/10 overflow-hidden">
                {transactions.slice(0, 25).map((tx) => {
                  const isGain = tx.amount > 0;
                  return (
                    <div key={tx.txId} className="p-4 flex items-center justify-between gap-4">
                      <div className="space-y-0.5 min-w-0">
                        <div className="text-sm font-semibold text-white truncate">
                          {formatTxTitle(tx)}
                        </div>
                        <div className="text-xs text-slate-400 font-math tabular-nums">
                          {t.profileAvailablePointsLabel}: {tx.balanceAfter}
                        </div>
                      </div>
                      <div
                        dir="ltr"
                        className={`font-math text-sm font-extrabold tabular-nums shrink-0 ${
                          isGain ? 'text-emerald-300' : 'text-amber-300'
                        }`}
                      >
                        {isGain ? `+${tx.amount}` : tx.amount}
                      </div>
                    </div>
                  );
                })}
              </LiquidGlassCard>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: ACCOUNT SETTINGS */}
      {activeTab === 'settings' && (
        <AccountSettingsPanel
          onNavigate={onNavigate}
          onOpenCountrySelection={onOpenCountrySelection}
        />
      )}
    </motion.section>
  );
}
