import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  Award,
  CheckCircle2,
  ClipboardCheck,
  Clock,
  RotateCcw,
  Save,
  Sparkles,
  XCircle,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { LanguageSwitcher } from '@/src/components/ui/LanguageSwitcher';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { MathMasterLogo } from '@/src/components/ui/MathMasterLogo';
import { useAuth } from '@/src/contexts/AuthContext';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useProgress } from '@/src/contexts/ProgressContext';
import {
  EXAM_DURATION_SECONDS,
  buildSectionFinalExam,
  getSectionById,
} from '@/src/data/curriculum';
import { WinCelebration } from '@/src/features/learning/WinCelebration';
import { storageService } from '@/src/services/storageService';
import type { SectionId } from '@/src/types/curriculum';
import type { ExamSubmissionResult } from '@/src/types/progress';

interface SectionExamScreenProps {
  sectionId: SectionId;
  backOrigin?: 'section' | 'exams';
  onBack: () => void;
  onViewCertificate: () => void;
}

type ReviewFilter = 'all' | 'wrong';

function formatTimerMMSS(totalSeconds: number): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const mins = Math.floor(safe / 60);
  const secs = safe % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export function SectionExamScreen({
  sectionId,
  backOrigin = 'section',
  onBack,
  onViewCertificate,
}: SectionExamScreenProps) {
  const { language, direction, t } = useLanguage();
  const { firebaseUser } = useAuth();
  const { submitExam, submittingAttempt } = useProgress();

  const uid = firebaseUser?.uid ?? '';
  const section = getSectionById(sectionId);
  const questions = useMemo(() => buildSectionFinalExam(sectionId), [sectionId]);

  const [currentIdx, setCurrentIdx] = useState(0);
  const [answers, setAnswers] = useState<number[]>(() => Array(30).fill(-1));
  const [startedAtMs, setStartedAtMs] = useState<number>(() => Date.now());
  const [expiresAtMs, setExpiresAtMs] = useState<number>(
    () => Date.now() + EXAM_DURATION_SECONDS * 1000,
  );
  const [remainingSeconds, setRemainingSeconds] = useState<number>(EXAM_DURATION_SECONDS);
  const [validationMsg, setValidationMsg] = useState<string | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [result, setResult] = useState<ExamSubmissionResult | null>(null);
  const [reviewFilter, setReviewFilter] = useState<ReviewFilter>('all');

  const autoSubmitTriggeredRef = useRef(false);
  const draftReadyRef = useRef(false);

  const performSubmission = useCallback(
    async (answersSnapshot: number[], durationSec: number, timedOut: boolean) => {
      setSubmitError(null);
      try {
        const res = await submitExam(sectionId, answersSnapshot, {
          durationSeconds: durationSec,
          timedOut,
        });
        if (uid) {
          storageService.clearExamDraft(uid, sectionId);
        }
        setResult(res);
        setReviewFilter(res.wrongCount > 0 ? 'wrong' : 'all');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } catch {
        autoSubmitTriggeredRef.current = false;
        setSubmitError(t.errorGeneric);
      }
    },
    [sectionId, submitExam, t.errorGeneric, uid],
  );

  // Restore saved draft or start fresh 30-minute session on mount / section change
  useEffect(() => {
    autoSubmitTriggeredRef.current = false;
    draftReadyRef.current = false;
    setValidationMsg(null);
    setSubmitError(null);
    setResult(null);
    setReviewFilter('all');

    const now = Date.now();
    const existingDraft = uid ? storageService.getExamDraft(uid, sectionId) : null;

    if (existingDraft) {
      const rem = Math.max(0, Math.ceil((existingDraft.expiresAtMs - now) / 1000));
      setCurrentIdx(existingDraft.currentIdx);
      setAnswers(existingDraft.answers);
      setStartedAtMs(existingDraft.startedAtMs);
      setExpiresAtMs(existingDraft.expiresAtMs);
      setRemainingSeconds(rem);
      draftReadyRef.current = true;

      if (rem <= 0 && !autoSubmitTriggeredRef.current) {
        autoSubmitTriggeredRef.current = true;
        void performSubmission(existingDraft.answers, EXAM_DURATION_SECONDS, true);
      }
    } else {
      const freshAnswers = Array(questions.length).fill(-1);
      const freshStart = now;
      const freshExpiry = freshStart + EXAM_DURATION_SECONDS * 1000;
      setCurrentIdx(0);
      setAnswers(freshAnswers);
      setStartedAtMs(freshStart);
      setExpiresAtMs(freshExpiry);
      setRemainingSeconds(EXAM_DURATION_SECONDS);
      if (uid) {
        storageService.saveExamDraft({
          uid,
          sectionId,
          startedAtMs: freshStart,
          expiresAtMs: freshExpiry,
          currentIdx: 0,
          answers: freshAnswers,
        });
      }
      draftReadyRef.current = true;
    }
  }, [uid, sectionId, questions.length, performSubmission]);

  // Persist exam draft continuously on every answer or question jump
  useEffect(() => {
    if (!uid || !draftReadyRef.current || result) return;
    storageService.saveExamDraft({
      uid,
      sectionId,
      startedAtMs,
      expiresAtMs,
      currentIdx,
      answers,
    });
  }, [uid, sectionId, startedAtMs, expiresAtMs, currentIdx, answers, result]);

  // Drift-proof 1-second timer tick using expiresAtMs
  useEffect(() => {
    if (result || !draftReadyRef.current) return;

    const tick = () => {
      const rem = Math.max(0, Math.ceil((expiresAtMs - Date.now()) / 1000));
      setRemainingSeconds(rem);
      if (rem <= 0 && !autoSubmitTriggeredRef.current) {
        autoSubmitTriggeredRef.current = true;
        void performSubmission(answers, EXAM_DURATION_SECONDS, true);
      }
    };

    const intervalId = window.setInterval(tick, 1000);
    return () => window.clearInterval(intervalId);
  }, [expiresAtMs, result, answers, performSubmission]);

  const answeredCount = useMemo(() => answers.filter((a) => a !== -1).length, [answers]);
  const unansweredCount = questions.length - answeredCount;

  const filteredReview = useMemo(() => {
    if (!result) return [];
    const indexed = result.review.map((item, idx) => ({ item, idx }));
    if (reviewFilter === 'wrong') {
      return indexed.filter(({ item }) => !item.isCorrect);
    }
    return indexed;
  }, [result, reviewFilter]);

  if (!section) return null;

  const BackArrow = direction === 'rtl' ? ArrowRight : ArrowLeft;
  const ForwardArrow = direction === 'rtl' ? ArrowLeft : ArrowRight;
  const backLabel = backOrigin === 'exams' ? t.backToExamsHubBtn : t.backToSectionBtn;

  const handleRestartExam = () => {
    const freshAnswers = Array(questions.length).fill(-1);
    const freshStart = Date.now();
    const freshExpiry = freshStart + EXAM_DURATION_SECONDS * 1000;
    autoSubmitTriggeredRef.current = false;
    setAnswers(freshAnswers);
    setCurrentIdx(0);
    setStartedAtMs(freshStart);
    setExpiresAtMs(freshExpiry);
    setRemainingSeconds(EXAM_DURATION_SECONDS);
    setValidationMsg(null);
    setSubmitError(null);
    setResult(null);
    setReviewFilter('all');

    if (uid) {
      storageService.saveExamDraft({
        uid,
        sectionId,
        startedAtMs: freshStart,
        expiresAtMs: freshExpiry,
        currentIdx: 0,
        answers: freshAnswers,
      });
    }
  };

  const handleSelectOption = (optionIndex: number) => {
    setValidationMsg(null);
    setAnswers((prev) => {
      const next = [...prev];
      next[currentIdx] = optionIndex;
      return next;
    });
  };

  const handleJumpNextUnanswered = () => {
    const afterCurrent = answers.findIndex((a, i) => i > currentIdx && a === -1);
    const target = afterCurrent !== -1 ? afterCurrent : answers.findIndex((a) => a === -1);
    if (target !== -1) {
      setValidationMsg(null);
      setCurrentIdx(target);
    }
  };

  const handleSubmitExam = async () => {
    if (remainingSeconds > 0) {
      const firstUnanswered = answers.findIndex((a) => a === -1);
      if (firstUnanswered !== -1) {
        setCurrentIdx(firstUnanswered);
        setValidationMsg(t.answerAllPrompt);
        return;
      }
    }

    const elapsedSec = Math.min(
      EXAM_DURATION_SECONDS,
      Math.max(1, Math.round((Date.now() - startedAtMs) / 1000)),
    );
    await performSubmission(answers, elapsedSec, remainingSeconds <= 0);
  };

  const currentQ = questions[currentIdx];
  const isCriticalTime = remainingSeconds <= 60;
  const isLowTime = remainingSeconds <= 300;

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="min-h-screen flex flex-col px-4 py-5 sm:px-8 sm:py-7 max-w-4xl mx-auto w-full gap-6 pb-12"
    >
      {/* Top Bar */}
      <header className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={onBack}
          className="liquid-glass-subtle min-h-[44px] px-4 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white hover:bg-white/10 inline-flex items-center gap-2 whitespace-nowrap shrink-0 transition-colors"
        >
          <BackArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{backLabel}</span>
        </button>

        <div className="hidden sm:flex items-center gap-2.5 shrink-0">
          <MathMasterLogo size="sm" />
          <span className="font-display text-sm font-bold text-white">
            {t.examCardTitle}
          </span>
        </div>

        <LanguageSwitcher />
      </header>

      {/* Exam Banner + Live 30-Minute Countdown Timer */}
      <LiquidGlassCard className="p-5 sm:p-7 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div
            className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${section.accentFrom} ${section.accentTo} border border-white/20 flex items-center justify-center text-white shrink-0`}
          >
            <ClipboardCheck className="w-6 h-6" aria-hidden="true" />
          </div>
          <div className="space-y-1">
            <div className="text-xs font-semibold text-blue-200">
              {language === 'ar' ? section.titleAr : section.titleEn}
            </div>
            <h1 className="font-display text-xl sm:text-2xl font-bold text-white">
              {t.examCardTitle}
            </h1>
            {!result && (
              <div className="text-[11px] font-medium text-emerald-300/90 inline-flex items-center gap-1.5">
                <Save className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                <span>{t.examAutoSavedNotice}</span>
              </div>
            )}
          </div>
        </div>

        {!result ? (
          <div
            aria-live="polite"
            className={`px-4 py-2.5 rounded-2xl border flex items-center gap-3 self-start sm:self-center shrink-0 transition-colors ${
              isCriticalTime
                ? 'bg-rose-500/20 border-rose-400/50 text-rose-100 animate-pulse'
                : isLowTime
                  ? 'bg-amber-500/20 border-amber-400/45 text-amber-100'
                  : 'bg-white/[0.06] border-white/15 text-white'
            }`}
          >
            <Clock
              className={`w-5 h-5 shrink-0 ${
                isCriticalTime ? 'text-rose-300' : isLowTime ? 'text-amber-300' : 'text-blue-300'
              }`}
              aria-hidden="true"
            />
            <div>
              <div className="text-[11px] opacity-80 leading-none mb-1">{t.examTimerLabel}</div>
              <div dir="ltr" className="font-math text-xl font-extrabold tabular-nums leading-none">
                {formatTimerMMSS(remainingSeconds)}
              </div>
            </div>
          </div>
        ) : (
          <div className="text-xs font-medium text-slate-300">{t.resultPassingRule}</div>
        )}
      </LiquidGlassCard>

      {!result && currentQ && (
        <div className="space-y-5">
          {/* 30-Question Compact Navigator with Answered vs Unanswered Highlight */}
          <LiquidGlassCard variant="subtle" className="p-4 sm:p-5 space-y-3.5">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-medium">
              <span className="font-math tabular-nums text-slate-200">
                {t.questionCounterLabel(currentIdx + 1, questions.length)}
              </span>

              <div className="flex flex-wrap items-center gap-2">
                <span
                  className={`font-math tabular-nums px-2.5 py-1 rounded-lg border ${
                    unansweredCount > 0
                      ? 'bg-amber-500/15 border-amber-400/35 text-amber-200'
                      : 'bg-emerald-500/15 border-emerald-400/35 text-emerald-200'
                  }`}
                >
                  {t.examUnansweredCountLabel(unansweredCount)}
                </span>

                {unansweredCount > 0 && (
                  <button
                    type="button"
                    onClick={handleJumpNextUnanswered}
                    className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/15 border border-white/15 text-blue-200 font-semibold transition-colors"
                  >
                    {t.examJumpUnansweredBtn}
                  </button>
                )}
              </div>
            </div>

            <div className="grid grid-cols-6 sm:grid-cols-10 md:grid-cols-15 gap-1.5">
              {questions.map((q, idx) => {
                const active = idx === currentIdx;
                const answered = answers[idx] !== -1;
                return (
                  <button
                    key={q.id}
                    type="button"
                    onClick={() => {
                      setValidationMsg(null);
                      setCurrentIdx(idx);
                    }}
                    aria-label={`${idx + 1} (${answered ? t.answeredCountLabel(1, 1) : t.examNotAnsweredLabel})`}
                    className={`min-h-[36px] rounded-xl text-xs font-bold font-math tabular-nums border transition-all ${
                      active
                        ? 'bg-gradient-to-br from-blue-500 to-violet-600 border-white/50 text-white shadow-[0_0_12px_rgba(99,102,241,0.45)]'
                        : answered
                          ? 'bg-emerald-500/20 border-emerald-400/40 text-emerald-200 hover:bg-emerald-500/30'
                          : 'bg-amber-500/[0.08] border-amber-400/30 text-amber-100 hover:bg-amber-500/20'
                    }`}
                  >
                    {idx + 1}
                  </button>
                );
              })}
            </div>
          </LiquidGlassCard>

          {/* Active Exam Question */}
          <LiquidGlassCard className="p-6 sm:p-8 space-y-6">
            <div className="flex items-center justify-between gap-2 text-xs font-medium text-blue-200 font-math">
              <span>{t.examQuestionSourceStage(currentIdx + 1)}</span>
              <span className="tabular-nums text-slate-300">
                {t.answeredCountLabel(answeredCount, questions.length)}
              </span>
            </div>

            <h2 className="font-display text-lg sm:text-xl font-bold text-white leading-relaxed">
              {language === 'ar' ? currentQ.promptAr : currentQ.promptEn}
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {currentQ.options.map((opt, optIdx) => {
                const selected = answers[currentIdx] === optIdx;
                const letters = ['A', 'B', 'C', 'D'];
                return (
                  <button
                    key={`${currentQ.id}-opt-${optIdx}`}
                    type="button"
                    onClick={() => handleSelectOption(optIdx)}
                    className={`min-h-[56px] p-4 rounded-2xl border text-start flex items-center gap-3 transition-all ${
                      selected
                        ? 'bg-gradient-to-r from-blue-500/30 to-violet-600/30 border-blue-300/70 text-white shadow-[0_0_24px_rgba(99,102,241,0.3)]'
                        : 'bg-white/[0.045] hover:bg-white/[0.09] border-white/12 text-slate-100'
                    }`}
                  >
                    <span
                      className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold font-math shrink-0 border ${
                        selected
                          ? 'bg-blue-400 text-slate-950 border-white/40'
                          : 'bg-white/10 text-slate-300 border-white/15'
                      }`}
                    >
                      {letters[optIdx]}
                    </span>
                    <span dir="auto" className="text-sm sm:text-base font-semibold font-math break-words">
                      {opt}
                    </span>
                  </button>
                );
              })}
            </div>

            {validationMsg && (
              <div
                role="alert"
                className="p-3.5 rounded-2xl bg-amber-500/15 border border-amber-400/35 text-xs sm:text-sm text-amber-100 flex items-center gap-2"
              >
                <AlertTriangle className="w-4 h-4 text-amber-300 shrink-0" aria-hidden="true" />
                <span>{validationMsg}</span>
              </div>
            )}

            {submitError && (
              <div
                role="alert"
                className="p-3.5 rounded-2xl bg-rose-500/15 border border-rose-400/35 text-xs sm:text-sm text-rose-100 flex items-center justify-between gap-3"
              >
                <span>{submitError}</span>
                <button
                  type="button"
                  onClick={() => void handleSubmitExam()}
                  className="px-3 py-1.5 rounded-xl bg-rose-500/30 hover:bg-rose-500/40 text-xs font-semibold text-white shrink-0"
                >
                  {t.retryStageBtn}
                </button>
              </div>
            )}

            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-white/10">
              <button
                type="button"
                disabled={currentIdx === 0}
                onClick={() => setCurrentIdx((i) => Math.max(0, i - 1))}
                className="liquid-glass-subtle min-h-[44px] px-4 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white disabled:opacity-40 disabled:cursor-not-allowed inline-flex items-center gap-2 whitespace-nowrap shrink-0"
              >
                <BackArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{t.prevQuestionBtn}</span>
              </button>

              {currentIdx < questions.length - 1 ? (
                <button
                  type="button"
                  onClick={() => setCurrentIdx((i) => Math.min(questions.length - 1, i + 1))}
                  className="liquid-glass-button min-h-[44px] px-5 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center gap-2 whitespace-nowrap shrink-0"
                >
                  <span>{t.nextQuestionBtn}</span>
                  <ForwardArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
                </button>
              ) : (
                <button
                  type="button"
                  disabled={submittingAttempt}
                  onClick={() => void handleSubmitExam()}
                  className="liquid-glass-button min-h-[46px] px-6 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white disabled:opacity-60 inline-flex items-center gap-2 whitespace-nowrap shrink-0"
                >
                  <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>{submittingAttempt ? t.submittingQuizBtn : t.submitQuizBtn}</span>
                </button>
              )}
            </div>
          </LiquidGlassCard>
        </div>
      )}

      {/* EXAM RESULT + BREAKDOWN + CERTIFICATE CTA + FILTERABLE QUESTION REVIEW */}
      {result && (
        <div className="space-y-6">
          {result.timedOut && (
            <LiquidGlassCard
              variant="subtle"
              className="p-4 border-amber-400/40 bg-amber-500/10 flex items-center gap-3 text-xs sm:text-sm text-amber-100"
            >
              <Clock className="w-5 h-5 text-amber-300 shrink-0" aria-hidden="true" />
              <span>{t.examTimeoutAutoSubmittedMsg}</span>
            </LiquidGlassCard>
          )}

          <LiquidGlassCard
            className={`p-6 sm:p-9 text-center space-y-6 ${
              result.passed
                ? 'ring-1 ring-emerald-400/45 shadow-[0_0_40px_rgba(16,185,129,0.22)]'
                : 'ring-1 ring-rose-400/35'
            }`}
          >
            <WinCelebration stars={result.passed ? 3 : 0} passed={result.passed} />

            <div className="space-y-2">
              <div
                className={`inline-flex items-center gap-2 text-sm font-bold ${
                  result.passed ? 'text-emerald-300' : 'text-rose-300'
                }`}
              >
                {result.passed ? (
                  <CheckCircle2 className="w-5 h-5 shrink-0" aria-hidden="true" />
                ) : (
                  <XCircle className="w-5 h-5 shrink-0" aria-hidden="true" />
                )}
                <span>{result.passed ? t.examPassedTitle : t.examFailedTitle}</span>
              </div>

              <div className="font-math text-4xl sm:text-5xl font-extrabold text-white tabular-nums">
                {result.score} <span className="text-xl text-slate-400">/ 100</span>
              </div>

              <p className="text-xs sm:text-sm text-slate-300">
                {result.passed ? t.examPassedSubtitle : t.examFailedSubtitle}
              </p>
            </div>

            {/* Correct / Wrong / Duration Summary Tiles */}
            <div className="grid grid-cols-3 gap-3 max-w-lg mx-auto">
              <div className="p-3 rounded-2xl bg-emerald-500/12 border border-emerald-400/30">
                <div className="text-[11px] text-emerald-200">{t.examCorrectCountLabel}</div>
                <div className="font-math text-xl font-extrabold text-white tabular-nums mt-0.5">
                  {result.correctCount}
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-rose-500/12 border border-rose-400/30">
                <div className="text-[11px] text-rose-200">{t.examWrongCountLabel}</div>
                <div className="font-math text-xl font-extrabold text-white tabular-nums mt-0.5">
                  {result.wrongCount}
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-white/[0.05] border border-white/15">
                <div className="text-[11px] text-slate-300">{t.examTimeSpentLabel}</div>
                <div dir="ltr" className="font-math text-xl font-extrabold text-blue-200 tabular-nums mt-0.5">
                  {formatTimerMMSS(result.durationSeconds)}
                </div>
              </div>
            </div>

            {/* Itemized Point Rewards (+200 Exam Pass, +50 Perfect 100/100) */}
            <div className="flex flex-wrap items-center justify-center gap-2.5">
              {result.examPassPoints > 0 && (
                <div className="px-4 py-2 rounded-2xl bg-emerald-500/20 border border-emerald-400/35 text-xs font-semibold text-emerald-200 inline-flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-emerald-300" aria-hidden="true" />
                  <span>{t.rewardExamPassBadge(result.examPassPoints)}</span>
                </div>
              )}

              {result.perfectScoreBonusPoints > 0 && (
                <div className="px-4 py-2 rounded-2xl bg-amber-500/20 border border-amber-400/40 text-xs font-semibold text-amber-100 inline-flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-300" aria-hidden="true" />
                  <span>{t.rewardExamPerfectBadge(result.perfectScoreBonusPoints)}</span>
                </div>
              )}

              {result.passed && result.rewardAlreadyClaimed && (
                <div className="px-4 py-2 rounded-2xl bg-white/[0.06] border border-white/15 text-xs font-medium text-slate-200">
                  {t.resultAlreadyClaimedBadge}
                </div>
              )}
            </div>

            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              {result.passed && result.certificateId && (
                <button
                  type="button"
                  onClick={onViewCertificate}
                  className="liquid-glass-button min-h-[48px] px-6 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center gap-2 whitespace-nowrap shrink-0"
                >
                  <Award className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>{t.examViewCertificateBtn}</span>
                </button>
              )}

              <button
                type="button"
                onClick={handleRestartExam}
                className="liquid-glass-subtle min-h-[46px] px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white hover:bg-white/10 inline-flex items-center gap-2 whitespace-nowrap shrink-0"
              >
                <RotateCcw className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{t.examRetakeBtn}</span>
              </button>
            </div>
          </LiquidGlassCard>

          {/* Answer Review Filter Header */}
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-1">
              <h2 className="font-display text-lg font-bold text-white">
                {t.resultReviewHeading}
              </h2>

              <div
                role="tablist"
                aria-label="Exam review filter"
                className="inline-flex items-center gap-1.5 p-1 rounded-2xl liquid-glass-subtle self-start sm:self-auto"
              >
                <button
                  type="button"
                  role="tab"
                  aria-selected={reviewFilter === 'wrong'}
                  onClick={() => setReviewFilter('wrong')}
                  className={`min-h-[36px] px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                    reviewFilter === 'wrong'
                      ? 'bg-rose-500/75 text-white shadow-sm'
                      : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {t.examReviewFilterWrong(result.wrongCount)}
                </button>
                <button
                  type="button"
                  role="tab"
                  aria-selected={reviewFilter === 'all'}
                  onClick={() => setReviewFilter('all')}
                  className={`min-h-[36px] px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                    reviewFilter === 'all'
                      ? 'bg-gradient-to-r from-blue-500/80 to-violet-600/80 text-white shadow-sm'
                      : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {t.examReviewFilterAll(result.totalQuestions)}
                </button>
              </div>
            </div>

            {filteredReview.length === 0 ? (
              <LiquidGlassCard variant="subtle" className="p-6 text-center space-y-2 border-emerald-400/35">
                <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" aria-hidden="true" />
                <div className="font-display text-base font-bold text-white">
                  {t.examReviewNoWrongTitle}
                </div>
                <p className="text-xs sm:text-sm text-slate-300">
                  {t.examReviewNoWrongSubtitle}
                </p>
              </LiquidGlassCard>
            ) : (
              filteredReview.map(({ item, idx }) => (
                <LiquidGlassCard
                  key={item.questionId}
                  variant="subtle"
                  className={`p-5 space-y-3 ${
                    item.isCorrect ? 'border-emerald-400/30' : 'border-rose-400/30'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    <span className="mt-0.5 shrink-0">
                      {item.isCorrect ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-400" aria-hidden="true" />
                      ) : (
                        <XCircle className="w-5 h-5 text-rose-400" aria-hidden="true" />
                      )}
                    </span>
                    <div className="space-y-1">
                      <div className="text-[11px] font-medium text-slate-400 font-math">
                        {t.examQuestionSourceStage(idx + 1)}
                      </div>
                      <p className="text-sm sm:text-base font-semibold text-white leading-relaxed">
                        <span className="font-math text-slate-400 me-1.5">{idx + 1}.</span>
                        {language === 'ar' ? item.promptAr : item.promptEn}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs sm:text-sm">
                    <div
                      className={`p-3 rounded-xl border ${
                        item.isCorrect
                          ? 'bg-emerald-500/15 border-emerald-400/30 text-emerald-100'
                          : 'bg-rose-500/15 border-rose-400/30 text-rose-100'
                      }`}
                    >
                      <span className="block text-[11px] opacity-80 mb-0.5">
                        {t.resultYourAnswerLabel}
                      </span>
                      <span dir="auto" className="font-math font-bold">
                        {item.selectedIndex >= 0
                          ? item.options[item.selectedIndex]
                          : t.examNotAnsweredLabel}
                      </span>
                    </div>

                    <div className="p-3 rounded-xl bg-emerald-500/12 border border-emerald-400/25 text-emerald-100">
                      <span className="block text-[11px] opacity-80 mb-0.5">
                        {t.resultCorrectAnswerLabel}
                      </span>
                      <span dir="auto" className="font-math font-bold">
                        {item.options[item.correctIndex]}
                      </span>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-white/[0.035] border border-white/10 text-xs sm:text-sm text-slate-200 leading-relaxed">
                    <span className="font-semibold text-blue-200 me-1.5">
                      {t.resultExplanationLabel}:
                    </span>
                    {language === 'ar' ? item.explanationAr : item.explanationEn}
                  </div>
                </LiquidGlassCard>
              ))
            )}
          </div>
        </div>
      )}
    </motion.section>
  );
}
