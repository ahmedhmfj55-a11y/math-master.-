import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Crown,
  Printer,
  ShieldCheck,
} from 'lucide-react';
import { motion } from 'motion/react';
import { LanguageSwitcher } from '@/src/components/ui/LanguageSwitcher';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { MathMasterLogo } from '@/src/components/ui/MathMasterLogo';
import { useAuth } from '@/src/contexts/AuthContext';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useProgress } from '@/src/contexts/ProgressContext';
import { CURRICULUM_SECTIONS } from '@/src/data/curriculum';

interface MasterCertificateScreenProps {
  onBack: () => void;
}

export function MasterCertificateScreen({ onBack }: MasterCertificateScreenProps) {
  const { language, direction, t } = useLanguage();
  const { firebaseUser, userProfile, selectedCountry } = useAuth();
  const { masterCertificate, sectionProgressMap } = useProgress();

  if (!masterCertificate) {
    return null;
  }

  const BackArrow = direction === 'rtl' ? ArrowRight : ArrowLeft;

  const learnerName =
    userProfile?.displayName ||
    firebaseUser?.displayName ||
    firebaseUser?.phoneNumber ||
    firebaseUser?.email ||
    'Math Master';

  const countryName = selectedCountry
    ? language === 'ar'
      ? selectedCountry.nameAr
      : selectedCountry.nameEn
    : userProfile
      ? language === 'ar'
        ? userProfile.countryNameAr
        : userProfile.countryNameEn
      : '';

  const formattedDate = masterCertificate.issuedAt?.toDate
    ? masterCertificate.issuedAt.toDate().toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      })
    : new Date().toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="min-h-screen flex flex-col px-4 py-5 sm:px-8 sm:py-7 max-w-5xl mx-auto w-full gap-6 pb-12"
    >
      {/* Top Action Bar (hidden when saving/printing as PDF) */}
      <header className="flex items-center justify-between gap-3 print:hidden">
        <button
          type="button"
          onClick={onBack}
          className="liquid-glass-subtle min-h-[44px] px-4 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white hover:bg-white/10 inline-flex items-center gap-2 whitespace-nowrap shrink-0 transition-colors"
        >
          <BackArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{t.certBackToAchievementsBtn}</span>
        </button>

        <div className="flex items-center gap-2.5 shrink-0">
          <LanguageSwitcher />
          <button
            type="button"
            onClick={() => window.print()}
            className="liquid-glass-button min-h-[44px] px-4 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center gap-2 whitespace-nowrap shrink-0"
          >
            <Printer className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>{t.certPrintBtn}</span>
          </button>
        </div>
      </header>

      {/* Grand Gold Liquid Glass Certificate Canvas */}
      <LiquidGlassCard className="relative p-7 sm:p-12 overflow-hidden ring-2 ring-amber-300/60 shadow-[0_0_80px_rgba(251,191,36,0.3)] bg-gradient-to-br from-amber-500/15 via-slate-900/90 to-indigo-950/90 print:bg-slate-900 print:border-amber-400">
        {/* Decorative Gold Borders */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-4 rounded-2xl border border-amber-300/35"
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-6 rounded-xl border border-amber-200/15"
        />

        <div className="relative z-10 flex flex-col items-center text-center space-y-6">
          <div className="flex flex-col items-center gap-3">
            <div className="w-18 h-18 rounded-3xl bg-gradient-to-br from-amber-300 via-yellow-500 to-orange-600 border border-white/50 flex items-center justify-center shadow-[0_0_40px_rgba(251,191,36,0.45)]">
              <Crown className="w-9 h-9 text-white" aria-hidden="true" />
            </div>
            <div className="flex items-center gap-2">
              <MathMasterLogo size="sm" />
              <span className="font-display text-lg font-bold text-white" dir="ltr">
                {t.brandName}
              </span>
            </div>
          </div>

          <div className="space-y-2">
            <h1 className="font-display text-2xl sm:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-yellow-100 to-amber-300">
              {t.masterCertTitle}
            </h1>
            <p className="text-xs sm:text-sm text-slate-200">{t.masterCertPresentedTo}</p>
          </div>

          {/* Learner Name & Country */}
          <div className="space-y-2 py-3 px-8 rounded-2xl bg-white/[0.05] border border-amber-300/30">
            <div className="font-display text-2xl sm:text-4xl font-bold text-white">
              {learnerName}
            </div>
            {countryName && (
              <div className="text-xs sm:text-sm text-amber-100 flex items-center justify-center gap-2">
                {selectedCountry && <span aria-hidden="true">{selectedCountry.flag}</span>}
                <span>{countryName}</span>
              </div>
            )}
          </div>

          {/* Mastery Body */}
          <p className="max-w-3xl text-sm sm:text-base text-slate-200 leading-relaxed">
            {t.masterCertBody}
          </p>

          {/* All 8 Mastered Sections Seal Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 w-full">
            {CURRICULUM_SECTIONS.map((sec) => {
              const score = sectionProgressMap[sec.id]?.examBestScore ?? 100;
              return (
                <div
                  key={sec.id}
                  className="p-2.5 rounded-xl bg-white/[0.04] border border-amber-300/25 flex items-center gap-2 text-start"
                >
                  <span
                    className={`w-8 h-8 rounded-lg bg-gradient-to-br ${sec.accentFrom} ${sec.accentTo} flex items-center justify-center font-math text-sm font-bold text-white shrink-0`}
                  >
                    {sec.symbol}
                  </span>
                  <div className="min-w-0">
                    <div className="text-[11px] font-bold text-white truncate">
                      {language === 'ar' ? sec.titleAr : sec.titleEn}
                    </div>
                    <div className="text-[10px] font-math text-emerald-300 tabular-nums">
                      {score}/100
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Grand Metadata Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 w-full pt-4 border-t border-white/15">
            <div className="p-3.5 rounded-2xl bg-white/[0.04] border border-white/10 space-y-1">
              <div className="text-[11px] text-slate-400">{t.masterCertAvgScoreLabel}</div>
              <div className="font-math text-xl font-bold text-emerald-300 tabular-nums flex items-center justify-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{masterCertificate.averageExamScore} / 100</span>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-white/[0.04] border border-white/10 space-y-1">
              <div className="text-[11px] text-slate-400">{t.masterCertSectionsLabel}</div>
              <div className="font-math text-xl font-bold text-amber-200 tabular-nums">
                {masterCertificate.completedSectionsCount} / 8
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-white/[0.04] border border-white/10 space-y-1">
              <div className="text-[11px] text-slate-400">{t.certDateLabel}</div>
              <div className="text-sm font-semibold text-white">{formattedDate}</div>
            </div>

            <div className="p-3.5 rounded-2xl bg-white/[0.04] border border-white/10 space-y-1">
              <div className="text-[11px] text-slate-400">{t.certIdLabel}</div>
              <div dir="ltr" className="font-math text-xs font-semibold text-amber-200">
                {masterCertificate.certificateId}
              </div>
            </div>
          </div>

          {/* Official Seal Footer */}
          <div className="pt-2 flex items-center justify-center gap-2 text-xs text-amber-200/85">
            <ShieldCheck className="w-4 h-4 text-amber-300 shrink-0" aria-hidden="true" />
            <span>{t.masterCertFooterNote}</span>
          </div>
        </div>
      </LiquidGlassCard>
    </motion.section>
  );
}
