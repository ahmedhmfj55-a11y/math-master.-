import { ArrowLeft, ArrowRight, Award, CheckCircle2, Star } from 'lucide-react';
import { motion } from 'motion/react';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useProgress } from '@/src/contexts/ProgressContext';
import { CURRICULUM_SECTIONS } from '@/src/data/curriculum';
import type { SectionId } from '@/src/types/curriculum';

interface SectionDashboardGridProps {
  onSelectSection: (sectionId: SectionId) => void;
}

export function SectionDashboardGrid({ onSelectSection }: SectionDashboardGridProps) {
  const { language, direction, t } = useLanguage();
  const { getSectionProgress, loadingProgress } = useProgress();

  const ArrowIcon = direction === 'rtl' ? ArrowLeft : ArrowRight;

  return (
    <section aria-labelledby="curriculum-sections-heading" className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 px-1">
        <div className="space-y-1">
          <h2 id="curriculum-sections-heading" className="font-display text-xl sm:text-2xl font-bold text-white">
            {t.sectionsTitle}
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed">
            {t.sectionsSubtitle}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {CURRICULUM_SECTIONS.map((section, idx) => {
          const prog = getSectionProgress(section.id);
          const completed = prog?.completedStagesCount ?? 0;
          const totalStars = prog?.totalStars ?? 0;
          const pct = Math.round((completed / 30) * 100);
          const isCertified = Boolean(prog?.examPassed && prog?.certificateId);
          const isCompletedAllStages = completed >= 30;

          const ctaLabel = isCompletedAllStages
            ? t.reviewSection
            : completed > 0
              ? t.continueSection
              : t.enterSection;

          return (
            <motion.div
              key={section.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, delay: Math.min(idx * 0.04, 0.25) }}
              className="flex"
            >
              <LiquidGlassCard
                variant="subtle"
                className={`p-5 flex flex-col justify-between gap-4 w-full transition-all duration-200 hover:bg-white/[0.09] ${
                  isCertified
                    ? 'ring-1 ring-emerald-400/40 shadow-[0_0_28px_rgba(16,185,129,0.16)]'
                    : completed > 0
                      ? 'ring-1 ring-blue-400/35'
                      : ''
                }`}
              >
                <div className="space-y-3.5">
                  <div className="flex items-start justify-between gap-3">
                    <div
                      className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${section.accentFrom} ${section.accentTo} border border-white/20 flex items-center justify-center text-xl font-bold text-white font-math shrink-0 shadow-inner`}
                      aria-hidden="true"
                    >
                      {section.symbol}
                    </div>

                    <div className="flex flex-col items-end gap-1">
                      <span className="text-xs font-math tabular-nums text-slate-400">
                        0{section.order}
                      </span>
                      {isCertified && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-300">
                          <Award className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                          <span>{t.sectionCertifiedBadge}</span>
                        </span>
                      )}
                      {!isCertified && isCompletedAllStages && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-sky-300">
                          <CheckCircle2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                          <span>{t.examUnlockedBadge}</span>
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <h3 className="font-display text-base font-bold text-white leading-snug">
                      {language === 'ar' ? section.titleAr : section.titleEn}
                    </h3>
                    <p className="text-xs text-slate-300/90 leading-relaxed line-clamp-2">
                      {language === 'ar' ? section.descriptionAr : section.descriptionEn}
                    </p>
                  </div>
                </div>

                <div className="space-y-3 pt-2 border-t border-white/10">
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-300 font-medium font-math tabular-nums">
                        {loadingProgress ? '...' : t.sectionProgressLabel(completed, 30)}
                      </span>
                      <span className="inline-flex items-center gap-1 text-amber-300 font-math tabular-nums">
                        <Star className="w-3.5 h-3.5 fill-amber-300/80" aria-hidden="true" />
                        <span>{totalStars}/90</span>
                      </span>
                    </div>

                    <div className="h-2 w-full rounded-full bg-white/10 overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          isCertified
                            ? 'bg-gradient-to-r from-emerald-400 to-teal-300'
                            : 'bg-gradient-to-r from-blue-500 to-violet-500'
                        }`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => onSelectSection(section.id)}
                    className="liquid-glass-button w-full min-h-[44px] px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0 transition-all"
                  >
                    <span>{ctaLabel}</span>
                    <ArrowIcon className="w-4 h-4 shrink-0" aria-hidden="true" />
                  </button>
                </div>
              </LiquidGlassCard>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}
