import {
  ArrowLeft,
  ArrowRight,
  Award,
  CheckCircle2,
  ClipboardCheck,
  Lock,
  Play,
  RotateCcw,
  Sparkles,
  Star,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useMemo, useState } from 'react';
import { LanguageSwitcher } from '@/src/components/ui/LanguageSwitcher';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { MathMasterLogo } from '@/src/components/ui/MathMasterLogo';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useProgress } from '@/src/contexts/ProgressContext';
import { getSectionById, getSectionStages } from '@/src/data/curriculum';
import type { DifficultyLevel, SectionId } from '@/src/types/curriculum';

interface SectionDetailScreenProps {
  sectionId: SectionId;
  onBack: () => void;
  onSelectStage: (stageNumber: number) => void;
  onStartExam: () => void;
  onViewCertificate: () => void;
}

type DifficultyFilter = 'all' | DifficultyLevel;

export function SectionDetailScreen({
  sectionId,
  onBack,
  onSelectStage,
  onStartExam,
  onViewCertificate,
}: SectionDetailScreenProps) {
  const { language, direction, t } = useLanguage();
  const { getSectionProgress, getStageProgress, isStageUnlocked, isExamUnlocked } = useProgress();
  const [filter, setFilter] = useState<DifficultyFilter>('all');
  const [lockedNotice, setLockedNotice] = useState<string | null>(null);

  const section = getSectionById(sectionId);
  const allStages = useMemo(() => getSectionStages(sectionId), [sectionId]);
  const sectionProg = getSectionProgress(sectionId);
  const completedCount = sectionProg?.completedStagesCount ?? 0;
  const totalStars = sectionProg?.totalStars ?? 0;
  const unlockedStage = sectionProg?.unlockedStage ?? 1;
  const examOpen = isExamUnlocked(sectionId);
  const examPassed = Boolean(sectionProg?.examPassed && sectionProg?.certificateId);
  const pct = Math.round((completedCount / 30) * 100);

  const filteredStages = useMemo(() => {
    if (filter === 'all') return allStages;
    return allStages.filter((s) => s.difficulty === filter);
  }, [allStages, filter]);

  const BackArrow = direction === 'rtl' ? ArrowRight : ArrowLeft;
  const ForwardArrow = direction === 'rtl' ? ArrowLeft : ArrowRight;

  if (!section) return null;

  const difficultyLabel = (diff: DifficultyLevel) => {
    if (diff === 'easy') return language === 'ar' ? 'سهل' : 'Easy';
    if (diff === 'medium') return language === 'ar' ? 'متوسط' : 'Medium';
    return language === 'ar' ? 'صعب' : 'Hard';
  };

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="min-h-dvh flex flex-col px-4 py-5 sm:px-8 sm:py-7 max-w-6xl mx-auto w-full gap-6 safe-pb-nav"
    >
      {/* Top Bar */}
      <header className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={onBack}
          className="liquid-glass-subtle min-h-[44px] px-4 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white hover:bg-white/10 inline-flex items-center gap-2 whitespace-nowrap shrink-0 transition-colors"
        >
          <BackArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{t.backToDashboard}</span>
        </button>

        <div className="hidden sm:flex items-center gap-2.5 shrink-0">
          <MathMasterLogo size="sm" />
          <span className="font-display text-base font-bold text-white" dir="ltr">
            {t.brandName}
          </span>
        </div>

        <LanguageSwitcher />
      </header>

      {/* Section Overview Banner */}
      <LiquidGlassCard className="p-6 sm:p-8 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="flex items-start gap-4">
            <div
              className={`w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-br ${section.accentFrom} ${section.accentTo} border border-white/25 flex items-center justify-center text-2xl sm:text-3xl font-bold text-white font-math shrink-0 shadow-lg`}
              aria-hidden="true"
            >
              {section.symbol}
            </div>
            <div className="space-y-1.5">
              <div className="text-xs font-medium text-blue-200/90 font-math tabular-nums">
                {language === 'ar' ? `القسم ${section.order} من 8` : `Section ${section.order} of 8`}
              </div>
              <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">
                {language === 'ar' ? section.titleAr : section.titleEn}
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-2xl">
                {language === 'ar' ? section.descriptionAr : section.descriptionEn}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 self-start md:self-center shrink-0">
            <div className="px-4 py-2.5 rounded-2xl bg-white/[0.05] border border-white/10 text-center">
              <div className="text-[11px] text-slate-400">{t.statsCompletedStages}</div>
              <div className="text-lg font-bold text-white font-math tabular-nums">
                {completedCount} / 30
              </div>
            </div>
            <div className="px-4 py-2.5 rounded-2xl bg-white/[0.05] border border-white/10 text-center">
              <div className="text-[11px] text-slate-400">{t.statsStarsEarned}</div>
              <div className="text-lg font-bold text-amber-300 font-math tabular-nums flex items-center justify-center gap-1">
                <Star className="w-4 h-4 fill-amber-300" aria-hidden="true" />
                <span>{totalStars}/90</span>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-1.5">
          <div className="h-2.5 w-full rounded-full bg-white/10 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                examPassed
                  ? 'bg-gradient-to-r from-emerald-400 to-teal-300'
                  : 'bg-gradient-to-r from-blue-500 to-violet-500'
              }`}
              style={{ width: `${pct}%` }}
            />
          </div>
        </div>

        {/* Comprehensive Final Exam & Certificate Panel */}
        <div
          className={`p-5 rounded-2xl border transition-all flex flex-col lg:flex-row lg:items-center justify-between gap-4 ${
            examPassed
              ? 'bg-emerald-500/10 border-emerald-400/35'
              : examOpen
                ? 'bg-gradient-to-r from-blue-500/15 to-violet-500/15 border-blue-400/40 shadow-[0_0_28px_rgba(99,102,241,0.22)]'
                : 'bg-white/[0.03] border-white/10'
          }`}
        >
          <div className="flex items-start gap-3.5">
            <div
              className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 border ${
                examPassed
                  ? 'bg-emerald-500/20 border-emerald-400/40 text-emerald-200'
                  : examOpen
                    ? 'bg-blue-500/25 border-blue-400/40 text-blue-200'
                    : 'bg-white/5 border-white/10 text-slate-400'
              }`}
            >
              {examPassed ? (
                <Award className="w-5 h-5" aria-hidden="true" />
              ) : examOpen ? (
                <ClipboardCheck className="w-5 h-5" aria-hidden="true" />
              ) : (
                <Lock className="w-5 h-5" aria-hidden="true" />
              )}
            </div>
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="font-display text-base sm:text-lg font-bold text-white">
                  {t.examCardTitle}
                </h2>
                {examOpen && !examPassed && (
                  <span className="text-xs font-semibold text-blue-200 inline-flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>{t.examUnlockedBadge}</span>
                  </span>
                )}
                {examPassed && sectionProg && (
                  <span className="text-xs font-semibold text-emerald-300 font-math tabular-nums">
                    {t.stageBestScoreLabel(sectionProg.examBestScore)}
                  </span>
                )}
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {examOpen ? t.examCardDesc : t.examLockedNotice(completedCount)}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            {examPassed && (
              <button
                type="button"
                onClick={onViewCertificate}
                className="min-h-[44px] px-4 py-2.5 rounded-2xl bg-emerald-500/25 hover:bg-emerald-500/35 border border-emerald-300/45 text-xs sm:text-sm font-semibold text-emerald-100 inline-flex items-center gap-2 whitespace-nowrap shrink-0 transition-colors"
              >
                <Award className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{t.examViewCertificateBtn}</span>
              </button>
            )}

            <button
              type="button"
              disabled={!examOpen}
              onClick={() => {
                if (examOpen) onStartExam();
              }}
              className={`min-h-[44px] px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold inline-flex items-center gap-2 whitespace-nowrap shrink-0 transition-all ${
                examOpen
                  ? 'liquid-glass-button text-white'
                  : 'bg-white/5 border border-white/10 text-slate-400 cursor-not-allowed'
              }`}
            >
              {!examOpen && <Lock className="w-4 h-4 shrink-0" aria-hidden="true" />}
              <span>
                {examPassed || (sectionProg?.examAttempts ?? 0) > 0
                  ? t.examRetakeBtn
                  : t.examStartBtn}
              </span>
              {examOpen && <ForwardArrow className="w-4 h-4 shrink-0" aria-hidden="true" />}
            </button>
          </div>
        </div>
      </LiquidGlassCard>

      {/* Difficulty Filters + Inline Lock Notice */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div
          role="tablist"
          aria-label="Difficulty filter"
          className="inline-flex flex-wrap items-center gap-1.5 p-1.5 rounded-2xl liquid-glass-subtle"
        >
          {(
            [
              { id: 'all', label: t.difficultyAll },
              { id: 'easy', label: t.difficultyEasy },
              { id: 'medium', label: t.difficultyMedium },
              { id: 'hard', label: t.difficultyHard },
            ] as const
          ).map((item) => {
            const active = filter === item.id;
            return (
              <button
                key={item.id}
                role="tab"
                aria-selected={active}
                type="button"
                onClick={() => setFilter(item.id)}
                className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-all ${
                  active
                    ? 'bg-gradient-to-r from-blue-500/80 to-violet-600/80 text-white shadow-sm'
                    : 'text-slate-300 hover:text-white hover:bg-white/5'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>

        {lockedNotice && (
          <div
            role="status"
            className="px-4 py-2.5 rounded-2xl bg-amber-500/15 border border-amber-400/35 text-xs sm:text-sm text-amber-100 inline-flex items-center gap-2"
          >
            <Lock className="w-4 h-4 text-amber-300 shrink-0" aria-hidden="true" />
            <span>{lockedNotice}</span>
          </div>
        )}
      </div>

      {/* 30 Progressive Stages Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pb-8">
        {filteredStages.map((stage) => {
          const unlocked = isStageUnlocked(sectionId, stage.stageNumber);
          const prog = getStageProgress(sectionId, stage.stageNumber);
          const passed = Boolean(prog?.passed);
          const isCurrentFrontier = unlocked && !passed && stage.stageNumber === unlockedStage;
          const stars = prog?.bestStars ?? 0;

          const cardClasses = !unlocked
            ? 'bg-white/[0.025] border-white/10 opacity-75 cursor-not-allowed'
            : isCurrentFrontier
              ? 'bg-gradient-to-br from-blue-500/20 via-indigo-500/15 to-violet-600/20 border-blue-400/60 shadow-[0_0_32px_rgba(99,102,241,0.34)] ring-1 ring-blue-300/40'
              : passed
                ? 'bg-emerald-500/[0.07] border-emerald-400/30 hover:bg-emerald-500/[0.11]'
                : 'bg-white/[0.06] border-white/15 hover:bg-white/[0.09]';

          return (
            <div
              key={stage.id}
              onClick={() => {
                if (!unlocked) {
                  setLockedNotice(t.stageLockedNotice(stage.stageNumber - 1));
                }
              }}
              className={`rounded-3xl border backdrop-blur-xl p-5 flex flex-col justify-between gap-4 transition-all duration-200 ${cardClasses}`}
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <span
                      className={`w-9 h-9 rounded-xl flex items-center justify-center text-sm font-bold font-math tabular-nums border ${
                        !unlocked
                          ? 'bg-white/5 border-white/10 text-slate-400'
                          : isCurrentFrontier
                            ? 'bg-blue-500/35 border-blue-300/60 text-white shadow-[0_0_16px_rgba(59,130,246,0.45)]'
                            : passed
                              ? 'bg-emerald-500/25 border-emerald-400/45 text-emerald-200'
                              : 'bg-white/10 border-white/20 text-white'
                      }`}
                    >
                      {stage.stageNumber}
                    </span>

                    <div className="flex flex-col">
                      <span className="text-[11px] font-medium text-slate-400">
                        {t.stageLabel(stage.stageNumber)} · {difficultyLabel(stage.difficulty)}
                      </span>
                      <span
                        className={`text-xs font-semibold inline-flex items-center gap-1 ${
                          !unlocked
                            ? 'text-slate-400'
                            : passed
                              ? 'text-emerald-300'
                              : isCurrentFrontier
                                ? 'text-blue-200'
                                : 'text-sky-200'
                        }`}
                      >
                        {!unlocked ? (
                          <>
                            <Lock className="w-3.5 h-3.5" aria-hidden="true" />
                            <span>{t.stageLockedLabel}</span>
                          </>
                        ) : passed ? (
                          <>
                            <CheckCircle2 className="w-3.5 h-3.5" aria-hidden="true" />
                            <span>{t.stageCompletedLabel}</span>
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
                            <span>{t.stageUnlockedLabel}</span>
                          </>
                        )}
                      </span>
                    </div>
                  </div>

                  {/* Star indicators */}
                  {unlocked && (
                    <div className="flex items-center gap-0.5" aria-label={`${stars} of 3 stars`}>
                      {[1, 2, 3].map((slot) => (
                        <Star
                          key={slot}
                          className={`w-4 h-4 ${
                            slot <= stars
                              ? 'text-amber-300 fill-amber-300'
                              : 'text-slate-600'
                          }`}
                          aria-hidden="true"
                        />
                      ))}
                    </div>
                  )}
                </div>

                <h3 className="font-display text-base font-bold text-white leading-snug">
                  {language === 'ar' ? stage.titleAr : stage.titleEn}
                </h3>

                {prog && prog.attempts > 0 && (
                  <div className="flex items-center justify-between text-xs text-slate-300 font-math tabular-nums pt-1">
                    <span>{t.stageBestScoreLabel(prog.bestScore)}</span>
                    <span>{t.stageAttemptsLabel(prog.attempts)}</span>
                  </div>
                )}
              </div>

              <div>
                {unlocked ? (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setLockedNotice(null);
                      onSelectStage(stage.stageNumber);
                    }}
                    className={`w-full min-h-[44px] px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0 transition-all ${
                      isCurrentFrontier
                        ? 'liquid-glass-button text-white'
                        : passed
                          ? 'bg-white/[0.08] hover:bg-white/[0.14] border border-white/15 text-white'
                          : 'bg-blue-500/25 hover:bg-blue-500/35 border border-blue-400/35 text-blue-100'
                    }`}
                  >
                    {passed ? (
                      <RotateCcw className="w-4 h-4 shrink-0" aria-hidden="true" />
                    ) : (
                      <Play className="w-4 h-4 shrink-0" aria-hidden="true" />
                    )}
                    <span>
                      {passed
                        ? t.stageReplayAction
                        : isCurrentFrontier
                          ? t.stageStartAction
                          : t.stageContinueAction}
                    </span>
                  </button>
                ) : (
                  <button
                    type="button"
                    aria-disabled="true"
                    onClick={(e) => {
                      e.stopPropagation();
                      setLockedNotice(t.stageLockedNotice(stage.stageNumber - 1));
                    }}
                    className="w-full min-h-[44px] px-4 py-2.5 rounded-2xl text-xs font-semibold bg-white/[0.04] border border-white/10 text-slate-400 inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0 cursor-not-allowed"
                  >
                    <Lock className="w-4 h-4 shrink-0" aria-hidden="true" />
                    <span>{t.stageLockedLabel}</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </motion.section>
  );
}
