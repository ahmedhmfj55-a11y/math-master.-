import { Sparkles, Star } from 'lucide-react';
import { motion, useReducedMotion } from 'motion/react';
import { useMemo } from 'react';

interface WinCelebrationProps {
  stars: number; // 0..3 (or 3 for exam pass)
  passed: boolean;
  goldenMode?: boolean;
}

interface Particle {
  id: number;
  x: number;
  y: number;
  rotate: number;
  scale: number;
  color: string;
  delay: number;
}

const PARTICLE_COLORS = [
  '#60a5fa', // sky blue
  '#a78bfa', // violet
  '#34d399', // emerald
  '#fbbf24', // gold
  '#f472b6', // rose
];

const GOLDEN_COLORS = [
  '#fde047',
  '#facc15',
  '#fbbf24',
  '#f59e0b',
  '#fef08a',
];

export function WinCelebration({ stars, passed, goldenMode = false }: WinCelebrationProps) {
  const prefersReducedMotion = useReducedMotion();

  const particles = useMemo<Particle[]>(() => {
    const palette = goldenMode ? GOLDEN_COLORS : PARTICLE_COLORS;
    const count = goldenMode ? 28 : 18;
    return Array.from({ length: count }, (_, i) => {
      const angle = (i / count) * Math.PI * 2;
      const radius = (goldenMode ? 68 : 58) + (i % 3) * 30;
      return {
        id: i,
        x: Math.cos(angle) * radius,
        y: Math.sin(angle) * radius - 10,
        rotate: (i % 2 === 0 ? 1 : -1) * (45 + i * 18),
        scale: (goldenMode ? 0.9 : 0.75) + (i % 3) * 0.22,
        color: palette[i % palette.length],
        delay: (i % 7) * 0.035,
      };
    });
  }, [goldenMode]);

  return (
    <div className="relative flex flex-col items-center justify-center py-4 select-none overflow-hidden">
      {passed && goldenMode && (
        <div
          aria-hidden="true"
          className="pointer-events-none absolute w-44 h-44 rounded-full bg-amber-400/20 blur-2xl"
        />
      )}
      {passed && !prefersReducedMotion && (
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 flex items-center justify-center"
        >
          {particles.map((p) => (
            <motion.span
              key={p.id}
              initial={{ opacity: 0.95, x: 0, y: 0, scale: 0.3, rotate: 0 }}
              animate={{
                opacity: [0.95, 1, 0],
                x: p.x,
                y: p.y,
                scale: [0.4, p.scale, 0.2],
                rotate: p.rotate,
              }}
              transition={{
                duration: goldenMode ? 1.55 : 1.25,
                delay: p.delay,
                ease: [0.16, 1, 0.3, 1],
              }}
              className={`absolute rounded-sm ${goldenMode ? 'w-3 h-3' : 'w-2.5 h-2.5'}`}
              style={{ backgroundColor: p.color }}
            />
          ))}
        </div>
      )}

      {/* Star Rating Display */}
      <div className="relative z-10 flex items-center justify-center gap-3">
        {[1, 2, 3].map((slot) => {
          const earned = passed && slot <= stars;
          const isCenter = slot === 2;
          return (
            <motion.div
              key={slot}
              initial={prefersReducedMotion ? false : { scale: 0.6, opacity: 0 }}
              animate={{ scale: isCenter ? 1.15 : 1, opacity: 1 }}
              transition={{
                duration: 0.45,
                delay: prefersReducedMotion ? 0 : slot * 0.12,
                ease: [0.16, 1, 0.3, 1],
              }}
              className={`relative flex items-center justify-center rounded-2xl border transition-colors ${
                isCenter ? 'w-14 h-14' : 'w-11 h-11 mt-2'
              } ${
                earned
                  ? 'bg-amber-400/20 border-amber-300/60 text-amber-300 shadow-[0_0_24px_rgba(251,191,36,0.35)]'
                  : 'bg-white/[0.04] border-white/10 text-slate-500'
              }`}
            >
              <Star
                className={`${isCenter ? 'w-7 h-7' : 'w-5 h-5'} ${earned ? 'fill-amber-300' : ''}`}
                aria-hidden="true"
              />
            </motion.div>
          );
        })}
      </div>

      {passed && (
        <motion.div
          initial={prefersReducedMotion ? false : { opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, delay: 0.3 }}
          className="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-amber-200"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-300" aria-hidden="true" />
          <span className="font-math tabular-nums">{stars} / 3</span>
        </motion.div>
      )}
    </div>
  );
}
