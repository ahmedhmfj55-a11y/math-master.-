import { ArrowLeft, ArrowRight, Award, CheckCircle2, Printer, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';
import { LanguageSwitcher } from '@/src/components/ui/LanguageSwitcher';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { MathMasterLogo } from '@/src/components/ui/MathMasterLogo';
import { useAuth } from '@/src/contexts/AuthContext';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useProgress } from '@/src/contexts/ProgressContext';
import { getSectionById } from '@/src/data/curriculum';
import type { SectionId } from '@/src/types/curriculum';

interface CertificateScreenProps {
  sectionId: SectionId;
  onBackToSection: () => void;
}

export function CertificateScreen({ sectionId, onBackToSection }: CertificateScreenProps) {
  const { language, direction, t } = useLanguage();
  const { firebaseUser, userProfile, selectedCountry } = useAuth();
  const { getSectionProgress } = useProgress();

  const section = getSectionById(sectionId);
  const sectionProg = getSectionProgress(sectionId);

  if (!section || !sectionProg?.examPassed || !sectionProg.certificateId) {
    return null;
  }

  const BackArrow = direction === 'rtl' ? ArrowRight : ArrowLeft;

  const learnerName =
    userProfile?.displayName ||
    firebaseUser?.displayName ||
    firebaseUser?.phoneNumber ||
    firebaseUser?.email ||
    'Math Master';

  const countryName = selectedCountry
    ? language === 'ar'
      ? selectedCountry.nameAr
      : selectedCountry.nameEn
    : userProfile
      ? language === 'ar'
        ? userProfile.countryNameAr
        : userProfile.countryNameEn
      : '';

  const formattedDate = sectionProg.updatedAt?.toDate
    ? sectionProg.updatedAt.toDate().toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      })
    : new Date().toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="min-h-screen flex flex-col px-4 py-5 sm:px-8 sm:py-7 max-w-4xl mx-auto w-full gap-6 pb-12"
    >
      {/* Top Bar (hidden on print) */}
      <header className="flex items-center justify-between gap-3 print:hidden">
        <button
          type="button"
          onClick={onBackToSection}
          className="liquid-glass-subtle min-h-[44px] px-4 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white hover:bg-white/10 inline-flex items-center gap-2 whitespace-nowrap shrink-0 transition-colors"
        >
          <BackArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{t.certBackToSectionBtn}</span>
        </button>

        <div className="flex items-center gap-2.5 shrink-0">
          <LanguageSwitcher />
          <button
            type="button"
            onClick={() => window.print()}
            className="liquid-glass-button min-h-[44px] px-4 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center gap-2 whitespace-nowrap shrink-0"
          >
            <Printer className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>{t.certPrintBtn}</span>
          </button>
        </div>
      </header>

      {/* Formal Certificate Surface */}
      <LiquidGlassCard className="relative p-7 sm:p-12 overflow-hidden ring-1 ring-amber-300/40 shadow-[0_0_60px_rgba(99,102,241,0.3)] print:bg-slate-900 print:border-amber-400">
        {/* Decorative Subtle Corner Frame */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-4 rounded-2xl border border-amber-300/25"
        />

        <div className="relative z-10 flex flex-col items-center text-center space-y-6">
          <div className="flex flex-col items-center gap-3">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400/25 via-blue-500/25 to-violet-600/30 border border-amber-300/45 flex items-center justify-center shadow-[0_0_32px_rgba(251,191,36,0.28)]">
              <Award className="w-8 h-8 text-amber-300" aria-hidden="true" />
            </div>
            <div className="flex items-center gap-2">
              <MathMasterLogo size="sm" />
              <span className="font-display text-lg font-bold text-white" dir="ltr">
                {t.brandName}
              </span>
            </div>
          </div>

          <div className="space-y-2">
            <h1 className="font-display text-2xl sm:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-white to-blue-200">
              {t.certHeaderTitle}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300">{t.certPresentedTo}</p>
          </div>

          {/* Learner Name & Country */}
          <div className="space-y-2 py-2 px-6 rounded-2xl bg-white/[0.04] border border-white/10">
            <div className="font-display text-2xl sm:text-3xl font-bold text-white">
              {learnerName}
            </div>
            {countryName && (
              <div className="text-xs sm:text-sm text-slate-300 flex items-center justify-center gap-2">
                {selectedCountry && <span aria-hidden="true">{selectedCountry.flag}</span>}
                <span>{countryName}</span>
              </div>
            )}
          </div>

          {/* Achievement Statement */}
          <div className="max-w-2xl space-y-3">
            <p className="text-sm sm:text-base text-slate-200 leading-relaxed">
              {t.certBodyPrefix}
            </p>
            <div className="inline-flex items-center gap-3 px-6 py-3 rounded-2xl bg-gradient-to-r from-blue-500/20 to-violet-600/20 border border-blue-300/35">
              <span className="font-math text-xl font-bold text-blue-200" aria-hidden="true">
                {section.symbol}
              </span>
              <span className="font-display text-lg sm:text-xl font-bold text-white">
                {language === 'ar' ? section.titleAr : section.titleEn}
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {t.certBodySuffix}
            </p>
          </div>

          {/* Metadata Strip */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 w-full pt-4 border-t border-white/15">
            <div className="p-3.5 rounded-2xl bg-white/[0.035] border border-white/10 space-y-1">
              <div className="text-[11px] text-slate-400">{t.certScoreLabel}</div>
              <div className="font-math text-xl font-bold text-emerald-300 tabular-nums flex items-center justify-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{sectionProg.examBestScore} / 100</span>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-white/[0.035] border border-white/10 space-y-1">
              <div className="text-[11px] text-slate-400">{t.certDateLabel}</div>
              <div className="text-sm font-semibold text-white">{formattedDate}</div>
            </div>

            <div className="p-3.5 rounded-2xl bg-white/[0.035] border border-white/10 space-y-1">
              <div className="text-[11px] text-slate-400">{t.certIdLabel}</div>
              <div dir="ltr" className="font-math text-xs sm:text-sm font-semibold text-blue-200">
                {sectionProg.certificateId}
              </div>
            </div>
          </div>

          {/* Verification Footer */}
          <div className="pt-2 flex items-center justify-center gap-2 text-xs text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-300 shrink-0" aria-hidden="true" />
            <span>{t.certIssuedBy}</span>
          </div>
        </div>
      </LiquidGlassCard>
    </motion.section>
  );
}
