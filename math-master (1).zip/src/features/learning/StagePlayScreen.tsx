import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  CheckCircle2,
  ClipboardList,
  Lightbulb,
  Play,
  RotateCcw,
  Sparkles,
  XCircle,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useEffect, useMemo, useState } from 'react';
import { LanguageSwitcher } from '@/src/components/ui/LanguageSwitcher';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { MathMasterLogo } from '@/src/components/ui/MathMasterLogo';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useProgress } from '@/src/contexts/ProgressContext';
import { getSectionById, getStageDefinition } from '@/src/data/curriculum';
import { WinCelebration } from '@/src/features/learning/WinCelebration';
import type { SectionId } from '@/src/types/curriculum';
import type { StageSubmissionResult } from '@/src/types/progress';

interface StagePlayScreenProps {
  sectionId: SectionId;
  stageNumber: number;
  onBackToSection: () => void;
  onGoToNextStage: (nextStageNumber: number) => void;
}

type StagePhase = 'lesson' | 'quiz' | 'result';

export function StagePlayScreen({
  sectionId,
  stageNumber,
  onBackToSection,
  onGoToNextStage,
}: StagePlayScreenProps) {
  const { language, direction, t } = useLanguage();
  const { submitStage, submittingAttempt, isStageUnlocked } = useProgress();

  const section = getSectionById(sectionId);
  const stage = getStageDefinition(sectionId, stageNumber);

  const [phase, setPhase] = useState<StagePhase>('lesson');
  const [currentIdx, setCurrentIdx] = useState(0);
  const [answers, setAnswers] = useState<number[]>(() => Array(10).fill(-1));
  const [validationMsg, setValidationMsg] = useState<string | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [result, setResult] = useState<StageSubmissionResult | null>(null);

  // Reset state whenever navigating to a different stage
  useEffect(() => {
    setPhase('lesson');
    setCurrentIdx(0);
    setAnswers(Array(10).fill(-1));
    setValidationMsg(null);
    setSubmitError(null);
    setResult(null);
  }, [sectionId, stageNumber]);

  const answeredCount = useMemo(() => answers.filter((a) => a !== -1).length, [answers]);

  if (!section || !stage) return null;

  const BackArrow = direction === 'rtl' ? ArrowRight : ArrowLeft;
  const ForwardArrow = direction === 'rtl' ? ArrowLeft : ArrowRight;

  const startFreshQuiz = () => {
    setAnswers(Array(stage.questions.length).fill(-1));
    setCurrentIdx(0);
    setValidationMsg(null);
    setSubmitError(null);
    setResult(null);
    setPhase('quiz');
  };

  const handleSelectOption = (optionIndex: number) => {
    setValidationMsg(null);
    setAnswers((prev) => {
      const next = [...prev];
      next[currentIdx] = optionIndex;
      return next;
    });
  };

  const handleSubmitQuiz = async () => {
    const firstUnanswered = answers.findIndex((a) => a === -1);
    if (firstUnanswered !== -1) {
      setCurrentIdx(firstUnanswered);
      setValidationMsg(t.answerAllPrompt);
      return;
    }

    setSubmitError(null);
    try {
      const res = await submitStage(sectionId, stageNumber, answers);
      setResult(res);
      setPhase('result');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch {
      setSubmitError(t.errorGeneric);
    }
  };

  const currentQuestion = stage.questions[currentIdx];

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="min-h-screen flex flex-col px-4 py-5 sm:px-8 sm:py-7 max-w-4xl mx-auto w-full gap-6 pb-12"
    >
      {/* Top Bar */}
      <header className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={onBackToSection}
          className="liquid-glass-subtle min-h-[44px] px-4 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white hover:bg-white/10 inline-flex items-center gap-2 whitespace-nowrap shrink-0 transition-colors"
        >
          <BackArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{t.backToSectionBtn}</span>
        </button>

        <div className="hidden sm:flex items-center gap-2.5 shrink-0">
          <MathMasterLogo size="sm" />
          <span className="font-display text-sm font-bold text-white">
            {language === 'ar' ? section.titleAr : section.titleEn}
          </span>
        </div>

        <LanguageSwitcher />
      </header>

      {/* Stage Title & Mode Switcher */}
      <LiquidGlassCard className="p-5 sm:p-7 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="text-xs font-semibold text-blue-200 font-math tabular-nums">
              {language === 'ar' ? section.titleAr : section.titleEn} · {t.stageLabel(stageNumber)}
            </div>
            <h1 className="font-display text-xl sm:text-2xl font-bold text-white text-balance">
              {language === 'ar' ? stage.titleAr : stage.titleEn}
            </h1>
          </div>

          {phase !== 'result' && (
            <div className="inline-flex items-center gap-1.5 p-1 rounded-2xl liquid-glass-subtle self-start sm:self-auto">
              <button
                type="button"
                onClick={() => setPhase('lesson')}
                className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-all ${
                  phase === 'lesson'
                    ? 'bg-gradient-to-r from-blue-500/85 to-violet-600/85 text-white'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{t.tabLesson}</span>
              </button>
              <button
                type="button"
                onClick={() => setPhase('quiz')}
                className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-all ${
                  phase === 'quiz'
                    ? 'bg-gradient-to-r from-blue-500/85 to-violet-600/85 text-white'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <ClipboardList className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{t.tabQuiz}</span>
              </button>
            </div>
          )}
        </div>
      </LiquidGlassCard>

      {/* PHASE 1: LESSON & WORKED EXAMPLES */}
      {phase === 'lesson' && (
        <div className="space-y-5">
          <LiquidGlassCard variant="subtle" className="p-6 sm:p-8 space-y-6">
            <div className="space-y-2">
              <h2 className="text-sm font-semibold text-blue-200 flex items-center gap-2">
                <BookOpen className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{t.lessonSummaryTitle}</span>
              </h2>
              <p className="text-sm sm:text-base text-slate-100 leading-relaxed">
                {language === 'ar' ? stage.lesson.summaryAr : stage.lesson.summaryEn}
              </p>
            </div>

            {/* Core Formula Box */}
            <div className="p-5 rounded-2xl bg-gradient-to-r from-blue-500/15 to-violet-500/15 border border-blue-400/30 space-y-2">
              <div className="text-xs font-semibold text-violet-200 flex items-center gap-2">
                <Lightbulb className="w-4 h-4 text-amber-300 shrink-0" aria-hidden="true" />
                <span>
                  {t.lessonRuleTitle}:{' '}
                  {language === 'ar' ? stage.lesson.ruleTitleAr : stage.lesson.ruleTitleEn}
                </span>
              </div>
              <div
                dir="ltr"
                className="font-math text-base sm:text-lg font-bold text-white tracking-wide py-1"
              >
                {stage.lesson.ruleFormula}
              </div>
            </div>

            {/* 2 Worked Examples */}
            <div className="space-y-3">
              <h3 className="text-sm font-semibold text-white">{t.lessonExamplesTitle}</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {stage.lesson.examples.map((ex, i) => (
                  <div
                    key={i}
                    className="p-4 sm:p-5 rounded-2xl bg-white/[0.04] border border-white/10 space-y-2.5"
                  >
                    <div className="text-[11px] font-semibold text-blue-200">
                      {t.exampleProblemLabel} {i + 1}
                    </div>
                    <p className="text-sm font-semibold text-white leading-relaxed">
                      {language === 'ar' ? ex.problemAr : ex.problemEn}
                    </p>
                    <div className="pt-2 border-t border-white/10 space-y-1">
                      <div className="text-[11px] text-slate-400">{t.exampleSolutionLabel}</div>
                      <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
                        {language === 'ar' ? ex.solutionAr : ex.solutionEn}
                      </p>
                    </div>
                    <div className="pt-1 flex items-center justify-between text-xs">
                      <span className="text-slate-400">{t.exampleAnswerLabel}:</span>
                      <span
                        dir="ltr"
                        className="font-math font-bold text-emerald-300 px-2.5 py-0.5 rounded-lg bg-emerald-500/15 border border-emerald-400/25"
                      >
                        {ex.answer}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              <div className="text-xs text-slate-300">{t.resultPassingRule}</div>
              <button
                type="button"
                onClick={startFreshQuiz}
                className="liquid-glass-button min-h-[48px] px-6 py-3 rounded-2xl text-sm font-semibold text-white inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0 transition-all"
              >
                <Play className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{t.startStageQuizBtn}</span>
              </button>
            </div>
          </LiquidGlassCard>
        </div>
      )}

      {/* PHASE 2: INTERACTIVE 10-QUESTION QUIZ */}
      {phase === 'quiz' && currentQuestion && (
        <div className="space-y-5">
          {/* Question Navigator */}
          <LiquidGlassCard variant="subtle" className="p-4 sm:p-5 space-y-3">
            <div className="flex items-center justify-between text-xs font-medium text-slate-300">
              <span className="font-math tabular-nums">
                {t.questionCounterLabel(currentIdx + 1, stage.questions.length)}
              </span>
              <span className="font-math tabular-nums">
                {t.answeredCountLabel(answeredCount, stage.questions.length)}
              </span>
            </div>
            <div className="grid grid-cols-5 sm:grid-cols-10 gap-2">
              {stage.questions.map((q, idx) => {
                const isActive = idx === currentIdx;
                const isAnswered = answers[idx] !== -1;
                return (
                  <button
                    key={q.id}
                    type="button"
                    onClick={() => {
                      setValidationMsg(null);
                      setCurrentIdx(idx);
                    }}
                    className={`min-h-[40px] rounded-xl text-xs font-bold font-math tabular-nums border transition-all ${
                      isActive
                        ? 'bg-gradient-to-br from-blue-500 to-violet-600 border-white/40 text-white shadow-[0_0_16px_rgba(99,102,241,0.45)]'
                        : isAnswered
                          ? 'bg-emerald-500/20 border-emerald-400/40 text-emerald-200 hover:bg-emerald-500/30'
                          : 'bg-white/[0.04] border-white/10 text-slate-300 hover:bg-white/10'
                    }`}
                  >
                    {idx + 1}
                  </button>
                );
              })}
            </div>
          </LiquidGlassCard>

          {/* Question Card */}
          <LiquidGlassCard className="p-6 sm:p-8 space-y-6">
            <h2 className="font-display text-lg sm:text-xl font-bold text-white leading-relaxed">
              {language === 'ar' ? currentQuestion.promptAr : currentQuestion.promptEn}
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {currentQuestion.options.map((opt, optIdx) => {
                const selected = answers[currentIdx] === optIdx;
                const letters = ['A', 'B', 'C', 'D'];
                return (
                  <button
                    key={`${currentQuestion.id}-opt-${optIdx}`}
                    type="button"
                    onClick={() => handleSelectOption(optIdx)}
                    className={`min-h-[56px] p-4 rounded-2xl border text-start flex items-center gap-3 transition-all ${
                      selected
                        ? 'bg-gradient-to-r from-blue-500/30 to-violet-600/30 border-blue-300/70 text-white shadow-[0_0_24px_rgba(99,102,241,0.3)]'
                        : 'bg-white/[0.045] hover:bg-white/[0.09] border-white/12 text-slate-100'
                    }`}
                  >
                    <span
                      className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold font-math shrink-0 border ${
                        selected
                          ? 'bg-blue-400 text-slate-950 border-white/40'
                          : 'bg-white/10 text-slate-300 border-white/15'
                      }`}
                    >
                      {letters[optIdx]}
                    </span>
                    <span dir="auto" className="text-sm sm:text-base font-semibold font-math break-words">
                      {opt}
                    </span>
                  </button>
                );
              })}
            </div>

            {validationMsg && (
              <div
                role="alert"
                className="p-3.5 rounded-2xl bg-amber-500/15 border border-amber-400/35 text-xs sm:text-sm text-amber-100"
              >
                {validationMsg}
              </div>
            )}

            {submitError && (
              <div
                role="alert"
                className="p-3.5 rounded-2xl bg-rose-500/15 border border-rose-400/35 text-xs sm:text-sm text-rose-100"
              >
                {submitError}
              </div>
            )}

            {/* Navigation & Submit */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-white/10">
              <button
                type="button"
                disabled={currentIdx === 0}
                onClick={() => setCurrentIdx((i) => Math.max(0, i - 1))}
                className="liquid-glass-subtle min-h-[44px] px-4 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white disabled:opacity-40 disabled:cursor-not-allowed inline-flex items-center gap-2 whitespace-nowrap shrink-0"
              >
                <BackArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{t.prevQuestionBtn}</span>
              </button>

              {currentIdx < stage.questions.length - 1 ? (
                <button
                  type="button"
                  onClick={() => setCurrentIdx((i) => Math.min(stage.questions.length - 1, i + 1))}
                  className="liquid-glass-button min-h-[44px] px-5 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center gap-2 whitespace-nowrap shrink-0"
                >
                  <span>{t.nextQuestionBtn}</span>
                  <ForwardArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
                </button>
              ) : (
                <button
                  type="button"
                  disabled={submittingAttempt}
                  onClick={() => void handleSubmitQuiz()}
                  className="liquid-glass-button min-h-[46px] px-6 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white disabled:opacity-60 inline-flex items-center gap-2 whitespace-nowrap shrink-0"
                >
                  <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>{submittingAttempt ? t.submittingQuizBtn : t.submitQuizBtn}</span>
                </button>
              )}
            </div>
          </LiquidGlassCard>
        </div>
      )}

      {/* PHASE 3: EVALUATION RESULT + EXPLANATIONS */}
      {phase === 'result' && result && (
        <div className="space-y-6">
          <LiquidGlassCard
            className={`p-6 sm:p-9 text-center space-y-5 ${
              result.sectionCompletionBonusPoints > 0
                ? 'ring-1 ring-amber-300/60 shadow-[0_0_55px_rgba(251,191,36,0.32)] bg-gradient-to-b from-amber-500/12 to-transparent'
                : result.passed
                  ? 'ring-1 ring-emerald-400/40 shadow-[0_0_40px_rgba(16,185,129,0.2)]'
                  : 'ring-1 ring-rose-400/35'
            }`}
          >
            <WinCelebration
              stars={result.stars}
              passed={result.passed}
              goldenMode={result.sectionCompletionBonusPoints > 0}
            />

            <div className="space-y-2">
              <div
                className={`inline-flex items-center gap-2 text-sm font-bold ${
                  result.passed ? 'text-emerald-300' : 'text-rose-300'
                }`}
              >
                {result.passed ? (
                  <CheckCircle2 className="w-5 h-5 shrink-0" aria-hidden="true" />
                ) : (
                  <XCircle className="w-5 h-5 shrink-0" aria-hidden="true" />
                )}
                <span>{result.passed ? t.resultPassedTitle : t.resultFailedTitle}</span>
              </div>

              <div className="font-math text-4xl sm:text-5xl font-extrabold text-white tabular-nums">
                {result.score} <span className="text-xl text-slate-400">/ 100</span>
              </div>

              <p className="text-xs sm:text-sm text-slate-300">
                {t.resultCorrectOutOf(result.correctCount, result.totalQuestions)} ·{' '}
                {result.passed ? t.resultPassedSubtitle : t.resultFailedSubtitle}
              </p>
            </div>

            {/* Points & Unlock Feedback */}
            <div className="flex flex-wrap items-center justify-center gap-2.5 pt-1">
              {result.stageWinPoints > 0 && (
                <div className="px-4 py-2 rounded-2xl bg-emerald-500/20 border border-emerald-400/35 text-xs font-semibold text-emerald-200 inline-flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-emerald-300" aria-hidden="true" />
                  <span>{t.rewardStageWinBadge(result.stageWinPoints)}</span>
                </div>
              )}

              {result.perfectScoreBonusPoints > 0 && (
                <div className="px-4 py-2 rounded-2xl bg-amber-500/20 border border-amber-400/40 text-xs font-semibold text-amber-200 inline-flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-300" aria-hidden="true" />
                  <span>{t.rewardPerfectScoreBadge(result.perfectScoreBonusPoints)}</span>
                </div>
              )}

              {result.sectionCompletionBonusPoints > 0 && (
                <div className="px-4 py-2 rounded-2xl bg-violet-500/25 border border-violet-300/45 text-xs font-semibold text-violet-100 inline-flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-violet-200" aria-hidden="true" />
                  <span>{t.rewardSectionCompleteBadge(result.sectionCompletionBonusPoints)}</span>
                </div>
              )}

              {result.passed && result.rewardAlreadyClaimed && (
                <div className="px-4 py-2 rounded-2xl bg-white/[0.06] border border-white/15 text-xs font-medium text-slate-200">
                  {t.resultAlreadyClaimedBadge}
                </div>
              )}

              {result.unlockedNextStage && (
                <div className="px-4 py-2 rounded-2xl bg-blue-500/20 border border-blue-400/35 text-xs font-semibold text-blue-100">
                  {t.resultUnlockedNextBadge(result.unlockedNextStage)}
                </div>
              )}

              {result.passed && stageNumber === 30 && (
                <div className="px-4 py-2 rounded-2xl bg-violet-500/20 border border-violet-400/40 text-xs font-semibold text-violet-100">
                  {t.resultSectionReadyForExamBadge}
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center justify-center gap-3 pt-3">
              <button
                type="button"
                onClick={startFreshQuiz}
                className="liquid-glass-subtle min-h-[46px] px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white hover:bg-white/10 inline-flex items-center gap-2 whitespace-nowrap shrink-0"
              >
                <RotateCcw className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{t.retryStageBtn}</span>
              </button>

              <button
                type="button"
                onClick={() => setPhase('lesson')}
                className="liquid-glass-subtle min-h-[46px] px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-slate-200 hover:text-white hover:bg-white/10 inline-flex items-center gap-2 whitespace-nowrap shrink-0"
              >
                <BookOpen className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{t.reviewLessonAgainBtn}</span>
              </button>

              {stageNumber < 30 && (result.passed || isStageUnlocked(sectionId, stageNumber + 1)) && (
                <button
                  type="button"
                  onClick={() => onGoToNextStage(stageNumber + 1)}
                  className="liquid-glass-button min-h-[46px] px-6 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center gap-2 whitespace-nowrap shrink-0"
                >
                  <span>{t.nextStageBtn(stageNumber + 1)}</span>
                  <ForwardArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
                </button>
              )}

              {stageNumber === 30 && result.passed && (
                <button
                  type="button"
                  onClick={onBackToSection}
                  className="liquid-glass-button min-h-[46px] px-6 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center gap-2 whitespace-nowrap shrink-0"
                >
                  <span>{t.backToSectionBtn}</span>
                </button>
              )}
            </div>
          </LiquidGlassCard>

          {/* Complete Answer Key & Explanations */}
          <div className="space-y-3">
            <h2 className="font-display text-lg font-bold text-white px-1">
              {t.resultReviewHeading}
            </h2>
            {result.review.map((item, idx) => (
              <LiquidGlassCard
                key={item.questionId}
                variant="subtle"
                className={`p-5 space-y-3 ${
                  item.isCorrect ? 'border-emerald-400/30' : 'border-rose-400/30'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-2.5">
                    <span className="mt-0.5 shrink-0">
                      {item.isCorrect ? (
                        <CheckCircle2 className="w-5 h-5 text-emerald-400" aria-hidden="true" />
                      ) : (
                        <XCircle className="w-5 h-5 text-rose-400" aria-hidden="true" />
                      )}
                    </span>
                    <p className="text-sm sm:text-base font-semibold text-white leading-relaxed">
                      <span className="font-math text-slate-400 me-1.5">{idx + 1}.</span>
                      {language === 'ar' ? item.promptAr : item.promptEn}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs sm:text-sm">
                  <div
                    className={`p-3 rounded-xl border ${
                      item.isCorrect
                        ? 'bg-emerald-500/15 border-emerald-400/30 text-emerald-100'
                        : 'bg-rose-500/15 border-rose-400/30 text-rose-100'
                    }`}
                  >
                    <span className="block text-[11px] opacity-80 mb-0.5">
                      {t.resultYourAnswerLabel}
                    </span>
                    <span dir="auto" className="font-math font-bold">
                      {item.selectedIndex >= 0 ? item.options[item.selectedIndex] : '—'}
                    </span>
                  </div>

                  <div className="p-3 rounded-xl bg-emerald-500/12 border border-emerald-400/25 text-emerald-100">
                    <span className="block text-[11px] opacity-80 mb-0.5">
                      {t.resultCorrectAnswerLabel}
                    </span>
                    <span dir="auto" className="font-math font-bold">
                      {item.options[item.correctIndex]}
                    </span>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-white/[0.035] border border-white/10 text-xs sm:text-sm text-slate-200 leading-relaxed">
                  <span className="font-semibold text-blue-200 me-1.5">
                    {t.resultExplanationLabel}:
                  </span>
                  {language === 'ar' ? item.explanationAr : item.explanationEn}
                </div>
              </LiquidGlassCard>
            ))}
          </div>
        </div>
      )}
    </motion.section>
  );
}
