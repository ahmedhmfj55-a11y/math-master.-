import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Info,
  Layers,
  Lock,
  Play,
  RotateCcw,
  Sparkles,
  Unlock,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useMemo } from 'react';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useQuestionBank } from '@/src/contexts/QuestionBankContext';
import {
  BANK_DIFFICULTY_TIERS,
  BANK_TIER_MASTERY_POINTS,
  BANK_TIER_TARGET_COUNT,
  BANK_TOPICS,
  getGradeById,
} from '@/src/data/questionBank/catalog';
import { getAvailableQuestionCount } from '@/src/data/questionBank/bankEngine';
import type { BankDifficultyTier, GradeId } from '@/src/types/questionBank';

interface GradeLevelScreenProps {
  gradeId: GradeId;
  onBack: () => void;
  onStartQuiz: (gradeId: GradeId, tier: BankDifficultyTier) => void;
}

export function GradeLevelScreen({
  gradeId,
  onBack,
  onStartQuiz,
}: GradeLevelScreenProps) {
  const { language, direction, t } = useLanguage();
  const {
    getTierProgress,
    isBankTierUnlocked,
    getGradeMasteredTiersCount,
  } = useQuestionBank();

  const BackArrow = direction === 'rtl' ? ArrowRight : ArrowLeft;
  const grade = getGradeById(gradeId);

  const tierRows = useMemo(() => {
    return BANK_DIFFICULTY_TIERS.map((tierMeta) => ({
      meta: tierMeta,
      availableCount: getAvailableQuestionCount(gradeId, tierMeta.id),
      progress: getTierProgress(gradeId, tierMeta.id),
      unlocked: isBankTierUnlocked(gradeId, tierMeta.id),
    }));
  }, [gradeId, getTierProgress, isBankTierUnlocked]);

  const hasPartialVerifiedTiers = tierRows.some(
    (r) => r.availableCount < BANK_TIER_TARGET_COUNT,
  );
  const masteredCount = getGradeMasteredTiersCount(gradeId);

  if (!grade) {
    return null;
  }

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="min-h-dvh flex flex-col px-4 py-5 sm:px-8 sm:py-7 max-w-5xl mx-auto w-full gap-6 safe-pb-nav"
    >
      <div>
        <button
          type="button"
          onClick={onBack}
          className="liquid-glass-subtle min-h-[42px] px-4 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white hover:bg-white/10 inline-flex items-center gap-2 transition-colors"
        >
          <BackArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{t.bankBackToHubBtn}</span>
        </button>
      </div>

      {/* Grade Overview Header */}
      <LiquidGlassCard className="p-5 sm:p-8 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
          <div className="flex items-start gap-4">
            <div
              className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${grade.accentFrom} ${grade.accentTo} border border-white/30 flex items-center justify-center text-white font-math font-bold text-lg shrink-0 shadow-lg keep-white`}
            >
              {String(grade.order).padStart(2, '0')}
            </div>
            <div className="space-y-1.5">
              <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">
                {language === 'ar' ? grade.titleAr : grade.titleEn}
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-2xl">
                {language === 'ar' ? grade.subtitleAr : grade.subtitleEn}
              </p>
            </div>
          </div>

          <div className="px-4 py-2.5 rounded-2xl bg-white/[0.06] border border-white/15 text-center shrink-0 self-start">
            <div className="text-[11px] text-slate-400">{t.bankMasteredTiersLabel}</div>
            <div className="text-lg font-bold text-emerald-300 font-math tabular-nums">
              {masteredCount} / 5
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <div className="text-xs font-semibold text-slate-300">{t.bankGradeTopicsLabel}</div>
          <div className="flex flex-wrap gap-2">
            {grade.topics.map((topicId) => {
              const topic = BANK_TOPICS[topicId];
              return (
                <span
                  key={topicId}
                  className="px-3 py-1 rounded-xl bg-white/[0.06] border border-white/12 text-xs font-medium text-blue-100"
                >
                  {language === 'ar' ? topic.titleAr : topic.titleEn}
                </span>
              );
            })}
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-blue-500/10 border border-blue-400/25 text-xs text-blue-100 flex items-center gap-2.5">
          <Sparkles className="w-4 h-4 text-sky-300 shrink-0" aria-hidden="true" />
          <span>{t.bankTierUnlockRule}</span>
        </div>

        {hasPartialVerifiedTiers && (
          <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-400/30 text-xs text-amber-100 flex items-start gap-2.5">
            <Info className="w-4 h-4 text-amber-300 shrink-0 mt-0.5" aria-hidden="true" />
            <span>
              {language === 'ar'
                ? 'في المستويات البحثية والعالمية المتقدمة نُظهر عدد المسائل المتحققة رياضياً بدقة دون أي حشو آلي، مع تمييز المسائل البحثية المفتوحة غير المحلولة عالمياً.'
                : 'In advanced research and global tiers, exact verified problem counts are shown honestly without artificial filler, and open unsolved problems are clearly separated.'}
            </span>
          </div>
        )}
      </LiquidGlassCard>

      {/* 5 Difficulty Tier Cards */}
      <div className="space-y-3.5">
        {tierRows.map(({ meta, availableCount, progress, unlocked }) => {
          const mastered = Boolean(progress?.mastered);
          const canPlay = unlocked && availableCount > 0;

          return (
            <LiquidGlassCard
              key={meta.id}
              variant="subtle"
              className={`p-5 transition-all ${
                mastered
                  ? 'border-emerald-400/40 bg-emerald-500/[0.06]'
                  : unlocked
                    ? 'border-white/15 hover:bg-white/[0.08]'
                    : 'opacity-70 border-white/10'
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-start gap-4 min-w-0 flex-1">
                  <div
                    className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${meta.accentClass} border flex items-center justify-center text-white shrink-0 shadow-md keep-white`}
                  >
                    {mastered ? (
                      <CheckCircle2 className="w-6 h-6" aria-hidden="true" />
                    ) : unlocked ? (
                      <Unlock className="w-5 h-5" aria-hidden="true" />
                    ) : (
                      <Lock className="w-5 h-5" aria-hidden="true" />
                    )}
                  </div>

                  <div className="space-y-1.5 min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-xs font-math text-slate-400">
                        {String(meta.order).padStart(2, '0')} / 05
                      </span>
                      <h2 className="font-display text-lg font-bold text-white">
                        {language === 'ar' ? meta.titleAr : meta.titleEn}
                      </h2>
                      <span className="px-2.5 py-0.5 rounded-lg bg-white/[0.07] border border-white/12 text-[11px] font-math text-sky-200 inline-flex items-center gap-1">
                        <Layers className="w-3 h-3 shrink-0" aria-hidden="true" />
                        <span>
                          {availableCount} {language === 'ar' ? 'سؤال متحقق' : 'verified'}
                        </span>
                      </span>
                      {mastered && (
                        <span className="px-2.5 py-0.5 rounded-lg bg-emerald-500/20 border border-emerald-400/35 text-[11px] font-semibold text-emerald-200">
                          {t.stageCompletedLabel}
                        </span>
                      )}
                    </div>

                    {availableCount < BANK_TIER_TARGET_COUNT && (
                      <p className="text-xs text-amber-200/90">
                        {t.bankHonestCountNote(availableCount, BANK_TIER_TARGET_COUNT)}
                      </p>
                    )}

                    <div className="flex flex-wrap items-center gap-3 text-xs text-slate-300 font-math">
                      <span>
                        +{BANK_TIER_MASTERY_POINTS} {t.leaderboardPointsUnit}
                      </span>
                      {progress && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span>{t.stageBestScoreLabel(progress.bestScore)}</span>
                          <span aria-hidden="true">·</span>
                          <span>{t.stageAttemptsLabel(progress.attempts)}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="shrink-0">
                  {canPlay ? (
                    <button
                      type="button"
                      onClick={() => onStartQuiz(gradeId, meta.id)}
                      className="liquid-glass-button w-full md:w-auto min-h-[46px] px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center justify-center gap-2 whitespace-nowrap"
                    >
                      {progress ? (
                        <RotateCcw className="w-4 h-4 shrink-0" aria-hidden="true" />
                      ) : (
                        <Play className="w-4 h-4 shrink-0" aria-hidden="true" />
                      )}
                      <span>{progress ? t.bankTierReplayBtn : t.bankTierStartBtn}</span>
                    </button>
                  ) : (
                    <div className="min-h-[46px] px-4 py-2.5 rounded-2xl bg-white/[0.04] border border-white/10 text-xs font-semibold text-slate-400 inline-flex items-center justify-center gap-2">
                      <Lock className="w-4 h-4 shrink-0" aria-hidden="true" />
                      <span>{t.bankTierLockedBtn}</span>
                    </div>
                  )}
                </div>
              </div>
            </LiquidGlassCard>
          );
        })}
      </div>
    </motion.section>
  );
}
