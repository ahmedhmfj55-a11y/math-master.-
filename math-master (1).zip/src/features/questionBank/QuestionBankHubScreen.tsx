import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  BrainCircuit,
  CheckCircle2,
  Crown,
  Flame,
  GraduationCap,
  Layers,
  Sparkles,
  Target,
  TrendingUp,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useMemo, useState } from 'react';
import { AppTopBar, type HubTab } from '@/src/components/ui/AppTopBar';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useQuestionBank } from '@/src/contexts/QuestionBankContext';
import {
  BANK_TOPICS,
  GENIUS_SOLVE_POINTS,
  GRADE_LEVELS,
  getGradeByOrder,
  getTierMeta,
} from '@/src/data/questionBank/catalog';
import {
  WORLD_GENIUS_CHALLENGES,
  analyzeStudentPerformance,
  getAvailableQuestionCount,
  getTotalVerifiedQuestionCount,
} from '@/src/data/questionBank/bankEngine';
import type {
  BankDifficultyTier,
  BankTopicId,
  GradeId,
  GradeStageBand,
} from '@/src/types/questionBank';

interface QuestionBankHubScreenProps {
  onNavigate: (tab: HubTab) => void;
  onSelectGrade: (gradeId: GradeId) => void;
  onStartAdaptiveQuiz: (
    gradeId: GradeId,
    tier: BankDifficultyTier,
    focusTopicId?: BankTopicId,
  ) => void;
  onOpenGeniusChallenges: () => void;
}

type BandFilter = 'all' | GradeStageBand;

export function QuestionBankHubScreen({
  onNavigate,
  onSelectGrade,
  onStartAdaptiveQuiz,
  onOpenGeniusChallenges,
}: QuestionBankHubScreenProps) {
  const { language, direction, t } = useLanguage();
  const {
    bankProgressMap,
    adaptiveProfile,
    loadingBank,
    getGradeMasteredTiersCount,
  } = useQuestionBank();
  const [bandFilter, setBandFilter] = useState<BandFilter>('all');

  const BackArrow = direction === 'rtl' ? ArrowRight : ArrowLeft;
  const ForwardArrow = direction === 'rtl' ? ArrowLeft : ArrowRight;

  const totalVerifiedQuestions = useMemo(() => getTotalVerifiedQuestionCount(), []);

  const masteredTiersCount = useMemo(() => {
    return GRADE_LEVELS.reduce((acc, g) => acc + getGradeMasteredTiersCount(g.id), 0);
  }, [getGradeMasteredTiersCount]);

  const diagnostics = useMemo(
    () => analyzeStudentPerformance(adaptiveProfile),
    [adaptiveProfile],
  );

  const recGradeOrder = adaptiveProfile?.recommendedGradeNumber ?? 1;
  const recGrade = getGradeByOrder(recGradeOrder) ?? GRADE_LEVELS[0];
  const recTier = adaptiveProfile?.recommendedTier ?? 'very_easy';
  const recTierMeta = getTierMeta(recTier);

  const solvedGeniusTotal = useMemo(
    () => WORLD_GENIUS_CHALLENGES.filter((c) => c.status === 'solved_verified').length,
    [],
  );

  const userGeniusSolved = useMemo(() => {
    return Object.values(bankProgressMap).filter(
      (r) => r.bankKey.startsWith('genius-') && r.mastered,
    ).length;
  }, [bankProgressMap]);

  const filteredGrades = useMemo(() => {
    if (bandFilter === 'all') return GRADE_LEVELS;
    return GRADE_LEVELS.filter((g) => g.band === bandFilter);
  }, [bandFilter]);

  const handlePracticeWeakTopic = (topicId: BankTopicId) => {
    const preferred =
      recGrade.topics.includes(topicId)
        ? recGrade
        : GRADE_LEVELS.find((g) => g.topics.includes(topicId)) ?? recGrade;
    const tierForPractice = preferred.id === recGrade.id ? recTier : 'very_easy';
    onStartAdaptiveQuiz(preferred.id, tierForPractice, topicId);
  };

  const bandTabs: { id: BandFilter; label: string }[] = [
    { id: 'all', label: t.bankBandAll },
    { id: 'elementary', label: t.bankBandElementary },
    { id: 'middle', label: t.bankBandMiddle },
    { id: 'high', label: t.bankBandHigh },
    { id: 'university_research', label: t.bankBandUniversityResearch },
  ];

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="min-h-dvh flex flex-col px-4 py-5 sm:px-8 sm:py-7 max-w-6xl mx-auto w-full gap-6 safe-pb-nav"
    >
      <AppTopBar activeTab="question-bank" onNavigate={onNavigate} />

      {/* Header + Verified Summary Metrics */}
      <LiquidGlassCard className="p-5 sm:p-7 space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <button
              type="button"
              onClick={() => onNavigate('home')}
              className="text-xs font-semibold text-blue-200 hover:text-white inline-flex items-center gap-1.5 mb-1 transition-colors"
            >
              <BackArrow className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{t.backToHomeBtn}</span>
            </button>
            <div className="flex items-center gap-2 text-xs font-semibold text-sky-300">
              <GraduationCap className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>18 · {t.navQuestionBank}</span>
            </div>
            <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">
              {t.bankHubTitle}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              {t.bankHubSubtitle}
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 shrink-0">
            <div className="px-3.5 py-2.5 rounded-2xl bg-white/[0.05] border border-white/10 text-center">
              <div className="text-[11px] text-slate-400 flex items-center justify-center gap-1">
                <Layers className="w-3.5 h-3.5 text-sky-300 shrink-0" aria-hidden="true" />
                <span className="truncate">{t.bankTotalQuestionsLabel}</span>
              </div>
              <div className="text-base sm:text-lg font-bold text-white font-math tabular-nums">
                {totalVerifiedQuestions.toLocaleString()}
              </div>
            </div>

            <div className="px-3.5 py-2.5 rounded-2xl bg-white/[0.05] border border-white/10 text-center">
              <div className="text-[11px] text-slate-400 flex items-center justify-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300 shrink-0" aria-hidden="true" />
                <span className="truncate">{t.bankMasteredTiersLabel}</span>
              </div>
              <div className="text-base sm:text-lg font-bold text-emerald-300 font-math tabular-nums">
                {masteredTiersCount} / {GRADE_LEVELS.length * 5}
              </div>
            </div>

            <div className="px-3.5 py-2.5 rounded-2xl bg-white/[0.05] border border-white/10 text-center">
              <div className="text-[11px] text-slate-400 flex items-center justify-center gap-1">
                <Target className="w-3.5 h-3.5 text-violet-300 shrink-0" aria-hidden="true" />
                <span className="truncate">{t.bankAccuracyLabel}</span>
              </div>
              <div className="text-base sm:text-lg font-bold text-violet-200 font-math tabular-nums">
                {diagnostics.overallAccuracy}%
              </div>
            </div>

            <div className="px-3.5 py-2.5 rounded-2xl bg-white/[0.05] border border-white/10 text-center">
              <div className="text-[11px] text-slate-400 flex items-center justify-center gap-1">
                <Crown className="w-3.5 h-3.5 text-amber-300 shrink-0" aria-hidden="true" />
                <span className="truncate">{t.bankGeniusSolvedLabel}</span>
              </div>
              <div className="text-base sm:text-lg font-bold text-amber-300 font-math tabular-nums">
                {userGeniusSolved} / {solvedGeniusTotal}
              </div>
            </div>
          </div>
        </div>
      </LiquidGlassCard>

      {/* Two Primary Bank Pillars: Adaptive Smart Practice + World Genius Arena */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Adaptive Smart Recommendation Card */}
        <LiquidGlassCard className="p-5 sm:p-6 border-sky-400/35 bg-gradient-to-br from-sky-500/16 via-blue-500/10 to-indigo-600/18 flex flex-col justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-sky-500 to-indigo-600 border border-white/30 flex items-center justify-center text-white shrink-0 shadow-[0_8px_24px_rgba(56,189,248,0.35)]">
              <BrainCircuit className="w-6 h-6" aria-hidden="true" />
            </div>
            <div className="space-y-1.5 min-w-0 flex-1">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-sky-500/20 border border-sky-300/35 text-[11px] font-semibold text-sky-200">
                <Sparkles className="w-3 h-3 shrink-0" aria-hidden="true" />
                <span>{t.bankAdaptiveCardTitle}</span>
              </div>
              <h2 className="font-display text-lg sm:text-xl font-bold text-white">
                {language === 'ar' ? recGrade.titleAr : recGrade.titleEn}
              </h2>
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-300">
                <span className="px-2.5 py-0.5 rounded-lg bg-white/[0.08] border border-white/15 font-semibold text-white">
                  {language === 'ar' ? recTierMeta.titleAr : recTierMeta.titleEn}
                </span>
                <span className="truncate">
                  {language === 'ar' ? recGrade.subtitleAr : recGrade.subtitleEn}
                </span>
              </div>
            </div>
          </div>

          <button
            type="button"
            disabled={loadingBank}
            onClick={() => onStartAdaptiveQuiz(recGrade.id, recTier)}
            className="liquid-glass-button w-full min-h-[46px] px-5 py-2.5 rounded-2xl text-sm font-semibold text-white inline-flex items-center justify-center gap-2 disabled:opacity-60"
          >
            <BrainCircuit className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>{t.bankAdaptiveStartBtn}</span>
            <ForwardArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
          </button>
        </LiquidGlassCard>

        {/* World Genius Challenges Arena Card */}
        <LiquidGlassCard className="p-5 sm:p-6 border-amber-400/35 bg-gradient-to-br from-amber-500/16 via-orange-500/10 to-rose-600/16 flex flex-col justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-rose-600 border border-white/30 flex items-center justify-center text-white shrink-0 shadow-[0_8px_24px_rgba(245,158,11,0.35)]">
              <Crown className="w-6 h-6" aria-hidden="true" />
            </div>
            <div className="space-y-1.5 min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2 text-[11px] font-semibold">
                <span className="px-2.5 py-0.5 rounded-lg bg-amber-500/20 border border-amber-300/35 text-amber-200 font-math">
                  +{GENIUS_SOLVE_POINTS} {t.leaderboardPointsUnit}
                </span>
                <span className="px-2.5 py-0.5 rounded-lg bg-white/[0.08] border border-white/15 text-slate-200 font-math">
                  {WORLD_GENIUS_CHALLENGES.length}
                </span>
              </div>
              <h2 className="font-display text-lg sm:text-xl font-bold text-white">
                {t.bankGeniusCardTitle}
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {t.bankGeniusCardDesc}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onOpenGeniusChallenges}
            className="liquid-glass-button w-full min-h-[46px] px-5 py-2.5 rounded-2xl text-sm font-semibold text-white inline-flex items-center justify-center gap-2"
          >
            <Flame className="w-4 h-4 text-amber-200 shrink-0" aria-hidden="true" />
            <span>{t.bankGeniusOpenBtn}</span>
            <ForwardArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
          </button>
        </LiquidGlassCard>
      </div>

      {/* Adaptive Strengths & Weaknesses Diagnostic Report */}
      <LiquidGlassCard variant="subtle" className="p-5 sm:p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <TrendingUp className="w-5 h-5 text-sky-300 shrink-0" aria-hidden="true" />
            <h2 className="font-display text-base sm:text-lg font-bold text-white">
              {t.bankDiagnosticsTitle}
            </h2>
          </div>
          {adaptiveProfile && adaptiveProfile.totalQuizzesCompleted > 0 && (
            <span className="text-xs font-math text-slate-300">
              {adaptiveProfile.totalBankCorrect} / {adaptiveProfile.totalBankQuestionsAnswered} (
              {diagnostics.overallAccuracy}%)
            </span>
          )}
        </div>

        {diagnostics.allTopics.length === 0 ? (
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            {t.bankDiagnosticsEmpty}
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Strengths */}
            <div className="p-4 rounded-2xl bg-emerald-500/[0.07] border border-emerald-400/25 space-y-3">
              <div className="text-xs font-bold text-emerald-200 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{t.bankStrengthsHeading}</span>
              </div>
              {diagnostics.strengths.length === 0 ? (
                <p className="text-xs text-slate-400">—</p>
              ) : (
                <div className="space-y-2">
                  {diagnostics.strengths.slice(0, 4).map((row) => (
                    <div
                      key={row.topicId}
                      className="flex items-center justify-between gap-2 text-xs px-3 py-2 rounded-xl bg-white/[0.04]"
                    >
                      <span className="font-semibold text-white truncate">
                        {language === 'ar' ? row.titleAr : row.titleEn}
                      </span>
                      <span className="font-math font-bold text-emerald-300 shrink-0">
                        {row.accuracy}% ({row.correct}/{row.attempted})
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Weaknesses & Targeted Practice CTA */}
            <div className="p-4 rounded-2xl bg-amber-500/[0.07] border border-amber-400/25 space-y-3">
              <div className="text-xs font-bold text-amber-200 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{t.bankWeaknessesHeading}</span>
              </div>
              {diagnostics.weaknesses.length === 0 ? (
                <p className="text-xs text-emerald-200">
                  {language === 'ar'
                    ? 'جميع مهاراتك المختبرة فوق عتبة الإتقان!'
                    : 'All tested skills are currently above the mastery threshold!'}
                </p>
              ) : (
                <div className="space-y-2">
                  {diagnostics.weaknesses.slice(0, 4).map((row) => (
                    <div
                      key={row.topicId}
                      className="flex items-center justify-between gap-2 text-xs px-3 py-2 rounded-xl bg-white/[0.04]"
                    >
                      <div className="min-w-0">
                        <div className="font-semibold text-white truncate">
                          {language === 'ar' ? row.titleAr : row.titleEn}
                        </div>
                        <div className="text-[11px] font-math text-amber-200">
                          {row.accuracy}% ({row.correct}/{row.attempted})
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handlePracticeWeakTopic(row.topicId)}
                        className="px-3 py-1.5 rounded-xl bg-amber-500/25 hover:bg-amber-500/40 border border-amber-300/40 text-amber-100 text-[11px] font-semibold shrink-0 transition-colors"
                      >
                        {t.bankPracticeWeakBtn}
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </LiquidGlassCard>

      {/* Band Filters */}
      <div className="flex flex-wrap items-center gap-2">
        {bandTabs.map((tab) => {
          const active = bandFilter === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setBandFilter(tab.id)}
              className={`min-h-[40px] px-4 py-1.5 rounded-2xl text-xs font-semibold transition-all ${
                active
                  ? 'liquid-glass-button text-white'
                  : 'liquid-glass-subtle text-slate-300 hover:text-white hover:bg-white/[0.08]'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* 18 Educational Levels Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredGrades.map((grade) => {
          const masteredTiers = getGradeMasteredTiersCount(grade.id);
          const gradeVerifiedCount =
            getAvailableQuestionCount(grade.id, 'very_easy') +
            getAvailableQuestionCount(grade.id, 'easy') +
            getAvailableQuestionCount(grade.id, 'medium') +
            getAvailableQuestionCount(grade.id, 'hard') +
            getAvailableQuestionCount(grade.id, 'very_hard');
          const pct = Math.round((masteredTiers / 5) * 100);
          const isRecommended = grade.order === recGradeOrder;

          return (
            <LiquidGlassCard
              key={grade.id}
              variant="subtle"
              className={`p-5 flex flex-col justify-between gap-4 transition-all hover:bg-white/[0.08] ${
                isRecommended ? 'border-sky-400/50 shadow-[0_8px_30px_rgba(56,189,248,0.16)]' : ''
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div
                    className={`w-11 h-11 rounded-2xl bg-gradient-to-br ${grade.accentFrom} ${grade.accentTo} border border-white/30 flex items-center justify-center text-white font-math font-bold text-sm shrink-0 shadow-md keep-white`}
                  >
                    {String(grade.order).padStart(2, '0')}
                  </div>

                  <div className="flex flex-wrap items-center justify-end gap-1.5">
                    <span className="px-2.5 py-0.5 rounded-lg bg-white/[0.07] border border-white/10 text-[11px] font-math text-slate-200">
                      {gradeVerifiedCount} {language === 'ar' ? 'سؤال' : 'Q'}
                    </span>
                    <span
                      className={`px-2.5 py-0.5 rounded-lg border text-[11px] font-math font-semibold ${
                        masteredTiers === 5
                          ? 'bg-emerald-500/20 border-emerald-400/40 text-emerald-200'
                          : 'bg-white/[0.05] border-white/10 text-slate-300'
                      }`}
                    >
                      {masteredTiers}/5
                    </span>
                  </div>
                </div>

                <div className="space-y-1">
                  <h3 className="font-display text-base sm:text-lg font-bold text-white leading-snug">
                    {language === 'ar' ? grade.titleAr : grade.titleEn}
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed line-clamp-2">
                    {language === 'ar' ? grade.subtitleAr : grade.subtitleEn}
                  </p>
                </div>

                <div className="flex flex-wrap gap-1.5">
                  {grade.topics.slice(0, 3).map((topicId) => {
                    const topic = BANK_TOPICS[topicId];
                    return (
                      <span
                        key={topicId}
                        className="px-2 py-0.5 rounded-lg bg-white/[0.05] border border-white/10 text-[10px] font-medium text-slate-300"
                      >
                        {language === 'ar' ? topic.titleAr : topic.titleEn}
                      </span>
                    );
                  })}
                </div>
              </div>

              <div className="space-y-3 pt-1">
                <div className="h-1.5 w-full rounded-full bg-white/10 overflow-hidden">
                  <div
                    className={`h-full rounded-full bg-gradient-to-r ${grade.accentFrom} ${grade.accentTo} transition-all duration-500`}
                    style={{ width: `${pct}%` }}
                  />
                </div>

                <button
                  type="button"
                  onClick={() => onSelectGrade(grade.id)}
                  className="liquid-glass-button w-full min-h-[42px] px-4 py-2 rounded-2xl text-xs font-semibold text-white inline-flex items-center justify-center gap-2"
                >
                  <span>{t.bankEnterGradeBtn}</span>
                  <ForwardArrow className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                </button>
              </div>
            </LiquidGlassCard>
          );
        })}
      </div>
    </motion.section>
  );
}
