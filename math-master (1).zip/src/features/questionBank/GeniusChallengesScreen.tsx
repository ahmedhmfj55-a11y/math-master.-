import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Crown,
  FlaskConical,
  Lightbulb,
  Sparkles,
  XCircle,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useMemo, useState } from 'react';
import { AppTopBar, type HubTab } from '@/src/components/ui/AppTopBar';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useQuestionBank } from '@/src/contexts/QuestionBankContext';
import { WORLD_GENIUS_CHALLENGES } from '@/src/data/questionBank/bankEngine';
import { GENIUS_SOLVE_POINTS } from '@/src/data/questionBank/catalog';
import type { GeniusChallengeItem } from '@/src/types/questionBank';

interface GeniusChallengesScreenProps {
  onNavigate: (tab: HubTab) => void;
  onBackToBank: () => void;
}

type GeniusFilter = 'all' | 'solved_verified' | 'open_research';
const OPTION_LETTERS = ['A', 'B', 'C', 'D'] as const;

export function GeniusChallengesScreen({
  onNavigate,
  onBackToBank,
}: GeniusChallengesScreenProps) {
  const { language, direction, t } = useLanguage();
  const { getGeniusProgress, submitGeniusChallenge, submittingBank } = useQuestionBank();
  const [filter, setFilter] = useState<GeniusFilter>('all');
  const [expandedId, setExpandedId] = useState<string | null>(
    WORLD_GENIUS_CHALLENGES[0]?.id ?? null,
  );
  const [hintOpenIds, setHintOpenIds] = useState<Record<string, boolean>>({});
  const [draftAnswers, setDraftAnswers] = useState<
    Record<string, { selectedIndex?: number; writtenValue?: string }>
  >({});
  const [feedbackById, setFeedbackById] = useState<
    Record<
      string,
      {
        isCorrect: boolean;
        pointsAwarded: number;
        userAnswerDisplay: string;
      }
    >
  >({});

  const BackArrow = direction === 'rtl' ? ArrowRight : ArrowLeft;

  const filteredChallenges = useMemo(() => {
    if (filter === 'all') return WORLD_GENIUS_CHALLENGES;
    return WORLD_GENIUS_CHALLENGES.filter((c) => c.status === filter);
  }, [filter]);

  const solvedTotal = useMemo(
    () => WORLD_GENIUS_CHALLENGES.filter((c) => c.status === 'solved_verified').length,
    [],
  );

  const solvedByUser = useMemo(
    () =>
      WORLD_GENIUS_CHALLENGES.filter((c) => Boolean(getGeniusProgress(c.id)?.mastered)).length,
    [getGeniusProgress],
  );

  const handleCheckChallenge = async (challenge: GeniusChallengeItem) => {
    const ans = draftAnswers[challenge.id];
    if (!ans) return;
    if (challenge.question.format === 'written' && !ans.writtenValue?.trim()) return;
    if (challenge.question.format !== 'written' && ans.selectedIndex === undefined) return;

    const res = await submitGeniusChallenge({
      challenge,
      answer: ans,
    });
    setFeedbackById((prev) => ({
      ...prev,
      [challenge.id]: {
        isCorrect: res.isCorrect,
        pointsAwarded: res.pointsAwarded,
        userAnswerDisplay: res.userAnswerDisplay,
      },
    }));
  };

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="min-h-dvh flex flex-col px-4 py-5 sm:px-8 sm:py-7 max-w-6xl mx-auto w-full gap-6 safe-pb-nav"
    >
      <AppTopBar activeTab="question-bank" onNavigate={onNavigate} />

      <LiquidGlassCard className="p-5 sm:p-8 space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <button
              type="button"
              onClick={onBackToBank}
              className="text-xs font-semibold text-blue-200 hover:text-white inline-flex items-center gap-1.5 mb-1 transition-colors"
            >
              <BackArrow className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{t.bankBackToHubBtn}</span>
            </button>
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-amber-300">
              <Crown className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>{t.bankGeniusRewardBadge}</span>
            </div>
            <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">
              {t.bankGeniusCardTitle}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              {t.bankGeniusCardDesc}
            </p>
          </div>

          <div className="px-4 py-3 rounded-2xl bg-white/[0.06] border border-white/15 text-center shrink-0 self-start">
            <div className="text-[11px] text-slate-400">{t.bankGeniusSolvedLabel}</div>
            <div className="text-xl font-bold text-amber-300 font-math tabular-nums">
              {solvedByUser} / {solvedTotal}
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {(
            [
              { id: 'all', label: `${t.bankGeniusFilterAll} (${WORLD_GENIUS_CHALLENGES.length})` },
              {
                id: 'solved_verified',
                label: `${t.bankGeniusFilterSolved} (${solvedTotal})`,
              },
              {
                id: 'open_research',
                label: `${t.bankGeniusFilterOpen} (${WORLD_GENIUS_CHALLENGES.length - solvedTotal})`,
              },
            ] as const
          ).map((tab) => {
            const active = filter === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setFilter(tab.id)}
                className={`min-h-[38px] px-4 py-1.5 rounded-2xl text-xs font-semibold transition-all ${
                  active
                    ? 'liquid-glass-button text-white'
                    : 'liquid-glass-subtle text-slate-300 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </LiquidGlassCard>

      {/* Challenges List */}
      <div className="space-y-4">
        {filteredChallenges.map((challenge) => {
          const isOpenResearch = challenge.status === 'open_research';
          const progress = getGeniusProgress(challenge.id);
          const alreadySolved = Boolean(progress?.mastered);
          const isExpanded = expandedId === challenge.id;
          const q = challenge.question;
          const draft = draftAnswers[challenge.id];
          const feedback = feedbackById[challenge.id];
          const hintVisible = Boolean(hintOpenIds[challenge.id]);
          const steps = language === 'ar' ? q.stepsAr : q.stepsEn;

          return (
            <LiquidGlassCard
              key={challenge.id}
              variant="subtle"
              className={`p-5 sm:p-6 space-y-4 ${
                isOpenResearch
                  ? 'border-amber-400/35 bg-amber-500/[0.04]'
                  : alreadySolved
                    ? 'border-emerald-400/40 bg-emerald-500/[0.05]'
                    : 'border-white/15'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                <div className="space-y-1.5 min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2 text-[11px] font-semibold">
                    <span
                      className={`px-2.5 py-0.5 rounded-lg border inline-flex items-center gap-1 ${
                        isOpenResearch
                          ? 'bg-amber-500/20 border-amber-400/40 text-amber-200'
                          : 'bg-emerald-500/20 border-emerald-400/40 text-emerald-200'
                      }`}
                    >
                      {isOpenResearch ? (
                        <FlaskConical className="w-3 h-3 shrink-0" aria-hidden="true" />
                      ) : (
                        <CheckCircle2 className="w-3 h-3 shrink-0" aria-hidden="true" />
                      )}
                      <span>
                        {isOpenResearch ? t.bankGeniusBadgeOpen : t.bankGeniusBadgeSolved}
                      </span>
                    </span>

                    <span className="px-2.5 py-0.5 rounded-lg bg-white/[0.06] border border-white/12 text-slate-300">
                      {language === 'ar' ? challenge.sourceLabelAr : challenge.sourceLabelEn}
                    </span>

                    {alreadySolved && (
                      <span className="px-2.5 py-0.5 rounded-lg bg-violet-500/20 border border-violet-400/35 text-violet-200">
                        {t.bankGeniusSolvedStamp}
                      </span>
                    )}
                  </div>

                  <h2 className="font-display text-lg sm:text-xl font-bold text-white">
                    {language === 'ar' ? challenge.titleAr : challenge.titleEn}
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                    {language === 'ar' ? challenge.statementAr : challenge.statementEn}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setExpandedId(isExpanded ? null : challenge.id)}
                  className="liquid-glass-subtle min-h-[40px] px-4 py-2 rounded-2xl text-xs font-semibold text-white hover:bg-white/10 shrink-0 self-start"
                >
                  {isExpanded
                    ? language === 'ar'
                      ? 'إخفاء مساحة الحل'
                      : 'Collapse'
                    : language === 'ar'
                      ? 'فتح التحدي'
                      : 'Open Challenge'}
                </button>
              </div>

              {isOpenResearch && (challenge.partialProgressAr || challenge.partialProgressEn) && (
                <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-400/30 text-xs text-amber-100 flex items-start gap-2.5">
                  <AlertTriangle className="w-4 h-4 text-amber-300 shrink-0 mt-0.5" />
                  <div className="space-y-0.5">
                    <div className="font-bold">{t.bankGeniusPartialProgressLabel}</div>
                    <p className="leading-relaxed">
                      {language === 'ar'
                        ? challenge.partialProgressAr
                        : challenge.partialProgressEn}
                    </p>
                  </div>
                </div>
              )}

              {isExpanded && (
                <div className="pt-3 border-t border-white/10 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="text-sm sm:text-base font-semibold text-white leading-relaxed">
                      {language === 'ar' ? q.promptAr : q.promptEn}
                    </p>

                    <button
                      type="button"
                      onClick={() =>
                        setHintOpenIds((prev) => ({
                          ...prev,
                          [challenge.id]: !prev[challenge.id],
                        }))
                      }
                      className="liquid-glass-subtle min-h-[34px] px-3 py-1 rounded-xl text-xs font-semibold text-amber-200 inline-flex items-center gap-1.5"
                    >
                      <Lightbulb className="w-3.5 h-3.5" />
                      <span>{hintVisible ? t.bankQuizHideHintBtn : t.bankQuizShowHintBtn}</span>
                    </button>
                  </div>

                  {hintVisible && (
                    <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-400/25 text-xs text-amber-100 leading-relaxed">
                      {language === 'ar' ? q.hintAr : q.hintEn}
                    </div>
                  )}

                  {q.format === 'written' ? (
                    <input
                      type="text"
                      dir="ltr"
                      value={draft?.writtenValue ?? ''}
                      onChange={(e) =>
                        setDraftAnswers((prev) => ({
                          ...prev,
                          [challenge.id]: { writtenValue: e.target.value },
                        }))
                      }
                      placeholder={t.bankQuizWrittenPlaceholder}
                      className="liquid-glass-input w-full min-h-[48px] px-4 rounded-2xl text-base font-math text-white placeholder:text-slate-400 focus:outline-none"
                    />
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {(q.options ?? []).map((opt, optIdx) => {
                        const selected = draft?.selectedIndex === optIdx;
                        return (
                          <button
                            key={optIdx}
                            type="button"
                            onClick={() =>
                              setDraftAnswers((prev) => ({
                                ...prev,
                                [challenge.id]: { selectedIndex: optIdx },
                              }))
                            }
                            className={`min-h-[52px] p-3.5 rounded-2xl border text-start flex items-center gap-3 transition-all ${
                              selected
                                ? 'bg-gradient-to-br from-blue-500/30 to-violet-600/30 border-blue-400 text-white'
                                : 'bg-white/[0.04] border-white/12 hover:bg-white/[0.08] text-slate-100'
                            }`}
                          >
                            <span
                              className={`w-7 h-7 rounded-xl font-math text-xs font-bold flex items-center justify-center shrink-0 ${
                                selected
                                  ? 'bg-blue-500 text-white'
                                  : 'bg-white/[0.08] text-slate-300'
                              }`}
                            >
                              {OPTION_LETTERS[optIdx]}
                            </span>
                            <span className="font-math text-xs sm:text-sm font-semibold" dir="auto">
                              {opt}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  )}

                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <button
                      type="button"
                      disabled={submittingBank}
                      onClick={() => void handleCheckChallenge(challenge)}
                      className="liquid-glass-button min-h-[44px] px-5 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center gap-2 disabled:opacity-60"
                    >
                      <Sparkles className="w-4 h-4 shrink-0" aria-hidden="true" />
                      <span>{t.bankGeniusSubmitCheckBtn}</span>
                    </button>

                    {!alreadySolved && (
                      <span className="text-xs font-math text-amber-200">
                        +{GENIUS_SOLVE_POINTS} {t.leaderboardPointsUnit}
                      </span>
                    )}
                  </div>

                  {(feedback || alreadySolved) && (
                    <div
                      className={`p-4 rounded-2xl border space-y-2.5 ${
                        feedback
                          ? feedback.isCorrect
                            ? 'bg-emerald-500/10 border-emerald-400/35'
                            : 'bg-rose-500/10 border-rose-400/35'
                          : 'bg-emerald-500/10 border-emerald-400/30'
                      }`}
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-bold">
                        {feedback ? (
                          <span
                            className={`inline-flex items-center gap-1.5 ${
                              feedback.isCorrect ? 'text-emerald-300' : 'text-rose-300'
                            }`}
                          >
                            {feedback.isCorrect ? (
                              <CheckCircle2 className="w-4 h-4" />
                            ) : (
                              <XCircle className="w-4 h-4" />
                            )}
                            <span>
                              {feedback.isCorrect ? t.resultPassedTitle : t.resultFailedTitle}
                            </span>
                          </span>
                        ) : (
                          <span className="text-emerald-300 inline-flex items-center gap-1.5">
                            <CheckCircle2 className="w-4 h-4" />
                            <span>{t.bankGeniusSolvedStamp}</span>
                          </span>
                        )}

                        {feedback && feedback.pointsAwarded > 0 && (
                          <span className="px-2.5 py-0.5 rounded-lg bg-violet-500/25 border border-violet-300/40 text-violet-100 font-math">
                            +{feedback.pointsAwarded} {t.leaderboardPointsUnit}
                          </span>
                        )}
                      </div>

                      {(feedback?.isCorrect || alreadySolved) && (
                        <div className="space-y-2 text-xs text-slate-200">
                          <div className="font-math text-emerald-300" dir="ltr">
                            {t.resultCorrectAnswerLabel}: {q.displayAnswer}
                          </div>
                          {steps.length > 0 && (
                            <ol className="list-decimal list-inside space-y-1">
                              {steps.map((step, sIdx) => (
                                <li key={sIdx} className="leading-relaxed">
                                  {step}
                                </li>
                              ))}
                            </ol>
                          )}
                          <p className="text-slate-300 leading-relaxed">
                            {language === 'ar' ? q.explanationAr : q.explanationEn}
                          </p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </LiquidGlassCard>
          );
        })}
      </div>
    </motion.section>
  );
}
