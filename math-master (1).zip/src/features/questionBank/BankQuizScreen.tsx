import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  BookOpen,
  CheckCircle2,
  Lightbulb,
  RotateCcw,
  Sparkles,
  TrendingUp,
  XCircle,
} from 'lucide-react';
import { motion } from 'motion/react';
import { useState } from 'react';
import { LiquidGlassCard } from '@/src/components/ui/LiquidGlassCard';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useQuestionBank } from '@/src/contexts/QuestionBankContext';
import {
  BANK_TOPICS,
  getGradeById,
  getTierMeta,
} from '@/src/data/questionBank/catalog';
import { selectAdaptiveQuizQuestions } from '@/src/data/questionBank/bankEngine';
import type {
  BankDifficultyTier,
  BankQuestion,
  BankQuizSubmissionResult,
  BankTopicId,
  GradeId,
} from '@/src/types/questionBank';

interface BankQuizScreenProps {
  gradeId: GradeId;
  tier: BankDifficultyTier;
  focusTopicId?: BankTopicId;
  onBackToGrade: () => void;
  onNextTier: (nextTier: BankDifficultyTier) => void;
}

const OPTION_LETTERS = ['A', 'B', 'C', 'D'] as const;
const MATH_SYMBOLS = ['-', '/', '.', '√', 'π', '^'] as const;

export function BankQuizScreen({
  gradeId,
  tier,
  focusTopicId,
  onBackToGrade,
  onNextTier,
}: BankQuizScreenProps) {
  const { language, direction, t } = useLanguage();
  const {
    adaptiveProfile,
    getTierProgress,
    isBankTierUnlocked,
    submittingBank,
    submitBankQuiz,
  } = useQuestionBank();

  const BackArrow = direction === 'rtl' ? ArrowRight : ArrowLeft;
  const ForwardArrow = direction === 'rtl' ? ArrowLeft : ArrowRight;

  const grade = getGradeById(gradeId);
  const tierMeta = getTierMeta(tier);

  const [questions, setQuestions] = useState<BankQuestion[]>(() =>
    selectAdaptiveQuizQuestions({
      gradeId,
      tier,
      seenQuestionIds: getTierProgress(gradeId, tier)?.seenQuestionIds ?? [],
      topicStats: adaptiveProfile?.topicStats ?? {},
      focusTopicId,
    }),
  );
  const [answers, setAnswers] = useState<
    Record<number, { selectedIndex?: number; writtenValue?: string }>
  >({});
  const [currentIdx, setCurrentIdx] = useState(0);
  const [showHint, setShowHint] = useState(false);
  const [result, setResult] = useState<BankQuizSubmissionResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const currentQuestion = questions[currentIdx];

  const answeredCount = questions.filter((_, idx) => {
    const ans = answers[idx];
    if (!ans) return false;
    if (questions[idx].format === 'written') {
      return Boolean(ans.writtenValue && ans.writtenValue.trim().length > 0);
    }
    return ans.selectedIndex !== undefined;
  }).length;

  const handleSelectOption = (optionIndex: number) => {
    setAnswers((prev) => ({
      ...prev,
      [currentIdx]: { selectedIndex: optionIndex },
    }));
    setErrorMsg(null);
  };

  const handleWrittenChange = (value: string) => {
    setAnswers((prev) => ({
      ...prev,
      [currentIdx]: { writtenValue: value },
    }));
    setErrorMsg(null);
  };

  const handleInsertSymbol = (sym: string) => {
    const existing = answers[currentIdx]?.writtenValue ?? '';
    handleWrittenChange(`${existing}${sym}`);
  };

  const handleJumpTo = (idx: number) => {
    setCurrentIdx(idx);
    setShowHint(false);
  };

  const handleSubmit = async () => {
    if (answeredCount < questions.length) {
      setErrorMsg(t.answerAllPrompt);
      return;
    }
    setErrorMsg(null);
    try {
      const answerArray = questions.map((_, idx) => answers[idx]);
      const res = await submitBankQuiz({
        gradeId,
        tier,
        questions,
        answers: answerArray,
      });
      setResult(res);
    } catch (err) {
      console.error('Question bank quiz submission failed:', err);
      setErrorMsg(t.errorGeneric);
    }
  };

  const handleRetryNewSet = () => {
    const seen = getTierProgress(gradeId, tier)?.seenQuestionIds ?? [];
    const fresh = selectAdaptiveQuizQuestions({
      gradeId,
      tier,
      seenQuestionIds: seen,
      topicStats: adaptiveProfile?.topicStats ?? {},
      focusTopicId,
    });
    setQuestions(fresh);
    setAnswers({});
    setCurrentIdx(0);
    setShowHint(false);
    setResult(null);
    setErrorMsg(null);
  };

  if (!grade || questions.length === 0) {
    return (
      <section className="min-h-dvh flex items-center justify-center p-6 max-w-xl mx-auto">
        <LiquidGlassCard className="p-6 text-center space-y-4">
          <p className="text-sm text-slate-300">{t.errorGeneric}</p>
          <button
            type="button"
            onClick={onBackToGrade}
            className="liquid-glass-button px-5 py-2.5 rounded-2xl text-sm font-semibold text-white"
          >
            {t.backToSectionBtn}
          </button>
        </LiquidGlassCard>
      </section>
    );
  }

  // Post-Submission Diagnostic & Step-by-Step Verification View
  if (result) {
    const nextTierUnlocked =
      result.unlockedNextTier && isBankTierUnlocked(gradeId, result.unlockedNextTier);
    const adaptiveBadgeText =
      result.adaptiveShift === 'upgraded'
        ? t.bankQuizAdaptiveUpgraded
        : result.adaptiveShift === 'reinforced'
          ? t.bankQuizAdaptiveReinforced
          : t.bankQuizAdaptiveSteady;

    return (
      <motion.section
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="min-h-dvh flex flex-col px-4 py-5 sm:px-8 sm:py-7 max-w-4xl mx-auto w-full gap-6 pb-12"
      >
        <LiquidGlassCard className="p-6 sm:p-8 text-center space-y-5">
          <div
            className={`w-16 h-16 mx-auto rounded-3xl flex items-center justify-center border ${
              result.mastered
                ? 'bg-emerald-500/20 border-emerald-400/45 text-emerald-300'
                : 'bg-amber-500/20 border-amber-400/45 text-amber-300'
            }`}
          >
            {result.mastered ? (
              <CheckCircle2 className="w-8 h-8" aria-hidden="true" />
            ) : (
              <AlertTriangle className="w-8 h-8" aria-hidden="true" />
            )}
          </div>

          <div className="space-y-1.5">
            <div className="text-xs font-semibold text-slate-300">
              {language === 'ar' ? grade.titleAr : grade.titleEn} ·{' '}
              {language === 'ar' ? tierMeta.titleAr : tierMeta.titleEn}
            </div>
            <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">
              {result.mastered ? t.resultPassedTitle : t.resultFailedTitle}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-lg mx-auto">
              {result.mastered ? t.resultPassedSubtitle : t.resultFailedSubtitle}
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 py-2">
            <div className="px-5 py-3 rounded-2xl bg-white/[0.06] border border-white/15">
              <div className="text-[11px] text-slate-400">{t.resultScoreLabel}</div>
              <div className="text-3xl font-bold text-white font-math tabular-nums">
                {result.score}%
              </div>
            </div>
            <div className="px-5 py-3 rounded-2xl bg-white/[0.06] border border-white/15">
              <div className="text-[11px] text-slate-400">{t.examCorrectCountLabel}</div>
              <div className="text-3xl font-bold text-emerald-300 font-math tabular-nums">
                {result.correctCount} / {result.totalQuestions}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2 text-xs">
            {result.pointsAwarded > 0 && (
              <span className="px-3 py-1.5 rounded-xl bg-violet-500/25 border border-violet-300/45 text-violet-100 font-semibold inline-flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" aria-hidden="true" />
                <span>{t.resultPointsEarnedBadge(result.pointsAwarded)}</span>
              </span>
            )}
            {result.rewardAlreadyClaimed && result.mastered && result.pointsAwarded === 0 && (
              <span className="px-3 py-1.5 rounded-xl bg-white/[0.07] border border-white/15 text-slate-300">
                {t.resultAlreadyClaimedBadge}
              </span>
            )}
            <span className="px-3 py-1.5 rounded-xl bg-sky-500/20 border border-sky-400/35 text-sky-100 font-semibold inline-flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5" aria-hidden="true" />
              <span>{adaptiveBadgeText}</span>
            </span>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={handleRetryNewSet}
              className="liquid-glass-subtle min-h-[46px] px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white hover:bg-white/10 inline-flex items-center gap-2"
            >
              <RotateCcw className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>{t.retryStageBtn}</span>
            </button>

            {result.unlockedNextTier && nextTierUnlocked && (
              <button
                type="button"
                onClick={() => onNextTier(result.unlockedNextTier!)}
                className="liquid-glass-button min-h-[46px] px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center gap-2"
              >
                <span>
                  {language === 'ar'
                    ? getTierMeta(result.unlockedNextTier).titleAr
                    : getTierMeta(result.unlockedNextTier).titleEn}
                </span>
                <ForwardArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
              </button>
            )}

            <button
              type="button"
              onClick={onBackToGrade}
              className="liquid-glass-subtle min-h-[46px] px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-slate-200 hover:text-white inline-flex items-center gap-2"
            >
              <BackArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>{t.backToSectionBtn}</span>
            </button>
          </div>
        </LiquidGlassCard>

        {/* Step-by-Step Verification Review */}
        <div className="space-y-3">
          <h2 className="font-display text-lg font-bold text-white px-1">
            {t.bankQuizStepReviewTitle}
          </h2>
          {result.review.map((item, idx) => {
            const topicMeta = BANK_TOPICS[item.question.topic];
            const steps = language === 'ar' ? item.question.stepsAr : item.question.stepsEn;
            return (
              <LiquidGlassCard
                key={item.question.id}
                variant="subtle"
                className={`p-5 space-y-3 ${
                  item.isCorrect
                    ? 'border-emerald-400/35 bg-emerald-500/[0.05]'
                    : 'border-rose-400/35 bg-rose-500/[0.05]'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2 text-[11px] font-semibold">
                      <span className="font-math text-slate-400">#{idx + 1}</span>
                      <span className="px-2 py-0.5 rounded-lg bg-white/[0.06] text-sky-200">
                        {language === 'ar' ? topicMeta.titleAr : topicMeta.titleEn}
                      </span>
                    </div>
                    <p className="text-sm sm:text-base font-semibold text-white leading-relaxed">
                      {language === 'ar' ? item.question.promptAr : item.question.promptEn}
                    </p>
                  </div>
                  {item.isCorrect ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  ) : (
                    <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
                  <div className="p-3 rounded-xl bg-white/[0.04] border border-white/10">
                    <div className="text-slate-400 mb-1">{t.resultYourAnswerLabel}</div>
                    <div
                      className={`font-math font-bold ${
                        item.isCorrect ? 'text-emerald-300' : 'text-rose-300'
                      }`}
                      dir="ltr"
                    >
                      {item.userAnswerDisplay}
                    </div>
                  </div>
                  <div className="p-3 rounded-xl bg-white/[0.04] border border-white/10">
                    <div className="text-slate-400 mb-1">{t.resultCorrectAnswerLabel}</div>
                    <div className="font-math font-bold text-emerald-300" dir="ltr">
                      {item.question.displayAnswer}
                    </div>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-white/[0.03] border border-white/10 space-y-2">
                  <div className="text-xs font-bold text-sky-200">{t.resultExplanationLabel}</div>
                  {steps.length > 0 && (
                    <ol className="space-y-1 text-xs text-slate-200 list-decimal list-inside">
                      {steps.map((step, sIdx) => (
                        <li key={sIdx} className="leading-relaxed">
                          {step}
                        </li>
                      ))}
                    </ol>
                  )}
                  <p className="text-xs text-slate-300 leading-relaxed pt-1 border-t border-white/10">
                    {language === 'ar'
                      ? item.question.explanationAr
                      : item.question.explanationEn}
                  </p>
                </div>
              </LiquidGlassCard>
            );
          })}
        </div>
      </motion.section>
    );
  }

  // Active Quiz Session
  const topicMeta = BANK_TOPICS[currentQuestion.topic];
  const currentAnswer = answers[currentIdx];
  const progressPct = Math.round(((currentIdx + 1) / questions.length) * 100);

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="min-h-dvh flex flex-col px-4 py-5 sm:px-8 sm:py-7 max-w-4xl mx-auto w-full gap-5 pb-12"
    >
      {/* Top Quiz Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <button
          type="button"
          onClick={onBackToGrade}
          className="liquid-glass-subtle min-h-[42px] px-4 py-2 rounded-2xl text-xs font-semibold text-white hover:bg-white/10 inline-flex items-center gap-2"
        >
          <BackArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{t.backToSectionBtn}</span>
        </button>

        <div className="flex flex-wrap items-center gap-2 text-xs font-semibold">
          <span className="px-3 py-1.5 rounded-xl liquid-glass-subtle text-white">
            {language === 'ar' ? grade.titleAr : grade.titleEn}
          </span>
          <span className="px-3 py-1.5 rounded-xl bg-blue-500/20 border border-blue-400/35 text-blue-200">
            {language === 'ar' ? tierMeta.titleAr : tierMeta.titleEn}
          </span>
        </div>
      </div>

      {/* Progress Bar & Question Dots */}
      <LiquidGlassCard variant="subtle" className="p-4 sm:p-5 space-y-3">
        <div className="flex items-center justify-between text-xs text-slate-300 font-math">
          <span>{t.questionCounterLabel(currentIdx + 1, questions.length)}</span>
          <span>{t.answeredCountLabel(answeredCount, questions.length)}</span>
        </div>
        <div className="h-2 w-full rounded-full bg-white/10 overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-sky-400 to-violet-500 transition-all duration-300"
            style={{ width: `${progressPct}%` }}
          />
        </div>
        <div className="flex flex-wrap gap-1.5 pt-1">
          {questions.map((q, idx) => {
            const ans = answers[idx];
            const isAnswered =
              q.format === 'written'
                ? Boolean(ans?.writtenValue?.trim())
                : ans?.selectedIndex !== undefined;
            const isCurrent = idx === currentIdx;
            return (
              <button
                key={q.id}
                type="button"
                onClick={() => handleJumpTo(idx)}
                className={`w-8 h-8 rounded-xl text-xs font-math font-bold transition-all ${
                  isCurrent
                    ? 'bg-gradient-to-br from-blue-500 to-violet-600 text-white ring-2 ring-white/50'
                    : isAnswered
                      ? 'bg-emerald-500/25 border border-emerald-400/40 text-emerald-200'
                      : 'bg-white/[0.06] border border-white/10 text-slate-300 hover:bg-white/10'
                }`}
              >
                {idx + 1}
              </button>
            );
          })}
        </div>
      </LiquidGlassCard>

      {/* Active Question Card */}
      <LiquidGlassCard className="p-5 sm:p-8 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="px-3 py-1 rounded-xl bg-violet-500/20 border border-violet-400/35 text-violet-200 font-semibold inline-flex items-center gap-1.5">
              <BookOpen className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              <span>{language === 'ar' ? topicMeta.titleAr : topicMeta.titleEn}</span>
            </span>

            {currentQuestion.status === 'open_research' && (
              <span className="px-3 py-1 rounded-xl bg-amber-500/20 border border-amber-400/40 text-amber-200 font-semibold">
                {t.bankGeniusBadgeOpen}
              </span>
            )}
          </div>

          <button
            type="button"
            onClick={() => setShowHint((v) => !v)}
            className="liquid-glass-subtle min-h-[36px] px-3 py-1.5 rounded-xl text-xs font-semibold text-amber-200 hover:bg-white/10 inline-flex items-center gap-1.5"
          >
            <Lightbulb className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
            <span>{showHint ? t.bankQuizHideHintBtn : t.bankQuizShowHintBtn}</span>
          </button>
        </div>

        <h2 className="font-display text-lg sm:text-2xl font-bold text-white leading-relaxed">
          {language === 'ar' ? currentQuestion.promptAr : currentQuestion.promptEn}
        </h2>

        {showHint && (
          <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-400/30 text-xs sm:text-sm text-amber-100 leading-relaxed flex items-start gap-2.5">
            <Lightbulb className="w-4 h-4 text-amber-300 shrink-0 mt-0.5" aria-hidden="true" />
            <span>{language === 'ar' ? currentQuestion.hintAr : currentQuestion.hintEn}</span>
          </div>
        )}

        {/* Answer Input Area: Written vs 4-Option MCQ */}
        {currentQuestion.format === 'written' ? (
          <div className="space-y-3">
            <label
              htmlFor="bank-written-answer"
              className="block text-xs font-semibold text-slate-300"
            >
              {t.bankQuizWrittenLabel}
            </label>
            <input
              id="bank-written-answer"
              type="text"
              dir="ltr"
              value={currentAnswer?.writtenValue ?? ''}
              onChange={(e) => handleWrittenChange(e.target.value)}
              placeholder={t.bankQuizWrittenPlaceholder}
              className="liquid-glass-input w-full min-h-[54px] px-4 rounded-2xl text-lg font-math text-white placeholder:text-slate-400 focus:outline-none"
              autoComplete="off"
            />
            <div className="flex flex-wrap items-center gap-2">
              {MATH_SYMBOLS.map((sym) => (
                <button
                  key={sym}
                  type="button"
                  onClick={() => handleInsertSymbol(sym)}
                  className="liquid-glass-subtle min-w-[42px] min-h-[38px] px-3 rounded-xl font-math text-sm font-bold text-sky-200 hover:bg-white/15"
                >
                  {sym}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {(currentQuestion.options ?? []).map((opt, optIdx) => {
              const selected = currentAnswer?.selectedIndex === optIdx;
              return (
                <button
                  key={optIdx}
                  type="button"
                  onClick={() => handleSelectOption(optIdx)}
                  className={`min-h-[60px] p-4 rounded-2xl border text-start flex items-center gap-3 transition-all ${
                    selected
                      ? 'bg-gradient-to-br from-blue-500/30 to-violet-600/30 border-blue-400 shadow-[0_6px_24px_rgba(99,102,241,0.35)] text-white'
                      : 'bg-white/[0.04] border-white/12 hover:bg-white/[0.08] text-slate-100'
                  }`}
                >
                  <span
                    className={`w-8 h-8 rounded-xl font-math text-xs font-bold flex items-center justify-center shrink-0 ${
                      selected
                        ? 'bg-blue-500 text-white'
                        : 'bg-white/[0.08] text-slate-300'
                    }`}
                  >
                    {OPTION_LETTERS[optIdx]}
                  </span>
                  <span className="font-math text-sm sm:text-base font-semibold break-words" dir="auto">
                    {opt}
                  </span>
                </button>
              );
            })}
          </div>
        )}

        {errorMsg && (
          <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-400/35 text-xs font-semibold text-rose-200 text-center">
            {errorMsg}
          </div>
        )}

        {/* Navigation & Submit Footer */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-white/10">
          <button
            type="button"
            disabled={currentIdx === 0}
            onClick={() => handleJumpTo(Math.max(0, currentIdx - 1))}
            className="liquid-glass-subtle min-h-[46px] px-4 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white hover:bg-white/10 inline-flex items-center gap-2 disabled:opacity-40"
          >
            <BackArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>{t.prevQuestionBtn}</span>
          </button>

          {currentIdx < questions.length - 1 ? (
            <button
              type="button"
              onClick={() => handleJumpTo(Math.min(questions.length - 1, currentIdx + 1))}
              className="liquid-glass-button min-h-[46px] px-5 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center gap-2"
            >
              <span>{t.nextQuestionBtn}</span>
              <ForwardArrow className="w-4 h-4 shrink-0" aria-hidden="true" />
            </button>
          ) : (
            <button
              type="button"
              disabled={submittingBank}
              onClick={() => void handleSubmit()}
              className="liquid-glass-button min-h-[46px] px-6 py-2 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center gap-2 disabled:opacity-60"
            >
              <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>{submittingBank ? t.submittingQuizBtn : t.submitQuizBtn}</span>
            </button>
          )}
        </div>
      </LiquidGlassCard>
    </motion.section>
  );
}
