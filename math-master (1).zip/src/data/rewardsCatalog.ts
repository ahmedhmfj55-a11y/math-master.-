import type { RewardCategory, ShopRewardItem } from '@/src/types/rewards';

export const DEFAULT_AVATAR_ID = 'avatar-classic';

export interface FreeAvatarPreset {
  id: string;
  nameAr: string;
  nameEn: string;
  accentFrom: string;
  accentTo: string;
}

export const FREE_AVATAR_PRESETS: FreeAvatarPreset[] = [
  {
    id: 'avatar-classic',
    nameAr: 'الشرارة الكلاسيكية',
    nameEn: 'Classic Spark',
    accentFrom: 'from-blue-500',
    accentTo: 'to-violet-600',
  },
  {
    id: 'avatar-pi',
    nameAr: 'شعار باي (π)',
    nameEn: 'Pi Emblem (π)',
    accentFrom: 'from-sky-500',
    accentTo: 'to-indigo-600',
  },
  {
    id: 'avatar-sigma',
    nameAr: 'شعار سيجما (Σ)',
    nameEn: 'Sigma Crest (Σ)',
    accentFrom: 'from-violet-500',
    accentTo: 'to-fuchsia-600',
  },
  {
    id: 'avatar-delta',
    nameAr: 'شعار دلتا (Δ)',
    nameEn: 'Delta Prism (Δ)',
    accentFrom: 'from-cyan-500',
    accentTo: 'to-blue-600',
  },
  {
    id: 'avatar-omega',
    nameAr: 'شعار أوميغا (Ω)',
    nameEn: 'Omega Seal (Ω)',
    accentFrom: 'from-indigo-500',
    accentTo: 'to-purple-600',
  },
];

export const FREE_AVATAR_IDS = new Set<string>([
  ...FREE_AVATAR_PRESETS.map((a) => a.id),
  'avatar-google',
]);

export function getFreeAvatarPreset(avatarId: string | undefined | null): FreeAvatarPreset | undefined {
  if (!avatarId) return undefined;
  return FREE_AVATAR_PRESETS.find((item) => item.id === avatarId);
}

export function isFreeAvatarId(avatarId: string | undefined | null): boolean {
  return Boolean(avatarId && FREE_AVATAR_IDS.has(avatarId));
}

export const REWARDS_CATALOG: ShopRewardItem[] = [
  // --- Digital Medals & Badges ---
  {
    id: 'badge-spark',
    category: 'badge',
    nameAr: 'وسام الشرارة الأولى',
    nameEn: 'First Spark Medal',
    descriptionAr: 'وسام بداية الرحلة نحو التميز الرياضي.',
    descriptionEn: 'Marks the start of your mathematical mastery journey.',
    cost: 100,
    accentFrom: 'from-sky-400',
    accentTo: 'to-blue-600',
    symbol: '✦',
  },
  {
    id: 'badge-arithmetic',
    category: 'badge',
    nameAr: 'وسام عبقري الحساب',
    nameEn: 'Arithmetic Virtuoso',
    descriptionAr: 'شارة تقدير للسرعة والدقة في العمليات الحسابية.',
    descriptionEn: 'Honorary badge for precision and speed in core arithmetic.',
    cost: 250,
    accentFrom: 'from-blue-400',
    accentTo: 'to-indigo-600',
    symbol: '∑',
  },
  {
    id: 'badge-geometry',
    category: 'badge',
    nameAr: 'وسام المهندس الهندسي',
    nameEn: 'Geometric Architect',
    descriptionAr: 'وسام الإبداع في الأشكال والزوايا والنظريات الهندسية.',
    descriptionEn: 'Recognizes mastery over polygons, angles, and theorems.',
    cost: 400,
    accentFrom: 'from-cyan-400',
    accentTo: 'to-violet-600',
    symbol: '△',
  },
  {
    id: 'badge-scholar',
    category: 'badge',
    nameAr: 'وسام التميز الرياضي',
    nameEn: 'Math Scholar Crest',
    descriptionAr: 'شعار المتعلمين المثابرين عبر المراحل المتقدمة.',
    descriptionEn: 'Crest awarded to dedicated learners advancing through hard tiers.',
    cost: 600,
    accentFrom: 'from-indigo-400',
    accentTo: 'to-purple-600',
    symbol: 'π',
  },
  {
    id: 'badge-olympiad',
    category: 'badge',
    nameAr: 'وسام بطل الأولمبياد',
    nameEn: 'Olympiad Champion',
    descriptionAr: 'وسام رفيع لمتحدّي المسائل الأولمبية الصعبة.',
    descriptionEn: 'Prestigious seal for solvers of Olympiad-caliber challenges.',
    cost: 1000,
    accentFrom: 'from-amber-400',
    accentTo: 'to-orange-500',
    symbol: 'Φ',
  },
  {
    id: 'badge-crown',
    category: 'badge',
    nameAr: 'التاج الملكي للرياضيات',
    nameEn: 'Grand Master Crown',
    descriptionAr: 'أعلى وسام رقمي في منصة Math Master العالمية.',
    descriptionEn: 'The pinnacle digital crest on Math Master Global.',
    cost: 2000,
    accentFrom: 'from-yellow-300',
    accentTo: 'to-amber-600',
    symbol: '♔',
  },

  // --- Liquid Glass Profile Avatars ---
  {
    id: 'avatar-nova',
    category: 'avatar',
    nameAr: 'رائد الفضاء الرياضي',
    nameEn: 'Cosmic Explorer',
    descriptionAr: 'صورة رمزية زجاجية بتصميم المدارات الكونية.',
    descriptionEn: 'Liquid Glass orbital explorer emblem.',
    cost: 150,
    accentFrom: 'from-blue-500',
    accentTo: 'to-cyan-400',
    symbol: 'Orbit',
  },
  {
    id: 'avatar-owl',
    category: 'avatar',
    nameAr: 'بومة الحكمة التحليلية',
    nameEn: 'Analytical Owl',
    descriptionAr: 'رمز الذكاء العميق والتفكير المنطقي الهادئ.',
    descriptionEn: 'Symbol of analytical depth and calm logical reasoning.',
    cost: 300,
    accentFrom: 'from-indigo-500',
    accentTo: 'to-violet-400',
    symbol: 'Prism',
  },
  {
    id: 'avatar-prism',
    category: 'avatar',
    nameAr: 'المنشور البلوري',
    nameEn: 'Crystal Prism',
    descriptionAr: 'تصميم بلوري متعدد الأوجه يعكس إضاءة الزجاج السائل.',
    descriptionEn: 'Faceted glass crystal reflecting luminous blue-violet rays.',
    cost: 450,
    accentFrom: 'from-sky-400',
    accentTo: 'to-fuchsia-500',
    symbol: 'Gem',
  },
  {
    id: 'avatar-phoenix',
    category: 'avatar',
    nameAr: 'عنقاء الإتقان',
    nameEn: 'Golden Phoenix',
    descriptionAr: 'شعار الإصرار والتفوق المتجدد في كل امتحان.',
    descriptionEn: 'Emblem of resilience and rising mastery across every exam.',
    cost: 750,
    accentFrom: 'from-amber-400',
    accentTo: 'to-rose-500',
    symbol: 'Flame',
  },
  {
    id: 'avatar-dragon',
    category: 'avatar',
    nameAr: 'تنين المعادلات',
    nameEn: 'Quantum Dragon',
    descriptionAr: 'صورة رمزية نادرة لأبطال الجبر والتحديات الكبرى.',
    descriptionEn: 'Rare emblem for champions of algebra and advanced theory.',
    cost: 1200,
    accentFrom: 'from-violet-500',
    accentTo: 'to-emerald-400',
    symbol: 'Atom',
  },
  {
    id: 'avatar-aurora',
    category: 'avatar',
    nameAr: 'حارس الشفق',
    nameEn: 'Aurora Sovereign',
    descriptionAr: 'أفخم صورة شخصية مضيئة لمتصدري التصنيف العالمي.',
    descriptionEn: 'Luminous sovereign emblem crafted for global top rankers.',
    cost: 1800,
    accentFrom: 'from-fuchsia-400',
    accentTo: 'to-cyan-300',
    symbol: 'Crown',
  },

  // --- Distinguished Titles ---
  {
    id: 'title-explorer',
    category: 'title',
    nameAr: 'مكتشف الأرقام',
    nameEn: 'Number Explorer',
    descriptionAr: 'لقب يظهر أسفل اسمك في التصنيف العالمي وملفك الشخصي.',
    descriptionEn: 'Displayed alongside your name on your profile and leaderboard.',
    cost: 150,
    accentFrom: 'from-sky-400',
    accentTo: 'to-blue-500',
    symbol: 'I',
  },
  {
    id: 'title-solver',
    category: 'title',
    nameAr: 'قناص المعادلات',
    nameEn: 'Equation Solver',
    descriptionAr: 'لقب مميز لمتقني التحليل وحل المسائل بدقة.',
    descriptionEn: 'Distinguished title for sharp algebraic problem solvers.',
    cost: 350,
    accentFrom: 'from-blue-400',
    accentTo: 'to-violet-500',
    symbol: 'II',
  },
  {
    id: 'title-architect',
    category: 'title',
    nameAr: 'مهندس المنطق',
    nameEn: 'Logic Architect',
    descriptionAr: 'لقب رفيع للمبدعين في البرهان والهندسة.',
    descriptionEn: 'Title honoring structured proofs and geometric thinking.',
    cost: 600,
    accentFrom: 'from-indigo-400',
    accentTo: 'to-purple-500',
    symbol: 'III',
  },
  {
    id: 'title-maestro',
    category: 'title',
    nameAr: 'مايسترو الرياضيات',
    nameEn: 'Math Maestro',
    descriptionAr: 'لقب التفوق الشامل عبر مختلف الأقسام التعليمية.',
    descriptionEn: 'Awarded to versatile learners excelling across tracks.',
    cost: 950,
    accentFrom: 'from-violet-400',
    accentTo: 'to-pink-500',
    symbol: 'IV',
  },
  {
    id: 'title-legend',
    category: 'title',
    nameAr: 'أسطورة الأولمبياد',
    nameEn: 'Olympiad Legend',
    descriptionAr: 'لقب نخبوي يميز المتفوقين في التحديات المتقدمة.',
    descriptionEn: 'Elite rank title celebrating Olympiad challenge mastery.',
    cost: 1500,
    accentFrom: 'from-amber-400',
    accentTo: 'to-orange-500',
    symbol: 'V',
  },
  {
    id: 'title-grandmaster',
    category: 'title',
    nameAr: 'الأستاذ الأعظم للرياضيات',
    nameEn: 'Grand Math Master',
    descriptionAr: 'أرقى الألقاب العالمية داخل منصة Math Master.',
    descriptionEn: 'The highest honorary title on Math Master Global.',
    cost: 2500,
    accentFrom: 'from-yellow-300',
    accentTo: 'to-amber-500',
    symbol: 'VI',
  },
];

export function getRewardById(itemId: string | undefined | null): ShopRewardItem | undefined {
  if (!itemId) return undefined;
  return REWARDS_CATALOG.find((item) => item.id === itemId);
}

export function getRewardsByCategory(category: RewardCategory): ShopRewardItem[] {
  return REWARDS_CATALOG.filter((item) => item.category === category);
}
