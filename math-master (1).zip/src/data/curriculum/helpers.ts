import type { DifficultyLevel, QuizQuestion, SectionId } from '@/src/types/curriculum';

export function getDifficultyForStage(stageNumber: number): DifficultyLevel {
  if (stageNumber <= 10) return 'easy';
  if (stageNumber <= 20) return 'medium';
  return 'hard';
}

/**
 * Mulberry32 deterministic PRNG so every stage/question is stable across sessions.
 */
export function createSeededRng(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state = (state + 0x6d2b79f5) >>> 0;
    let t = Math.imul(state ^ (state >>> 15), 1 | state);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function hashString(value: string): number {
  let hash = 2166136261;
  for (let i = 0; i < value.length; i++) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

export function randInt(rng: () => number, min: number, max: number): number {
  return Math.floor(rng() * (max - min + 1)) + min;
}

/**
 * Builds 4 strictly distinct formatted options and shuffles them deterministically.
 */
export function buildChoiceQuestion(params: {
  id: string;
  promptAr: string;
  promptEn: string;
  correctValue: string;
  distractors: string[];
  explanationAr: string;
  explanationEn: string;
  seedKey: string;
}): QuizQuestion {
  const rng = createSeededRng(hashString(params.seedKey));
  const uniqueDistractors: string[] = [];
  for (const d of params.distractors) {
    if (d !== params.correctValue && !uniqueDistractors.includes(d)) {
      uniqueDistractors.push(d);
    }
    if (uniqueDistractors.length === 3) break;
  }

  // Fallback safeguard if fewer than 3 distinct distractors were supplied
  let fallbackCounter = 1;
  while (uniqueDistractors.length < 3) {
    const candidate = `${params.correctValue} (${fallbackCounter})`;
    if (!uniqueDistractors.includes(candidate) && candidate !== params.correctValue) {
      uniqueDistractors.push(candidate);
    }
    fallbackCounter++;
  }

  const pool: { value: string; isCorrect: boolean }[] = [
    { value: params.correctValue, isCorrect: true },
    { value: uniqueDistractors[0], isCorrect: false },
    { value: uniqueDistractors[1], isCorrect: false },
    { value: uniqueDistractors[2], isCorrect: false },
  ];

  // Fisher-Yates deterministic shuffle
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }

  const correctIndex = pool.findIndex((item) => item.isCorrect) as 0 | 1 | 2 | 3;

  return {
    id: params.id,
    promptAr: params.promptAr,
    promptEn: params.promptEn,
    options: [pool[0].value, pool[1].value, pool[2].value, pool[3].value],
    correctIndex,
    explanationAr: params.explanationAr,
    explanationEn: params.explanationEn,
  };
}

export function numericDistractors(
  correct: number,
  offsets: number[],
  allowNegative = false,
): string[] {
  const result: string[] = [];
  for (const offset of offsets) {
    const candidate = correct + offset;
    if (!allowNegative && candidate < 0) continue;
    const str = String(candidate);
    if (str !== String(correct) && !result.includes(str)) {
      result.push(str);
    }
  }
  let step = 1;
  while (result.length < 6) {
    const candidate = correct + step;
    const str = String(candidate);
    if (str !== String(correct) && !result.includes(str)) {
      result.push(str);
    }
    step++;
  }
  return result;
}

export function gcd(a: number, b: number): number {
  let x = Math.abs(a);
  let y = Math.abs(b);
  while (y !== 0) {
    const t = y;
    y = x % y;
    x = t;
  }
  return x || 1;
}

export function lcm(a: number, b: number): number {
  return Math.abs(a * b) / gcd(a, b);
}

export function formatFraction(num: number, den: number): string {
  const g = gcd(num, den);
  const n = num / g;
  const d = den / g;
  if (d === 1) return `${n}`;
  return `${n}/${d}`;
}

export function makeStageId(sectionId: SectionId, stageNumber: number): string {
  return `${sectionId}-s${stageNumber}`;
}
