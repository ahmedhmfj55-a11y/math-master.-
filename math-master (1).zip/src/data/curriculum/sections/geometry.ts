import {
  buildChoiceQuestion,
  getDifficultyForStage,
  makeStageId,
  numericDistractors,
} from '@/src/data/curriculum/helpers';
import type { QuizQuestion, StageDefinition, WorkedExample } from '@/src/types/curriculum';

interface TopicSpec {
  stage: number;
  titleAr: string;
  titleEn: string;
  summaryAr: string;
  summaryEn: string;
  ruleTitleAr: string;
  ruleTitleEn: string;
  ruleFormula: string;
  examples: [WorkedExample, WorkedExample];
  generate: (qIdx: number, isExam: boolean) => QuizQuestion;
}

function geoQ(
  stage: number,
  qIdx: number,
  isExam: boolean,
  promptAr: string,
  promptEn: string,
  correct: string,
  distractors: string[],
  explanationAr: string,
  explanationEn: string,
): QuizQuestion {
  const id = isExam ? `geometry-exam-s${stage}` : `geometry-s${stage}-q${qIdx + 1}`;
  return buildChoiceQuestion({
    id,
    promptAr,
    promptEn,
    correctValue: correct,
    distractors,
    explanationAr,
    explanationEn,
    seedKey: `${id}-${promptEn}`,
  });
}

const TOPICS: TopicSpec[] = [
  {
    stage: 1,
    titleAr: 'أنواع الزوايا الأساسية',
    titleEn: 'Classifying Angles',
    summaryAr: 'الزاوية الحادة أقل من 90°، القائمة 90°، المنفرجة بين 90° و 180°، والمستقيمة 180°.',
    summaryEn: 'Acute < 90°, Right = 90°, Obtuse between 90° and 180°, Straight = 180°.',
    ruleTitleAr: 'تصنيف الزوايا',
    ruleTitleEn: 'Angle Types',
    ruleFormula: '0° < Acute < 90° < Obtuse < 180°',
    examples: [
      { problemAr: 'ما نوع الزاوية التي قياسها 125°؟', problemEn: 'Type of a 125° angle?', solutionAr: 'بين 90° و 180° ← منفرجة', solutionEn: 'Obtuse', answer: 'منفرجة / Obtuse' },
      { problemAr: 'ما قياس الزاوية القائمة؟', problemEn: 'Measure of a right angle?', solutionAr: '90°', solutionEn: '90°', answer: '90°' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const angles = [25, 42, 68, 85, 95, 118, 134, 152, 165, 38, 144];
      const deg = angles[idx];
      const isAcute = deg < 90;
      const ans = isAcute ? 'حادة (Acute)' : 'منفرجة (Obtuse)';
      return geoQ(1, qIdx, isExam, `ما نوع الزاوية التي قياسها ${deg}°؟`, `What type of angle measures ${deg}°?`, ans, [isAcute ? 'منفرجة (Obtuse)' : 'حادة (Acute)', 'قائمة (Right)', 'مستقيمة (Straight)'], `لأن ${deg}° ${isAcute ? 'أقل من 90°' : 'أكبر من 90° وأقل من 180°'} فهي زاوية ${ans}.`, `Since ${deg}° is ${isAcute ? 'less than 90°' : 'between 90° and 180°'}, it is ${ans}.`);
    },
  },
  {
    stage: 2,
    titleAr: 'الزاويتان المتتامتان',
    titleEn: 'Complementary Angles',
    summaryAr: 'الزاويتان المتتامتان مجموع قياسهما يساوي 90°.',
    summaryEn: 'Two complementary angles sum to exactly 90°.',
    ruleTitleAr: 'مجموع المتتامتين',
    ruleTitleEn: 'Complementary Sum',
    ruleFormula: 'α + β = 90°',
    examples: [
      { problemAr: 'ما متممة الزاوية 35°؟', problemEn: 'Complement of 35°?', solutionAr: '90 − 35 = 55°', solutionEn: '55°', answer: '55°' },
      { problemAr: 'ما متممة الزاوية 62°؟', problemEn: 'Complement of 62°?', solutionAr: '28°', solutionEn: '28°', answer: '28°' },
    ],
    generate: (qIdx, isExam) => {
      const deg = 14 + qIdx * 6 + (isExam ? 3 : 0);
      const ans = 90 - deg;
      return geoQ(2, qIdx, isExam, `ما قياس الزاوية المتممة للزاوية ${deg}°؟`, `Find the complement of a ${deg}° angle:`, `${ans}°`, [`${180 - deg}°`, `${ans + 10}°`, `${Math.abs(ans - 10)}°`], `90° − ${deg}° = ${ans}°.`, `90° − ${deg}° = ${ans}°.`);
    },
  },
  {
    stage: 3,
    titleAr: 'الزاويتان المتكاملتان',
    titleEn: 'Supplementary Angles',
    summaryAr: 'الزاويتان المتكاملتان على خط مستقيم مجموع قياسهما 180°.',
    summaryEn: 'Two supplementary angles on a straight line sum to 180°.',
    ruleTitleAr: 'مجموع المتكاملتين',
    ruleTitleEn: 'Supplementary Sum',
    ruleFormula: 'α + β = 180°',
    examples: [
      { problemAr: 'ما مكملة الزاوية 110°؟', problemEn: 'Supplement of 110°?', solutionAr: '180 − 110 = 70°', solutionEn: '70°', answer: '70°' },
      { problemAr: 'ما مكملة الزاوية 45°؟', problemEn: 'Supplement of 45°?', solutionAr: '135°', solutionEn: '135°', answer: '135°' },
    ],
    generate: (qIdx, isExam) => {
      const deg = 32 + qIdx * 11 + (isExam ? 4 : 0);
      const ans = 180 - deg;
      return geoQ(3, qIdx, isExam, `ما قياس الزاوية المكملة للزاوية ${deg}°؟`, `Find the supplement of a ${deg}° angle:`, `${ans}°`, [`${Math.abs(90 - deg)}°`, `${ans + 15}°`, `${ans - 10}°`], `180° − ${deg}° = ${ans}°.`, `180° − ${deg}° = ${ans}°.`);
    },
  },
  {
    stage: 4,
    titleAr: 'الزوايا حول نقطة واحدة',
    titleEn: 'Angles Around a Point',
    summaryAr: 'مجموع قياسات الزوايا المتجمعة حول نقطة واحدة يساوي 360°.',
    summaryEn: 'The sum of all angles meeting at a single point is 360°.',
    ruleTitleAr: 'الدورة الكاملة',
    ruleTitleEn: 'Full Turn',
    ruleFormula: '∑ angles around a point = 360°',
    examples: [
      { problemAr: 'ثلاث زوايا حول نقطة: 120°، 150°، x. أوجد x', problemEn: 'Three angles at a point: 120°, 150°, x. Find x', solutionAr: '360 − 270 = 90°', solutionEn: '90°', answer: '90°' },
      { problemAr: 'أربع زوايا متساوية حول نقطة، ما قياس كل منها؟', problemEn: '4 equal angles around a point?', solutionAr: '360 ÷ 4 = 90°', solutionEn: '90°', answer: '90°' },
    ],
    generate: (qIdx, isExam) => {
      const a = 80 + qIdx * 8 + (isExam ? 5 : 0);
      const b = 110 + ((qIdx * 7) % 50);
      const ans = 360 - (a + b);
      return geoQ(4, qIdx, isExam, `ثلاث زوايا متجمعة حول نقطة قياس اثنتين منها ${a}° و ${b}°، ما قياس الزاوية الثالثة؟`, `Three angles meet at a point. Two measure ${a}° and ${b}°. Find the third:`, `${ans}°`, [`${180 - a}°`, `${ans + 20}°`, `${ans - 15}°`], `360° − (${a}° + ${b}°) = ${ans}°.`, `360° − (${a}° + ${b}°) = ${ans}°.`);
    },
  },
  {
    stage: 5,
    titleAr: 'محيط المستطيل والمربع',
    titleEn: 'Perimeter of Rectangles & Squares',
    summaryAr: 'المحيط هو مجموع أطوال أضلاع الشكل المغلق.',
    summaryEn: 'Perimeter is the total boundary length around a polygon.',
    ruleTitleAr: 'قوانين المحيط',
    ruleTitleEn: 'Perimeter Formulas',
    ruleFormula: 'P_rect = 2(L + W) , P_square = 4s',
    examples: [
      { problemAr: 'مستطيل طوله 9 وعرضه 5، ما محيطه؟', problemEn: 'Rectangle L=9, W=5, perimeter?', solutionAr: '2(9 + 5) = 28', solutionEn: '28', answer: '28' },
      { problemAr: 'مربع ضلعه 7، ما محيطه؟', problemEn: 'Square side 7, perimeter?', solutionAr: '4 × 7 = 28', solutionEn: '28', answer: '28' },
    ],
    generate: (qIdx, isExam) => {
      const L = 6 + qIdx * 2 + (isExam ? 1 : 0);
      const W = 3 + (qIdx % 6);
      const ans = 2 * (L + W);
      return geoQ(5, qIdx, isExam, `مستطيل طوله ${L} سم وعرضه ${W} سم، ما محيطه بالسنتيمتر؟`, `A rectangle has length ${L} cm and width ${W} cm. Find its perimeter:`, String(ans), numericDistractors(ans, [L * W - ans || 5, 2, -2, 4]), `المحيط = 2 × (${L} + ${W}) = ${ans} سم.`, `Perimeter = 2(${L} + ${W}) = ${ans}.`);
    },
  },
  {
    stage: 6,
    titleAr: 'مساحة المستطيل والمربع',
    titleEn: 'Area of Rectangles & Squares',
    summaryAr: 'المساحة تقيس عدد الوحدات المربعة داخل الشكل وتُحسب بضرب الطول في العرض.',
    summaryEn: 'Area measures the enclosed square units inside a shape.',
    ruleTitleAr: 'قانون المساحة',
    ruleTitleEn: 'Area Formula',
    ruleFormula: 'A_rect = L × W , A_square = s²',
    examples: [
      { problemAr: 'مستطيل 8 × 5، ما مساحته؟', problemEn: 'Rectangle 8 by 5, area?', solutionAr: '40', solutionEn: '40', answer: '40' },
      { problemAr: 'مربع ضلعه 9، ما مساحته؟', problemEn: 'Square side 9, area?', solutionAr: '81', solutionEn: '81', answer: '81' },
    ],
    generate: (qIdx, isExam) => {
      const L = 5 + qIdx + (isExam ? 2 : 0);
      const W = 3 + ((qIdx * 2) % 6);
      const ans = L * W;
      return geoQ(6, qIdx, isExam, `احسب مساحة مستطيل أبعاده ${L} م و ${W} م (بالمتر المربع):`, `Find the area of a ${L} m × ${W} m rectangle:`, String(ans), numericDistractors(ans, [2 * (L + W) - ans || 6, L, -W, 4]), `المساحة = ${L} × ${W} = ${ans} م².`, `Area = ${L} × ${W} = ${ans} m².`);
    },
  },
  {
    stage: 7,
    titleAr: 'مجموع زوايا المثلث الداخلية',
    titleEn: 'Triangle Angle Sum',
    summaryAr: 'مجموع قياسات الزوايا الداخلية لأي مثلث يساوي دائماً 180°.',
    summaryEn: 'The three interior angles of any triangle always sum to 180°.',
    ruleTitleAr: 'مجموع زوايا المثلث',
    ruleTitleEn: 'Triangle Sum Theorem',
    ruleFormula: '∠A + ∠B + ∠C = 180°',
    examples: [
      { problemAr: 'مثلث فيه زاويتان 50° و 60°، ما الثالثة؟', problemEn: 'Triangle angles 50° and 60°, find third', solutionAr: '180 − 110 = 70°', solutionEn: '70°', answer: '70°' },
      { problemAr: 'مثلث قائم فيه زاوية 35°، ما الحادة الأخرى؟', problemEn: 'Right triangle with 35°, find other acute angle', solutionAr: '55°', solutionEn: '55°', answer: '55°' },
    ],
    generate: (qIdx, isExam) => {
      const a = 35 + qIdx * 5 + (isExam ? 3 : 0);
      const b = 40 + ((qIdx * 4) % 45);
      const ans = 180 - (a + b);
      return geoQ(7, qIdx, isExam, `في مثلث قياس زاويتين فيه ${a}° و ${b}°، ما قياس الزاوية الثالثة؟`, `Two angles of a triangle measure ${a}° and ${b}°. Find the third angle:`, `${ans}°`, [`${ans + 10}°`, `${Math.abs(ans - 10)}°`, `${180 - a}°`], `180° − (${a}° + ${b}°) = ${ans}°.`, `180° − (${a}° + ${b}°) = ${ans}°.`);
    },
  },
  {
    stage: 8,
    titleAr: 'مساحة المثلث',
    titleEn: 'Area of a Triangle',
    summaryAr: 'مساحة المثلث تساوي نصف حاصل ضرب القاعدة في الارتفاع العمودي.',
    summaryEn: 'Area of a triangle equals half the product of base and perpendicular height.',
    ruleTitleAr: 'مساحة المثلث',
    ruleTitleEn: 'Triangle Area',
    ruleFormula: 'A = ½ × base × height',
    examples: [
      { problemAr: 'مثلث قاعدته 10 وارتفاعه 6، مساحته؟', problemEn: 'Base 10, height 6, area?', solutionAr: '½ × 10 × 6 = 30', solutionEn: '30', answer: '30' },
      { problemAr: 'قاعدته 8 وارتفاعه 7، مساحته؟', problemEn: 'Base 8, height 7, area?', solutionAr: '28', solutionEn: '28', answer: '28' },
    ],
    generate: (qIdx, isExam) => {
      const b = 4 + qIdx * 2 + (isExam ? 2 : 0);
      const h = 3 + ((qIdx + (isExam ? 1 : 0)) % 7);
      const ans = (b * h) / 2;
      return geoQ(8, qIdx, isExam, `مثلث طول قاعدته ${b} سم وارتفاعه ${h} سم، ما مساحته بالسنتيمتر المربع؟`, `Find the area of a triangle with base ${b} cm and height ${h} cm:`, String(ans), numericDistractors(ans, [b * h - ans, 2, -2, 4]), `المساحة = ½ × ${b} × ${h} = ${ans} سم².`, `Area = ½ × ${b} × ${h} = ${ans} cm².`);
    },
  },
  {
    stage: 9,
    titleAr: 'تصنيف المثلثات وخصائصها',
    titleEn: 'Triangle Classification & Isosceles Angles',
    summaryAr: 'في المثلث متطابق الساقين تتساوى زاويتا القاعدة، وفي متطابق الأضلاع كل زاوية 60°.',
    summaryEn: 'Isosceles triangles have equal base angles; equilateral triangles have three 60° angles.',
    ruleTitleAr: 'زوايا القاعدة',
    ruleTitleEn: 'Isosceles Base Angles',
    ruleFormula: 'Base Angle = (180° − Vertex) / 2',
    examples: [
      { problemAr: 'مثلث متطابق الساقين زاوية رأسه 40°، ما زاوية القاعدة؟', problemEn: 'Isosceles vertex 40°, base angle?', solutionAr: '(180 − 40) ÷ 2 = 70°', solutionEn: '70°', answer: '70°' },
      { problemAr: 'زاوية القاعدة 55°، ما زاوية الرأس؟', problemEn: 'Base angle 55°, vertex angle?', solutionAr: '180 − 110 = 70°', solutionEn: '70°', answer: '70°' },
    ],
    generate: (qIdx, isExam) => {
      const vertex = 20 + qIdx * 10 + (isExam ? 4 : 0);
      const ans = (180 - vertex) / 2;
      return geoQ(9, qIdx, isExam, `في مثلث متطابق الساقين قياس زاوية الرأس ${vertex}°، ما قياس كل زاوية قاعدة؟`, `In an isosceles triangle, the vertex angle is ${vertex}°. Find each base angle:`, `${ans}°`, [`${180 - vertex}°`, `${ans + 10}°`, `${ans - 10}°`], `(180° − ${vertex}°) ÷ 2 = ${ans}°.`, `(180° − ${vertex}°) / 2 = ${ans}°.`);
    },
  },
  {
    stage: 10,
    titleAr: 'التماثل وخطوط التناظر في المضلعات',
    titleEn: 'Symmetry & Regular Polygons',
    summaryAr: 'المضلع المنتظم تتساوى أضلاعه وزواياه، ومحيطه يساوي عدد الأضلاع × طول الضلع.',
    summaryEn: 'Regular polygons have equal sides and equal angles; perimeter equals n × side.',
    ruleTitleAr: 'محيط المضلع المنتظم',
    ruleTitleEn: 'Regular Polygon Perimeter',
    ruleFormula: 'P = n × s',
    examples: [
      { problemAr: 'سداسي منتظم طول ضلعه 7، ما محيطه؟', problemEn: 'Regular hexagon side 7, perimeter?', solutionAr: '6 × 7 = 42', solutionEn: '42', answer: '42' },
      { problemAr: 'خماسي منتظم محيطه 45، ما طول ضلعه؟', problemEn: 'Regular pentagon perimeter 45, side?', solutionAr: '9', solutionEn: '9', answer: '9' },
    ],
    generate: (qIdx, isExam) => {
      const sides = 5 + ((qIdx + (isExam ? 1 : 0)) % 4);
      const s = 4 + qIdx;
      const ans = sides * s;
      return geoQ(10, qIdx, isExam, `مضلع منتظم عدد أضلاعه ${sides} وطول كل ضلع ${s} سم، ما محيطه؟`, `A regular ${sides}-sided polygon has side length ${s} cm. Find its perimeter:`, String(ans), numericDistractors(ans, [sides, -sides, s, -s]), `المحيط = ${sides} × ${s} = ${ans} سم.`, `Perimeter = ${sides} × ${s} = ${ans}.`);
    },
  },
  // --- MEDIUM (11 - 20) ---
  {
    stage: 11,
    titleAr: 'مساحة متوازي الأضلاع والمعين',
    titleEn: 'Area of Parallelograms & Rhombuses',
    summaryAr: 'مساحة متوازي الأضلاع تساوي القاعدة × الارتفاع، ومساحة المعين نصف ضرب القطرين.',
    summaryEn: 'Parallelogram area = base × height; Rhombus area = ½ × d₁ × d₂.',
    ruleTitleAr: 'متوازي الأضلاع والمعين',
    ruleTitleEn: 'Parallelogram & Rhombus',
    ruleFormula: 'A = b × h , A_rhombus = ½ d₁ d₂',
    examples: [
      { problemAr: 'معين قطراه 8 و 12، ما مساحته؟', problemEn: 'Rhombus diagonals 8 and 12, area?', solutionAr: '½ × 8 × 12 = 48', solutionEn: '48', answer: '48' },
      { problemAr: 'متوازي أضلاع قاعدته 11 وارتفاعه 6', problemEn: 'Parallelogram b=11, h=6', solutionAr: '66', solutionEn: '66', answer: '66' },
    ],
    generate: (qIdx, isExam) => {
      const d1 = 4 + qIdx * 2;
      const d2 = 5 + ((qIdx + (isExam ? 1 : 0)) % 7);
      const ans = (d1 * d2) / 2;
      return geoQ(11, qIdx, isExam, `معين طولا قطريه ${d1} سم و ${d2} سم، ما مساحته بالسنتيمتر المربع؟`, `A rhombus has diagonals ${d1} cm and ${d2} cm. Find its area:`, String(ans), numericDistractors(ans, [d1 * d2 - ans, 2, -2, 4]), `المساحة = ½ × ${d1} × ${d2} = ${ans} سم².`, `Area = ½ × ${d1} × ${d2} = ${ans}.`);
    },
  },
  {
    stage: 12,
    titleAr: 'مساحة شبه المنحرف',
    titleEn: 'Area of a Trapezoid',
    summaryAr: 'مساحة شبه المنحرف تساوي متوسط القاعدتين المتوازيتين مضروباً في الارتفاع.',
    summaryEn: 'Trapezoid area equals the average of the two parallel bases times the height.',
    ruleTitleAr: 'قانون شبه المنحرف',
    ruleTitleEn: 'Trapezoid Formula',
    ruleFormula: 'A = ½(b₁ + b₂) × h',
    examples: [
      { problemAr: 'قاعدتاه 6 و 10 وارتفاعه 5', problemEn: 'Bases 6 and 10, height 5', solutionAr: '½(16) × 5 = 40', solutionEn: '40', answer: '40' },
      { problemAr: 'قاعدتاه 8 و 14 وارتفاعه 4', problemEn: 'Bases 8 and 14, height 4', solutionAr: '11 × 4 = 44', solutionEn: '44', answer: '44' },
    ],
    generate: (qIdx, isExam) => {
      const b1 = 4 + qIdx;
      const b2 = b1 + 4 + ((qIdx % 3) * 2);
      const h = 3 + ((qIdx + (isExam ? 1 : 0)) % 6);
      const ans = ((b1 + b2) * h) / 2;
      return geoQ(12, qIdx, isExam, `شبه منحرف طولا قاعدتيه المتوازيتين ${b1} سم و ${b2} سم وارتفاعه ${h} سم، ما مساحته؟`, `Trapezoid with bases ${b1} cm and ${b2} cm and height ${h} cm. Area?`, String(ans), numericDistractors(ans, [h, -h, 4, -4]), `½ × (${b1} + ${b2}) × ${h} = ${ans} سم².`, `½(${b1} + ${b2}) × ${h} = ${ans}.`);
    },
  },
  {
    stage: 13,
    titleAr: 'المستقيمات المتوازية والقاطع',
    titleEn: 'Parallel Lines & Transversals',
    summaryAr: 'عند تقاطع مستقيمين متوازيين بقاطع تتساوى الزوايا المتبادلة والمتناظرة، وتتكامل المتحالفة.',
    summaryEn: 'Alternate and corresponding angles are equal; co-interior angles sum to 180°.',
    ruleTitleAr: 'علاقات التوازي',
    ruleTitleEn: 'Parallel Angle Rules',
    ruleFormula: 'Alternate = Equal , Co-interior sum = 180°',
    examples: [
      { problemAr: 'زاويتان متحالفتان إحداهما 65°، ما الأخرى؟', problemEn: 'Co-interior angle 65°, find partner', solutionAr: '180 − 65 = 115°', solutionEn: '115°', answer: '115°' },
      { problemAr: 'زاوية متبادلة داخلياً مع 72°', problemEn: 'Alternate interior to 72°', solutionAr: '72°', solutionEn: '72°', answer: '72°' },
    ],
    generate: (qIdx, isExam) => {
      const deg = 48 + qIdx * 7 + (isExam ? 3 : 0);
      const ans = 180 - deg;
      return geoQ(13, qIdx, isExam, `قطع مستقيم مستقيمين متوازيين، فإذا كان قياس إحدى الزاويتين المتحالفتين داخلياً ${deg}°، فما قياس الأخرى؟`, `A transversal cuts two parallel lines. One co-interior angle is ${deg}°. Find the other:`, `${ans}°`, [`${deg}°`, `${Math.abs(90 - deg)}°`, `${ans + 12}°`], `الزاويتان المتحالفتان متكاملتان: 180° − ${deg}° = ${ans}°.`, `Co-interior angles are supplementary: 180° − ${deg}° = ${ans}°.`);
    },
  },
  {
    stage: 14,
    titleAr: 'مجموع الزوايا الداخلية للمضلعات',
    titleEn: 'Interior Angle Sum of Polygons',
    summaryAr: 'مجموع الزوايا الداخلية لأي مضلع ذي n ضلع يساوي (n − 2) × 180°.',
    summaryEn: 'The interior angle sum of an n-gon equals (n − 2) × 180°.',
    ruleTitleAr: 'قانون المضلعات',
    ruleTitleEn: 'Polygon Sum Formula',
    ruleFormula: 'S = (n − 2) × 180°',
    examples: [
      { problemAr: 'مجموع زوايا الخماسي (5 أضلاع)', problemEn: 'Interior sum of pentagon (5 sides)', solutionAr: '3 × 180 = 540°', solutionEn: '540°', answer: '540°' },
      { problemAr: 'مجموع زوايا السداسي', problemEn: 'Hexagon sum', solutionAr: '720°', solutionEn: '720°', answer: '720°' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const n = 4 + idx;
      const ans = (n - 2) * 180;
      return geoQ(14, qIdx, isExam, `ما مجموع قياسات الزوايا الداخلية لمضلع عدد أضلاعه ${n}؟`, `What is the sum of interior angles of a ${n}-sided polygon?`, `${ans}°`, [`${n * 180}°`, `${(n - 1) * 180}°`, `${(n - 3) * 180}°`], `(${n} − 2) × 180° = ${ans}°.`, `(${n} − 2) × 180° = ${ans}°.`);
    },
  },
  {
    stage: 15,
    titleAr: 'محيط الدائرة بدلالة π',
    titleEn: 'Circumference of a Circle',
    summaryAr: 'محيط الدائرة يساوي القطر مضروباً في π (أو 2πr).',
    summaryEn: 'Circumference equals π times diameter (or 2πr).',
    ruleTitleAr: 'محيط الدائرة',
    ruleTitleEn: 'Circumference Formula',
    ruleFormula: 'C = 2πr = πd',
    examples: [
      { problemAr: 'دائرة نصف قطرها 5، محيطها بدلالة π؟', problemEn: 'Radius 5, circumference in terms of π?', solutionAr: '10π', solutionEn: '10π', answer: '10π' },
      { problemAr: 'دائرة قطرها 12، محيطها؟', problemEn: 'Diameter 12, circumference?', solutionAr: '12π', solutionEn: '12π', answer: '12π' },
    ],
    generate: (qIdx, isExam) => {
      const r = 3 + qIdx * 2 + (isExam ? 1 : 0);
      const ans = `${2 * r}π`;
      return geoQ(15, qIdx, isExam, `دائرة طول نصف قطرها ${r} سم، ما محيطها بدلالة π؟`, `A circle has radius ${r} cm. Find its circumference in terms of π:`, ans, [`${r}π`, `${r * r}π`, `${4 * r}π`], `C = 2π × ${r} = ${ans}.`, `C = 2π(${r}) = ${ans}.`);
    },
  },
  {
    stage: 16,
    titleAr: 'مساحة الدائرة بدلالة π',
    titleEn: 'Area of a Circle',
    summaryAr: 'مساحة الدائرة تساوي π مضروبة في مربع نصف القطر.',
    summaryEn: 'Area of a circle equals π multiplied by the square of its radius.',
    ruleTitleAr: 'مساحة الدائرة',
    ruleTitleEn: 'Circle Area Formula',
    ruleFormula: 'A = πr²',
    examples: [
      { problemAr: 'نصف قطرها 6، مساحتها؟', problemEn: 'Radius 6, area?', solutionAr: '36π', solutionEn: '36π', answer: '36π' },
      { problemAr: 'قطرها 10، مساحتها؟', problemEn: 'Diameter 10, area?', solutionAr: 'r=5 ← 25π', solutionEn: '25π', answer: '25π' },
    ],
    generate: (qIdx, isExam) => {
      const r = 2 + qIdx + (isExam ? 1 : 0);
      const ans = `${r * r}π`;
      return geoQ(16, qIdx, isExam, `دائرة نصف قطرها ${r} سم، ما مساحتها بدلالة π؟`, `Find the area of a circle with radius ${r} cm in terms of π:`, ans, [`${2 * r}π`, `${r}π`, `${(r + 1) * (r + 1)}π`], `A = π × ${r}² = ${ans}.`, `A = π × ${r}² = ${ans}.`);
    },
  },
  {
    stage: 17,
    titleAr: 'نظرية فيثاغورس (إيجاد الوتر)',
    titleEn: 'Pythagorean Theorem: Hypotenuse',
    summaryAr: 'في المثلث القائم مربع الوتر يساوي مجموع مربعي الضلعين القائمين.',
    summaryEn: 'In a right triangle, c² = a² + b².',
    ruleTitleAr: 'معادلة فيثاغورس',
    ruleTitleEn: 'Pythagorean Theorem',
    ruleFormula: 'c = √(a² + b²)',
    examples: [
      { problemAr: 'ضلعان قائمان 3 و 4، ما الوتر؟', problemEn: 'Legs 3 and 4, hypotenuse?', solutionAr: '√(9+16) = 5', solutionEn: '5', answer: '5' },
      { problemAr: 'ضلعان قائمان 6 و 8، ما الوتر؟', problemEn: 'Legs 6 and 8, hypotenuse?', solutionAr: '10', solutionEn: '10', answer: '10' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const triples: [number, number, number][] = [
        [3, 4, 5], [6, 8, 10], [5, 12, 13], [8, 15, 17], [9, 12, 15],
        [7, 24, 25], [12, 16, 20], [10, 24, 26], [15, 20, 25], [9, 40, 41], [12, 35, 37],
      ];
      const [a, b, c] = triples[idx];
      return geoQ(17, qIdx, isExam, `مثلث قائم الزاوية طولا ضلعيه القائمين ${a} سم و ${b} سم، ما طول الوتر؟`, `A right triangle has legs ${a} cm and ${b} cm. Find the hypotenuse:`, String(c), numericDistractors(c, [1, -1, 2, a + b - c]), `√(${a}² + ${b}²) = √${a * a + b * b} = ${c}.`, `√(${a}² + ${b}²) = ${c}.`);
    },
  },
  {
    stage: 18,
    titleAr: 'نظرية فيثاغورس (إيجاد ضلع قائم)',
    titleEn: 'Pythagorean Theorem: Missing Leg',
    summaryAr: 'لإيجاد طول ضلع قائم نطرح مربع الضلع المعلوم من مربع الوتر ثم نأخذ الجذر.',
    summaryEn: 'Subtract the known leg squared from the hypotenuse squared, then take the square root.',
    ruleTitleAr: 'إيجاد الضلع القائم',
    ruleTitleEn: 'Leg Formula',
    ruleFormula: 'a = √(c² − b²)',
    examples: [
      { problemAr: 'الوتر 13 وأحد الضلعين 5، ما الآخر؟', problemEn: 'Hypotenuse 13, leg 5, other leg?', solutionAr: '√(169−25) = 12', solutionEn: '12', answer: '12' },
      { problemAr: 'الوتر 10 وضلع 6، ما الآخر؟', problemEn: 'Hypotenuse 10, leg 6?', solutionAr: '8', solutionEn: '8', answer: '8' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const triples: [number, number, number][] = [
        [3, 4, 5], [6, 8, 10], [5, 12, 13], [8, 15, 17], [9, 12, 15],
        [7, 24, 25], [12, 16, 20], [10, 24, 26], [15, 20, 25], [20, 21, 29], [16, 30, 34],
      ];
      const [a, b, c] = triples[idx];
      return geoQ(18, qIdx, isExam, `مثلث قائم طول وتره ${c} سم وطول أحد ضلعيه القائمين ${a} سم، ما طول الضلع القائم الآخر؟`, `Right triangle with hypotenuse ${c} cm and one leg ${a} cm. Find the other leg:`, String(b), numericDistractors(b, [1, -1, 2, c - b]), `√(${c}² − ${a}²) = √${c * c - a * a} = ${b}.`, `√(${c}² − ${a}²) = ${b}.`);
    },
  },
  {
    stage: 19,
    titleAr: 'حجم متوازي المستطيلات والمكعب',
    titleEn: 'Volume of Cuboids & Cubes',
    summaryAr: 'الحجم يقيس السعة ثلاثية الأبعاد ويُحسب بضرب الطول × العرض × الارتفاع.',
    summaryEn: 'Volume equals length × width × height (or side³ for a cube).',
    ruleTitleAr: 'قانون الحجم',
    ruleTitleEn: 'Box Volume',
    ruleFormula: 'V = L × W × H , V_cube = s³',
    examples: [
      { problemAr: 'صندوق أبعاده 5 و 4 و 3، ما حجمه؟', problemEn: 'Box 5 × 4 × 3, volume?', solutionAr: '60', solutionEn: '60', answer: '60' },
      { problemAr: 'مكعب ضلعه 4، ما حجمه؟', problemEn: 'Cube side 4, volume?', solutionAr: '64', solutionEn: '64', answer: '64' },
    ],
    generate: (qIdx, isExam) => {
      const l = 3 + qIdx;
      const w = 2 + ((qIdx + (isExam ? 1 : 0)) % 5);
      const h = 2 + (qIdx % 4);
      const ans = l * w * h;
      return geoQ(19, qIdx, isExam, `متوازي مستطيلات أبعاده ${l} سم، ${w} سم، ${h} سم، ما حجمه بالسنتيمتر المكعب؟`, `Find the volume of a ${l} × ${w} × ${h} cm rectangular prism:`, String(ans), numericDistractors(ans, [l, -w, 6, -6]), `الحجم = ${l} × ${w} × ${h} = ${ans} سم³.`, `V = ${l} × ${w} × ${h} = ${ans} cm³.`);
    },
  },
  {
    stage: 20,
    titleAr: 'نقطة المنتصف في المستوى الإحداثي',
    titleEn: 'Midpoint in the Coordinate Plane',
    summaryAr: 'إحداثيا نقطة المنتصف هما متوسط الإحداثيين السينيين ومتوسط الصاديين.',
    summaryEn: 'Midpoint coordinates average the x-coordinates and the y-coordinates.',
    ruleTitleAr: 'قانون نقطة المنتصف',
    ruleTitleEn: 'Midpoint Formula',
    ruleFormula: 'M = ((x₁+x₂)/2 , (y₁+y₂)/2)',
    examples: [
      { problemAr: 'منتصف (2, 4) و (8, 10)', problemEn: 'Midpoint of (2,4) and (8,10)', solutionAr: '(5, 7)', solutionEn: '(5, 7)', answer: '(5, 7)' },
      { problemAr: 'منتصف (1, 3) و (7, 9)', problemEn: 'Midpoint of (1,3) and (7,9)', solutionAr: '(4, 6)', solutionEn: '(4, 6)', answer: '(4, 6)' },
    ],
    generate: (qIdx, isExam) => {
      const x1 = 1 + qIdx;
      const y1 = 2 + (qIdx % 5);
      const mx = x1 + 2 + ((qIdx + (isExam ? 1 : 0)) % 4);
      const my = y1 + 3;
      const x2 = 2 * mx - x1;
      const y2 = 2 * my - y1;
      const ans = `(${mx}, ${my})`;
      return geoQ(20, qIdx, isExam, `ما إحداثيا نقطة المنتصف للقطعة الواصلة بين (${x1}, ${y1}) و (${x2}, ${y2})؟`, `Find the midpoint between (${x1}, ${y1}) and (${x2}, ${y2}):`, ans, [`(${mx + 1}, ${my})`, `(${mx}, ${my + 1})`, `(${x2 - x1}, ${y2 - y1})`], `((${x1}+${x2})/2, (${y1}+${y2})/2) = ${ans}.`, `Averaging coordinates gives ${ans}.`);
    },
  },
  // --- HARD (21 - 30) ---
  {
    stage: 21,
    titleAr: 'المسافة بين نقطتين في المستوى',
    titleEn: 'Distance Formula',
    summaryAr: 'نحسب المسافة بين نقطتين بتطبيق نظرية فيثاغورس على فرقي السينات والصادات.',
    summaryEn: 'Distance between two points applies Pythagoras to Δx and Δy.',
    ruleTitleAr: 'قانون المسافة',
    ruleTitleEn: 'Euclidean Distance',
    ruleFormula: 'd = √((x₂−x₁)² + (y₂−y₁)²)',
    examples: [
      { problemAr: 'المسافة بين (1, 2) و (4, 6)', problemEn: 'Distance between (1,2) and (4,6)', solutionAr: '√(3²+4²) = 5', solutionEn: '5', answer: '5' },
      { problemAr: 'المسافة بين (0, 0) و (6, 8)', problemEn: 'Distance between (0,0) and (6,8)', solutionAr: '10', solutionEn: '10', answer: '10' },
    ],
    generate: (qIdx, isExam) => {
      const triples: [number, number, number][] = [[3, 4, 5], [6, 8, 10], [5, 12, 13], [8, 15, 17], [9, 12, 15]];
      const [dx, dy, d] = triples[(qIdx + (isExam ? 1 : 0)) % triples.length];
      const x1 = 1 + qIdx;
      const y1 = 2 + (qIdx % 4);
      return geoQ(21, qIdx, isExam, `ما المسافة بين النقطتين (${x1}, ${y1}) و (${x1 + dx}, ${y1 + dy})؟`, `Find the distance between (${x1}, ${y1}) and (${x1 + dx}, ${y1 + dy}):`, String(d), numericDistractors(d, [1, -1, 2, dx + dy - d]), `√(${dx}² + ${dy}²) = ${d}.`, `√(${dx}² + ${dy}²) = ${d}.`);
    },
  },
  {
    stage: 22,
    titleAr: 'ميل الخط المستقيم',
    titleEn: 'Slope of a Line',
    summaryAr: 'الميل يساوي نسبة التغير الرأسي Δy إلى التغير الأفقي Δx.',
    summaryEn: 'Slope measures vertical rise divided by horizontal run.',
    ruleTitleAr: 'قانون الميل',
    ruleTitleEn: 'Slope Formula',
    ruleFormula: 'm = (y₂ − y₁) / (x₂ − x₁)',
    examples: [
      { problemAr: 'ميل المستقيم المار بـ (1,2) و (4,11)', problemEn: 'Slope through (1,2) and (4,11)', solutionAr: '9 / 3 = 3', solutionEn: '3', answer: '3' },
      { problemAr: 'ميل المستقيم المار بـ (2,5) و (6,13)', problemEn: 'Slope through (2,5) and (6,13)', solutionAr: '8 / 4 = 2', solutionEn: '2', answer: '2' },
    ],
    generate: (qIdx, isExam) => {
      const x1 = 1 + (qIdx % 4);
      const y1 = 2 + (qIdx % 5);
      const dx = 2 + ((qIdx + (isExam ? 1 : 0)) % 4);
      const m = 2 + ((qIdx * 2 + (isExam ? 1 : 0)) % 5);
      const x2 = x1 + dx;
      const y2 = y1 + m * dx;
      return geoQ(22, qIdx, isExam, `ما ميل المستقيم المار بالنقطتين (${x1}, ${y1}) و (${x2}, ${y2})؟`, `Find the slope of the line through (${x1}, ${y1}) and (${x2}, ${y2}):`, String(m), numericDistractors(m, [1, -1, 2, dx]), `(${y2} − ${y1}) ÷ (${x2} − ${x1}) = ${m * dx} ÷ ${dx} = ${m}.`, `(${y2} − ${y1}) / (${x2} − ${x1}) = ${m}.`);
    },
  },
  {
    stage: 23,
    titleAr: 'المساحة السطحية للمكعب ومتوازي المستطيلات',
    titleEn: 'Surface Area of Cubes & Cuboids',
    summaryAr: 'المساحة السطحية هي مجموع مساحات جميع الأوجه الستة للمجسم.',
    summaryEn: 'Surface area sums the areas of all six faces of the solid.',
    ruleTitleAr: 'المساحة الكلية',
    ruleTitleEn: 'Total Surface Area',
    ruleFormula: 'SA_cube = 6s² , SA_box = 2(LW+LH+WH)',
    examples: [
      { problemAr: 'مكعب ضلعه 5، مساحته السطحية؟', problemEn: 'Cube side 5, surface area?', solutionAr: '6 × 25 = 150', solutionEn: '150', answer: '150' },
      { problemAr: 'مكعب ضلعه 3، مساحته السطحية؟', problemEn: 'Cube side 3, surface area?', solutionAr: '54', solutionEn: '54', answer: '54' },
    ],
    generate: (qIdx, isExam) => {
      const s = 2 + qIdx + (isExam ? 1 : 0);
      const ans = 6 * s * s;
      return geoQ(23, qIdx, isExam, `ما المساحة السطحية الكلية لمكعب طول حرفه ${s} سم؟`, `Find the total surface area of a cube with edge length ${s} cm:`, String(ans), numericDistractors(ans, [s * s, -s * s, 6, -6]), `6 × ${s}² = 6 × ${s * s} = ${ans} سم².`, `6 × ${s}² = ${ans} cm².`);
    },
  },
  {
    stage: 24,
    titleAr: 'حجم الأسطوانة بدلالة π',
    titleEn: 'Volume of a Cylinder',
    summaryAr: 'حجم الأسطوانة يساوي مساحة القاعدة الدائرية مضروبة في الارتفاع.',
    summaryEn: 'Cylinder volume equals the circular base area times height.',
    ruleTitleAr: 'حجم الأسطوانة',
    ruleTitleEn: 'Cylinder Volume',
    ruleFormula: 'V = πr²h',
    examples: [
      { problemAr: 'أسطوانة r=3 و h=5، حجمها؟', problemEn: 'Cylinder r=3, h=5, volume?', solutionAr: '45π', solutionEn: '45π', answer: '45π' },
      { problemAr: 'r=4 و h=6، حجمها؟', problemEn: 'r=4, h=6, volume?', solutionAr: '96π', solutionEn: '96π', answer: '96π' },
    ],
    generate: (qIdx, isExam) => {
      const r = 2 + (qIdx % 5);
      const h = 3 + ((qIdx + (isExam ? 1 : 0)) % 7);
      const coef = r * r * h;
      return geoQ(24, qIdx, isExam, `أسطوانة نصف قطر قاعدتها ${r} سم وارتفاعها ${h} سم، ما حجمها بدلالة π؟`, `Cylinder with radius ${r} cm and height ${h} cm. Volume in terms of π?`, `${coef}π`, [`${2 * r * h}π`, `${r * h}π`, `${coef + r}π`], `V = π × ${r}² × ${h} = ${coef}π.`, `V = π(${r}²)(${h}) = ${coef}π.`);
    },
  },
  {
    stage: 25,
    titleAr: 'حجم المخروط والهرم',
    titleEn: 'Volume of Cones & Pyramids',
    summaryAr: 'حجم المخروط أو الهرم يساوي ثلث مساحة القاعدة في الارتفاع.',
    summaryEn: 'Cone or pyramid volume is one-third of base area times height.',
    ruleTitleAr: 'قاعدة الثلث',
    ruleTitleEn: 'One-Third Rule',
    ruleFormula: 'V = ⅓ × BaseArea × h',
    examples: [
      { problemAr: 'هرم مساحة قاعدته 24 وارتفاعه 5', problemEn: 'Pyramid base area 24, height 5', solutionAr: '⅓ × 24 × 5 = 40', solutionEn: '40', answer: '40' },
      { problemAr: 'هرم قاعدته مربعة ضلعها 6 وارتفاعه 4', problemEn: 'Square pyramid side 6, height 4', solutionAr: '⅓ × 36 × 4 = 48', solutionEn: '48', answer: '48' },
    ],
    generate: (qIdx, isExam) => {
      const baseArea = 3 * (4 + qIdx * 2);
      const h = 4 + ((qIdx + (isExam ? 1 : 0)) % 6);
      const ans = (baseArea * h) / 3;
      return geoQ(25, qIdx, isExam, `هرم مساحة قاعدته ${baseArea} سم² وارتفاعه ${h} سم، ما حجمه بالسنتيمتر المكعب؟`, `Pyramid with base area ${baseArea} cm² and height ${h} cm. Volume?`, String(ans), numericDistractors(ans, [baseArea * h - ans, 6, -6, 3]), `⅓ × ${baseArea} × ${h} = ${ans} سم³.`, `⅓ × ${baseArea} × ${h} = ${ans} cm³.`);
    },
  },
  {
    stage: 26,
    titleAr: 'الزاوية الخارجية للمثلث',
    titleEn: 'Exterior Angle of a Triangle',
    summaryAr: 'قياس الزاوية الخارجية للمثلث يساوي مجموع قياسي الزاويتين الداخليتين البعيدتين.',
    summaryEn: 'An exterior angle equals the sum of the two non-adjacent interior angles.',
    ruleTitleAr: 'الزاوية الخارجية',
    ruleTitleEn: 'Exterior Angle Theorem',
    ruleFormula: '∠ext = ∠A + ∠B',
    examples: [
      { problemAr: 'زاويتان داخليتان بعيدتان 45° و 65°، الخارجية؟', problemEn: 'Remote interior 45° and 65°, exterior?', solutionAr: '110°', solutionEn: '110°', answer: '110°' },
      { problemAr: 'خارجية 130° وإحدى البعيدتين 55°، الأخرى؟', problemEn: 'Exterior 130°, one remote 55°?', solutionAr: '75°', solutionEn: '75°', answer: '75°' },
    ],
    generate: (qIdx, isExam) => {
      const a = 32 + qIdx * 4;
      const b = 44 + ((qIdx * 3 + (isExam ? 5 : 0)) % 35);
      const ans = a + b;
      return geoQ(26, qIdx, isExam, `مثلث قياس زاويتين داخليتين فيه ${a}° و ${b}°، ما قياس الزاوية الخارجية المجاورة للزاوية الثالثة؟`, `Two remote interior angles of a triangle are ${a}° and ${b}°. Find the exterior angle:`, `${ans}°`, [`${180 - ans}°`, `${ans + 10}°`, `${ans - 10}°`], `الزاوية الخارجية = ${a}° + ${b}° = ${ans}°.`, `Exterior angle = ${a}° + ${b}° = ${ans}°.`);
    },
  },
  {
    stage: 27,
    titleAr: 'الأشكال المتشابهة ومعامل التشابه',
    titleEn: 'Similar Figures & Scale Factors',
    summaryAr: 'في الأشكال المتشابهة تتناسب الأضلاع المتناظرة بنفس معامل التشابه k.',
    summaryEn: 'Corresponding sides of similar figures share a constant scale factor k.',
    ruleTitleAr: 'تناسب التشابه',
    ruleTitleEn: 'Similarity Ratio',
    ruleFormula: 'Area ratio = k² , Side ratio = k',
    examples: [
      { problemAr: 'مثلثان متشابهان نسبة أضلاعهما 1:3، مساحة الصغير 10، الكبير؟', problemEn: 'Scale 1:3, small area 10, large?', solutionAr: '10 × 3² = 90', solutionEn: '90', answer: '90' },
      { problemAr: 'نسبة التشابه 2، ومحيط الصغير 15', problemEn: 'Scale 2, small perimeter 15', solutionAr: '30', solutionEn: '30', answer: '30' },
    ],
    generate: (qIdx, isExam) => {
      const k = 2 + ((qIdx + (isExam ? 1 : 0)) % 4);
      const smallArea = 5 + qIdx * 2;
      const ans = smallArea * k * k;
      return geoQ(27, qIdx, isExam, `مضلعان متشابهان نسبة أطوال أضلاعهما 1 : ${k}، إذا كانت مساحة الأصغر ${smallArea} سم²، فما مساحة الأكبر؟`, `Two similar polygons have side ratio 1 : ${k}. If the smaller area is ${smallArea} cm², find the larger area:`, String(ans), numericDistractors(ans, [smallArea * k - ans, k, -k, 5]), `نسبة المساحتين = ${k}² = ${k * k}، إذن المساحة = ${smallArea} × ${k * k} = ${ans}.`, `Area scales by k² = ${k * k}: ${smallArea} × ${k * k} = ${ans}.`);
    },
  },
  {
    stage: 28,
    titleAr: 'طول القوس ومساحة القطاع الدائري',
    titleEn: 'Arc Length & Sector Area',
    summaryAr: 'نضرب محيط الدائرة أو مساحتها في نسبة الزاوية المركزية إلى 360°.',
    summaryEn: 'Multiply circumference or area by the central angle fraction θ/360°.',
    ruleTitleAr: 'القطاع الدائري',
    ruleTitleEn: 'Sector Fraction',
    ruleFormula: 'SectorArea = (θ/360) × πr²',
    examples: [
      { problemAr: 'قطاع زاويته 90° في دائرة r=4، مساحته؟', problemEn: '90° sector, r=4, area?', solutionAr: '¼ × 16π = 4π', solutionEn: '4π', answer: '4π' },
      { problemAr: 'قطاع 60° في دائرة r=6، مساحته؟', problemEn: '60° sector, r=6, area?', solutionAr: '1/6 × 36π = 6π', solutionEn: '6π', answer: '6π' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const cases: [number, number][] = [
        [90, 4], [60, 6], [120, 3], [45, 8], [180, 2],
        [90, 8], [60, 12], [120, 6], [30, 6], [180, 4], [45, 4],
      ];
      const [theta, r] = cases[idx];
      const coef = (theta * r * r) / 360;
      return geoQ(28, qIdx, isExam, `قطاع دائري زاويته المركزية ${theta}° في دائرة نصف قطرها ${r} سم، ما مساحته بدلالة π؟`, `Find the area (in terms of π) of a ${theta}° sector in a circle of radius ${r} cm:`, `${coef}π`, [`${r * r}π`, `${coef * 2}π`, `${coef + 3}π`], `(${theta}/360) × π × ${r}² = ${coef}π.`, `(${theta}/360) × π(${r}²) = ${coef}π.`);
    },
  },
  {
    stage: 29,
    titleAr: 'حجم الكرة ومساحتها بدلالة π',
    titleEn: 'Sphere Volume',
    summaryAr: 'يُحسب حجم الكرة بالصيغة (4/3)πr³.',
    summaryEn: 'Compute sphere volume using V = (4/3)πr³.',
    ruleTitleAr: 'حجم الكرة',
    ruleTitleEn: 'Sphere Volume Formula',
    ruleFormula: 'V = (4/3)πr³',
    examples: [
      { problemAr: 'كرة نصف قطرها 3، حجمها؟', problemEn: 'Sphere r=3, volume?', solutionAr: '(4/3)π(27) = 36π', solutionEn: '36π', answer: '36π' },
      { problemAr: 'كرة نصف قطرها 6، حجمها؟', problemEn: 'Sphere r=6, volume?', solutionAr: '(4/3)π(216) = 288π', solutionEn: '288π', answer: '288π' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const r = 3 * (idx + 1);
      const coef = (4 * r * r * r) / 3;
      return geoQ(29, qIdx, isExam, `كرة نصف قطرها ${r} سم، ما حجمها بدلالة π؟`, `Find the volume (in terms of π) of a sphere with radius ${r} cm:`, `${coef}π`, [`${4 * r * r}π`, `${r * r * r}π`, `${coef + 12}π`], `V = (4/3)π × ${r}³ = ${coef}π.`, `V = (4/3)π(${r}³) = ${coef}π.`);
    },
  },
  {
    stage: 30,
    titleAr: 'التحدي الهندسي المتكامل',
    titleEn: 'Master Geometry Challenge',
    summaryAr: 'تطبيق فيثاغورس مع المساحات والحجوم في مسائل هندسية مركبة.',
    summaryEn: 'Combine Pythagorean triples with area and perimeter reasoning.',
    ruleTitleAr: 'الهندسة المركبة',
    ruleTitleEn: 'Composite Geometry',
    ruleFormula: 'Hypotenuse → Area & Perimeter',
    examples: [
      { problemAr: 'مستطيل قطره 13 وعرضه 5، ما مساحته؟', problemEn: 'Rectangle diagonal 13, width 5, area?', solutionAr: 'الطول = 12 ← المساحة = 60', solutionEn: '60', answer: '60' },
      { problemAr: 'معين قطراه 6 و 8، ما محيطه؟', problemEn: 'Rhombus diagonals 6 and 8, perimeter?', solutionAr: 'طول الضلع = √(3²+4²)=5 ← المحيط 20', solutionEn: '20', answer: '20' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const triples: [number, number, number][] = [
        [3, 4, 5], [5, 12, 13], [6, 8, 10], [8, 15, 17], [7, 24, 25],
        [9, 12, 15], [12, 16, 20], [10, 24, 26], [15, 20, 25], [20, 21, 29], [16, 30, 34],
      ];
      const [w, l, d] = triples[idx];
      const ans = w * l;
      return geoQ(30, qIdx, isExam, `مستطيل طول قطره ${d} سم وعرضه ${w} سم، ما مساحته بالسنتيمتر المربع؟`, `A rectangle has diagonal ${d} cm and width ${w} cm. Find its area:`, String(ans), numericDistractors(ans, [w * d - ans, 4, -4, w]), `بفيثاغورس الطول = √(${d}²−${w}²) = ${l}، إذن المساحة = ${w} × ${l} = ${ans}.`, `By Pythagoras, length = ${l}, so area = ${w} × ${l} = ${ans}.`);
    },
  },
];

export const GEOMETRY_STAGES: StageDefinition[] = TOPICS.map((spec) => {
  const questions: QuizQuestion[] = [];
  for (let i = 0; i < 10; i++) {
    questions.push(spec.generate(i, false));
  }
  return {
    id: makeStageId('geometry', spec.stage),
    sectionId: 'geometry',
    stageNumber: spec.stage,
    difficulty: getDifficultyForStage(spec.stage),
    titleAr: spec.titleAr,
    titleEn: spec.titleEn,
    lesson: {
      summaryAr: spec.summaryAr,
      summaryEn: spec.summaryEn,
      ruleTitleAr: spec.ruleTitleAr,
      ruleTitleEn: spec.ruleTitleEn,
      ruleFormula: spec.ruleFormula,
      examples: spec.examples,
    },
    questions,
    examQuestion: spec.generate(10, true),
  };
});
