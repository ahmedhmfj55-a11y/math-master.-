import {
  buildChoiceQuestion,
  formatFraction,
  gcd,
  getDifficultyForStage,
  makeStageId,
  numericDistractors,
} from '@/src/data/curriculum/helpers';
import type { QuizQuestion, StageDefinition, WorkedExample } from '@/src/types/curriculum';

interface RatiosTopicSpec {
  stage: number;
  titleAr: string;
  titleEn: string;
  summaryAr: string;
  summaryEn: string;
  ruleTitleAr: string;
  ruleTitleEn: string;
  ruleFormula: string;
  examples: [WorkedExample, WorkedExample];
  generate: (qIdx: number, isExam: boolean) => QuizQuestion;
}

function makeNumericQ(
  stage: number,
  qIdx: number,
  isExam: boolean,
  promptAr: string,
  promptEn: string,
  correct: number,
  offsets: number[],
  explanationAr: string,
  explanationEn: string,
): QuizQuestion {
  const id = isExam ? `ratios-exam-s${stage}` : `ratios-s${stage}-q${qIdx + 1}`;
  return buildChoiceQuestion({
    id,
    promptAr,
    promptEn,
    correctValue: String(correct),
    distractors: numericDistractors(correct, offsets, false),
    explanationAr,
    explanationEn,
    seedKey: `${id}-${promptEn}`,
  });
}

function makeTextQ(
  stage: number,
  qIdx: number,
  isExam: boolean,
  promptAr: string,
  promptEn: string,
  correctValue: string,
  distractors: string[],
  explanationAr: string,
  explanationEn: string,
): QuizQuestion {
  const id = isExam ? `ratios-exam-s${stage}` : `ratios-s${stage}-q${qIdx + 1}`;
  return buildChoiceQuestion({
    id,
    promptAr,
    promptEn,
    correctValue,
    distractors,
    explanationAr,
    explanationEn,
    seedKey: `${id}-${promptEn}`,
  });
}

const TOPICS: RatiosTopicSpec[] = [
  // EASY (1..10)
  {
    stage: 1,
    titleAr: 'مفهوم النسبة وكتابتها',
    titleEn: 'Understanding Ratios',
    summaryAr: 'النسبة هي مقارنة بين كميتين من النوع نفسه باستخدام القسمة، وتُكتب بصيغة a : b أو a/b.',
    summaryEn: 'A ratio compares two quantities by division and is written as a : b or a/b.',
    ruleTitleAr: 'كتابة النسبة',
    ruleTitleEn: 'Writing a Ratio',
    ruleFormula: 'a : b  (الترتيب مهم)',
    examples: [
      { problemAr: 'في صف 12 ولداً و18 بنتاً، ما نسبة الأولاد إلى البنات بأبسط صورة؟', problemEn: 'In a class of 12 boys and 18 girls, what is the simplest ratio of boys to girls?', solutionAr: 'نقسم الحدين على القاسم المشترك الأكبر 6: 12÷6 : 18÷6 = 2 : 3.', solutionEn: 'Divide both by GCD 6: 12÷6 : 18÷6 = 2 : 3.', answer: '2 : 3' },
      { problemAr: '5 أقلام و15 دفتراً، ما نسبة الأقلام إلى الدفاتر؟', problemEn: '5 pens and 15 notebooks. Ratio of pens to notebooks?', solutionAr: '5 : 15 نقسم على 5 فنحصل على 1 : 3.', solutionEn: '5 : 15 divided by 5 gives 1 : 3.', answer: '1 : 3' },
    ],
    generate: (qIdx, isExam) => {
      const k = 2 + (qIdx % 5) + (isExam ? 1 : 0);
      const a = 2 + (qIdx % 3);
      const b = a + 1 + ((qIdx + (isExam ? 1 : 0)) % 4);
      const g = gcd(a, b);
      const sa = a / g;
      const sb = b / g;
      const totA = a * k;
      const totB = b * k;
      return makeTextQ(
        1, qIdx, isExam,
        `إذا كان عدد الكرات الحمراء ${totA} والزرقاء ${totB}، فما نسبة الحمراء إلى الزرقاء بأبسط صورة؟`,
        `If there are ${totA} red balls and ${totB} blue balls, what is the ratio of red to blue in simplest form?`,
        `${sa} : ${sb}`,
        [`${sb} : ${sa}`, `${sa + 1} : ${sb}`, `${sa} : ${sb + 1}`],
        `نقسم الحدين على القاسم المشترك (${gcd(totA, totB)}) لنحصل على ${sa} : ${sb}.`,
        `Divide both terms by GCD (${gcd(totA, totB)}) to get ${sa} : ${sb}.`,
      );
    },
  },
  {
    stage: 2,
    titleAr: 'النسب المتكافئة',
    titleEn: 'Equivalent Ratios',
    summaryAr: 'نحصل على نسبة مكافئة بضرب حدي النسبة أو قسمتهما على العدد نفسه غير الصفر.',
    summaryEn: 'Equivalent ratios are formed by multiplying or dividing both terms by the same non-zero number.',
    ruleTitleAr: 'خاصية التكافؤ',
    ruleTitleEn: 'Equivalence Property',
    ruleFormula: 'a : b = (a × k) : (b × k)',
    examples: [
      { problemAr: 'أوجد x إذا كانت 3 : 5 = 12 : x', problemEn: 'Find x if 3 : 5 = 12 : x', solutionAr: 'ضربنا 3 في 4 لنحصل على 12، فنضرب 5 في 4 = 20.', solutionEn: '3 multiplied by 4 is 12, so multiply 5 by 4 = 20.', answer: '20' },
      { problemAr: 'أوجد العدد المفقود: 4 : 7 = x : 35', problemEn: 'Find x: 4 : 7 = x : 35', solutionAr: '35 ÷ 7 = 5، إذن x = 4 × 5 = 20.', solutionEn: '35 ÷ 7 = 5, so x = 4 × 5 = 20.', answer: '20' },
    ],
    generate: (qIdx, isExam) => {
      const a = 2 + (qIdx % 5);
      const b = 3 + ((qIdx + 2) % 6) + (a === 3 ? 1 : 0);
      const k = 2 + ((qIdx + (isExam ? 3 : 0)) % 6);
      const x = b * k;
      return makeNumericQ(
        2, qIdx, isExam,
        `أوجد قيمة x في النسبة المتكافئة: ${a} : ${b} = ${a * k} : x`,
        `Find x in the equivalent ratio: ${a} : ${b} = ${a * k} : x`,
        x,
        [b, -b, 2, -2, k],
        `بما أن ${a} × ${k} = ${a * k}، فإن x = ${b} × ${k} = ${x}.`,
        `Since ${a} × ${k} = ${a * k}, x = ${b} × ${k} = ${x}.`,
      );
    },
  },
  {
    stage: 3,
    titleAr: 'معدل الوحدة',
    titleEn: 'Unit Rates',
    summaryAr: 'معدل الوحدة هو مقارنة كمية بواحدة واحدة من كمية أخرى مثل كيلومتر لكل ساعة أو سعر القطعة الواحدة.',
    summaryEn: 'A unit rate compares a quantity to one unit of another quantity, such as cost per item or km per hour.',
    ruleTitleAr: 'حساب معدل الوحدة',
    ruleTitleEn: 'Unit Rate Formula',
    ruleFormula: 'معدل الوحدة = الكمية الأولى ÷ الكمية الثانية',
    examples: [
      { problemAr: 'ثمن 6 دفاتر 42 ريالاً، ما ثمن الدفتر الواحد؟', problemEn: '6 notebooks cost 42 SAR. What is the unit price?', solutionAr: '42 ÷ 6 = 7 ريالات للدفتر.', solutionEn: '42 ÷ 6 = 7 per notebook.', answer: '7' },
      { problemAr: 'تقطع سيارة 240 كم في 3 ساعات، ما سرعتها؟', problemEn: 'A car travels 240 km in 3 hours. What is its speed?', solutionAr: '240 ÷ 3 = 80 كم/ساعة.', solutionEn: '240 ÷ 3 = 80 km/h.', answer: '80' },
    ],
    generate: (qIdx, isExam) => {
      const unitRate = 6 + qIdx * 2 + (isExam ? 3 : 0);
      const units = 3 + (qIdx % 6);
      const total = unitRate * units;
      return makeNumericQ(
        3, qIdx, isExam,
        `إذا كان ثمن ${units} تذاكر يساوي ${total} وحدة نقدية، فما ثمن التذكرة الواحدة؟`,
        `If ${units} tickets cost ${total} credits, what is the price of 1 ticket?`,
        unitRate,
        [1, -1, 2, -2, units],
        `معدل الوحدة = ${total} ÷ ${units} = ${unitRate}.`,
        `Unit rate = ${total} ÷ ${units} = ${unitRate}.`,
      );
    },
  },
  {
    stage: 4,
    titleAr: 'مقارنة النسب والأسعار',
    titleEn: 'Comparing Ratios & Best Buy',
    summaryAr: 'لمقارنة عرضين مختلفين نحسب معدل الوحدة لكل عرض ثم نختار الأفضل أو الأقل سعراً للوحدة.',
    summaryEn: 'To compare two offers, compute the unit rate for each and select the better value.',
    ruleTitleAr: 'مقارنة العرضين',
    ruleTitleEn: 'Comparing Unit Prices',
    ruleFormula: 'الأوفر هو الأقل في (السعر ÷ الكمية)',
    examples: [
      { problemAr: 'عرض أ: 4 أقلام بـ 20، عرض ب: 5 أقلام بـ 20. أيهما أقل سعراً للقلم؟', problemEn: 'Offer A: 4 pens for 20, Offer B: 5 pens for 20. Which has lower unit price?', solutionAr: 'أ = 5 للقلم، ب = 4 للقلم. عرض ب أوفر وسعر القلم 4.', solutionEn: 'A = 5/pen, B = 4/pen. Better unit price is 4.', answer: '4' },
      { problemAr: 'ما الفرق بين معدل 60÷3 و 80÷5؟', problemEn: 'Difference between rates 60÷3 and 80÷5?', solutionAr: '20 - 16 = 4.', solutionEn: '20 - 16 = 4.', answer: '4' },
    ],
    generate: (qIdx, isExam) => {
      const rateLow = 4 + (qIdx % 6) + (isExam ? 2 : 0);
      const rateHigh = rateLow + 2 + (qIdx % 3);
      const qty1 = 3 + (qIdx % 4);
      const qty2 = 4 + ((qIdx + 1) % 4);
      return makeNumericQ(
        4, qIdx, isExam,
        `العرض الأول: ${qty1} علب بـ ${rateHigh * qty1}، والعرض الثاني: ${qty2} علب بـ ${rateLow * qty2}. كم سعر العلبة الواحدة في العرض الأوفر؟`,
        `Offer 1: ${qty1} boxes for ${rateHigh * qty1}. Offer 2: ${qty2} boxes for ${rateLow * qty2}. What is the unit price of the cheaper offer?`,
        rateLow,
        [rateHigh - rateLow, 1, -1, 3],
        `سعر العلبة في الأول = ${rateHigh}، وفي الثاني = ${rateLow}، إذن الأوفر ${rateLow}.`,
        `Offer 1 unit price = ${rateHigh}, Offer 2 = ${rateLow}, so cheaper unit price is ${rateLow}.`,
      );
    },
  },
  {
    stage: 5,
    titleAr: 'مفهوم التناسب وحل التناسب البسيط',
    titleEn: 'Introduction to Proportions',
    summaryAr: 'التناسب هو تساوي نسبتين، ونحله بالضرب التبادلي حيث حاصل ضرب الطرفين يساوي حاصل ضرب الوسطين.',
    summaryEn: 'A proportion is an equation stating two ratios are equal, solved via cross-multiplication.',
    ruleTitleAr: 'الضرب التبادلي',
    ruleTitleEn: 'Cross-Multiplication',
    ruleFormula: 'a/b = c/d  ⟺  a × d = b × c',
    examples: [
      { problemAr: 'حل التناسب: x/6 = 10/15', problemEn: 'Solve: x/6 = 10/15', solutionAr: '15x = 60 ومنه x = 4.', solutionEn: '15x = 60, so x = 4.', answer: '4' },
      { problemAr: 'حل التناسب: 8/x = 4/9', problemEn: 'Solve: 8/x = 4/9', solutionAr: '4x = 72 ومنه x = 18.', solutionEn: '4x = 72, so x = 18.', answer: '18' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const a = 2 + (idx % 4);
      const b = 3 + ((idx + 1) % 5);
      const k = 2 + idx;
      const x = a * k;
      const denom = b * k;
      return makeNumericQ(
        5, qIdx, isExam,
        `حل التناسب لإيجاد قيمة x:  x / ${denom} = ${a} / ${b}`,
        `Solve the proportion for x:  x / ${denom} = ${a} / ${b}`,
        x,
        [2, -2, a, b, -1],
        `${b}x = ${a} × ${denom} = ${a * denom}، وبالتقسيم على ${b} نجد x = ${x}.`,
        `${b}x = ${a} × ${denom} = ${a * denom}, dividing by ${b} gives x = ${x}.`,
      );
    },
  },
  {
    stage: 6,
    titleAr: 'النسبة المئوية والكسور',
    titleEn: 'Percentages & Fractions',
    summaryAr: 'النسبة المئوية هي نسبة مقامها 100؛ لتحويل كسر إلى نسبة مئوية نضربه في 100%.',
    summaryEn: 'A percentage is a ratio out of 100. Multiply a fraction by 100 to express it as a percent.',
    ruleTitleAr: 'تحويل الكسر لنسبة مئوية',
    ruleTitleEn: 'Fraction to Percent',
    ruleFormula: '(a / b) × 100%',
    examples: [
      { problemAr: 'ما النسبة المئوية للكسر 3/4؟', problemEn: 'What percentage is 3/4?', solutionAr: '(3 ÷ 4) × 100 = 75%.', solutionEn: '(3 ÷ 4) × 100 = 75%.', answer: '75%' },
      { problemAr: 'ما النسبة المئوية لـ 2/5؟', problemEn: 'What percentage is 2/5?', solutionAr: '(2 ÷ 5) × 100 = 40%.', solutionEn: '(2 ÷ 5) × 100 = 40%.', answer: '40%' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const pairs: [number, number, number][] = [
        [1, 4, 25], [3, 4, 75], [1, 5, 20], [2, 5, 40], [3, 5, 60],
        [4, 5, 80], [1, 10, 10], [3, 10, 30], [7, 10, 70], [9, 20, 45], [11, 20, 55],
      ];
      const [num, den, pct] = pairs[idx];
      return makeTextQ(
        6, qIdx, isExam,
        `حوّل الكسر ${num}/${den} إلى نسبة مئوية:`,
        `Convert the fraction ${num}/${den} to a percentage:`,
        `${pct}%`,
        [`${pct + 10}%`, `${Math.max(5, pct - 15)}%`, `${pct + 5}%`],
        `(${num} ÷ ${den}) × 100% = ${pct}%.`,
        `(${num} ÷ ${den}) × 100% = ${pct}%.`,
      );
    },
  },
  {
    stage: 7,
    titleAr: 'النسبة المئوية والأعداد العشرية',
    titleEn: 'Percentages & Decimals',
    summaryAr: 'لتحويل عدد عشري إلى نسبة مئوية نضربه في 100، وللتحويل العكسي نقسم على 100.',
    summaryEn: 'Multiply a decimal by 100 to convert to percent; divide a percent by 100 to convert to decimal.',
    ruleTitleAr: 'التحويل بين العشري والمئوي',
    ruleTitleEn: 'Decimal–Percent Conversion',
    ruleFormula: '0.ab = ab%',
    examples: [
      { problemAr: 'اكتب 0.35 بصورة نسبة مئوية', problemEn: 'Write 0.35 as a percent', solutionAr: '0.35 × 100 = 35%.', solutionEn: '0.35 × 100 = 35%.', answer: '35%' },
      { problemAr: 'اكتب 8% بصورة عدد عشري', problemEn: 'Write 8% as a decimal', solutionAr: '8 ÷ 100 = 0.08.', solutionEn: '8 ÷ 100 = 0.08.', answer: '0.08' },
    ],
    generate: (qIdx, isExam) => {
      const pct = 12 + qIdx * 7 + (isExam ? 4 : 0);
      const dec = (pct / 100).toFixed(2);
      if (qIdx % 2 === 0 && !isExam) {
        return makeTextQ(
          7, qIdx, isExam,
          `ما النسبة المئوية المكافئة للعدد العشري ${dec}؟`,
          `Which percentage equals the decimal ${dec}?`,
          `${pct}%`,
          [`${pct / 10}%`, `${pct + 10}%`, `${Math.max(1, pct - 10)}%`],
          `بضرب ${dec} × 100 نحصل على ${pct}%.`,
          `Multiplying ${dec} × 100 gives ${pct}%.`,
        );
      }
      return makeTextQ(
        7, qIdx, isExam,
        `اكتب النسبة ${pct}% على صورة عدد عشري:`,
        `Write ${pct}% as a decimal:`,
        dec,
        [(pct / 10).toFixed(2), ((pct + 10) / 100).toFixed(2), (Math.max(1, pct - 5) / 100).toFixed(2)],
        `بقسمة ${pct} ÷ 100 نحصل على ${dec}.`,
        `Dividing ${pct} ÷ 100 gives ${dec}.`,
      );
    },
  },
  {
    stage: 8,
    titleAr: 'إيجاد نسبة مئوية من عدد',
    titleEn: 'Percent of a Number',
    summaryAr: 'لحساب p% من العدد N، نضرب N في p ثم نقسم على 100.',
    summaryEn: 'To find p% of N, multiply N by p and divide by 100.',
    ruleTitleAr: 'النسبة المئوية من كمية',
    ruleTitleEn: 'Percent of a Quantity',
    ruleFormula: 'الجزء = (النسبة ÷ 100) × الكل',
    examples: [
      { problemAr: 'أوجد 20% من 150', problemEn: 'Find 20% of 150', solutionAr: '(20 ÷ 100) × 150 = 30.', solutionEn: '(20 ÷ 100) × 150 = 30.', answer: '30' },
      { problemAr: 'أوجد 25% من 80', problemEn: 'Find 25% of 80', solutionAr: 'ربع الـ 80 يساوي 20.', solutionEn: 'One quarter of 80 is 20.', answer: '20' },
    ],
    generate: (qIdx, isExam) => {
      const pcts = [10, 20, 25, 30, 40, 50, 60, 75, 80, 15, 35];
      const pct = pcts[(qIdx + (isExam ? 1 : 0)) % pcts.length];
      const whole = 40 + qIdx * 20 + (isExam ? 20 : 0);
      const ans = (pct * whole) / 100;
      return makeNumericQ(
        8, qIdx, isExam,
        `ما قيمة ${pct}% من العدد ${whole}؟`,
        `What is ${pct}% of ${whole}?`,
        ans,
        [5, -5, 10, -10, 2],
        `(${pct} ÷ 100) × ${whole} = ${ans}.`,
        `(${pct} ÷ 100) × ${whole} = ${ans}.`,
      );
    },
  },
  {
    stage: 9,
    titleAr: 'حساب النسبة المئوية للجزء من الكل',
    titleEn: 'Finding What Percent One Number Is of Another',
    summaryAr: 'لمعرفة النسبة المئوية التي يمثلها الجزء من الكل نقسم الجزء على الكل ونضرب في 100%.',
    summaryEn: 'Divide the part by the whole and multiply by 100 to find the percentage.',
    ruleTitleAr: 'قانون النسبة المئوية',
    ruleTitleEn: 'Percentage Formula',
    ruleFormula: 'النسبة% = (الجزء ÷ الكل) × 100',
    examples: [
      { problemAr: 'حصل طالب على 18 من 20، ما نسبته المئوية؟', problemEn: 'A student scored 18 out of 20. What percent is that?', solutionAr: '(18 ÷ 20) × 100 = 90%.', solutionEn: '(18 ÷ 20) × 100 = 90%.', answer: '90%' },
      { problemAr: '12 تمثل كم بالمئة من 40؟', problemEn: '12 is what percent of 40?', solutionAr: '(12 ÷ 40) × 100 = 30%.', solutionEn: '(12 ÷ 40) × 100 = 30%.', answer: '30%' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const bases = [20, 25, 50, 100, 20, 25, 50, 100, 20, 25, 50];
      const base = bases[idx];
      const step = 100 / base;
      const k = 3 + idx * 2;
      const safeK = k >= base ? 4 + (idx % 12) : k;
      const ansPct = safeK * step;
      return makeTextQ(
        9, qIdx, isExam,
        `يمثل العدد ${safeK} من العدد ${base} نسبة مئوية مقدارها:`,
        `What percent of ${base} is ${safeK}?`,
        `${ansPct}%`,
        [`${ansPct + step}%`, `${Math.max(step, ansPct - step)}%`, `${ansPct + 10}%`],
        `(${safeK} ÷ ${base}) × 100 = ${ansPct}%.`,
        `(${safeK} ÷ ${base}) × 100 = ${ansPct}%.`,
      );
    },
  },
  {
    stage: 10,
    titleAr: 'إيجاد الكل بمعلومية الجزء والنسبة',
    titleEn: 'Finding the Whole from a Part and Percent',
    summaryAr: 'إذا عُرف الجزء ونسبته المئوية، نحسب الكل بقسمة الجزء على النسبة مضروباً في 100.',
    summaryEn: 'Given a part and its percentage, divide the part by the percent and multiply by 100 to find the whole.',
    ruleTitleAr: 'إيجاد الكل',
    ruleTitleEn: 'Finding the Whole',
    ruleFormula: 'الكل = (الجزء × 100) ÷ النسبة',
    examples: [
      { problemAr: 'إذا كان 25% من عدد يساوي 15، فما العدد؟', problemEn: 'If 25% of a number is 15, what is the number?', solutionAr: '(15 × 100) ÷ 25 = 60.', solutionEn: '(15 × 100) ÷ 25 = 60.', answer: '60' },
      { problemAr: '40% من مبلغ يساوي 80، ما المبلغ الكلي؟', problemEn: '40% of an amount is 80. Find the total.', solutionAr: '(80 × 100) ÷ 40 = 200.', solutionEn: '(80 × 100) ÷ 40 = 200.', answer: '200' },
    ],
    generate: (qIdx, isExam) => {
      const pcts = [10, 20, 25, 40, 50, 75, 80];
      const pct = pcts[(qIdx + (isExam ? 2 : 0)) % pcts.length];
      const whole = (4 + qIdx + (isExam ? 3 : 0)) * 20;
      const part = (pct * whole) / 100;
      return makeNumericQ(
        10, qIdx, isExam,
        `إذا كان ${pct}% من عدد يساوي ${part}، فما هو العدد الكلي؟`,
        `If ${pct}% of a number is ${part}, what is the whole number?`,
        whole,
        [20, -20, 10, -10, 40],
        `الكل = (${part} × 100) ÷ ${pct} = ${whole}.`,
        `Whole = (${part} × 100) ÷ ${pct} = ${whole}.`,
      );
    },
  },

  // MEDIUM (11..20)
  {
    stage: 11,
    titleAr: 'التناسب الطردي',
    titleEn: 'Direct Proportion',
    summaryAr: 'يتناسب متغيران طردياً إذا زاد أحدهما بزيادة الآخر بالمعامل نفسه بحيث تبقى النسبة y/x ثابتة.',
    summaryEn: 'Two quantities vary directly when their ratio y/x stays constant as both increase or decrease together.',
    ruleTitleAr: 'علاقة التناسب الطردي',
    ruleTitleEn: 'Direct Variation',
    ruleFormula: 'y₁ / x₁ = y₂ / x₂',
    examples: [
      { problemAr: 'تستهلك آلة 12 لتراً في 4 ساعات، كم تستهلك في 7 ساعات؟', problemEn: 'A machine uses 12L in 4 hours. How much in 7 hours?', solutionAr: 'معدل الساعة 3 لترات، وفي 7 ساعات = 21 لتراً.', solutionEn: '3 L/hr × 7 hr = 21 L.', answer: '21' },
      { problemAr: 'ثمن 5 كجم تفاح 30، ما ثمن 8 كجم؟', problemEn: '5 kg apples cost 30. Cost of 8 kg?', solutionAr: 'ثمن الكجم 6، إذن 8 × 6 = 48.', solutionEn: '6 per kg × 8 = 48.', answer: '48' },
    ],
    generate: (qIdx, isExam) => {
      const k = 4 + (qIdx % 7);
      const x1 = 3 + (qIdx % 4);
      const x2 = x1 + 3 + ((qIdx + (isExam ? 2 : 0)) % 5);
      const y1 = k * x1;
      const y2 = k * x2;
      return makeNumericQ(
        11, qIdx, isExam,
        `تتناسب الكميتان طردياً: إذا كانت y = ${y1} عندما x = ${x1}، فما قيمة y عندما x = ${x2}؟`,
        `If y varies directly as x and y = ${y1} when x = ${x1}, find y when x = ${x2}:`,
        y2,
        [k, -k, x2, -x1, 2],
        `ثابت التناسب = ${y1} ÷ ${x1} = ${k}، إذن y = ${k} × ${x2} = ${y2}.`,
        `Constant k = ${y1} ÷ ${x1} = ${k}, so y = ${k} × ${x2} = ${y2}.`,
      );
    },
  },
  {
    stage: 12,
    titleAr: 'التناسب العكسي',
    titleEn: 'Inverse Proportion',
    summaryAr: 'في التناسب العكسي إذا زادت كمية نقصت الأخرى بنفس النسبة، ويبقى حاصل ضربهما x × y ثابتاً.',
    summaryEn: 'In inverse proportion, as one quantity increases the other decreases so that their product x × y stays constant.',
    ruleTitleAr: 'ثابت التناسب العكسي',
    ruleTitleEn: 'Inverse Variation',
    ruleFormula: 'x₁ × y₁ = x₂ × y₂',
    examples: [
      { problemAr: 'ينجز 6 عمال عملاً في 10 أيام، في كم يوم ينجزه 12 عاملاً؟', problemEn: '6 workers finish a job in 10 days. How many days for 12 workers?', solutionAr: '6 × 10 = 12 × y ومنه y = 5 أيام.', solutionEn: '6 × 10 = 12 × y, so y = 5 days.', answer: '5' },
      { problemAr: 'سيارة بسرعة 60 كم/س تقطع مسافة في 4 ساعات، كم ساعة تستغرق بسرعة 80 كم/س؟', problemEn: 'At 60 km/h a trip takes 4 hours. How long at 80 km/h?', solutionAr: '60 × 4 = 240 ÷ 80 = 3 ساعات.', solutionEn: '240 ÷ 80 = 3 hours.', answer: '3' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const pairs: [number, number, number][] = [
        [4, 12, 6], [6, 10, 5], [8, 9, 12], [5, 16, 10], [6, 15, 9],
        [4, 18, 9], [10, 12, 15], [8, 15, 12], [9, 12, 6], [12, 10, 8], [6, 20, 15],
      ];
      const [w1, d1, w2] = pairs[idx];
      const d2 = (w1 * d1) / w2;
      return makeNumericQ(
        12, qIdx, isExam,
        `يُنجز ${w1} عمال مهمة في ${d1} يوماً. كم يوماً يحتاج ${w2} عمال لإنجاز المهمة نفسها بالسرعة ذاتها؟`,
        `${w1} workers complete a task in ${d1} days. How many days will ${w2} workers take at the same rate?`,
        d2,
        [2, -1, 4, 1, -2],
        `بالتناسب العكسي: ${w1} × ${d1} = ${w1 * d1}، وبالتقسيم على ${w2} نحصل على ${d2} يوماً.`,
        `By inverse proportion: (${w1} × ${d1}) ÷ ${w2} = ${d2} days.`,
      );
    },
  },
  {
    stage: 13,
    titleAr: 'التخفيضات والخصم التجاري',
    titleEn: 'Discounts & Sale Price',
    summaryAr: 'لحساب السعر بعد الخصم نحسب قيمة الخصم ونطرحها من السعر الأصلي، أو نضرب في (100% - نسبة الخصم).',
    summaryEn: 'Calculate the discount amount and subtract from the original price, or multiply by (100% - discount%).',
    ruleTitleAr: 'السعر بعد الخصم',
    ruleTitleEn: 'Sale Price Formula',
    ruleFormula: 'السعر الجديد = الأصلي × (1 - نسبة الخصم)',
    examples: [
      { problemAr: 'قميص سعره 200 وعليه خصم 15%، ما سعره بعد الخصم؟', problemEn: 'A 200 shirt has a 15% discount. Sale price?', solutionAr: 'الخصم = 30، السعر الجديد = 200 - 30 = 170.', solutionEn: 'Discount = 30, sale price = 170.', answer: '170' },
      { problemAr: 'خصم 20% على سلعة سعرها 150', problemEn: '20% off a 150 item', solutionAr: '150 × 0.80 = 120.', solutionEn: '150 × 0.80 = 120.', answer: '120' },
    ],
    generate: (qIdx, isExam) => {
      const price = 100 + qIdx * 40 + (isExam ? 20 : 0);
      const discPct = [10, 15, 20, 25, 30, 40][qIdx % 6];
      const salePrice = price - (price * discPct) / 100;
      return makeNumericQ(
        13, qIdx, isExam,
        `سعر جهاز ${price} وخُفض بنسبة ${discPct}%. ما السعر الجديد بعد الخصم؟`,
        `An item priced at ${price} is discounted by ${discPct}%. What is the sale price?`,
        salePrice,
        [(price * discPct) / 100, 10, -10, 20],
        `قيمة الخصم = ${(price * discPct) / 100}، فيصبح السعر ${price} - ${(price * discPct) / 100} = ${salePrice}.`,
        `Discount = ${(price * discPct) / 100}, so sale price = ${price} - ${(price * discPct) / 100} = ${salePrice}.`,
      );
    },
  },
  {
    stage: 14,
    titleAr: 'الزيادة والضريبة المضافة',
    titleEn: 'Markups & Sales Tax',
    summaryAr: 'عند إضافة زيادة أو ضريبة، نحسب مقدار الزيادة ونجمعه إلى السعر الأساسي.',
    summaryEn: 'For a markup or tax, compute the added percentage amount and add it to the base price.',
    ruleTitleAr: 'السعر بعد الزيادة',
    ruleTitleEn: 'Price After Markup/Tax',
    ruleFormula: 'السعر النهائي = الأساسي × (1 + نسبة الزيادة)',
    examples: [
      { problemAr: 'سلعة سعرها 200 تضاف إليها ضريبة 15%، ما السعر النهائي؟', problemEn: 'Item costs 200 plus 15% tax. Total?', solutionAr: 'الضريبة = 30، النهائي = 230.', solutionEn: 'Tax = 30, total = 230.', answer: '230' },
      { problemAr: 'زيادة راتب 400 بنسبة 10%', problemEn: '10% raise on 400', solutionAr: '400 + 40 = 440.', solutionEn: '400 + 40 = 440.', answer: '440' },
    ],
    generate: (qIdx, isExam) => {
      const base = 100 + qIdx * 20 + (isExam ? 40 : 0);
      const taxPct = [5, 10, 15, 20, 25][(qIdx + (isExam ? 1 : 0)) % 5];
      const finalPrice = base + (base * taxPct) / 100;
      return makeNumericQ(
        14, qIdx, isExam,
        `سعر منتج قبل الضريبة ${base}، وتُفرض ضريبة بنسبة ${taxPct}%. ما السعر شامل الضريبة؟`,
        `A product costs ${base} before a ${taxPct}% tax. What is the final price with tax?`,
        finalPrice,
        [(base * taxPct) / 100, 10, -10, 15],
        `الضريبة = ${(base * taxPct) / 100}، إذن الإجمالي = ${base} + ${(base * taxPct) / 100} = ${finalPrice}.`,
        `Tax = ${(base * taxPct) / 100}, total = ${base} + ${(base * taxPct) / 100} = ${finalPrice}.`,
      );
    },
  },
  {
    stage: 15,
    titleAr: 'نسبة التغير المئوية',
    titleEn: 'Percent Change (Increase & Decrease)',
    summaryAr: 'نسبة التغير تقيس مقدار الزيادة أو النقصان منسوباً دائماً إلى القيمة الأصلية.',
    summaryEn: 'Percent change measures the difference between new and old values relative to the original value.',
    ruleTitleAr: 'قانون نسبة التغير',
    ruleTitleEn: 'Percent Change Formula',
    ruleFormula: 'نسبة التغير% = (|الجديد - الأصلي| ÷ الأصلي) × 100',
    examples: [
      { problemAr: 'ارتفع سعر كتاب من 40 إلى 50، ما نسبة الزيادة؟', problemEn: 'Price rose from 40 to 50. Percent increase?', solutionAr: '(10 ÷ 40) × 100 = 25%.', solutionEn: '(10 ÷ 40) × 100 = 25%.', answer: '25%' },
      { problemAr: 'انخفض عدد الطلاب من 200 إلى 160، ما نسبة الانخفاض؟', problemEn: 'Students fell from 200 to 160. Percent decrease?', solutionAr: '(40 ÷ 200) × 100 = 20%.', solutionEn: '(40 ÷ 200) × 100 = 20%.', answer: '20%' },
    ],
    generate: (qIdx, isExam) => {
      const orig = [40, 50, 80, 100, 200][(qIdx + (isExam ? 1 : 0)) % 5];
      const changePct = [10, 15, 20, 25, 30, 40, 50][(qIdx * 2 + (isExam ? 3 : 0)) % 7];
      const safeOrig = orig === 40 && changePct === 15 ? 100 : orig;
      const isInc = qIdx % 2 === 0;
      const next = isInc ? safeOrig + (safeOrig * changePct) / 100 : safeOrig - (safeOrig * changePct) / 100;
      return makeTextQ(
        15, qIdx, isExam,
        `${isInc ? 'ارتفعت' : 'انخفضت'} القيمة من ${safeOrig} إلى ${next}. ما نسبة التغير المئوية؟`,
        `A value ${isInc ? 'increased' : 'decreased'} from ${safeOrig} to ${next}. What is the percent change?`,
        `${changePct}%`,
        [`${changePct + 5}%`, `${Math.max(5, changePct - 5)}%`, `${changePct + 10}%`],
        `الفرق = ${Math.abs(next - safeOrig)}، وبقسمته على الأصل ${safeOrig} ثم الضرب في 100 نحصل على ${changePct}%.`,
        `Change = ${Math.abs(next - safeOrig)}; dividing by ${safeOrig} × 100% = ${changePct}%.`,
      );
    },
  },
  {
    stage: 16,
    titleAr: 'تقسيم الكميات بنسبة معطاة',
    titleEn: 'Dividing Quantities in a Given Ratio',
    summaryAr: 'لتقسيم مبلغ بنسبة a : b، نجمع أجزاء النسبة (a + b) ونقسم المبلغ الكلي عليها لإيجاد قيمة الجزء الواحد.',
    summaryEn: 'To split a total in ratio a : b, sum the ratio parts (a + b) to find the value of one share.',
    ruleTitleAr: 'قيمة الحصة الواحدة',
    ruleTitleEn: 'Value of One Share',
    ruleFormula: 'قيمة الجزء = الكل ÷ (a + b)',
    examples: [
      { problemAr: 'قُسّم 120 بنسبة 1 : 2، ما الحصة الكبرى؟', problemEn: 'Split 120 in ratio 1 : 2. Larger share?', solutionAr: 'مجموع الأجزاء 3، الجزء = 40، الكبرى = 80.', solutionEn: '3 parts → 40 each → larger is 80.', answer: '80' },
      { problemAr: 'قُسّم 100 بنسبة 2 : 3، ما الحصة الصغرى؟', problemEn: 'Split 100 in ratio 2 : 3. Smaller share?', solutionAr: '5 أجزاء → 20 للجزء → الصغرى = 40.', solutionEn: '5 parts → 20 each → smaller is 40.', answer: '40' },
    ],
    generate: (qIdx, isExam) => {
      const a = 2 + (qIdx % 4);
      const b = a + 1 + ((qIdx + (isExam ? 1 : 0)) % 3);
      const share = 10 + qIdx * 5 + (isExam ? 5 : 0);
      const total = (a + b) * share;
      const larger = b * share;
      return makeNumericQ(
        16, qIdx, isExam,
        `تم توزيع ${total} بين شخصين بنسبة ${a} : ${b}. ما نصيب صاحب الحصة الأكبر؟`,
        `${total} is shared between two people in the ratio ${a} : ${b}. What is the larger share?`,
        larger,
        [a * share, share, -share, 20],
        `مجموع الأجزاء = ${a + b}، قيمة الجزء = ${total} ÷ ${a + b} = ${share}، إذن الأكبر = ${b} × ${share} = ${larger}.`,
        `Total parts = ${a + b}, one part = ${share}, larger share = ${b} × ${share} = ${larger}.`,
      );
    },
  },
  {
    stage: 17,
    titleAr: 'النسب الثلاثية (a : b : c)',
    titleEn: 'Three-Term Ratios',
    summaryAr: 'تُستخدم النسب الثلاثية لتوزيع كمية على ثلاثة أطراف أو ربط نسبتين عن طريق العنصر المشترك.',
    summaryEn: 'Three-part ratios distribute a quantity across three shares or combine two ratios sharing a middle term.',
    ruleTitleAr: 'توحيد النسبتين',
    ruleTitleEn: 'Combining Ratios',
    ruleFormula: 'نوحد قيمة b في (a:b) و (b:c)',
    examples: [
      { problemAr: 'قُسّم 180 بنسبة 1 : 2 : 3، ما نصيب الأوسط؟', problemEn: 'Split 180 in 1 : 2 : 3. Middle share?', solutionAr: 'مجموع الأجزاء 6 → الجزء 30 → الأوسط = 60.', solutionEn: '6 parts → 30 each → middle is 60.', answer: '60' },
      { problemAr: 'إذا كان a:b = 2:3 و b:c = 3:5، ما مجموع أجزاء النسبة؟', problemEn: 'If a:b=2:3 and b:c=3:5, sum of parts?', solutionAr: 'a:b:c = 2:3:5 والمجموع 10.', solutionEn: 'a:b:c = 2:3:5, sum = 10.', answer: '10' },
    ],
    generate: (qIdx, isExam) => {
      const a = 1 + (qIdx % 3);
      const b = 2 + (qIdx % 4);
      const c = b + 2 + ((qIdx + (isExam ? 1 : 0)) % 3);
      const unit = 8 + qIdx * 2 + (isExam ? 4 : 0);
      const total = (a + b + c) * unit;
      const ans = c * unit;
      return makeNumericQ(
        17, qIdx, isExam,
        `قُسّم مبلغ ${total} بنسبة ${a} : ${b} : ${c}. ما قيمة الحصة الكبرى؟`,
        `An amount of ${total} is split in ratio ${a} : ${b} : ${c}. What is the largest share?`,
        ans,
        [b * unit, a * unit, unit, -unit],
        `مجموع الأجزاء = ${a + b + c}، قيمة الجزء = ${unit}، الحصة الكبرى = ${c} × ${unit} = ${ans}.`,
        `Total parts = ${a + b + c}, unit = ${unit}, largest share = ${c} × ${unit} = ${ans}.`,
      );
    },
  },
  {
    stage: 18,
    titleAr: 'مقياس الرسم والخرائط',
    titleEn: 'Map Scales & Models',
    summaryAr: 'مقياس الرسم هو نسبة الطول في الرسم إلى الطول الحقيقي بالوحدة نفسها: (الطول على الرسم ÷ الطول الحقيقي).',
    summaryEn: 'Scale is the ratio of drawing length to actual length using the same units.',
    ruleTitleAr: 'قانون مقياس الرسم',
    ruleTitleEn: 'Scale Formula',
    ruleFormula: 'الطول الحقيقي = طول الرسم × معامل المقياس',
    examples: [
      { problemAr: 'مقياس خريطة 1 سم : 5 كم، كم يمثل 4 سم على الخريطة؟', problemEn: 'Scale 1 cm : 5 km. What actual distance is 4 cm?', solutionAr: '4 × 5 = 20 كم.', solutionEn: '4 × 5 = 20 km.', answer: '20' },
      { problemAr: 'المسافة الحقيقية 60 كم والمقياس 1 سم : 10 كم، كم طولها على الخريطة؟', problemEn: 'Actual 60 km, scale 1 cm : 10 km. Map length?', solutionAr: '60 ÷ 10 = 6 سم.', solutionEn: '60 ÷ 10 = 6 cm.', answer: '6' },
    ],
    generate: (qIdx, isExam) => {
      const kmPerCm = 5 + (qIdx % 6) * 5 + (isExam ? 5 : 0);
      const mapCm = 3 + ((qIdx * 2 + (isExam ? 1 : 0)) % 9);
      const actualKm = kmPerCm * mapCm;
      return makeNumericQ(
        18, qIdx, isExam,
        `مقياس رسم خريطة هو 1 سم لكل ${kmPerCm} كم. إذا كانت المسافة بين مدينتين على الخريطة ${mapCm} سم، فما المسافة الحقيقية بالكيلومتر؟`,
        `A map scale is 1 cm : ${kmPerCm} km. If two cities are ${mapCm} cm apart on the map, what is the actual distance in km?`,
        actualKm,
        [kmPerCm, -kmPerCm, 5, -5],
        `المسافة الحقيقية = ${mapCm} × ${kmPerCm} = ${actualKm} كم.`,
        `Actual distance = ${mapCm} × ${kmPerCm} = ${actualKm} km.`,
      );
    },
  },
  {
    stage: 19,
    titleAr: 'الفائدة البسيطة',
    titleEn: 'Simple Interest',
    summaryAr: 'تُحسب الفائدة البسيطة بضرب رأس المال في معدل الفائدة السنوي في عدد السنوات.',
    summaryEn: 'Simple interest is calculated by multiplying Principal × annual Rate × Time in years.',
    ruleTitleAr: 'قانون الفائدة البسيطة',
    ruleTitleEn: 'Simple Interest Formula',
    ruleFormula: 'I = P × r × t',
    examples: [
      { problemAr: 'أُودع مبلغ 1000 بفائدة بسيطة 5% سنوياً لمدة 3 سنوات، ما الفائدة؟', problemEn: 'Principal 1000 at 5% simple interest for 3 years. Find interest.', solutionAr: '1000 × 0.05 × 3 = 150.', solutionEn: '1000 × 0.05 × 3 = 150.', answer: '150' },
      { problemAr: 'مبلغ 2000 بفائدة 4% لمدة سنتين', problemEn: '2000 at 4% for 2 years', solutionAr: '2000 × 0.04 × 2 = 160.', solutionEn: '2000 × 0.04 × 2 = 160.', answer: '160' },
    ],
    generate: (qIdx, isExam) => {
      const p = (10 + qIdx * 5 + (isExam ? 5 : 0)) * 100;
      const r = 4 + (qIdx % 5);
      const t = 2 + (qIdx % 3);
      const interest = (p * r * t) / 100;
      return makeNumericQ(
        19, qIdx, isExam,
        `استُثمر مبلغ ${p} بمعدل عائد بسيط ${r}% سنوياً لمدة ${t} سنوات. ما مقدار العائد؟`,
        `A principal of ${p} earns ${r}% simple annual interest for ${t} years. What is the interest earned?`,
        interest,
        [(p * r) / 100, 50, -50, 20],
        `الفائدة = (${p} × ${r} × ${t}) ÷ 100 = ${interest}.`,
        `Interest = (${p} × ${r} × ${t}) ÷ 100 = ${interest}.`,
      );
    },
  },
  {
    stage: 20,
    titleAr: 'الربح والخسارة في التجارة',
    titleEn: 'Profit & Loss Percentages',
    summaryAr: 'نسبة الربح أو الخسارة تُحسب دائماً بالنسبة إلى سعر التكلفة الأصلي.',
    summaryEn: 'Profit or loss percentage is always measured relative to the original cost price.',
    ruleTitleAr: 'نسبة الربح',
    ruleTitleEn: 'Profit Percentage',
    ruleFormula: 'سعر البيع = التكلفة × (1 + نسبة الربح)',
    examples: [
      { problemAr: 'اشترى تاجر بضاعة بـ 250 وباعها بربح 20%، ما سعر البيع؟', problemEn: 'Bought for 250 and sold at 20% profit. Selling price?', solutionAr: 'الربح = 50، سعر البيع = 300.', solutionEn: 'Profit = 50, selling price = 300.', answer: '300' },
      { problemAr: 'تكلفة 400 وخسارة 10%، ما سعر البيع؟', problemEn: 'Cost 400 with 10% loss. Selling price?', solutionAr: '400 - 40 = 360.', solutionEn: '400 - 40 = 360.', answer: '360' },
    ],
    generate: (qIdx, isExam) => {
      const cost = 200 + qIdx * 40 + (isExam ? 20 : 0);
      const profitPct = [10, 15, 20, 25, 30][qIdx % 5];
      const sell = cost + (cost * profitPct) / 100;
      return makeNumericQ(
        20, qIdx, isExam,
        `تكلفة سلعة ${cost} وتم بيعها بربح ${profitPct}%. ما سعر البيع؟`,
        `An item costs ${cost} and is sold at a ${profitPct}% profit. What is the selling price?`,
        sell,
        [(cost * profitPct) / 100, 20, -20, 40],
        `الربح = ${(cost * profitPct) / 100}، فيكون سعر البيع = ${cost} + ${(cost * profitPct) / 100} = ${sell}.`,
        `Profit = ${(cost * profitPct) / 100}, selling price = ${sell}.`,
      );
    },
  },

  // HARD (21..30)
  {
    stage: 21,
    titleAr: 'التخفيضات المتتالية',
    titleEn: 'Successive Discounts',
    summaryAr: 'الخصمان المتتاليان لا يُجمعان مباشرة؛ يُطبق الخصم الثاني على السعر بعد الخصم الأول.',
    summaryEn: 'Successive discounts do not add linearly; the second discount applies to the already-reduced price.',
    ruleTitleAr: 'السعر بعد خصمين متتاليين',
    ruleTitleEn: 'Successive Discount Factor',
    ruleFormula: 'السعر = الأصلي × (1 - d₁) × (1 - d₂)',
    examples: [
      { problemAr: 'سلعة بـ 200 خُفضت 10% ثم خُفض السعر الجديد 20%، ما السعر النهائي؟', problemEn: '200 item discounted 10%, then 20% off new price. Final price?', solutionAr: '200 × 0.9 = 180، ثم 180 × 0.8 = 144.', solutionEn: '200 × 0.9 = 180, then 180 × 0.8 = 144.', answer: '144' },
      { problemAr: 'ما الخصم المكافئ لخصمين 20% ثم 10%؟', problemEn: 'Single discount equal to 20% then 10%?', solutionAr: '0.8 × 0.9 = 0.72 → خصم 28%.', solutionEn: '0.8 × 0.9 = 0.72 → 28% off.', answer: '28%' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const price = (2 + idx) * 100;
      const d1 = 10 + (idx % 3) * 10; // 10, 20, 30
      const d2 = 10 + ((idx + 1) % 3) * 10;
      const finalPrice = (price * (100 - d1) * (100 - d2)) / 10000;
      const naivePrice = (price * (100 - d1 - d2)) / 100;
      return makeNumericQ(
        21, qIdx, isExam,
        `سلعة سعرها ${price} خُفضت بنسبة ${d1}% ثم خُفض السعر الناتج بنسبة ${d2}%. ما السعر النهائي؟`,
        `An item priced at ${price} is discounted by ${d1}%, then the new price is discounted by ${d2}%. What is the final price?`,
        finalPrice,
        [naivePrice - finalPrice || 8, 10, -10, 12],
        `بعد الخصم الأول = ${(price * (100 - d1)) / 100}، وبعد الثاني = ${finalPrice}.`,
        `After 1st discount = ${(price * (100 - d1)) / 100}, after 2nd = ${finalPrice}.`,
      );
    },
  },
  {
    stage: 22,
    titleAr: 'العودة إلى السعر الأصلي (النسبة العكسية)',
    titleEn: 'Reverse Percentages (Original Price)',
    summaryAr: 'لإيجاد السعر قبل الخصم أو الزيادة، نقسم السعر النهائي على نسبة ما يمثله من الأصل.',
    summaryEn: 'To recover the original price before a discount or markup, divide the final price by its percentage multiplier.',
    ruleTitleAr: 'قانون السعر الأصلي',
    ruleTitleEn: 'Reverse Percentage Formula',
    ruleFormula: 'الأصلي = السعر الجديد ÷ (1 ± النسبة)',
    examples: [
      { problemAr: 'بيعَت سلعة بـ 160 بعد خصم 20%، ما سعرها الأصلي؟', problemEn: 'Sold for 160 after 20% off. Original price?', solutionAr: '160 تمثل 80%، إذن الأصلي = 160 ÷ 0.8 = 200.', solutionEn: '160 is 80%, so 160 ÷ 0.8 = 200.', answer: '200' },
      { problemAr: 'بعد زيادة 25% أصبح العدد 150، ما العدد الأصلي؟', problemEn: 'After 25% increase, value is 150. Original?', solutionAr: '150 ÷ 1.25 = 120.', solutionEn: '150 ÷ 1.25 = 120.', answer: '120' },
    ],
    generate: (qIdx, isExam) => {
      const disc = [20, 25, 30, 40][(qIdx + (isExam ? 1 : 0)) % 4];
      const orig = (4 + qIdx + (isExam ? 2 : 0)) * 50;
      const sale = (orig * (100 - disc)) / 100;
      return makeNumericQ(
        22, qIdx, isExam,
        `بعد خصم ${disc}% أصبح سعر الحاسوب ${sale}. ما سعره الأصلي قبل الخصم؟`,
        `After a ${disc}% discount, a laptop costs ${sale}. What was its original price?`,
        orig,
        [20, -20, 40, Math.round(sale * (disc / 100))],
        `السعر ${sale} يمثل ${100 - disc}% من الأصل، إذن الأصلي = (${sale} × 100) ÷ ${100 - disc} = ${orig}.`,
        `${sale} is ${100 - disc}% of original, so original = ${sale} ÷ ${(100 - disc) / 100} = ${orig}.`,
      );
    },
  },
  {
    stage: 23,
    titleAr: 'النمو المركب خلال سنتين',
    titleEn: 'Compound Growth Over Two Years',
    summaryAr: 'في النمو المركب تُضاف نسبة الزيادة في السنة الثانية على الرصيد الجديد الناتج عن السنة الأولى.',
    summaryEn: 'In compound growth, each year’s percentage increase applies to the updated total from the previous year.',
    ruleTitleAr: 'قانون النمو المركب',
    ruleTitleEn: 'Compound Growth Formula',
    ruleFormula: 'A = P × (1 + r)²',
    examples: [
      { problemAr: 'مبلغ 1000 ينمو 10% سنوياً لمدة سنتين، كم يصبح؟', problemEn: '1000 grows 10% annually for 2 years. Final amount?', solutionAr: '1000 × 1.1 × 1.1 = 1210.', solutionEn: '1000 × 1.1 × 1.1 = 1210.', answer: '1210' },
      { problemAr: 'عدد سكان 10000 ينمو 20% سنتين', problemEn: '10000 grows 20% for 2 years', solutionAr: '10000 × 1.44 = 14400.', solutionEn: '10000 × 1.44 = 14400.', answer: '14400' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const p = (1 + idx) * 1000;
      const r = idx % 2 === 0 ? 10 : 20;
      const factor = r === 10 ? 121 : 144;
      const finalAmt = (p * factor) / 100;
      const simpleAmt = p + (2 * p * r) / 100;
      return makeNumericQ(
        23, qIdx, isExam,
        `استُثمر مبلغ ${p} بعائد مركب ${r}% سنوياً لمدة سنتين. كم يصبح المبلغ الكلي؟`,
        `${p} is invested at ${r}% compound annual growth for 2 years. What is the final total?`,
        finalAmt,
        [simpleAmt - finalAmt, 100, -100, 200],
        `${p} × (1 + ${r / 100})² = ${p} × ${factor / 100} = ${finalAmt}.`,
        `${p} × (1 + ${r / 100})² = ${finalAmt}.`,
      );
    },
  },
  {
    stage: 24,
    titleAr: 'مسائل الخلائط والتركيز',
    titleEn: 'Mixtures & Concentration Ratios',
    summaryAr: 'تركيز محلول يساوي نسبة كمية المادة المذابة إلى الحجم الكلي للمخلوط.',
    summaryEn: 'The concentration of a mixture equals the solute amount divided by the total mixture volume.',
    ruleTitleAr: 'تركيز المحلول',
    ruleTitleEn: 'Mixture Concentration',
    ruleFormula: 'التركيز% = (المادة ÷ المخلوط الكلي) × 100',
    examples: [
      { problemAr: 'خُلط 30 مل ملح مع 70 مل ماء، ما تركيز الملح؟', problemEn: '30 mL salt mixed with 70 mL water. Salt %?', solutionAr: 'الكل 100 مل، إذن التركيز 30%.', solutionEn: 'Total 100 mL, so 30%.', answer: '30%' },
      { problemAr: 'كم كمية الملح في 200 مل محلول تركيزه 15%؟', problemEn: 'How much salt in 200 mL of 15% solution?', solutionAr: '200 × 0.15 = 30 مل.', solutionEn: '200 × 0.15 = 30 mL.', answer: '30' },
    ],
    generate: (qIdx, isExam) => {
      const solute = 15 + qIdx * 5 + (isExam ? 10 : 0);
      const total = [100, 200, 250, 500][(qIdx + (isExam ? 1 : 0)) % 4];
      const safeSolute = (total / 25) * (2 + (qIdx % 5) + (isExam ? 1 : 0));
      const water = total - safeSolute;
      const pct = (safeSolute * 100) / total;
      return makeTextQ(
        24, qIdx, isExam,
        `مُزج ${safeSolute} جرام سكر مع ${water} جرام ماء (المجموع ${total} جرام). ما النسبة المئوية للسكر في المحلول؟`,
        `${safeSolute} g of sugar is mixed with ${water} g of water (total ${total} g). What is the sugar concentration?`,
        `${pct}%`,
        [`${pct + 4}%`, `${Math.max(2, pct - 4)}%`, `${Math.round((safeSolute * 100) / water)}%`],
        `تركيز السكر = (${safeSolute} ÷ ${total}) × 100 = ${pct}%.`,
        `Sugar concentration = (${safeSolute} ÷ ${total}) × 100 = ${pct}%.`,
      );
    },
  },
  {
    stage: 25,
    titleAr: 'السرعة المتوسطة للرحلة',
    titleEn: 'Average Speed Across Multi-Part Trips',
    summaryAr: 'السرعة المتوسطة لا تساوي متوسط السرعتين؛ بل تساوي المسافة الكلية مقسومة على الزمن الكلي.',
    summaryEn: 'Average speed is Total Distance divided by Total Time, not the simple average of two speeds.',
    ruleTitleAr: 'السرعة المتوسطة',
    ruleTitleEn: 'Average Speed Formula',
    ruleFormula: 'السرعة المتوسطة = المسافة الكلية ÷ الزمن الكلي',
    examples: [
      { problemAr: 'قطعت سيارة 120 كم في ساعتين ثم 180 كم في 3 ساعات، ما سرعتها المتوسطة؟', problemEn: '120 km in 2h then 180 km in 3h. Average speed?', solutionAr: '(120+180) ÷ (2+3) = 300 ÷ 5 = 60 كم/س.', solutionEn: '300 ÷ 5 = 60 km/h.', answer: '60' },
      { problemAr: 'ذهاب 60 كم بسرعة 60 كم/س وعودة 60 كم بسرعة 30 كم/س', problemEn: '60 km at 60 km/h and back at 30 km/h', solutionAr: 'الزمن = 1 + 2 = 3 ساعات، السرعة = 120 ÷ 3 = 40.', solutionEn: 'Time 3h, distance 120 → 40 km/h.', answer: '40' },
    ],
    generate: (qIdx, isExam) => {
      const t1 = 2 + (qIdx % 3);
      const t2 = 2 + ((qIdx + 1) % 3);
      const avg = 45 + qIdx * 5 + (isExam ? 10 : 0);
      const totalTime = t1 + t2;
      const totalDist = avg * totalTime;
      const d1 = (avg - 10) * t1;
      const d2 = totalDist - d1;
      return makeNumericQ(
        25, qIdx, isExam,
        `سارت حافلة ${d1} كم في ${t1} ساعات، ثم ${d2} كم في ${t2} ساعات. ما سرعتها المتوسطة للرحلة كلها (كم/س)؟`,
        `A bus traveled ${d1} km in ${t1} hours, then ${d2} km in ${t2} hours. What is its average speed (km/h)?`,
        avg,
        [5, -5, 10, -10],
        `المسافة الكلية = ${totalDist}، الزمن الكلي = ${totalTime}، السرعة المتوسطة = ${totalDist} ÷ ${totalTime} = ${avg}.`,
        `Total distance = ${totalDist}, total time = ${totalTime}, average speed = ${avg}.`,
      );
    },
  },
  {
    stage: 26,
    titleAr: 'ربط النسب المشتركة',
    titleEn: 'Chaining Connected Ratios',
    summaryAr: 'عند وجود نسبتين A:B و B:C، نوحّد قيمة الحد المشترك B بالمضاعف المشترك الأصغر.',
    summaryEn: 'Given A:B and B:C, match the middle term B using the LCM to find A:B:C.',
    ruleTitleAr: 'توحيد الحد المشترك',
    ruleTitleEn: 'Bridging Ratios',
    ruleFormula: 'A:B و B:C  ←  اجعل B متساوياً فيهما',
    examples: [
      { problemAr: 'إذا كان A:B = 2:3 و B:C = 4:5، أوجد A:C بأبسط صورة', problemEn: 'If A:B = 2:3 and B:C = 4:5, find A:C', solutionAr: 'نوحد B إلى 12 فتصبح 8:12:15، إذن A:C = 8:15.', solutionEn: 'Match B to 12 → 8:12:15, so A:C = 8:15.', answer: '8 : 15' },
      { problemAr: 'A:B = 1:2 و B:C = 3:4، فما A:C؟', problemEn: 'A:B = 1:2 and B:C = 3:4, find A:C', solutionAr: 'A:B:C = 3:6:8، إذن A:C = 3:8.', solutionEn: 'A:B:C = 3:6:8, so A:C = 3:8.', answer: '3 : 8' },
    ],
    generate: (qIdx, isExam) => {
      const a = 1 + (qIdx % 3);
      const b1 = 2 + (qIdx % 2);
      const b2 = 3 + ((qIdx + (isExam ? 1 : 0)) % 3);
      const c = 4 + (qIdx % 4);
      const rawA = a * b2;
      const rawC = c * b1;
      const g = gcd(rawA, rawC);
      const sa = rawA / g;
      const sc = rawC / g;
      return makeTextQ(
        26, qIdx, isExam,
        `إذا كانت نسبة A : B = ${a} : ${b1} ونسبة B : C = ${b2} : ${c}، فما نسبة A : C بأبسط صورة؟`,
        `If A : B = ${a} : ${b1} and B : C = ${b2} : ${c}, what is A : C in simplest form?`,
        `${sa} : ${sc}`,
        [`${a} : ${c}`, `${sc} : ${sa}`, `${sa + 1} : ${sc}`],
        `نضرب الأولى في ${b2} والثانية في ${b1} ثم نبسط ${rawA}:${rawC} لنحصل على ${sa} : ${sc}.`,
        `Matching B gives ${rawA}:${rawC}, which simplifies to ${sa} : ${sc}.`,
      );
    },
  },
  {
    stage: 27,
    titleAr: 'معدلات العمل المشترك',
    titleEn: 'Combined Work Rates',
    summaryAr: 'إذا أنجز الأول عملاً في x ساعة والثاني في y ساعة، فإن ما ينجزانه معاً في ساعة واحدة هو (1/x + 1/y).',
    summaryEn: 'If worker A takes x hours and B takes y hours, together in 1 hour they finish 1/x + 1/y of the job.',
    ruleTitleAr: 'قانون العمل المشترك',
    ruleTitleEn: 'Combined Work Formula',
    ruleFormula: '1/T = 1/x + 1/y',
    examples: [
      { problemAr: 'ينجز أحمد عملاً في 6 ساعات وعلي في 3 ساعات، في كم ساعة ينجزانه معاً؟', problemEn: 'A finishes in 6h, B in 3h. Together?', solutionAr: '1/6 + 1/3 = 3/6 = 1/2، إذن ينجزانه في ساعتين.', solutionEn: '1/6 + 1/3 = 1/2 → 2 hours.', answer: '2' },
      { problemAr: 'صنبور يملأ حوضاً في 4 ساعات وآخر في 12 ساعة، كم يستغرقان معاً؟', problemEn: 'Pipe A: 4h, Pipe B: 12h. Together?', solutionAr: '1/4 + 1/12 = 4/12 = 1/3 → 3 ساعات.', solutionEn: '1/4 + 1/12 = 1/3 → 3 hours.', answer: '3' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const cleanTriples: [number, number, number][] = [
        [6, 3, 2], [4, 12, 3], [6, 12, 4], [10, 15, 6], [12, 24, 8],
        [8, 24, 6], [15, 30, 10], [9, 18, 6], [20, 30, 12], [12, 36, 9], [10, 40, 8],
      ];
      const [a, b, together] = cleanTriples[idx];
      return makeNumericQ(
        27, qIdx, isExam,
        `تملأ المضخة الأولى خزاناً في ${a} ساعات، وتملؤه الثانية في ${b} ساعة. في كم ساعة تملآن الخزان إذا عملتا معاً؟`,
        `Pump A fills a tank in ${a} hours and Pump B fills it in ${b} hours. How many hours will it take working together?`,
        together,
        [1, -1, 2, a - together],
        `1/${a} + 1/${b} = 1/${together}، إذن الوقت المطلوب = ${together} ساعات.`,
        `1/${a} + 1/${b} = 1/${together}, so together they take ${together} hours.`,
      );
    },
  },
  {
    stage: 28,
    titleAr: 'النسب في المساحات والحجوم',
    titleEn: 'Scaling Ratios in Area & Volume',
    summaryAr: 'إذا تَغيّر طول الضلع بنسبة k، فإن المحيط يتغير بنسبة k، والمساحة بنسبة k²، والحجم بنسبة k³.',
    summaryEn: 'If linear dimensions scale by k, perimeter scales by k, area by k², and volume by k³.',
    ruleTitleAr: 'تأثير مقياس التمدد',
    ruleTitleEn: 'Scale Factor for Area',
    ruleFormula: 'نسبة المساحتين = (نسبة الضلعين)²',
    examples: [
      { problemAr: 'نسبة طولي ضلعي مربعين 2 : 3، ما نسبة مساحتيهما؟', problemEn: 'Side ratio of two squares is 2 : 3. Area ratio?', solutionAr: '2² : 3² = 4 : 9.', solutionEn: '2² : 3² = 4 : 9.', answer: '4 : 9' },
      { problemAr: 'تضاعف طول ضلع مربع 3 مرات، كم مرة تتضاعف مساحته؟', problemEn: 'Square side triples. How many times does area increase?', solutionAr: '3² = 9 مرات.', solutionEn: '3² = 9 times.', answer: '9' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const pairs: [number, number][] = [
        [1, 2], [1, 3], [2, 3], [1, 4], [3, 4], [2, 5], [3, 5], [4, 5], [1, 5], [2, 7], [3, 7],
      ];
      const [sa, sb] = pairs[idx];
      return makeTextQ(
        28, qIdx, isExam,
        `نسبة تشابه ضلعي مضلعين متشابهين هي ${sa} : ${sb}. ما نسبة مساحتيهما؟`,
        `Two similar polygons have a side ratio of ${sa} : ${sb}. What is the ratio of their areas?`,
        `${sa * sa} : ${sb * sb}`,
        [`${sa} : ${sb}`, `${sa * 2} : ${sb * 2}`, `${sa * sa * sa} : ${sb * sb * sb}`],
        `نربع نسبة التشابه: (${sa})² : (${sb})² = ${sa * sa} : ${sb * sb}.`,
        `Square the side ratio: ${sa}² : ${sb}² = ${sa * sa} : ${sb * sb}.`,
      );
    },
  },
  {
    stage: 29,
    titleAr: 'مسائل متقدمة في تغيير النسب',
    titleEn: 'Dynamic Ratio Shifts',
    summaryAr: 'عند إضافة أو طرح كمية من أحد طرفي النسبة، نحول النسبة إلى معادلة باستخدام المتغير x (مثال 2x و3x).',
    summaryEn: 'When an amount is added to one part of a ratio, express the parts as ax and bx and solve the equation.',
    ruleTitleAr: 'معادلة تغيير النسبة',
    ruleTitleEn: 'Ratio Shift Equation',
    ruleFormula: '(ax + k) / (bx) = c / d',
    examples: [
      { problemAr: 'نسبة الكرات الحمراء للزرقاء 2 : 3، أضيفت 5 حمراء فأصبحت النسبة 3 : 3 (أي 1:1)، كم كرة زرقاء؟', problemEn: 'Red:Blue = 2:3. Add 5 red → ratio 1:1. How many blue?', solutionAr: '2x + 5 = 3x ومنه x = 5، الزرقاء = 3 × 5 = 15.', solutionEn: '2x + 5 = 3x → x = 5 → Blue = 15.', answer: '15' },
      { problemAr: 'نسبة 3:4 وإذا زاد الأول 6 تساويا، كم قيمة الثاني؟', problemEn: 'Ratio 3:4, adding 6 to first makes them equal. Second?', solutionAr: 'x = 6 → الثاني 24.', solutionEn: 'x = 6 → 24.', answer: '24' },
    ],
    generate: (qIdx, isExam) => {
      const a = 2 + (qIdx % 3);
      const b = a + 1 + (qIdx % 2);
      const x = 4 + qIdx + (isExam ? 2 : 0);
      const addA = (b - a) * x;
      const blueCount = b * x;
      return makeNumericQ(
        29, qIdx, isExam,
        `في حقيبة، نسبة الأقلام الزرقاء إلى الحمراء ${a} : ${b}. إذا أضفنا ${addA} قلماً أزرق تساوى العددان. كم قلماً أحمر في الحقيبة؟`,
        `In a bag, blue to red pens are in ratio ${a} : ${b}. Adding ${addA} blue pens makes them equal. How many red pens are there?`,
        blueCount,
        [a * x, x, -x, 6],
        `الفرق بالأجزاء = ${b - a} يساوي ${addA}، إذن الجزء = ${x}، وعدد الحمراء = ${b} × ${x} = ${blueCount}.`,
        `Difference is ${b - a} parts = ${addA}, so 1 part = ${x}, and red pens = ${b} × ${x} = ${blueCount}.`,
      );
    },
  },
  {
    stage: 30,
    titleAr: 'التحدي الشامل للنسب والتناسب',
    titleEn: 'Ratios & Proportions Mastery',
    summaryAr: 'يدمج هذا التحدي النسبة المئوية المتتالية مع توزيع النسب وحساب السعر الأصلي لحل مسائل حياتية متكاملة.',
    summaryEn: 'Synthesizes chained ratios, percentage shifts, discounts, and proportional reasoning.',
    ruleTitleAr: 'استراتيجية الحل المتكامل',
    ruleTitleEn: 'Integrated Ratio Strategy',
    ruleFormula: 'تحديد الأصل ← تطبيق النسب ← حساب الناتج',
    examples: [
      { problemAr: 'رُفع سعر 200 بنسبة 25% ثم خُفض بنسبة 20%، ما السعر النهائي؟', problemEn: '200 increased by 25% then decreased by 20%. Final?', solutionAr: '200 × 1.25 = 250، ثم 250 × 0.8 = 200.', solutionEn: '200 × 1.25 = 250, then × 0.8 = 200.', answer: '200' },
      { problemAr: 'ربح شركة 600 يوزع 2:3 بين شريكين ثم يدفع الأكبر 10% ضريبة، كم يتبقى له؟', problemEn: '600 profit split 2:3; larger pays 10% tax. Remaining?', solutionAr: 'الأكبر = 360، بعد خصم 10% يتبقى 324.', solutionEn: 'Larger = 360, minus 10% = 324.', answer: '324' },
    ],
    generate: (qIdx, isExam) => {
      const unit = 20 + qIdx * 10 + (isExam ? 10 : 0);
      const total = 5 * unit; // split 2:3
      const larger = 3 * unit;
      const net = (larger * 90) / 100;
      return makeNumericQ(
        30, qIdx, isExam,
        `وُزع ربح قدره ${total} بين شريكين بنسبة 2 : 3، ثم دفع الشريك صاحب الحصة الأكبر 10% مصاريف. كم المبلغ الصافي المتبقي له؟`,
        `A profit of ${total} is split 2 : 3 between two partners, and the larger shareholder pays a 10% fee. How much does he keep?`,
        net,
        [larger, 2 * unit, 10, -10],
        `حصة الأكبر = 3 × ${unit} = ${larger}، وبعد خصم 10% (${larger * 0.1}) يتبقى ${net}.`,
        `Larger share = ${larger}; after 10% deduction (${larger * 0.1}), ${net} remains.`,
      );
    },
  },
];

export const RATIOS_STAGES: StageDefinition[] = TOPICS.map((topic) => ({
  id: makeStageId('ratios', topic.stage),
  sectionId: 'ratios',
  stageNumber: topic.stage,
  difficulty: getDifficultyForStage(topic.stage),
  titleAr: topic.titleAr,
  titleEn: topic.titleEn,
  lesson: {
    summaryAr: topic.summaryAr,
    summaryEn: topic.summaryEn,
    ruleTitleAr: topic.ruleTitleAr,
    ruleTitleEn: topic.ruleTitleEn,
    ruleFormula: topic.ruleFormula,
    examples: topic.examples,
  },
  questions: Array.from({ length: 10 }, (_, qIdx) => topic.generate(qIdx, false)),
  examQuestion: topic.generate(10, true),
}));
