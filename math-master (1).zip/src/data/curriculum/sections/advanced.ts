import {
  buildChoiceQuestion,
  getDifficultyForStage,
  makeStageId,
  numericDistractors,
} from '@/src/data/curriculum/helpers';
import type { QuizQuestion, StageDefinition, WorkedExample } from '@/src/types/curriculum';

interface AdvancedTopicSpec {
  stage: number;
  titleAr: string;
  titleEn: string;
  summaryAr: string;
  summaryEn: string;
  ruleTitleAr: string;
  ruleTitleEn: string;
  ruleFormula: string;
  examples: [WorkedExample, WorkedExample];
  generate: (qIdx: number, isExam: boolean) => QuizQuestion;
}

function makeNumericQ(
  stage: number,
  qIdx: number,
  isExam: boolean,
  promptAr: string,
  promptEn: string,
  correct: number,
  offsets: number[],
  explanationAr: string,
  explanationEn: string,
  allowNegative = false,
): QuizQuestion {
  const id = isExam ? `advanced-exam-s${stage}` : `advanced-s${stage}-q${qIdx + 1}`;
  return buildChoiceQuestion({
    id,
    promptAr,
    promptEn,
    correctValue: String(correct),
    distractors: numericDistractors(correct, offsets, allowNegative),
    explanationAr,
    explanationEn,
    seedKey: `${id}-${promptEn}`,
  });
}

function makeTextQ(
  stage: number,
  qIdx: number,
  isExam: boolean,
  promptAr: string,
  promptEn: string,
  correctValue: string,
  distractors: string[],
  explanationAr: string,
  explanationEn: string,
): QuizQuestion {
  const id = isExam ? `advanced-exam-s${stage}` : `advanced-s${stage}-q${qIdx + 1}`;
  return buildChoiceQuestion({
    id,
    promptAr,
    promptEn,
    correctValue,
    distractors,
    explanationAr,
    explanationEn,
    seedKey: `${id}-${promptEn}`,
  });
}

const TOPICS: AdvancedTopicSpec[] = [
  // EASY (1..10)
  {
    stage: 1,
    titleAr: 'مجموع المتسلسلة الحسابية (صيغة غاوس)',
    titleEn: 'Arithmetic Series Sum (Gauss Method)',
    summaryAr: 'لجمع متتابعة حسابية من الحد الأول a إلى الحد الأخير l بعدد حدود n، نستخدم صيغة غاوس بجمع الحدود المتناظرة.',
    summaryEn: 'Sum an arithmetic sequence from first term a to last term l across n terms via n(a + l)/2.',
    ruleTitleAr: 'صيغة غاوس للمجموع',
    ruleTitleEn: 'Gauss Sum Formula',
    ruleFormula: 'S = n × (a + l) ÷ 2',
    examples: [
      { problemAr: 'احسب مجموع الأعداد من 1 إلى 20', problemEn: 'Sum integers from 1 to 20', solutionAr: '20 × (1 + 20) ÷ 2 = 210.', solutionEn: '20 × 21 ÷ 2 = 210.', answer: '210' },
      { problemAr: 'مجموع الأعداد الزوجية من 2 إلى 10', problemEn: 'Sum even numbers 2 to 10', solutionAr: '5 × (2 + 10) ÷ 2 = 30.', solutionEn: '5 × 12 ÷ 2 = 30.', answer: '30' },
    ],
    generate: (qIdx, isExam) => {
      const n = 10 + qIdx * 2 + (isExam ? 4 : 0);
      const sum = (n * (n + 1)) / 2;
      return makeNumericQ(
        1, qIdx, isExam,
        `ما مجموع الأعداد الصحيحة المتتالية من 1 إلى ${n}؟`,
        `What is the sum of consecutive integers from 1 to ${n}?`,
        sum,
        [n, -n, 10, -10],
        `S = ${n} × (${n} + 1) ÷ 2 = ${sum}.`,
        `S = ${n} × (${n} + 1) ÷ 2 = ${sum}.`,
      );
    },
  },
  {
    stage: 2,
    titleAr: 'الأنماط العددية والفروق المتزايدة',
    titleEn: 'Second-Order Number Patterns',
    summaryAr: 'في بعض المتتاليات لا يكون الفرق ثابتاً بل يزداد الفرق نفسه بنمط منتظم (فروق من الدرجة الثانية).',
    summaryEn: 'When first differences grow steadily, track the second differences to predict the next term.',
    ruleTitleAr: 'تحليل الفروق المتتالية',
    ruleTitleEn: 'Second Difference Rule',
    ruleFormula: 'الفرق التالي = الفرق السابق + الزيادة الثابتة',
    examples: [
      { problemAr: 'أكمل النمط: 2، 4، 7، 11، 16، ...', problemEn: 'Next in: 2, 4, 7, 11, 16, ...', solutionAr: 'الفروق +2، +3، +4، +5، التالي +6 = 22.', solutionEn: 'Differences +2,+3,+4,+5 → +6 = 22.', answer: '22' },
      { problemAr: 'أكمل: 1، 4، 9، 16، 25، ...', problemEn: 'Next in: 1, 4, 9, 16, 25, ...', solutionAr: 'مربعات الأعداد، التالي 36.', solutionEn: 'Squares → 36.', answer: '36' },
    ],
    generate: (qIdx, isExam) => {
      const start = 1 + qIdx + (isExam ? 3 : 0);
      const step0 = 2 + (qIdx % 3);
      const t1 = start;
      const t2 = t1 + step0;
      const t3 = t2 + step0 + 1;
      const t4 = t3 + step0 + 2;
      const t5 = t4 + step0 + 3;
      const next = t5 + step0 + 4;
      return makeNumericQ(
        2, qIdx, isExam,
        `ما العدد التالي في المتتالية: ${t1}، ${t2}، ${t3}، ${t4}، ${t5}، ...؟`,
        `What is the next term in the sequence: ${t1}, ${t2}, ${t3}, ${t4}, ${t5}, ...?`,
        next,
        [1, -1, 2, -2],
        `الفروق تتزايد بانتظام (+${step0}, +${step0 + 1}, +${step0 + 2}, +${step0 + 3})، إذن نضيف ${step0 + 4} ليصبح ${next}.`,
        `Differences grow by 1 each step, so add ${step0 + 4} to get ${next}.`,
      );
    },
  },
  {
    stage: 3,
    titleAr: 'اختبارات قابلية القسمة المركبة',
    titleEn: 'Advanced Divisibility Rules',
    summaryAr: 'يقبل العدد القسمة على 6 إذا قبل على 2 و3، وعلى 9 إذا كان مجموع أرقامه من مضاعفات 9، وعلى 4 إذا قبل آخر رقمين على 4.',
    summaryEn: 'A number is divisible by 6 if divisible by 2 & 3; by 9 if its digit sum is a multiple of 9.',
    ruleTitleAr: 'قاعدة المضاعف 9 و 3',
    ruleTitleEn: 'Digit-Sum Divisibility',
    ruleFormula: 'مجموع الأرقام يقبل القسمة على 9 ⟺ العدد يقبل على 9',
    examples: [
      { problemAr: 'ما الرقم k الذي يجعل العدد 4k5 يقبل القسمة على 9؟', problemEn: 'Find digit k so 4k5 is divisible by 9', solutionAr: '4 + k + 5 = 9 + k، أصغر رقم غير صفري يقبل القسمة: k = 0 أو 9 (لو طلبنا أكبر رقم = 9).', solutionEn: '4+k+5 divisible by 9 → k=0 or 9.', answer: '9' },
      { problemAr: 'أصغر رقم يجعل 31k يقبل على 6؟', problemEn: 'Digit k so 31k is divisible by 6?', solutionAr: 'يجب أن يكون زوجياً ومجموعه يقبل على 3 ← 3+1+2=6، إذن k=2.', solutionEn: 'Even and sum multiple of 3 → k=2.', answer: '2' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const pairs: [number, number][] = [
        [1, 2], [1, 3], [1, 4], [1, 5], [1, 6], [2, 3], [2, 4], [2, 5], [3, 4], [3, 5], [4, 4],
      ];
      const [a, b] = pairs[idx];
      const sumKnown = a + b;
      const k = 9 - (sumKnown % 9);
      return makeNumericQ(
        3, qIdx, isExam,
        `ما الرقم الفردي الوحيد k (من 1 إلى 9) الذي يجعل العدد المكوّن من ثلاث خانات ${a}${b}k يقبل القسمة على 9؟`,
        `What single digit k (1–9) makes the 3-digit number ${a}${b}k divisible by 9?`,
        k,
        [1, -1, 2, 3],
        `نجمع الأرقام: ${a} + ${b} + k = ${sumKnown} + k، ولكي يقبل القسمة على 9 يجب أن يكون k = ${k}.`,
        `Sum of digits = ${sumKnown} + k; to be divisible by 9, k = ${k}.`,
      );
    },
  },
  {
    stage: 4,
    titleAr: 'مبدأ برج الحمام (Pigeonhole Principle)',
    titleEn: 'Pigeonhole Principle',
    summaryAr: 'إذا وزعنا أكثر من n غرضاً على n صندوقاً فلا بد أن يحوي أحد الصناديق غرضين على الأقل؛ ولتأكيد الحصول على زوج متماثل نسحب (عدد الأنواع + 1).',
    summaryEn: 'To guarantee a matching pair among k types, draw k + 1 items in the worst-case scenario.',
    ruleTitleAr: 'ضمان زوج متطابق',
    ruleTitleEn: 'Worst-Case Guarantee',
    ruleFormula: 'أقل سحب مؤكد لزوج متماثل = عدد الألوان + 1',
    examples: [
      { problemAr: 'درج فيه جوارب حمراء وزرقاء وخضراء، كم جورباً نسحب في الظلام لنضمن زوجاً من نفس اللون؟', problemEn: 'Red, blue, green socks in dark. Min draws to guarantee a matching pair?', solutionAr: '3 ألوان + 1 = 4 جوارب.', solutionEn: '3 colors + 1 = 4 socks.', answer: '4' },
      { problemAr: '5 ألوان كرات، كم نسحب لنضمن كرتين من نفس اللون؟', problemEn: '5 colors, min draws for 2 matching?', solutionAr: '5 + 1 = 6.', solutionEn: '6.', answer: '6' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const colors = 3 + idx;
      const targetSame = 2 + (idx % 2); // 2 or 3
      const minDraws = colors * (targetSame - 1) + 1;
      return makeNumericQ(
        4, qIdx, isExam,
        `يحتوي صندوق مظلم على عدد كبير من الكرات بـ ${colors} ألوان مختلفة. ما أقل عدد من الكرات يجب سحبه دون نظر لنضمن الحصول على ${targetSame} كرات من اللون نفسه؟`,
        `A dark box contains many balls in ${colors} distinct colors. What is the minimum draws needed to guarantee ${targetSame} balls of the same color?`,
        minDraws,
        [colors, -1, 2, colors + targetSame],
        `في أسوأ حالة نسحب ${targetSame - 1} من كل لون (${colors * (targetSame - 1)})، والكرة التالية تضمن الهدف: ${minDraws}.`,
        `Worst case is ${targetSame - 1} of each of the ${colors} colors plus 1 = ${minDraws}.`,
      );
    },
  },
  {
    stage: 5,
    titleAr: 'المتتاليات الدورية والأيام',
    titleEn: 'Cyclic Patterns & Modular Days',
    summaryAr: 'في الأنماط المتكررة بدورة طولها D (مثل أيام الأسبوع D=7)، نوجد باقي قسمة العدد على D لتحديد الموضع.',
    summaryEn: 'For cycles of length D (like 7 days in a week), take the remainder modulo D to find the landing state.',
    ruleTitleAr: 'الحساب المعياري للدورة',
    ruleTitleEn: 'Modular Cycle Rule',
    ruleFormula: 'الموضع = الباقي من (N ÷ طول الدورة)',
    examples: [
      { problemAr: 'إذا كان اليوم الأحد، فما اليوم بعد 16 يوماً؟', problemEn: 'If today is Sunday, what day is 16 days later?', solutionAr: '16 ÷ 7 = 2 والباقي 2 ← الثلاثاء.', solutionEn: '16 mod 7 = 2 → Tuesday.', answer: 'الثلاثاء / Tuesday' },
      { problemAr: 'تتكرر الإشارة (أحمر، أصفر، أخضر) بالترتيب، ما لون الإشارة رقم 14؟', problemEn: 'Cycle (Red, Yellow, Green). 14th light?', solutionAr: '14 ÷ 3 الباقي 2 ← أصفر.', solutionEn: '14 mod 3 = 2 → Yellow.', answer: 'أصفر / Yellow' },
    ],
    generate: (qIdx, isExam) => {
      const daysAr = ['الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
      const daysEn = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      const startIdx = qIdx % 7;
      const offset = 15 + qIdx * 4 + (isExam ? 3 : 0);
      const endIdx = (startIdx + offset) % 7;
      const d1 = (endIdx + 1) % 7;
      const d2 = (endIdx + 2) % 7;
      const d3 = (endIdx + 5) % 7;
      return makeTextQ(
        5, qIdx, isExam,
        `إذا كان اليوم هو ${daysAr[startIdx]}، فبعد ${offset} يوماً سيكون اليوم هو:`,
        `If today is ${daysEn[startIdx]}, what day of the week is it after ${offset} days?`,
        `${daysAr[endIdx]} (${daysEn[endIdx]})`,
        [
          `${daysAr[d1]} (${daysEn[d1]})`,
          `${daysAr[d2]} (${daysEn[d2]})`,
          `${daysAr[d3]} (${daysEn[d3]})`,
        ],
        `باقي قسمة ${offset} على 7 هو ${offset % 7}، وبعد ${daysAr[startIdx]} بـ ${offset % 7} أيام يأتي ${daysAr[endIdx]}.`,
        `${offset} mod 7 = ${offset % 7}; ${offset % 7} days after ${daysEn[startIdx]} is ${daysEn[endIdx]}.`,
      );
    },
  },
  {
    stage: 6,
    titleAr: 'مسائل المصافحات وأقطار المضلعات',
    titleEn: 'Handshakes & Complete Graphs',
    summaryAr: 'عند مصافحة كل شخص من n شخصاً للبقية مرة واحدة، يكون عدد المصافحات الكلي مساوياً n(n-1) ÷ 2.',
    summaryEn: 'When n people each shake hands with every other person once, total handshakes = n(n − 1) / 2.',
    ruleTitleAr: 'قانون المصافحات',
    ruleTitleEn: 'Handshake Formula',
    ruleFormula: 'عدد المصافحات = n × (n - 1) ÷ 2',
    examples: [
      { problemAr: 'اجتمع 6 أصدقاء وتصافح كل منهم مع الآخر مرة واحدة، كم مصافحة حدثت؟', problemEn: '6 friends shake hands once each. Total handshakes?', solutionAr: '6 × 5 ÷ 2 = 15.', solutionEn: '6 × 5 ÷ 2 = 15.', answer: '15' },
      { problemAr: 'عدد مباريات دوري من دور واحد بين 8 فرق؟', problemEn: 'Single round-robin matches among 8 teams?', solutionAr: '8 × 7 ÷ 2 = 28.', solutionEn: '28.', answer: '28' },
    ],
    generate: (qIdx, isExam) => {
      const n = 5 + qIdx + (isExam ? 1 : 0);
      const total = (n * (n - 1)) / 2;
      return makeNumericQ(
        6, qIdx, isExam,
        `في بطولة رياضية تضم ${n} فرق، يلعب كل فريق ضد كل فريق آخر مباراة واحدة فقط. كم عدد المباريات الكلي؟`,
        `In a tournament with ${n} teams, every team plays every other team once. How many total games are played?`,
        total,
        [n * (n - 1), n * 2, 3, -3],
        `عدد المباريات = ${n} × (${n} - 1) ÷ 2 = ${total}.`,
        `Total games = ${n} × (${n} - 1) ÷ 2 = ${total}.`,
      );
    },
  },
  {
    stage: 7,
    titleAr: 'الحساب العكسي في الألغاز الرياضية',
    titleEn: 'Working Backwards Puzzles',
    summaryAr: 'لحـل ألغاز العمليات المتسلسلة، نبدأ من النتيجة النهائية ونعكس كل عملية بترتيب معكوس.',
    summaryEn: 'Solve multi-step number riddles by starting from the final output and reversing every operation.',
    ruleTitleAr: 'استراتيجية العكس',
    ruleTitleEn: 'Reverse Operations',
    ruleFormula: 'أضِف ⇄ اطرح  |  اضرب ⇄ اقسم',
    examples: [
      { problemAr: 'فكرت في عدد، ضربته في 3 ثم أضفت 5 فكان الناتج 26، ما العدد؟', problemEn: 'Multiplied by 3 then added 5 to get 26. Number?', solutionAr: '26 - 5 = 21، ثم 21 ÷ 3 = 7.', solutionEn: '(26 - 5) ÷ 3 = 7.', answer: '7' },
      { problemAr: 'قسمت عدداً على 2 ثم طرحت 4 فنتج 10', problemEn: 'Divided by 2, subtracted 4 to get 10', solutionAr: '(10 + 4) × 2 = 28.', solutionEn: '28.', answer: '28' },
    ],
    generate: (qIdx, isExam) => {
      const start = 4 + qIdx * 2 + (isExam ? 3 : 0);
      const mult = 2 + (qIdx % 4);
      const add = 3 + (qIdx % 7);
      const end = start * mult + add;
      return makeNumericQ(
        7, qIdx, isExam,
        `اخترتُ عدداً سرياً، ضربته في ${mult} ثم أضفتُ إلى الناتج ${add} فحصلتُ على ${end}. ما العدد السري؟`,
        `I thought of a number, multiplied it by ${mult}, then added ${add} to get ${end}. What was my number?`,
        start,
        [2, -2, mult, add],
        `نعكس بالترتيب: ${end} - ${add} = ${end - add}، ثم ${end - add} ÷ ${mult} = ${start}.`,
        `Work backwards: (${end} - ${add}) ÷ ${mult} = ${start}.`,
      );
    },
  },
  {
    stage: 8,
    titleAr: 'التطابقات الجبرية الذهنية',
    titleEn: 'Mental Math via Algebraic Identities',
    summaryAr: 'باستخدام الفرق بين مربعين (a² - b² = (a-b)(a+b)) نحسب عمليات ضرب وقوى معقدة ذهنياً في ثوانٍ.',
    summaryEn: 'Use a² − b² = (a − b)(a + b) to compute large squares and products mentally in seconds.',
    ruleTitleAr: 'فرق المربعين',
    ruleTitleEn: 'Difference of Squares',
    ruleFormula: 'a² − b² = (a − b)(a + b)',
    examples: [
      { problemAr: 'احسب ذهنياً: 52² - 48²', problemEn: 'Compute mentally: 52² - 48²', solutionAr: '(52 - 48)(52 + 48) = 4 × 100 = 400.', solutionEn: '4 × 100 = 400.', answer: '400' },
      { problemAr: 'احسب 21 × 19 باستخدام التطابق', problemEn: 'Compute 21 × 19 using identities', solutionAr: '(20 + 1)(20 - 1) = 400 - 1 = 399.', solutionEn: '20² - 1² = 399.', answer: '399' },
    ],
    generate: (qIdx, isExam) => {
      const a = 15 + qIdx * 3 + (isExam ? 2 : 0);
      const b = a - (2 + (qIdx % 4));
      const ans = a * a - b * b;
      return makeNumericQ(
        8, qIdx, isExam,
        `احسب قيمة: ${a}² - ${b}²`,
        `Evaluate: ${a}² - ${b}²`,
        ans,
        [(a - b) * (a - b), 10, -10, a + b],
        `(${a} - ${b}) × (${a} + ${b}) = ${a - b} × ${a + b} = ${ans}.`,
        `(${a} - ${b}) × (${a} + ${b}) = ${a - b} × ${a + b} = ${ans}.`,
      );
    },
  },
  {
    stage: 9,
    titleAr: 'العمليات الرمزية المعرّفة حديثاً',
    titleEn: 'Custom Defined Operators',
    summaryAr: 'في مسابقات الرياضيات تُعرّف رموز جديدة مثل (a ⊕ b) بقاعدة معينة؛ نعوّض في القاعدة بدقة حسب الترتيب.',
    summaryEn: 'When a contest defines a custom symbol like a ★ b, substitute a and b in exact order into the formula.',
    ruleTitleAr: 'التعويض في الرمز الجديد',
    ruleTitleEn: 'Operator Substitution',
    ruleFormula: 'إذا كان a ★ b = تعبير جبري ← عوض مكان a و b',
    examples: [
      { problemAr: 'إذا كان a ★ b = 2a + b، أوجد 4 ★ 5', problemEn: 'If a ★ b = 2a + b, find 4 ★ 5', solutionAr: '2(4) + 5 = 13.', solutionEn: '2(4) + 5 = 13.', answer: '13' },
      { problemAr: 'إذا كان a ⊕ b = a² - b، أوجد 5 ⊕ 9', problemEn: 'If a ⊕ b = a² - b, find 5 ⊕ 9', solutionAr: '25 - 9 = 16.', solutionEn: '16.', answer: '16' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const a = 3 + (idx % 5);
      const b = 2 + idx;
      const ans = a * b + (a - b);
      return makeNumericQ(
        9, qIdx, isExam,
        `إذا عُرّفت العملية (★) كالتالي: a ★ b = (a × b) + a - b، فما قيمة ${a} ★ ${b}؟`,
        `If the operation ★ is defined as a ★ b = (a × b) + a - b, find ${a} ★ ${b}:`,
        ans,
        [a * b, a + b, 2, -2],
        `نعوّض: (${a} × ${b}) + ${a} - ${b} = ${a * b} + ${a - b} = ${ans}.`,
        `Substitute: (${a} × ${b}) + ${a} - ${b} = ${ans}.`,
      );
    },
  },
  {
    stage: 10,
    titleAr: 'إيجاد خانة الآحاد للقوى الكبيرة',
    titleEn: 'Units Digit of Large Powers',
    summaryAr: 'تتكرر خانة الآحاد لقوى الأعداد الصحيحة في دورات طولها لا يتجاوز 4؛ نقسم الأس على 4 لمعرفة خانة الآحاد.',
    summaryEn: 'The units digit of powers repeats in cycles of length dividing 4; check exponent mod 4.',
    ruleTitleAr: 'دورة خانة الآحاد',
    ruleTitleEn: 'Units Digit Cycle',
    ruleFormula: 'آحاد aⁿ يتحدد بباقي قسمة n على 4',
    examples: [
      { problemAr: 'ما رقم آحاد العدد 2¹⁰؟', problemEn: 'What is the units digit of 2¹⁰?', solutionAr: 'دورة آحاد 2 هي (2،4،8،6). 10÷4 الباقي 2 ← آحاد 2² = 4.', solutionEn: 'Cycle (2,4,8,6). 10 mod 4 = 2 → 4.', answer: '4' },
      { problemAr: 'ما رقم آحاد العدد 7⁴؟', problemEn: 'Units digit of 7⁴?', solutionAr: '7¹→7، 7²→9، 7³→3، 7⁴→1.', solutionEn: '1.', answer: '1' },
    ],
    generate: (qIdx, isExam) => {
      const bases = [2, 3, 7, 8];
      const cycles: Record<number, number[]> = {
        2: [6, 2, 4, 8],
        3: [1, 3, 9, 7],
        7: [1, 7, 9, 3],
        8: [6, 8, 4, 2],
      };
      const base = bases[(qIdx + (isExam ? 1 : 0)) % bases.length];
      const exp = 11 + qIdx * 3 + (isExam ? 2 : 0);
      const digit = cycles[base][exp % 4];
      return makeNumericQ(
        10, qIdx, isExam,
        `ما رقم الآحاد (الخانة الأولى) لناتج القوة ${base}^${exp}؟`,
        `What is the units (last) digit of ${base}^${exp}?`,
        digit,
        [1, 2, -1, 3].map((d) => ((digit + d + 10) % 10) - digit).filter((x) => x !== 0),
        `دورة آحاد العدد ${base} طولها 4؛ وباقي قسمة ${exp} على 4 هو ${exp % 4}، فيكون الآحاد ${digit}.`,
        `The units cycle of ${base} has length 4; ${exp} mod 4 = ${exp % 4}, giving units digit ${digit}.`,
      );
    },
  },

  // MEDIUM (11..20)
  {
    stage: 11,
    titleAr: 'الأعمار والمعادلات الزمنية',
    titleEn: 'Age Word Puzzles',
    summaryAr: 'في مسائل الأعمار يزداد عمر كل شخص بالمقدار نفسه بعد مرور عدد من السنوات، ويبقى الفرق بين العمرين ثابتاً للأبد.',
    summaryEn: 'In age problems, everyone ages by the same amount over t years, and age differences stay constant.',
    ruleTitleAr: 'ثبات فرق العمر',
    ruleTitleEn: 'Constant Age Difference',
    ruleFormula: 'العمر بعد t سنة = العمر الحالي + t',
    examples: [
      { problemAr: 'عمر أب 3 أمثال عمر ابنه، ومجموع عمريهما 48، ما عمر الابن؟', problemEn: 'Father is 3× son, sum is 48. Son’s age?', solutionAr: 'x + 3x = 48 ← 4x = 48 ← x = 12.', solutionEn: '4x = 48 → x = 12.', answer: '12' },
      { problemAr: 'أكبر من أخيه بـ 6 سنوات ومجموع عمريهما 26', problemEn: '6 years older, sum 26', solutionAr: 'الأصغر = (26 - 6) ÷ 2 = 10.', solutionEn: '10.', answer: '10' },
    ],
    generate: (qIdx, isExam) => {
      const k = 2 + (qIdx % 3); // ratio
      const son = 8 + qIdx + (isExam ? 2 : 0);
      const t = 4 + (qIdx % 5);
      const sumNow = son * (k + 1);
      const sonLater = son + t;
      return makeNumericQ(
        11, qIdx, isExam,
        `مجموع عمري أب وابنه الآن ${sumNow} سنة، وعمر الأب يساوي ${k} أمثال عمر الابن. كم سيصبح عمر الابن بعد ${t} سنوات؟`,
        `A father and son’s ages sum to ${sumNow}, and the father is ${k} times as old as the son. How old will the son be in ${t} years?`,
        sonLater,
        [son - sonLater, k * son, 2, -2],
        `عمر الابن الآن = ${sumNow} ÷ ${k + 1} = ${son} سنة، وبعد ${t} سنوات يصبح ${sonLater}.`,
        `Son now = ${sumNow} ÷ ${k + 1} = ${son}; in ${t} years he will be ${sonLater}.`,
      );
    },
  },
  {
    stage: 12,
    titleAr: 'زوايا عقارب الساعة',
    titleEn: 'Clock Angle Problems',
    summaryAr: 'يتحرك عقرب الساعات 30° في الساعة (و0.5° في الدقيقة)، بينما يتحرك عقرب الدقائق 6° في الدقيقة.',
    summaryEn: 'The hour hand moves 30° per hour (0.5°/min) while the minute hand moves 6° per minute.',
    ruleTitleAr: 'زاوية الساعة التناظرية',
    ruleTitleEn: 'Clock Angle Formula',
    ruleFormula: 'θ = |30H − 5.5M|',
    examples: [
      { problemAr: 'ما الزاوية الصغرى بين العقربين عند الساعة 3:00؟', problemEn: 'Angle at 3:00?', solutionAr: '3 × 30 = 90°.', solutionEn: '90°.', answer: '90' },
      { problemAr: 'ما الزاوية عند 4:20؟', problemEn: 'Angle at 4:20?', solutionAr: '|30(4) - 5.5(20)| = |120 - 110| = 10°.', solutionEn: '|120 - 110| = 10°.', answer: '10' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const pairs: [number, number][] = [
        [2, 20], [4, 20], [6, 20], [8, 20], [10, 20], [3, 30], [5, 30], [7, 30], [9, 30], [1, 10], [2, 30],
      ];
      const [h, m] = pairs[idx];
      const raw = Math.abs(30 * h - 5.5 * m);
      const angle = raw > 180 ? 360 - raw : raw;
      return makeNumericQ(
        12, qIdx, isExam,
        `ما قياس الزاوية الصغرى بين عقربي الساعات والدقائق عندما تشير الساعة إلى ${h}:${m}؟`,
        `What is the smaller angle (in degrees) between the hour and minute hands at ${h}:${m}?`,
        angle,
        [15, -10, 30, 5],
        `|30×${h} - 5.5×${m}| = ${raw}° (والزاوية الصغرى = ${angle}°).`,
        `|30×${h} - 5.5×${m}| = ${angle}°.`,
      );
    },
  },
  {
    stage: 13,
    titleAr: 'مسائل التلاقي والالتحاق في الحركة',
    titleEn: 'Meeting & Catch-Up Motion',
    summaryAr: 'عند تحرك جسمين باتجاهين متعاكسين تُجمع سرعتاهما لإيجاد سرعة الاقتراب، وفي نفس الاتجاه تُطرح سرعتاهما.',
    summaryEn: 'For opposite directions add speeds to find closing rate; for same direction subtract speeds.',
    ruleTitleAr: 'السرعة النسبية',
    ruleTitleEn: 'Relative Speed',
    ruleFormula: 'متعاكسان: v₁ + v₂  |  نفس الاتجاه: |v₁ - v₂|',
    examples: [
      { problemAr: 'مسافة 300 كم بين سيارتين تتجهان نحو بعضهما بسرعتي 60 و40 كم/س، متى تلتقيان؟', problemEn: '300 km apart moving toward each other at 60 & 40 km/h. Time to meet?', solutionAr: '300 ÷ (60 + 40) = 3 ساعات.', solutionEn: '300 ÷ 100 = 3 hours.', answer: '3' },
      { problemAr: 'المسافة بين عدّاءين 40 م وسرعتاهما 12 و 8 م/ث بنفس الاتجاه، متى يلحق الأسرع؟', problemEn: '40 m apart same direction, 12 & 8 m/s. Catch-up time?', solutionAr: '40 ÷ (12 - 8) = 10 ثوانٍ.', solutionEn: '10 seconds.', answer: '10' },
    ],
    generate: (qIdx, isExam) => {
      const v1 = 40 + qIdx * 5;
      const v2 = 30 + (qIdx % 4) * 5;
      const hours = 2 + ((qIdx + (isExam ? 1 : 0)) % 5);
      const dist = (v1 + v2) * hours;
      return makeNumericQ(
        13, qIdx, isExam,
        `انطلق قطاران من مدينتين بينهما ${dist} كم باتجاه بعضهما، سرعة الأول ${v1} كم/س والثاني ${v2} كم/س. بعد كم ساعة يلتقيان؟`,
        `Two trains start ${dist} km apart heading toward each other at ${v1} km/h and ${v2} km/h. In how many hours do they meet?`,
        hours,
        [1, -1, 2, 3],
        `السرعة النسبية = ${v1} + ${v2} = ${v1 + v2} كم/س، إذن الزمن = ${dist} ÷ ${v1 + v2} = ${hours} ساعات.`,
        `Closing speed = ${v1 + v2} km/h; time = ${dist} ÷ ${v1 + v2} = ${hours} hours.`,
      );
    },
  },
  {
    stage: 14,
    titleAr: 'المجموع والفرق وضرب الجذور والمتطابقات',
    titleEn: 'Sum, Difference & Product Identities',
    summaryAr: 'بمعرفة (x + y) و (xy) نوجد (x² + y²) فوراً باستخدام المتطابقة التربيعية دون الحاجة لإيجاد x و y منفردين.',
    summaryEn: 'Compute x² + y² directly from (x + y)² − 2xy without solving for x and y individually.',
    ruleTitleAr: 'متطابقة مجموع المربعين',
    ruleTitleEn: 'Sum of Squares Identity',
    ruleFormula: 'x² + y² = (x + y)² − 2xy',
    examples: [
      { problemAr: 'إذا كان x + y = 7 و xy = 10، أوجد x² + y²', problemEn: 'If x + y = 7 and xy = 10, find x² + y²', solutionAr: '7² - 2(10) = 49 - 20 = 29.', solutionEn: '49 - 20 = 29.', answer: '29' },
      { problemAr: 'إذا كان x - y = 5 و xy = 6، أوجد x² + y²', problemEn: 'x - y = 5, xy = 6. Find x² + y²', solutionAr: '5² + 2(6) = 37.', solutionEn: '37.', answer: '37' },
    ],
    generate: (qIdx, isExam) => {
      const s = 6 + qIdx + (isExam ? 2 : 0);
      const p = 5 + qIdx * 2;
      const ans = s * s - 2 * p;
      return makeNumericQ(
        14, qIdx, isExam,
        `إذا كان x + y = ${s} و x × y = ${p}، فما قيمة x² + y²؟`,
        `If x + y = ${s} and xy = ${p}, what is the value of x² + y²?`,
        ans,
        [2 * p, -p, 4, -4],
        `x² + y² = (x + y)² - 2xy = ${s}² - 2(${p}) = ${s * s} - ${2 * p} = ${ans}.`,
        `x² + y² = ${s}² - 2(${p}) = ${ans}.`,
      );
    },
  },
  {
    stage: 15,
    titleAr: 'حل جمل المعادلات بالحيل المتماثلة',
    titleEn: 'Symmetric Systems of Equations',
    summaryAr: 'عند جمع معادلتين متماثلتين نحصل مباشرة على قيمة (x + y) دون حل كل متغير على حدة.',
    summaryEn: 'Add or subtract symmetric equations directly to find x + y or x − y in a single step.',
    ruleTitleAr: 'الجمع المباشر للمعادلات',
    ruleTitleEn: 'Symmetric Elimination',
    ruleFormula: '(ax + by = c) و (bx + ay = d)  ← اجمع المعادلتين',
    examples: [
      { problemAr: 'إذا كان 3x + 2y = 14 و 2x + 3y = 16، أوجد x + y', problemEn: '3x + 2y = 14 and 2x + 3y = 16. Find x + y', solutionAr: 'بالجمع: 5x + 5y = 30 ← x + y = 6.', solutionEn: 'Add: 5(x+y)=30 → x+y=6.', answer: '6' },
      { problemAr: 'إذا كان x + y = 10 و y + z = 14 و x + z = 12، ما x + y + z؟', problemEn: 'x+y=10, y+z=14, x+z=12. Find x+y+z', solutionAr: '2(x+y+z) = 36 ← 18.', solutionEn: '18.', answer: '18' },
    ],
    generate: (qIdx, isExam) => {
      const a = 3 + (qIdx % 4);
      const b = a + 2;
      const sumXY = 5 + qIdx + (isExam ? 2 : 0);
      const x = 2 + (qIdx % 3);
      const y = sumXY - x;
      const rhs1 = a * x + b * y;
      const rhs2 = b * x + a * y;
      return makeNumericQ(
        15, qIdx, isExam,
        `إذا كان ${a}x + ${b}y = ${rhs1} و ${b}x + ${a}y = ${rhs2}، فما قيمة (x + y)؟`,
        `If ${a}x + ${b}y = ${rhs1} and ${b}x + ${a}y = ${rhs2}, find (x + y):`,
        sumXY,
        [2, -2, a + b, 1],
        `بجمع المعادلتين: ${a + b}(x + y) = ${rhs1 + rhs2}، وبالقسمة على ${a + b} نجد x + y = ${sumXY}.`,
        `Adding both gives ${a + b}(x + y) = ${rhs1 + rhs2}, so x + y = ${sumXY}.`,
      );
    },
  },
  {
    stage: 16,
    titleAr: 'مجموع المتسلسلة الهندسية المنتهية',
    titleEn: 'Finite Geometric Series',
    summaryAr: 'في المتتابعة الهندسية يُضرب كل حد في أساس ثابت r، ومجموع أول n حدود يساوي a(rⁿ − 1) ÷ (r − 1).',
    summaryEn: 'In a geometric sequence each term multiplies by ratio r; its sum is a(rⁿ − 1) / (r − 1).',
    ruleTitleAr: 'مجموع المتسلسلة الهندسية',
    ruleTitleEn: 'Geometric Sum Formula',
    ruleFormula: 'Sₙ = a × (rⁿ − 1) ÷ (r − 1)',
    examples: [
      { problemAr: 'احسب مجموع: 1 + 2 + 4 + 8 + 16', problemEn: 'Sum: 1 + 2 + 4 + 8 + 16', solutionAr: '2⁵ - 1 = 31.', solutionEn: '31.', answer: '31' },
      { problemAr: 'احسب مجموع أول 4 حدود من: 3، 9، 27، 81', problemEn: 'Sum 3 + 9 + 27 + 81', solutionAr: '3 × (3⁴ - 1) ÷ 2 = 120.', solutionEn: '120.', answer: '120' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const configs: [number, number, number][] = [
        [1, 2, 4], [2, 3, 3], [3, 2, 5], [4, 3, 4], [5, 2, 6],
        [2, 3, 4], [6, 2, 5], [3, 3, 3], [7, 2, 4], [4, 3, 5], [8, 2, 5],
      ];
      const [a, r, n] = configs[idx];
      const sum = (a * (r ** n - 1)) / (r - 1);
      const terms = Array.from({ length: n }, (_, i) => a * r ** i);
      return makeNumericQ(
        16, qIdx, isExam,
        `أوجد مجموع المتسلسلة الهندسية: ${terms.join(' + ')}`,
        `Find the sum of the geometric series: ${terms.join(' + ')}`,
        sum,
        [terms[n - 1], -a, 4, 8],
        `a = ${a}, r = ${r}, n = ${n}: المجموع = ${a}×(${r}^${n} - 1)÷(${r}-1) = ${sum}.`,
        `Using Sₙ = a(rⁿ - 1)/(r - 1) gives ${sum}.`,
      );
    },
  },
  {
    stage: 17,
    titleAr: 'مسائل الحنفيات والملء والتفريغ',
    titleEn: 'Pipes Filling & Draining Tanks',
    summaryAr: 'إذا كان صنبور يملأ في a ساعة ومصرف يفرغ في b ساعة، فصافي الامتلاء في الساعة يساوي (1/a - 1/b).',
    summaryEn: 'When a pipe fills in a hours and a drain empties in b hours, net hourly rate is 1/a − 1/b.',
    ruleTitleAr: 'صافي معدل الملء',
    ruleTitleEn: 'Net Fill Rate',
    ruleFormula: '1/T = 1/ملء − 1/تفريغ',
    examples: [
      { problemAr: 'صنبور يملأ خزاناً في 3 ساعات ومصرف يفرغه في 6 ساعات، في كم ساعة يمتلئ إذا فُتحا معاً؟', problemEn: 'Fill 3h, drain 6h. Time to fill together?', solutionAr: '1/3 - 1/6 = 1/6 ← 6 ساعات.', solutionEn: '6 hours.', answer: '6' },
      { problemAr: 'ملء في 4 ساعات وتفريغ في 12 ساعة', problemEn: 'Fill 4h, drain 12h', solutionAr: '1/4 - 1/12 = 2/12 = 1/6 ← 6 ساعات.', solutionEn: '6 hours.', answer: '6' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const cases: [number, number, number][] = [
        [2, 4, 4], [3, 6, 6], [4, 12, 6], [4, 8, 8], [6, 12, 12],
        [5, 10, 10], [6, 18, 9], [8, 24, 12], [10, 30, 15], [12, 24, 24], [3, 12, 4],
      ];
      const [fill, drain, netTime] = cases[idx];
      return makeNumericQ(
        17, qIdx, isExam,
        `تملأ مضخة حوضاً خلال ${fill} ساعات، بينما يفرّغه مصرف خلال ${drain} ساعة. إذا فُتحا معاً، فبعد كم ساعة يمتلئ الحوض؟`,
        `An inlet pipe fills a pool in ${fill} hours while a drain empties it in ${drain} hours. If both are open, how many hours to fill the pool?`,
        netTime,
        [2, -1, 4, drain - fill],
        `1/${fill} - 1/${drain} = 1/${netTime}، إذن يمتلئ خلال ${netTime} ساعات.`,
        `1/${fill} - 1/${drain} = 1/${netTime}, so it fills in ${netTime} hours.`,
      );
    },
  },
  {
    stage: 18,
    titleAr: 'مميز المعادلة التربيعية وعدد جذورها',
    titleEn: 'Quadratic Discriminant & Root Analysis',
    summaryAr: 'في المعادلة ax² + bx + c = 0، يحدد المميز Δ = b² − 4ac عدد الجذور الحقيقية: موجب (جذران)، صفر (جذر واحد)، سالب (لا يوجد جذور حقيقية).',
    summaryEn: 'For ax² + bx + c = 0, discriminant Δ = b² − 4ac determines the number of real roots.',
    ruleTitleAr: 'قانون المميز',
    ruleTitleEn: 'Discriminant Formula',
    ruleFormula: 'Δ = b² − 4ac',
    examples: [
      { problemAr: 'أوجد قيمة المميز للمعادلة: x² - 6x + 9 = 0', problemEn: 'Find Δ for x² - 6x + 9 = 0', solutionAr: '(-6)² - 4(1)(9) = 36 - 36 = 0.', solutionEn: '0.', answer: '0' },
      { problemAr: 'قيمة k التي تجعل للمعادلة x² - kx + 16 = 0 جذراً حقيقياً مكرراً (k > 0)؟', problemEn: 'Positive k for equal roots of x² - kx + 16 = 0?', solutionAr: 'k² - 64 = 0 ← k = 8.', solutionEn: 'k = 8.', answer: '8' },
    ],
    generate: (qIdx, isExam) => {
      const r = 3 + qIdx + (isExam ? 1 : 0);
      const b = 2 * r;
      const c = r * r;
      return makeNumericQ(
        18, qIdx, isExam,
        `ما قيمة الثابت الموجب k التي تجعل للمعادلة التربيعية x² - kx + ${c} = 0 جذراً حقيقياً واحداً مكرراً (Δ = 0)؟`,
        `Find the positive constant k so that x² - kx + ${c} = 0 has exactly one repeated real root (Δ = 0):`,
        b,
        [r, 2, -2, 4],
        `نضع Δ = k² - 4(1)(${c}) = 0 ← k² = ${4 * c} ← k = ${b}.`,
        `Set Δ = k² - 4(${c}) = 0 → k = √${4 * c} = ${b}.`,
      );
    },
  },
  {
    stage: 19,
    titleAr: 'المعادلات الأسية واللوغاريتمية الأساسية',
    titleEn: 'Exponential Equations & Basic Logarithms',
    summaryAr: 'اللوغاريتم log_b(x) يسأل: ما الأس الذي نرفع له الأساس b لنحصل على x؟',
    summaryEn: 'log_b(x) gives the exponent needed on base b to produce x: b^y = x ⟺ log_b(x) = y.',
    ruleTitleAr: 'التكافؤ الأسي اللوغاريتمي',
    ruleTitleEn: 'Exponential–Log Equivalence',
    ruleFormula: 'bʸ = x  ⟺  log_b(x) = y',
    examples: [
      { problemAr: 'أوجد قيمة log₂(32)', problemEn: 'Evaluate log₂(32)', solutionAr: '2⁵ = 32، إذن الجواب 5.', solutionEn: '2⁵ = 32 → 5.', answer: '5' },
      { problemAr: 'حل المعادلة 3ˣ = 81', problemEn: 'Solve 3ˣ = 81', solutionAr: '3⁴ = 81 ← x = 4.', solutionEn: 'x = 4.', answer: '4' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const cases: [number, number][] = [
        [2, 3], [3, 2], [5, 2], [10, 2], [2, 4],
        [3, 3], [5, 3], [10, 3], [2, 5], [2, 6], [3, 4],
      ];
      const [base, exp] = cases[idx];
      const val = base ** exp;
      return makeNumericQ(
        19, qIdx, isExam,
        `أوجد قيمة x التي تحقق: log_${base}(${val}) = x`,
        `Evaluate x where: log_${base}(${val}) = x`,
        exp,
        [1, -1, 2, base],
        `بما أن ${base}^${exp} = ${val}، فإن قيمة اللوغاريتم x = ${exp}.`,
        `Since ${base}^${exp} = ${val}, log_${base}(${val}) = ${exp}.`,
      );
    },
  },
  {
    stage: 20,
    titleAr: 'عدّ المسارات في الشبكات المستطيلة',
    titleEn: 'Grid Path Counting',
    summaryAr: 'للانتقال من ركن شبكة إلى آخر عبر a خطوات يميناً وb خطوات للأعلى، عدد أقصر المسارات يساوي التوافيق C(a + b, a).',
    summaryEn: 'Shortest paths across an a × b grid equal the combination C(a + b, a).',
    ruleTitleAr: 'صيغة مسارات الشبكة',
    ruleTitleEn: 'Lattice Path Formula',
    ruleFormula: 'عدد المسارات = C(a + b, a)',
    examples: [
      { problemAr: 'كم مساراً من (0,0) إلى (2,3) بالتحرك يميناً أو أعلى فقط؟', problemEn: 'Paths from (0,0) to (2,3) moving right or up?', solutionAr: 'C(5,2) = 10.', solutionEn: '10.', answer: '10' },
      { problemAr: 'من (0,0) إلى (2,2)', problemEn: 'From (0,0) to (2,2)', solutionAr: 'C(4,2) = 6.', solutionEn: '6.', answer: '6' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const a = 2;
      const b = 2 + idx;
      const total = ((a + b) * (a + b - 1)) / 2;
      return makeNumericQ(
        20, qIdx, isExam,
        `كم أقصر مساراً مختلفاً للوصول من النقطة (0, 0) إلى النقطة (${a}, ${b}) إذا كان يُسمح بالتحرك يميناً أو للأعلى فقط؟`,
        `How many shortest paths go from (0, 0) to (${a}, ${b}) moving only right or up?`,
        total,
        [a * b, 2, -2, a + b],
        `نحتاج ${a} خطوات يميناً و${b} للأعلى (مجموعها ${a + b}): C(${a + b}, ${a}) = ${total}.`,
        `Total steps ${a + b}, choose ${a} right moves: C(${a + b}, ${a}) = ${total}.`,
      );
    },
  },

  // HARD (21..30)
  {
    stage: 21,
    titleAr: 'المتباينة الشهيرة AM ≥ GM',
    titleEn: 'AM–GM Inequality & Optimization',
    summaryAr: 'لأي عددين موجبين، الوسط الحسابي أكبر دائماً من أو يساوي الوسط الهندسي، وتتحقق القيمة الصغرى للمجموع أو العظمى للضرب عند تساويهما.',
    summaryEn: 'For positive a and b, (a + b)/2 ≥ √(ab); maximum product for a fixed sum occurs when a = b.',
    ruleTitleAr: 'تطبيق تعظيم حاصل الضرب',
    ruleTitleEn: 'Maximum Product Rule',
    ruleFormula: 'إذا كان a + b = S ثابت ← أقصى ضرب عند a = b = S/2',
    examples: [
      { problemAr: 'عددان موجبان مجموعهما 20، ما أكبر قيمة ممكنة لحاصل ضربهما؟', problemEn: 'Two positive numbers sum to 20. Max product?', solutionAr: 'عند تساويهما 10 × 10 = 100.', solutionEn: '10 × 10 = 100.', answer: '100' },
      { problemAr: 'مستطيل محيطه 24، ما أكبر مساحة ممكنة له؟', problemEn: 'Rectangle perimeter 24. Max area?', solutionAr: 'نصف المحيط 12 ← مربع ضلعه 6 ← المساحة 36.', solutionEn: '6 × 6 = 36.', answer: '36' },
    ],
    generate: (qIdx, isExam) => {
      const half = 6 + qIdx * 2 + (isExam ? 1 : 0);
      const sum = half * 2;
      const maxProd = half * half;
      return makeNumericQ(
        21, qIdx, isExam,
        `عددان موجبان مجموعهما ${sum}. ما أكبر قيمة ممكنة لحاصل ضربهما؟`,
        `Two positive numbers have a sum of ${sum}. What is the maximum possible value of their product?`,
        maxProd,
        [(half - 2) * (half + 2) - maxProd, sum, 10, -10],
        `تتحقق القيمة العظمى لحاصل الضرب عند تساوي العددين (${half} و ${half})، فيكون ${half}² = ${maxProd}.`,
        `Maximum product occurs when both equal ${half}: ${half}² = ${maxProd}.`,
      );
    },
  },
  {
    stage: 22,
    titleAr: 'المتسلسلات المتداخلة (Telescoping Sums)',
    titleEn: 'Telescoping Series Sums',
    summaryAr: 'في المجاميع من النوع Σ [1/(k(k+1))] نحلل كل حد إلى 1/k - 1/(k+1) فتُختصر الحدود الوسطى جميعها.',
    summaryEn: 'Split 1/(k(k+1)) into 1/k − 1/(k+1) so intermediate terms cancel cleanly.',
    ruleTitleAr: 'اختصار المجموع المتداخل',
    ruleTitleEn: 'Telescoping Cancellation',
    ruleFormula: '1/(1×2) + 1/(2×3) + ... + 1/(n(n+1)) = n / (n + 1)',
    examples: [
      { problemAr: 'احسب: 1/(1×2) + 1/(2×3) + 1/(3×4)', problemEn: 'Sum 1/(1×2) + 1/(2×3) + 1/(3×4)', solutionAr: '(1 - 1/2) + (1/2 - 1/3) + (1/3 - 1/4) = 1 - 1/4 = 3/4.', solutionEn: '1 - 1/4 = 3/4.', answer: '3/4' },
      { problemAr: 'أول 9 حدود من المتسلسلة نفسها؟', problemEn: 'First 9 terms?', solutionAr: '1 - 1/10 = 9/10.', solutionEn: '9/10.', answer: '9/10' },
    ],
    generate: (qIdx, isExam) => {
      const n = 4 + qIdx + (isExam ? 2 : 0);
      return makeTextQ(
        22, qIdx, isExam,
        `احسب قيمة المجموع: 1/(1×2) + 1/(2×3) + ... + 1/(${n}×${n + 1})`,
        `Evaluate the telescoping sum: 1/(1×2) + 1/(2×3) + ... + 1/(${n}×${n + 1})`,
        `${n}/${n + 1}`,
        [`${n - 1}/${n}`, `1/${n + 1}`, `${n}/${n + 2}`],
        `تُختصر كل الحدود الوسطى ويبقى 1 - 1/${n + 1} = ${n}/${n + 1}.`,
        `Middle terms cancel leaving 1 - 1/${n + 1} = ${n}/${n + 1}.`,
      );
    },
  },
  {
    stage: 23,
    titleAr: 'المعادلات الديوفانتية الخطية البسيطة',
    titleEn: 'Counting Integer Solutions (Diophantine)',
    summaryAr: 'تطلب المسائل الديوفانتية إيجاد حلول صحيحة موجبة لمعادلة بمجهولين مثل ax + by = c.',
    summaryEn: 'Diophantine equations seek positive integer pairs (x, y) satisfying ax + by = c.',
    ruleTitleAr: 'تعداد الحلول الصحيحة',
    ruleTitleEn: 'Integer Pair Counting',
    ruleFormula: 'نجرّب قيم المتغير الأكبر معاملاً بالترتيب',
    examples: [
      { problemAr: 'كم زوجاً صحيحاً موجباً (x,y) يحقق 2x + 3y = 18؟', problemEn: 'How many positive integer pairs (x,y) solve 2x + 3y = 18?', solutionAr: 'نجرب y=2 → x=6، و y=4 → x=3، إذن زوجان.', solutionEn: '(6,2) and (3,4) → 2 pairs.', answer: '2' },
      { problemAr: 'كم زوجاً موجباً يحقق x + 2y = 9؟', problemEn: 'Positive pairs for x + 2y = 9?', solutionAr: 'y = 1,2,3,4 تعطي 4 أزواج.', solutionEn: '4 pairs.', answer: '4' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const maxY = 2 + idx;
      const rhs = 6 * (maxY + 1);
      return makeNumericQ(
        23, qIdx, isExam,
        `كم زوجاً من الأعداد الصحيحة الموجبة (x, y) يحقق المعادلة: 2x + 3y = ${rhs}؟`,
        `How many pairs of positive integers (x, y) satisfy 2x + 3y = ${rhs}?`,
        maxY,
        [1, -1, 2, maxY + 2],
        `بما أن ${rhs} و 2x زوجيان، يجب أن يكون y زوجياً موجبًا وأقل من ${2 * (maxY + 1)}؛ أي y ∈ {2, 4, ..., ${2 * maxY}} وعددها ${maxY}.`,
        `y must be positive even with 3y < ${rhs}, giving ${maxY} pairs.`,
      );
    },
  },
  {
    stage: 24,
    titleAr: 'مسائل القواسم وعدد العوامل الموجبة',
    titleEn: 'Number of Positive Divisors',
    summaryAr: 'إذا تحلّل العدد إلى عوامل أولية p₁^a × p₂^b، فإن عدد قواسمه الموجبة يساوي (a + 1)(b + 1).',
    summaryEn: 'For prime factorization p₁^a × p₂^b, the number of positive divisors is (a + 1)(b + 1).',
    ruleTitleAr: 'قانون عدد القواسم',
    ruleTitleEn: 'Divisor Count Formula',
    ruleFormula: 'd(N) = (a + 1)(b + 1)...',
    examples: [
      { problemAr: 'كم عدد القواسم الموجبة للعدد 12؟', problemEn: 'How many positive divisors does 12 have?', solutionAr: '12 = 2² × 3¹ ← (2+1)(1+1) = 6 قواسم.', solutionEn: '(2+1)(1+1) = 6.', answer: '6' },
      { problemAr: 'كم قاسماً موجباً للعدد 36؟', problemEn: 'Positive divisors of 36?', solutionAr: '36 = 2² × 3² ← 3 × 3 = 9.', solutionEn: '9.', answer: '9' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const pairs: [number, number][] = [
        [2, 1], [3, 1], [2, 2], [4, 1], [3, 2], [2, 3], [5, 1], [3, 3], [4, 2], [2, 4], [1, 1],
      ];
      const [a, b] = pairs[idx];
      const n = 2 ** a * 3 ** b;
      const divisors = (a + 1) * (b + 1);
      return makeNumericQ(
        24, qIdx, isExam,
        `كم عدد القواسم (العوامل) الموجبة للعدد ${n}؟`,
        `How many positive divisors does ${n} have?`,
        divisors,
        [2, -2, 1, -1],
        `تحليل ${n} = 2^${a} × 3^${b}، لذا عدد القواسم = (${a}+1)(${b}+1) = ${divisors}.`,
        `${n} = 2^${a} × 3^${b}, so divisor count = (${a}+1)(${b}+1) = ${divisors}.`,
      );
    },
  },
  {
    stage: 25,
    titleAr: 'التضمين والاستبعاد لثلاث مجموعات',
    titleEn: 'Three-Set Inclusion–Exclusion',
    summaryAr: 'لحساب عدد مضاعفات أعداد متعددة ضمن نطاق، نجمع مضاعفات كل عدد ونطرح تقاطعات الأزواج ثم نعيد إضافة تقاطع الثلاثة.',
    summaryEn: 'Count elements in 3 overlapping sets by adding singles, subtracting pairs, and adding back the triple intersection.',
    ruleTitleAr: 'عدّ المضاعفات بالاستبعاد',
    ruleTitleEn: '3-Set Principle',
    ruleFormula: '|A ∪ B ∪ C| = Σ|A| - Σ|A∩B| + |A∩B∩C|',
    examples: [
      { problemAr: 'من 1 إلى 30: كم عدداً يقبل القسمة على 2 أو 3 أو 5؟', problemEn: 'From 1..30: divisible by 2, 3, or 5?', solutionAr: '15 + 10 + 6 - (5 + 3 + 2) + 1 = 22.', solutionEn: '22.', answer: '22' },
      { problemAr: 'من 1 إلى 20: كم عدداً يقبل على 2 أو 5؟', problemEn: '1..20: divisible by 2 or 5?', solutionAr: '10 + 4 - 2 = 12.', solutionEn: '12.', answer: '12' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const mult30 = 1 + idx;
      const n = 30 * mult30;
      const count = 22 * mult30;
      return makeNumericQ(
        25, qIdx, isExam,
        `كم عدداً صحيحاً من 1 إلى ${n} يقبل القسمة على 2 أو 3 أو 5 (على الأقل أحدها)؟`,
        `How many integers from 1 to ${n} are divisible by 2, 3, or 5?`,
        count,
        [mult30, -mult30, 3, -3],
        `كل 30 عدداً تحوي 22 مضاعفاً لـ 2 أو 3 أو 5، وبما أن ${n} = 30 × ${mult30} فالناتج = 22 × ${mult30} = ${count}.`,
        `By inclusion-exclusion, 22 of every 30 integers qualify: 22 × ${mult30} = ${count}.`,
      );
    },
  },
  {
    stage: 26,
    titleAr: 'المقلوبات الجبرية (x + 1/x)',
    titleEn: 'Reciprocal Powers Algebra',
    summaryAr: 'بمعرفة x + 1/x = k، نوجد x² + 1/x² = k² - 2 وكذلك x³ + 1/x³ = k³ - 3k دون حل المعادلة.',
    summaryEn: 'Given x + 1/x = k, compute x² + 1/x² = k² − 2 and x³ + 1/x³ = k³ − 3k.',
    ruleTitleAr: 'قوانين المقلوبات',
    ruleTitleEn: 'Reciprocal Identities',
    ruleFormula: 'x² + 1/x² = k² − 2  |  x³ + 1/x³ = k³ − 3k',
    examples: [
      { problemAr: 'إذا كان x + 1/x = 4، أوجد x² + 1/x²', problemEn: 'If x + 1/x = 4, find x² + 1/x²', solutionAr: '4² - 2 = 14.', solutionEn: '14.', answer: '14' },
      { problemAr: 'إذا كان x + 1/x = 3، أوجد x³ + 1/x³', problemEn: 'If x + 1/x = 3, find x³ + 1/x³', solutionAr: '3³ - 3(3) = 27 - 9 = 18.', solutionEn: '18.', answer: '18' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const k = 3 + idx;
      const isCube = idx % 2 === 1;
      if (isCube) {
        const ans = k ** 3 - 3 * k;
        return makeNumericQ(
          26, qIdx, isExam,
          `إذا كان x + (1/x) = ${k}، فما قيمة x³ + (1/x³)؟`,
          `If x + (1/x) = ${k}, find x³ + (1/x³):`,
          ans,
          [3 * k, -3, 2, k * k],
          `x³ + 1/x³ = ${k}³ - 3(${k}) = ${k ** 3} - ${3 * k} = ${ans}.`,
          `x³ + 1/x³ = ${k}³ - 3(${k}) = ${ans}.`,
        );
      }
      const ans = k * k - 2;
      return makeNumericQ(
        26, qIdx, isExam,
        `إذا كان x + (1/x) = ${k}، فما قيمة x² + (1/x²)؟`,
        `If x + (1/x) = ${k}, find x² + (1/x²):`,
        ans,
        [2, -2, 4, k],
        `x² + 1/x² = ${k}² - 2 = ${k * k} - 2 = ${ans}.`,
        `x² + 1/x² = ${k}² - 2 = ${ans}.`,
      );
    },
  },
  {
    stage: 27,
    titleAr: 'نسب المساحات في المثلثات',
    titleEn: 'Area Ratios in Triangles',
    summaryAr: 'في المثلثات المشتركة في الارتفاع، تكون نسبة مساحتيهما مساوية لنسبة طولي قاعدتيهما.',
    summaryEn: 'Triangles sharing the same height have areas proportional to their base lengths.',
    ruleTitleAr: 'نسبة القاعدة للمساحة',
    ruleTitleEn: 'Same-Height Area Ratio',
    ruleFormula: 'المساحة₁ / المساحة₂ = القاعدة₁ / القاعدة₂',
    examples: [
      { problemAr: 'مساحة مثلث ABC هي 30، النقطة D على BC حيث BD:DC = 2:3. ما مساحة ABD؟', problemEn: 'Area(ABC)=30, D on BC with BD:DC=2:3. Area(ABD)?', solutionAr: '30 × (2/5) = 12.', solutionEn: '30 × 2/5 = 12.', answer: '12' },
      { problemAr: 'الخط المتوسط يقسم المثلث إلى مثلثين، ما نسبة مساحة كل منهما للأصل؟', problemEn: 'Median divides triangle into two triangles of what fraction?', solutionAr: '1/2 المساحة.', solutionEn: '1/2.', answer: '1/2' },
    ],
    generate: (qIdx, isExam) => {
      const p = 1 + (qIdx % 3);
      const q = p + 1 + ((qIdx + (isExam ? 1 : 0)) % 3);
      const unitArea = 5 + qIdx * 2;
      const totalArea = (p + q) * unitArea;
      const ans = q * unitArea;
      return makeNumericQ(
        27, qIdx, isExam,
        `مساحة المثلث ABC تساوي ${totalArea}. تقع النقطة D على الضلع BC بحيث BD : DC = ${p} : ${q}. ما مساحة المثلث ADC؟`,
        `Triangle ABC has area ${totalArea}. Point D lies on BC so BD : DC = ${p} : ${q}. What is the area of triangle ADC?`,
        ans,
        [p * unitArea, unitArea, -unitArea, 5],
        `يشترك المثلثان في الارتفاع، فنسبة ADC إلى الكل هي ${q}/${p + q}: ${totalArea} × ${q}÷${p + q} = ${ans}.`,
        `Sharing altitude, Area(ADC) = ${totalArea} × ${q}/${p + q} = ${ans}.`,
      );
    },
  },
  {
    stage: 28,
    titleAr: 'الأسس العظمى في المضروب (صيغة ليجندر)',
    titleEn: 'Trailing Zeros in Factorials (Legendre)',
    summaryAr: 'عدد الأصفار في نهاية !n يساوي عدد مرات ظهور العامل 5 في تحليله: ⌊n/5⌋ + ⌊n/25⌋ + ⌊n/125⌋ + ...',
    summaryEn: 'Trailing zeros of n! equal the power of 5 in n!: ⌊n/5⌋ + ⌊n/25⌋ + ⌊n/125⌋ + ...',
    ruleTitleAr: 'أصفار المضروب',
    ruleTitleEn: 'Legendre’s Formula for 5',
    ruleFormula: 'الأصفار = ⌊n/5⌋ + ⌊n/25⌋ + ...',
    examples: [
      { problemAr: 'كم صفراً في نهاية 25! ؟', problemEn: 'How many trailing zeros in 25! ?', solutionAr: '⌊25/5⌋ + ⌊25/25⌋ = 5 + 1 = 6 أصفار.', solutionEn: '5 + 1 = 6.', answer: '6' },
      { problemAr: 'كم صفراً في نهاية 10! ؟', problemEn: 'Trailing zeros in 10! ?', solutionAr: '⌊10/5⌋ = 2.', solutionEn: '2.', answer: '2' },
    ],
    generate: (qIdx, isExam) => {
      const n = 15 + qIdx * 5 + (isExam ? 5 : 0);
      const zeros = Math.floor(n / 5) + Math.floor(n / 25);
      return makeNumericQ(
        28, qIdx, isExam,
        `كم صفراً متتالياً ينتهي به العدد (${n}!) (مضروب ${n})؟`,
        `How many trailing zeros are at the end of ${n}! (${n} factorial)?`,
        zeros,
        [Math.floor(n / 5) === zeros ? 1 : Math.floor(n / 5) - zeros, -1, 2, -2],
        `⌊${n}/5⌋ + ⌊${n}/25⌋ = ${Math.floor(n / 5)} + ${Math.floor(n / 25)} = ${zeros}.`,
        `⌊${n}/5⌋ + ⌊${n}/25⌋ = ${zeros}.`,
      );
    },
  },
  {
    stage: 29,
    titleAr: 'مسائل الحذف والمنطق العددي',
    titleEn: 'Logic & Parity Invariants',
    summaryAr: 'في مسائل تبديل الأرقام أو حذفها مع إضافة مجموعها أو طرحه، يبقى التكافؤ (الزوجية/الفردية) أو المجموع الكلي ثابتاً لا يتغير.',
    summaryEn: 'Track invariants—quantities like parity or modular sums that never change under repeated moves.',
    ruleTitleAr: 'الثابت الرياضي (Invariant)',
    ruleTitleEn: 'Invariant Principle',
    ruleFormula: 'حدّد الخاصية التي لا تتغير بعد كل خطوة',
    examples: [
      { problemAr: 'اكتب الأعداد من 1 إلى 7، إذا استبدلنا أي عددين بمجموعهما، فما آخر عدد يتبقى؟', problemEn: 'Numbers 1..7 on board; replace any two with their sum. Final number?', solutionAr: 'المجموع ثابت = 28، فآخر عدد 28.', solutionEn: 'Sum stays 28.', answer: '28' },
      { problemAr: 'مجموع 5 أعداد فردية، هل الناتج زوجي أم فردي؟', problemEn: 'Sum of 5 odd integers: even or odd?', solutionAr: 'فردي.', solutionEn: 'Odd.', answer: 'فردي' },
    ],
    generate: (qIdx, isExam) => {
      const top = 8 + qIdx + (isExam ? 2 : 0);
      const total = (top * (top + 1)) / 2;
      return makeNumericQ(
        29, qIdx, isExam,
        `كُتبت الأعداد من 1 إلى ${top} على لوح. في كل خطوة نمسح أي عددين a و b ونكتب مكانهما (a + b - 1). ما العدد الأخير الذي سيبقى في النهاية؟`,
        `Numbers 1 to ${top} are on a board. Each step, erase a and b and write (a + b - 1). What single number remains at the end?`,
        total - (top - 1),
        [total - (total - (top - 1)), 1, -1, top],
        `يحدث ${top - 1} استبدالاً، وفي كل مرة ينقص المجموع الكلي بمقدار 1؛ إذن النهائي = ${total} - ${top - 1} = ${total - (top - 1)}.`,
        `${top - 1} operations occur, reducing the sum ${total} by 1 each time → ${total - (top - 1)}.`,
      );
    },
  },
  {
    stage: 30,
    titleAr: 'التحدي الأولمبي الأعظم (Grand Challenge)',
    titleEn: 'Grand Math Master Olympiad Challenge',
    summaryAr: 'المواجهة النهائية في Math Master تجمع الجبر التماثلي والأعداد والهندسة والعد التوافقي في تحدٍّ فكري رفيع.',
    summaryEn: 'The ultimate Math Master challenge uniting algebraic identities, combinatorics, geometry, and number theory.',
    ruleTitleAr: 'ذروة الإتقان الرياضي',
    ruleTitleEn: 'Olympiad Synthesis',
    ruleFormula: 'دمج الجبر والعدّ والهندسة ونظرية الأعداد',
    examples: [
      { problemAr: 'إذا كان (x - 1/x) = 3، أوجد x² + 1/x²', problemEn: 'If x - 1/x = 3, find x² + 1/x²', solutionAr: '3² + 2 = 11.', solutionEn: '11.', answer: '11' },
      { problemAr: 'مضلع منتظم عدد أقطاره يساوي ضعف عدد أضلاعه، كم عدد أضلاعه؟', problemEn: 'Polygon with diagonals = 2 × sides. Number of sides?', solutionAr: 'n(n-3)/2 = 2n ← n = 7.', solutionEn: '7.', answer: '7' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const k = 2 + idx;
      const sides = 2 * k + 3;
      return makeNumericQ(
        30, qIdx, isExam,
        `مضلع محدّب عدد أقطاره يساوي ${k} أمثال عدد أضلاعه (صيغة الأقطار n(n-3)÷2). كم عدد أضلاع هذا المضلع؟`,
        `A convex polygon has ${k} times as many diagonals as sides (diagonals = n(n-3)/2). How many sides does it have?`,
        sides,
        [2, -2, 3, -1],
        `n(n - 3) ÷ 2 = ${k}n ← n - 3 = ${2 * k} ← n = ${sides}.`,
        `n(n - 3) / 2 = ${k}n → n - 3 = ${2 * k} → n = ${sides}.`,
      );
    },
  },
];

export const ADVANCED_STAGES: StageDefinition[] = TOPICS.map((topic) => ({
  id: makeStageId('advanced', topic.stage),
  sectionId: 'advanced',
  stageNumber: topic.stage,
  difficulty: getDifficultyForStage(topic.stage),
  titleAr: topic.titleAr,
  titleEn: topic.titleEn,
  lesson: {
    summaryAr: topic.summaryAr,
    summaryEn: topic.summaryEn,
    ruleTitleAr: topic.ruleTitleAr,
    ruleTitleEn: topic.ruleTitleEn,
    ruleFormula: topic.ruleFormula,
    examples: topic.examples,
  },
  questions: Array.from({ length: 10 }, (_, qIdx) => topic.generate(qIdx, false)),
  examQuestion: topic.generate(10, true),
}));
