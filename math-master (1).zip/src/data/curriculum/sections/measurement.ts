import {
  buildChoiceQuestion,
  getDifficultyForStage,
  makeStageId,
  numericDistractors,
} from '@/src/data/curriculum/helpers';
import type { QuizQuestion, StageDefinition, WorkedExample } from '@/src/types/curriculum';

interface TopicSpec {
  stage: number;
  titleAr: string;
  titleEn: string;
  summaryAr: string;
  summaryEn: string;
  ruleTitleAr: string;
  ruleTitleEn: string;
  ruleFormula: string;
  examples: [WorkedExample, WorkedExample];
  generate: (qIdx: number, isExam: boolean) => QuizQuestion;
}

function measQ(
  stage: number,
  qIdx: number,
  isExam: boolean,
  promptAr: string,
  promptEn: string,
  correct: string,
  distractors: string[],
  explanationAr: string,
  explanationEn: string,
): QuizQuestion {
  const id = isExam ? `measurement-exam-s${stage}` : `measurement-s${stage}-q${qIdx + 1}`;
  return buildChoiceQuestion({
    id,
    promptAr,
    promptEn,
    correctValue: correct,
    distractors,
    explanationAr,
    explanationEn,
    seedKey: `${id}-${promptEn}`,
  });
}

const TOPICS: TopicSpec[] = [
  {
    stage: 1,
    titleAr: 'التحويل بين السنتيمتر والمليمتر',
    titleEn: 'Centimeters to Millimeters',
    summaryAr: 'كل 1 سنتيمتر يساوي 10 مليمتر؛ للتحويل من الأكبر للأصغر نضرب في 10.',
    summaryEn: '1 cm equals 10 mm; multiply by 10 to convert cm to mm.',
    ruleTitleAr: 'علاقة سم بملم',
    ruleTitleEn: 'cm-mm Rule',
    ruleFormula: '1 cm = 10 mm',
    examples: [
      { problemAr: 'حوّل 7 سم إلى ملم', problemEn: 'Convert 7 cm to mm', solutionAr: '70 ملم', solutionEn: '70 mm', answer: '70' },
      { problemAr: 'حوّل 4.5 سم إلى ملم', problemEn: 'Convert 4.5 cm to mm', solutionAr: '45 ملم', solutionEn: '45 mm', answer: '45' },
    ],
    generate: (qIdx, isExam) => {
      const cm = 3 + qIdx * 2 + (isExam ? 1 : 0);
      const ans = cm * 10;
      return measQ(1, qIdx, isExam, `كم مليمتراً في ${cm} سنتيمترات؟`, `How many millimeters are in ${cm} cm?`, String(ans), numericDistractors(ans, [cm * 100 - ans, 10, -10, 5]), `${cm} × 10 = ${ans} ملم.`, `${cm} × 10 = ${ans} mm.`);
    },
  },
  {
    stage: 2,
    titleAr: 'التحويل بين المتر والسنتيمتر',
    titleEn: 'Meters to Centimeters',
    summaryAr: 'كل 1 متر يساوي 100 سنتيمتر.',
    summaryEn: 'Every 1 meter equals 100 centimeters.',
    ruleTitleAr: 'علاقة المتر بالسنتيمتر',
    ruleTitleEn: 'm-cm Rule',
    ruleFormula: '1 m = 100 cm',
    examples: [
      { problemAr: 'حوّل 3.5 م إلى سم', problemEn: '3.5 m to cm', solutionAr: '350 سم', solutionEn: '350 cm', answer: '350' },
      { problemAr: 'حوّل 600 سم إلى م', problemEn: '600 cm to m', solutionAr: '6 م', solutionEn: '6 m', answer: '6' },
    ],
    generate: (qIdx, isExam) => {
      const m = 2 + qIdx + (isExam ? 1 : 0);
      const ans = m * 100;
      return measQ(2, qIdx, isExam, `حوّل ${m} أمتار إلى سنتيمترات:`, `Convert ${m} meters to centimeters:`, String(ans), numericDistractors(ans, [m * 10 - ans, 100, -100, 50]), `${m} × 100 = ${ans} سم.`, `${m} × 100 = ${ans} cm.`);
    },
  },
  {
    stage: 3,
    titleAr: 'التحويل بين الكيلومتر والمتر',
    titleEn: 'Kilometers to Meters',
    summaryAr: 'الكيلومتر وحدة قياس المسافات الطويلة ويساوي 1000 متر.',
    summaryEn: '1 kilometer equals 1,000 meters.',
    ruleTitleAr: 'علاقة كم بمتر',
    ruleTitleEn: 'km-m Rule',
    ruleFormula: '1 km = 1000 m',
    examples: [
      { problemAr: 'حوّل 4 كم إلى متر', problemEn: '4 km to m', solutionAr: '4000 م', solutionEn: '4000 m', answer: '4000' },
      { problemAr: 'حوّل 2.5 كم إلى متر', problemEn: '2.5 km to m', solutionAr: '2500 م', solutionEn: '2500 m', answer: '2500' },
    ],
    generate: (qIdx, isExam) => {
      const km = 1.5 + qIdx * 0.5 + (isExam ? 0.5 : 0);
      const ans = km * 1000;
      return measQ(3, qIdx, isExam, `كم متراً في ${km} كيلومتر؟`, `How many meters are in ${km} km?`, String(ans), numericDistractors(ans, [100, -100, 500, -500]), `${km} × 1000 = ${ans} متر.`, `${km} × 1000 = ${ans} m.`);
    },
  },
  {
    stage: 4,
    titleAr: 'وحدات الكتلة: الكيلوغرام والغرام',
    titleEn: 'Kilograms & Grams',
    summaryAr: 'كل 1 كيلوغرام يساوي 1000 غرام.',
    summaryEn: '1 kilogram equals 1,000 grams.',
    ruleTitleAr: 'وحدة الكتلة',
    ruleTitleEn: 'Mass Conversion',
    ruleFormula: '1 kg = 1000 g',
    examples: [
      { problemAr: '3 كغ و 450 غ كم تساوي بالغرام؟', problemEn: '3 kg 450 g in grams?', solutionAr: '3450 غ', solutionEn: '3450 g', answer: '3450' },
      { problemAr: '5000 غ بالكيلوغرام؟', problemEn: '5000 g in kg?', solutionAr: '5 كغ', solutionEn: '5 kg', answer: '5' },
    ],
    generate: (qIdx, isExam) => {
      const kg = 2 + (qIdx % 6);
      const g = 150 + qIdx * 50 + (isExam ? 25 : 0);
      const ans = kg * 1000 + g;
      return measQ(4, qIdx, isExam, `كتلة جسم ${kg} كغ و ${g} غ، ما كتلته الكلية بالغرام؟`, `Convert ${kg} kg ${g} g entirely to grams:`, String(ans), numericDistractors(ans, [100, -100, 1000, -500]), `${kg}×1000 + ${g} = ${ans} غ.`, `${kg}×1000 + ${g} = ${ans} g.`);
    },
  },
  {
    stage: 5,
    titleAr: 'السعة: اللتر والمليلتر',
    titleEn: 'Liters & Milliliters',
    summaryAr: 'كل 1 لتر يساوي 1000 مليلتر.',
    summaryEn: '1 liter equals 1,000 milliliters.',
    ruleTitleAr: 'قياس السعة',
    ruleTitleEn: 'Capacity Conversion',
    ruleFormula: '1 L = 1000 mL',
    examples: [
      { problemAr: '2.4 لتر بالمليلتر؟', problemEn: '2.4 L in mL?', solutionAr: '2400 مل', solutionEn: '2400 mL', answer: '2400' },
      { problemAr: '750 مل باللتر؟', problemEn: '750 mL in L?', solutionAr: '0.75 لتر', solutionEn: '0.75 L', answer: '0.75' },
    ],
    generate: (qIdx, isExam) => {
      const ml = 1250 + qIdx * 250 + (isExam ? 150 : 0);
      const liters = (ml / 1000).toFixed(2).replace(/0$/, '');
      return measQ(5, qIdx, isExam, `كم لتراً يساوي ${ml} مليلتر؟`, `How many liters equal ${ml} mL?`, liters, [String(ml / 100), String(Number(liters) + 0.5), String(Number(liters) + 1)], `${ml} ÷ 1000 = ${liters} لتر.`, `${ml} / 1000 = ${liters} L.`);
    },
  },
  {
    stage: 6,
    titleAr: 'وحدات الزمن: الساعات والدقائق',
    titleEn: 'Hours & Minutes',
    summaryAr: 'كل ساعة تساوي 60 دقيقة، وكل دقيقة تساوي 60 ثانية.',
    summaryEn: '1 hour = 60 minutes, and 1 minute = 60 seconds.',
    ruleTitleAr: 'تحويل الوقت',
    ruleTitleEn: 'Time Conversion',
    ruleFormula: '1 hr = 60 min , 1 min = 60 s',
    examples: [
      { problemAr: 'ساعتان و 25 دقيقة بالدقائق؟', problemEn: '2 hr 25 min in minutes?', solutionAr: '120 + 25 = 145 دقيقة', solutionEn: '145 min', answer: '145' },
      { problemAr: '180 دقيقة بالساعات؟', problemEn: '180 min in hours?', solutionAr: '3 ساعات', solutionEn: '3 hr', answer: '3' },
    ],
    generate: (qIdx, isExam) => {
      const h = 1 + (qIdx % 5);
      const m = 10 + qIdx * 4 + (isExam ? 5 : 0);
      const ans = h * 60 + m;
      return measQ(6, qIdx, isExam, `كم دقيقة في ${h} ساعات و ${m} دقيقة؟`, `How many minutes are in ${h} hours and ${m} minutes?`, String(ans), numericDistractors(ans, [60, -60, 10, -10]), `${h} × 60 + ${m} = ${ans} دقيقة.`, `${h} × 60 + ${m} = ${ans} min.`);
    },
  },
  {
    stage: 7,
    titleAr: 'الأيام والأسابيع والشهور',
    titleEn: 'Days, Weeks & Months',
    summaryAr: 'الأسبوع 7 أيام، واليوم 24 ساعة، والسنة 12 شهراً.',
    summaryEn: '1 week = 7 days, 1 day = 24 hours, 1 year = 12 months.',
    ruleTitleAr: 'وحدات التقويم',
    ruleTitleEn: 'Calendar Units',
    ruleFormula: '1 wk = 7 days , 1 day = 24 hr',
    examples: [
      { problemAr: '6 أسابيع و 4 أيام بالأيام؟', problemEn: '6 weeks 4 days in days?', solutionAr: '42 + 4 = 46 يوماً', solutionEn: '46 days', answer: '46' },
      { problemAr: '3 أيام بالساعات؟', problemEn: '3 days in hours?', solutionAr: '72 ساعة', solutionEn: '72 hr', answer: '72' },
    ],
    generate: (qIdx, isExam) => {
      const w = 2 + qIdx;
      const d = 1 + ((qIdx + (isExam ? 2 : 0)) % 6);
      const ans = w * 7 + d;
      return measQ(7, qIdx, isExam, `كم يوماً في ${w} أسابيع و ${d} أيام؟`, `How many total days in ${w} weeks and ${d} days?`, String(ans), numericDistractors(ans, [7, -7, 2, -2]), `${w} × 7 + ${d} = ${ans} يوماً.`, `${w} × 7 + ${d} = ${ans} days.`);
    },
  },
  {
    stage: 8,
    titleAr: 'قراءة وجمع الفترات الزمنية',
    titleEn: 'Elapsed Time Calculations',
    summaryAr: 'نحسب المدة المنقضية بإضافة الساعات أولاً ثم الدقائق (مع حمل كل 60 دقيقة كساعة).',
    summaryEn: 'Add hours and minutes, regrouping every 60 minutes into 1 hour.',
    ruleTitleAr: 'الزمن المنقضي',
    ruleTitleEn: 'Elapsed Time',
    ruleFormula: '60 min → +1 hr',
    examples: [
      { problemAr: 'بدأ درس 9:20 واستمر 55 دقيقة، متى ينتهي؟', problemEn: 'Starts 9:20, lasts 55 min. End?', solutionAr: '10:15', solutionEn: '10:15', answer: '10:15' },
      { problemAr: 'من 2:15 إلى 4:40 كم المدة؟', problemEn: 'From 2:15 to 4:40?', solutionAr: 'ساعتان و 25 دقيقة', solutionEn: '2 hr 25 min', answer: '145 min' },
    ],
    generate: (qIdx, isExam) => {
      const startH = 8 + (qIdx % 4);
      const startM = 15 + (qIdx % 3) * 10;
      const dur = 40 + qIdx * 5 + (isExam ? 10 : 0);
      const totalM = startM + dur;
      const endH = startH + Math.floor(totalM / 60);
      const endM = totalM % 60;
      const pad = (n: number) => String(n).padStart(2, '0');
      const ans = `${endH}:${pad(endM)}`;
      return measQ(8, qIdx, isExam, `بدأت حصة الساعة ${startH}:${pad(startM)} واستمرت ${dur} دقيقة، متى تنتهي؟`, `A class starts at ${startH}:${pad(startM)} and lasts ${dur} minutes. When does it end?`, ans, [`${endH}:${pad((endM + 10) % 60)}`, `${endH + 1}:${pad(endM)}`, `${endH}:${pad((endM + 50) % 60)}`], `نضيف ${dur} دقيقة إلى ${startH}:${pad(startM)} فتكون الساعة ${ans}.`, `Adding ${dur} min to ${startH}:${pad(startM)} gives ${ans}.`);
    },
  },
  {
    stage: 9,
    titleAr: 'مقارنة القياسات بوحدات مختلفة',
    titleEn: 'Comparing Mixed Units',
    summaryAr: 'نوحّد الوحدات قبل المقارنة أو الجمع بين قياسين مختلفين.',
    summaryEn: 'Convert both measurements to the same unit before comparing or adding.',
    ruleTitleAr: 'التوحيد قبل المقارنة',
    ruleTitleEn: 'Uniform Unit Rule',
    ruleFormula: 'Convert to smaller unit first',
    examples: [
      { problemAr: 'أيهما أطول: 2 م أم 185 سم؟', problemEn: 'Longer: 2 m or 185 cm?', solutionAr: '2 م = 200 سم > 185 سم', solutionEn: '2 m', answer: '2 m' },
      { problemAr: 'أيهما أثقل: 1.5 كغ أم 1400 غ؟', problemEn: 'Heavier: 1.5 kg or 1400 g?', solutionAr: '1500 غ > 1400 غ', solutionEn: '1.5 kg', answer: '1.5 kg' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const m = 2 + (idx % 5);
      const extra = 12 + idx * 7;
      const ans = m * 100 + extra;
      return measQ(9, qIdx, isExam, `احسب المجموع بالسنتيمتر: ${m} م + ${extra} سم`, `Compute in centimeters: ${m} m + ${extra} cm`, String(ans), numericDistractors(ans, [100, -100, 10, -10]), `${m} م = ${m * 100} سم، والمجموع = ${ans} سم.`, `${m} m = ${m * 100} cm, total = ${ans} cm.`);
    },
  },
  {
    stage: 10,
    titleAr: 'درجات الحرارة المئوية والفرق بينها',
    titleEn: 'Celsius Temperature Differences',
    summaryAr: 'نحسب تغير درجة الحرارة بطرح الدرجة الابتدائية من النهائية (مع مراعاة تحت الصفر).',
    summaryEn: 'Temperature change equals final temperature minus initial temperature.',
    ruleTitleAr: 'التغير الحراري',
    ruleTitleEn: 'Temperature Change',
    ruleFormula: 'ΔT = T_final − T_initial',
    examples: [
      { problemAr: 'ارتفعت الحرارة من −4°C إلى 11°C، كم ارتفعت؟', problemEn: 'From -4°C to 11°C, change?', solutionAr: '11 − (−4) = 15°C', solutionEn: '15°C', answer: '15' },
      { problemAr: 'انخفضت من 18°C بمقدار 7°C', problemEn: '18°C drops by 7°C', solutionAr: '11°C', solutionEn: '11°C', answer: '11' },
    ],
    generate: (qIdx, isExam) => {
      const low = -(2 + ((qIdx + (isExam ? 1 : 0)) % 7));
      const high = 6 + qIdx * 2;
      const ans = high - low;
      return measQ(10, qIdx, isExam, `ارتفعت درجة الحرارة من ${low}°C إلى ${high}°C، كم درجة ارتفعت؟`, `Temperature rose from ${low}°C to ${high}°C. By how many degrees did it rise?`, String(ans), numericDistractors(ans, [low * 2, 2, -2, 4]), `${high} − (${low}) = ${ans}°C.`, `${high} − (${low}) = ${ans}°C.`);
    },
  },
  // --- MEDIUM (11 - 20) ---
  {
    stage: 11,
    titleAr: 'الأطنان والكيلوغرامات',
    titleEn: 'Metric Tons & Kilograms',
    summaryAr: 'الطن المتري الواحد يساوي 1000 كيلوغرام.',
    summaryEn: '1 metric ton equals 1,000 kilograms.',
    ruleTitleAr: 'تحويل الطن',
    ruleTitleEn: 'Ton Conversion',
    ruleFormula: '1 ton = 1000 kg',
    examples: [
      { problemAr: '3.2 طن بالكيلوغرام؟', problemEn: '3.2 tons in kg?', solutionAr: '3200 كغ', solutionEn: '3200 kg', answer: '3200' },
      { problemAr: '4500 كغ بالطن؟', problemEn: '4500 kg in tons?', solutionAr: '4.5 طن', solutionEn: '4.5 t', answer: '4.5' },
    ],
    generate: (qIdx, isExam) => {
      const tons = 1.5 + qIdx * 0.4 + (isExam ? 0.2 : 0);
      const ans = Math.round(tons * 1000);
      return measQ(11, qIdx, isExam, `شاحنة حمولتها ${tons.toFixed(1)} طن، كم تساوي بالكيلوغرام؟`, `Convert ${tons.toFixed(1)} metric tons to kilograms:`, String(ans), numericDistractors(ans, [100, -100, 500, -500]), `${tons.toFixed(1)} × 1000 = ${ans} كغ.`, `${tons.toFixed(1)} × 1000 = ${ans} kg.`);
    },
  },
  {
    stage: 12,
    titleAr: 'تحويل وحدات المساحة المربعة',
    titleEn: 'Converting Area Units (m² to cm²)',
    summaryAr: 'لأن 1 م = 100 سم، فإن 1 م² = 100 × 100 = 10,000 سم².',
    summaryEn: 'Because 1 m = 100 cm, 1 m² = 100² = 10,000 cm².',
    ruleTitleAr: 'تربيع معامل التحويل',
    ruleTitleEn: 'Squared Scale Factor',
    ruleFormula: '1 m² = 10,000 cm² , 1 cm² = 100 mm²',
    examples: [
      { problemAr: '2 م² بالسنتيمتر المربع؟', problemEn: '2 m² in cm²?', solutionAr: '20000 سم²', solutionEn: '20000 cm²', answer: '20000' },
      { problemAr: '5 سم² بالمليمتر المربع؟', problemEn: '5 cm² in mm²?', solutionAr: '500 ملم²', solutionEn: '500 mm²', answer: '500' },
    ],
    generate: (qIdx, isExam) => {
      const cm2 = 3 + qIdx * 2 + (isExam ? 1 : 0);
      const ans = cm2 * 100;
      return measQ(12, qIdx, isExam, `كم مليمتراً مربعاً في ${cm2} سم²؟`, `How many mm² are in ${cm2} cm²?`, String(ans), numericDistractors(ans, [cm2 * 10 - ans, 100, -100, 50]), `1 سم² = 10² = 100 ملم²، إذن ${cm2} × 100 = ${ans} ملم².`, `${cm2} × 100 = ${ans} mm².`);
    },
  },
  {
    stage: 13,
    titleAr: 'وحدات الحجم والسعة (الديسمتر المكعب)',
    titleEn: 'Volume Units: Liters & Cubic Centimeters',
    summaryAr: 'اللتر الواحد يعادل 1000 سم³ (أي 1 دسم³)، و 1 مل = 1 سم³.',
    summaryEn: '1 liter = 1,000 cm³ (1 dm³), and 1 mL = 1 cm³.',
    ruleTitleAr: 'ربط الحجم بالسعة',
    ruleTitleEn: 'Volume-Capacity Link',
    ruleFormula: '1 L = 1000 cm³ , 1 m³ = 1000 L',
    examples: [
      { problemAr: 'خزان حجمه 2 م³، كم لتراً يتسع؟', problemEn: '2 m³ tank in liters?', solutionAr: '2000 لتر', solutionEn: '2000 L', answer: '2000' },
      { problemAr: '3.5 لتر بالسنتيمتر المكعب؟', problemEn: '3.5 L in cm³?', solutionAr: '3500 سم³', solutionEn: '3500 cm³', answer: '3500' },
    ],
    generate: (qIdx, isExam) => {
      const m3 = 1 + qIdx + (isExam ? 1 : 0);
      const ans = m3 * 1000;
      return measQ(13, qIdx, isExam, `حوض حجمه ${m3} متر مكعب، كم سعته باللتر؟`, `A tank has volume ${m3} m³. What is its capacity in liters?`, String(ans), numericDistractors(ans, [m3 * 100 - ans, 1000, -500, 200]), `1 م³ = 1000 لتر، إذن ${m3} × 1000 = ${ans} لتر.`, `${m3} × 1000 = ${ans} L.`);
    },
  },
  {
    stage: 14,
    titleAr: 'السرعة والمسافة والزمن',
    titleEn: 'Speed, Distance & Time',
    summaryAr: 'السرعة تساوي المسافة مقسومة على الزمن، والمسافة تساوي السرعة × الزمن.',
    summaryEn: 'Distance = Speed × Time, and Speed = Distance / Time.',
    ruleTitleAr: 'مثلث الحركة',
    ruleTitleEn: 'Motion Formula',
    ruleFormula: 'd = v × t',
    examples: [
      { problemAr: 'سيارة سرعتها 80 كم/س لمدة 3 ساعات، المسافة؟', problemEn: '80 km/h for 3 hr, distance?', solutionAr: '240 كم', solutionEn: '240 km', answer: '240' },
      { problemAr: 'قطعت 180 كم في ساعتين، السرعة؟', problemEn: '180 km in 2 hr, speed?', solutionAr: '90 كم/س', solutionEn: '90 km/h', answer: '90' },
    ],
    generate: (qIdx, isExam) => {
      const speed = 50 + qIdx * 10 + (isExam ? 5 : 0);
      const hours = 2 + (qIdx % 4);
      const ans = speed * hours;
      return measQ(14, qIdx, isExam, `تتحرك سيارة بسرعة ثابتة ${speed} كم/ساعة، ما المسافة التي تقطعها في ${hours} ساعات؟`, `A car travels at ${speed} km/h for ${hours} hours. Distance covered (km)?`, String(ans), numericDistractors(ans, [speed, -speed, 20, -20]), `المسافة = ${speed} × ${hours} = ${ans} كم.`, `Distance = ${speed} × ${hours} = ${ans} km.`);
    },
  },
  {
    stage: 15,
    titleAr: 'تحويل السرعة من كم/س إلى م/ث',
    titleEn: 'Converting km/h to m/s',
    summaryAr: 'للتحويل من كم/س إلى م/ث نقسم على 3.6 (أو نضرب في 5/18).',
    summaryEn: 'Convert km/h to m/s by dividing by 3.6 (or multiplying by 5/18).',
    ruleTitleAr: 'معامل التحويل 3.6',
    ruleTitleEn: 'km/h to m/s',
    ruleFormula: 'm/s = (km/h) × (5 / 18)',
    examples: [
      { problemAr: 'حوّل 72 كم/س إلى م/ث', problemEn: 'Convert 72 km/h to m/s', solutionAr: '72 × 5/18 = 20 م/ث', solutionEn: '20 m/s', answer: '20' },
      { problemAr: 'حوّل 108 كم/س إلى م/ث', problemEn: 'Convert 108 km/h to m/s', solutionAr: '30 م/ث', solutionEn: '30 m/s', answer: '30' },
    ],
    generate: (qIdx, isExam) => {
      const ms = 5 + qIdx * 3 + (isExam ? 2 : 0);
      const kmh = (ms * 18) / 5;
      return measQ(15, qIdx, isExam, `سرعة قطار ${kmh} كم/ساعة، كم تعادل بالمتر في الثانية (م/ث)؟`, `Convert ${kmh} km/h into m/s:`, String(ms), numericDistractors(ms, [2, -2, 5, -5]), `${kmh} × (5/18) = ${ms} م/ث.`, `${kmh} × (5/18) = ${ms} m/s.`);
    },
  },
  {
    stage: 16,
    titleAr: 'مقياس الرسم على الخرائط',
    titleEn: 'Map Scale & Real Distance',
    summaryAr: 'مقياس الرسم يربط المسافة على الخريطة بالمسافة الحقيقية على الأرض.',
    summaryEn: 'A map scale translates map centimeters into real kilometers.',
    ruleTitleAr: 'قانون مقياس الرسم',
    ruleTitleEn: 'Scale Ratio',
    ruleFormula: 'Scale = Map Length / Real Length',
    examples: [
      { problemAr: 'مقياس 1 سم : 25 كم، المسافة 4 سم تمثل؟', problemEn: '1 cm : 25 km, 4 cm represents?', solutionAr: '100 كم', solutionEn: '100 km', answer: '100' },
      { problemAr: 'مقياس 1:500000، 3 سم تمثل؟', problemEn: '1:500,000, 3 cm in km?', solutionAr: '15 كم', solutionEn: '15 km', answer: '15' },
    ],
    generate: (qIdx, isExam) => {
      const kmPerCm = 10 + qIdx * 5 + (isExam ? 5 : 0);
      const cm = 3 + (qIdx % 5);
      const ans = kmPerCm * cm;
      return measQ(16, qIdx, isExam, `على خريطة كل 1 سم يمثل ${kmPerCm} كم في الحقيقة، فما المسافة الحقيقية لقطعة طولها ${cm} سم؟`, `On a map, 1 cm represents ${kmPerCm} km. What real distance (km) does ${cm} cm represent?`, String(ans), numericDistractors(ans, [kmPerCm, -kmPerCm, 5, -5]), `${cm} × ${kmPerCm} = ${ans} كم.`, `${cm} × ${kmPerCm} = ${ans} km.`);
    },
  },
  {
    stage: 17,
    titleAr: 'الكثافة: الكتلة والحجم',
    titleEn: 'Density, Mass & Volume',
    summaryAr: 'الكثافة تساوي الكتلة مقسومة على الحجم.',
    summaryEn: 'Density is mass divided by volume (ρ = m / V).',
    ruleTitleAr: 'قانون الكثافة',
    ruleTitleEn: 'Density Formula',
    ruleFormula: 'Density = Mass / Volume',
    examples: [
      { problemAr: 'كتلة 120 غ وحجم 15 سم³، الكثافة؟', problemEn: 'Mass 120g, volume 15 cm³?', solutionAr: '8 غ/سم³', solutionEn: '8 g/cm³', answer: '8' },
      { problemAr: 'كثافة 5 غ/سم³ وحجم 20 سم³، الكتلة؟', problemEn: 'Density 5, volume 20, mass?', solutionAr: '100 غ', solutionEn: '100 g', answer: '100' },
    ],
    generate: (qIdx, isExam) => {
      const density = 2 + ((qIdx + (isExam ? 1 : 0)) % 8);
      const vol = 10 + qIdx * 4;
      const mass = density * vol;
      return measQ(17, qIdx, isExam, `قطعة معدنية كتلتها ${mass} غ وحجمها ${vol} سم³، ما كثافتها (غ/سم³)؟`, `A metal block has mass ${mass} g and volume ${vol} cm³. Find its density (g/cm³):`, String(density), numericDistractors(density, [1, -1, 2, -2]), `${mass} ÷ ${vol} = ${density} غ/سم³.`, `${mass} / ${vol} = ${density} g/cm³.`);
    },
  },
  {
    stage: 18,
    titleAr: 'التحويل بين الدرجات المئوية والفهرنهايت',
    titleEn: 'Celsius to Fahrenheit Conversion',
    summaryAr: 'للتحويل من مئوي إلى فهرنهايت نضرب في 9/5 ثم نضيف 32.',
    summaryEn: 'Convert Celsius to Fahrenheit via F = (9/5)C + 32.',
    ruleTitleAr: 'معادلة التحويل الحراري',
    ruleTitleEn: 'C-to-F Formula',
    ruleFormula: '°F = (9/5)°C + 32',
    examples: [
      { problemAr: 'حوّل 20°C إلى فهرنهايت', problemEn: 'Convert 20°C to °F', solutionAr: '36 + 32 = 68°F', solutionEn: '68°F', answer: '68' },
      { problemAr: 'حوّل 0°C إلى فهرنهايت', problemEn: 'Convert 0°C to °F', solutionAr: '32°F', solutionEn: '32°F', answer: '32' },
    ],
    generate: (qIdx, isExam) => {
      const c = 5 * (1 + qIdx + (isExam ? 1 : 0));
      const f = (9 * c) / 5 + 32;
      return measQ(18, qIdx, isExam, `ما درجة الحرارة بالفهرنهايت المقابلة لـ ${c}°C؟`, `Convert ${c}°C to Fahrenheit (°F):`, String(f), numericDistractors(f, [9, -9, 10, -10]), `(9/5) × ${c} + 32 = ${(9 * c) / 5} + 32 = ${f}°F.`, `(9/5) × ${c} + 32 = ${f}°F.`);
    },
  },
  {
    stage: 19,
    titleAr: 'الوحدات الإمبراطورية: البوصة والقدم والياردة',
    titleEn: 'Inches, Feet & Yards',
    summaryAr: 'القدم يساوي 12 بوصة، والياردة تساوي 3 أقدام (36 بوصة).',
    summaryEn: '1 foot = 12 inches, and 1 yard = 3 feet = 36 inches.',
    ruleTitleAr: 'التحويل الإمبراطوري',
    ruleTitleEn: 'Imperial Length',
    ruleFormula: '1 yd = 3 ft , 1 ft = 12 in',
    examples: [
      { problemAr: '4 أقدام بالبوصة؟', problemEn: '4 ft in inches?', solutionAr: '48 بوصة', solutionEn: '48 in', answer: '48' },
      { problemAr: '5 ياردات بالأقدام؟', problemEn: '5 yd in feet?', solutionAr: '15 قدماً', solutionEn: '15 ft', answer: '15' },
    ],
    generate: (qIdx, isExam) => {
      const ft = 2 + qIdx + (isExam ? 1 : 0);
      const ans = ft * 12;
      return measQ(19, qIdx, isExam, `كم بوصة (inch) في ${ft} أقدام (feet)؟`, `How many inches are in ${ft} feet?`, String(ans), numericDistractors(ans, [12, -12, 6, -6]), `${ft} × 12 = ${ans} بوصة.`, `${ft} × 12 = ${ans} inches.`);
    },
  },
  {
    stage: 20,
    titleAr: 'ساعات العمل وحساب الأجور',
    titleEn: 'Rates & Unit Cost Calculations',
    summaryAr: 'نحسب تكلفة الوحدة بقسمة التكلفة الكلية على عدد الوحدات ثم نضرب في الكمية المطلوبة.',
    summaryEn: 'Compute unit rate by dividing total cost by quantity, then scale up.',
    ruleTitleAr: 'سعر الوحدة',
    ruleTitleEn: 'Unit Rate',
    ruleFormula: 'Total = (Cost / Units) × DesiredUnits',
    examples: [
      { problemAr: '4 ساعات عمل بـ 120 ريالاً، أجر 7 ساعات؟', problemEn: '4 hr pays 120, 7 hr?', solutionAr: '30 × 7 = 210', solutionEn: '210', answer: '210' },
      { problemAr: '5 كغ بـ 45 ريالاً، 8 كغ؟', problemEn: '5 kg cost 45, 8 kg?', solutionAr: '72', solutionEn: '72', answer: '72' },
    ],
    generate: (qIdx, isExam) => {
      const rate = 15 + qIdx * 5 + (isExam ? 5 : 0);
      const h1 = 3 + (qIdx % 3);
      const h2 = h1 + 2 + (qIdx % 4);
      const ans = rate * h2;
      return measQ(20, qIdx, isExam, `إذا كان أجر ${h1} ساعات عمل هو ${rate * h1} ريالاً، فكم أجر ${h2} ساعات بنفس المعدل؟`, `If ${h1} hours of work pay ${rate * h1}, how much do ${h2} hours pay at the same rate?`, String(ans), numericDistractors(ans, [rate, -rate, 10, -10]), `أجر الساعة = ${rate}، وأجر ${h2} ساعات = ${ans}.`, `Hourly rate is ${rate}, so ${h2} hours pay ${ans}.`);
    },
  },
  // --- HARD (21 - 30) ---
  {
    stage: 21,
    titleAr: 'التحويل بين وحدات الحجم المكعبة',
    titleEn: 'Cubic Volume Conversions',
    summaryAr: '1 م³ = 100³ = 1,000,000 سم³، و 1 دسم³ = 1000 سم³.',
    summaryEn: 'Volume scales with the cube of linear conversion factors.',
    ruleTitleAr: 'تكعيب معامل الطول',
    ruleTitleEn: 'Cubic Scale',
    ruleFormula: '1 dm³ = 1000 cm³ , 1 cm³ = 1000 mm³',
    examples: [
      { problemAr: '2.5 دسم³ بالسنتيمتر المكعب؟', problemEn: '2.5 dm³ in cm³?', solutionAr: '2500 سم³', solutionEn: '2500 cm³', answer: '2500' },
      { problemAr: '4 سم³ بالمليمتر المكعب؟', problemEn: '4 cm³ in mm³?', solutionAr: '4000 ملم³', solutionEn: '4000 mm³', answer: '4000' },
    ],
    generate: (qIdx, isExam) => {
      const cm3 = 2 + qIdx + (isExam ? 1 : 0);
      const ans = cm3 * 1000;
      return measQ(21, qIdx, isExam, `حوّل ${cm3} سم³ إلى مليمتر مكعب (ملم³):`, `Convert ${cm3} cm³ into cubic millimeters (mm³):`, String(ans), numericDistractors(ans, [cm3 * 100 - ans, 1000, -1000, 500]), `1 سم³ = 10³ = 1000 ملم³، إذن ${cm3} × 1000 = ${ans}.`, `${cm3} × 1000 = ${ans} mm³.`);
    },
  },
  {
    stage: 22,
    titleAr: 'معدل التدفق وتعبئة الخزانات',
    titleEn: 'Flow Rates & Tank Filling',
    summaryAr: 'الزمن اللازم للتعبئة يساوي سعة الخزان الكلية مقسومة على معدل التدفق.',
    summaryEn: 'Fill time equals total tank volume divided by the flow rate.',
    ruleTitleAr: 'زمن التعبئة',
    ruleTitleEn: 'Flow Time',
    ruleFormula: 'Time = Total Volume / Flow Rate',
    examples: [
      { problemAr: 'خزان 600 لتر ومعدل الضخ 25 لتر/دقيقة، الزمن؟', problemEn: '600 L at 25 L/min?', solutionAr: '24 دقيقة', solutionEn: '24 min', answer: '24' },
      { problemAr: '450 لتر بمعدل 15 لتر/دقيقة', problemEn: '450 L at 15 L/min', solutionAr: '30 دقيقة', solutionEn: '30 min', answer: '30' },
    ],
    generate: (qIdx, isExam) => {
      const rate = 12 + qIdx * 3 + (isExam ? 2 : 0);
      const mins = 10 + qIdx * 4;
      const cap = rate * mins;
      return measQ(22, qIdx, isExam, `خزان سعته ${cap} لتراً يضخ فيه الماء بمعدل ${rate} لتراً في الدقيقة، كم دقيقة تلزم لملئه؟`, `A ${cap}-liter tank is filled at ${rate} L/min. How many minutes to fill it?`, String(mins), numericDistractors(mins, [2, -2, 5, -5]), `${cap} ÷ ${rate} = ${mins} دقيقة.`, `${cap} / ${rate} = ${mins} minutes.`);
    },
  },
  {
    stage: 23,
    titleAr: 'السرعة المتوسطة لرحلة من مرحلتين',
    titleEn: 'Average Speed Across Two Legs',
    summaryAr: 'السرعة المتوسطة تساوي المسافة الكلية مقسومة على الزمن الكلي (وليس متوسط السرعتين!).',
    summaryEn: 'Average speed is Total Distance divided by Total Time—never a simple average of speeds.',
    ruleTitleAr: 'السرعة المتوسطة',
    ruleTitleEn: 'Average Speed',
    ruleFormula: 'v_avg = (d₁ + d₂) / (t₁ + t₂)',
    examples: [
      { problemAr: 'قطع 120 كم في ساعتين ثم 180 كم في 3 ساعات، السرعة المتوسطة؟', problemEn: '120km in 2h, 180km in 3h. Avg speed?', solutionAr: '300 ÷ 5 = 60 كم/س', solutionEn: '60 km/h', answer: '60' },
      { problemAr: '90 كم في ساعة ثم 150 كم في 3 ساعات', problemEn: '90km in 1h, 150km in 3h', solutionAr: '240 ÷ 4 = 60', solutionEn: '60', answer: '60' },
    ],
    generate: (qIdx, isExam) => {
      const t1 = 2;
      const t2 = 2 + (qIdx % 3);
      const avg = 45 + qIdx * 5 + (isExam ? 5 : 0);
      const totalD = avg * (t1 + t2);
      const d1 = (avg - 10) * t1;
      const d2 = totalD - d1;
      return measQ(23, qIdx, isExam, `قطعت حافلة ${d1} كم في ${t1} ساعات ثم ${d2} كم في ${t2} ساعات، ما سرعتها المتوسطة (كم/س)؟`, `A bus travels ${d1} km in ${t1} hr and ${d2} km in ${t2} hr. Find its average speed (km/h):`, String(avg), numericDistractors(avg, [5, -5, 10, -10]), `المسافة الكلية ${totalD} كم ÷ الزمن الكلي ${t1 + t2} س = ${avg} كم/س.`, `Total distance ${totalD} / total time ${t1 + t2} = ${avg} km/h.`);
    },
  },
  {
    stage: 24,
    titleAr: 'التوقيت الدولي وفروق المناطق الزمنية',
    titleEn: 'Time Zones & Flight Duration',
    summaryAr: 'نحسب مدة الرحلة بطرح وقت المغادرة (بعد توحيد التوقيت) من وقت الوصول.',
    summaryEn: 'Adjust both departure and arrival times to the same time zone before subtracting.',
    ruleTitleAr: 'توحيد المنطقة الزمنية',
    ruleTitleEn: 'Time Zone Alignment',
    ruleFormula: 'Duration = Arrival(local) − (Departure + ΔTZ)',
    examples: [
      { problemAr: 'أقلعت طائرة 10:00 من مدينة A ووصلت 16:00 إلى B (+2 ساعة)، مدة الرحلة؟', problemEn: 'Depart 10:00 A, arrive 16:00 B (+2h). Duration?', solutionAr: '16:00 − 12:00 = 4 ساعات', solutionEn: '4 hr', answer: '4' },
      { problemAr: 'أقلعت 08:00 ووصلت 14:00 (+1 ساعة)', problemEn: 'Depart 08:00, arrive 14:00 (+1h)', solutionAr: '5 ساعات', solutionEn: '5 hr', answer: '5' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const dep = 5 + idx;
      const tzDiff = 1 + (idx % 3);
      const flight = 3 + (idx % 5);
      const arr = dep + tzDiff + flight;
      return measQ(24, qIdx, isExam, `أقلعت رحلة الساعة ${dep}:00 من مدينة أ ووصلت الساعة ${arr}:00 إلى مدينة ب (تسبقها بـ ${tzDiff} ساعات)، كم ساعة استغرقت الرحلة؟`, `A flight departs City A at ${dep}:00 and lands in City B (which is ${tzDiff} hours ahead) at ${arr}:00. Flight duration (hours)?`, String(flight), numericDistractors(flight, [tzDiff + 3, -1, 1, 2]), `وقت الإقلاع بتوقيت ب هو ${dep + tzDiff}:00، والمدة = ${arr} − ${dep + tzDiff} = ${flight} ساعات.`, `Departure in B-time is ${dep + tzDiff}:00; duration = ${flight} hr.`);
    },
  },
  {
    stage: 25,
    titleAr: 'نسبة الخطأ والحدود التقريبية للقياس',
    titleEn: 'Measurement Error & Bounds',
    summaryAr: 'عند تقريب طول لأقرب وحدة، يكون أقصى خطأ مطلق يساوي نصف هذه الوحدة.',
    summaryEn: 'Rounding to unit U allows a maximum absolute error of ±0.5U.',
    ruleTitleAr: 'حدود القياس',
    ruleTitleEn: 'Error Bounds',
    ruleFormula: 'Upper = M + 0.5U , Lower = M − 0.5U',
    examples: [
      { problemAr: 'طول مقرب لأقرب سم يساوي 14 سم، الحد الأعلى؟', problemEn: '14 cm rounded to nearest cm, upper bound?', solutionAr: '14.5 سم', solutionEn: '14.5 cm', answer: '14.5' },
      { problemAr: 'طول 8 سم لأقرب سم، الحد الأدنى؟', problemEn: '8 cm rounded to nearest cm, lower bound?', solutionAr: '7.5 سم', solutionEn: '7.5 cm', answer: '7.5' },
    ],
    generate: (qIdx, isExam) => {
      const m = 10 + qIdx * 2 + (isExam ? 1 : 0);
      const askUpper = qIdx % 2 === 0;
      const ans = askUpper ? `${m}.5` : `${m - 1}.5`;
      return measQ(25, qIdx, isExam, `قيس طول قلم لأقرب سنتيمتر فكان ${m} سم، ما ${askUpper ? 'الحد الأعلى' : 'الحد الأدنى'} الممكن لطوله الفعلي؟`, `A length rounded to the nearest cm is ${m} cm. What is its ${askUpper ? 'upper' : 'lower'} bound?`, ans, [askUpper ? `${m - 1}.5` : `${m}.5`, `${m + 1}`, `${m - 1}`], `الحدود هي [${m - 1}.5 , ${m}.5]، لذا المطلوب هو ${ans} سم.`, `Bounds are [${m - 1}.5, ${m}.5], so answer is ${ans} cm.`);
    },
  },
  {
    stage: 26,
    titleAr: 'مقياس الرسم والمساحات',
    titleEn: 'Map Scale & Scaled Areas',
    summaryAr: 'عند مضاعفة مقياس الطول بمعامل k، تتضاعف المساحة بمعامل k².',
    summaryEn: 'When map scale is 1 cm : k km, 1 cm² on the map represents k² km².',
    ruleTitleAr: 'مساحة مقياس الرسم',
    ruleTitleEn: 'Area Scaling',
    ruleFormula: '1 cm² → k² km²',
    examples: [
      { problemAr: '1 سم يمثل 5 كم، ماذا تمثل 3 سم²؟', problemEn: '1 cm = 5 km, 3 cm² represents?', solutionAr: '3 × 25 = 75 كم²', solutionEn: '75 km²', answer: '75' },
      { problemAr: '1 سم = 4 كم، 2 سم² تمثل؟', problemEn: '1 cm = 4 km, 2 cm²?', solutionAr: '32 كم²', solutionEn: '32 km²', answer: '32' },
    ],
    generate: (qIdx, isExam) => {
      const k = 2 + ((qIdx + (isExam ? 1 : 0)) % 5);
      const mapArea = 2 + (qIdx % 6);
      const ans = mapArea * k * k;
      return measQ(26, qIdx, isExam, `على مخطط كل 1 سم يمثل ${k} كم، فكم كيلومتراً مربعاً تمثل مساحة ${mapArea} سم² على المخطط؟`, `On a map where 1 cm = ${k} km, what real area (km²) does ${mapArea} cm² represent?`, String(ans), numericDistractors(ans, [mapArea * k - ans, k, -k, 4]), `1 سم² تمثل ${k}² = ${k * k} كم²، إذن ${mapArea} × ${k * k} = ${ans} كم².`, `1 cm² = ${k}² = ${k * k} km², so ${mapArea} × ${k * k} = ${ans} km².`);
    },
  },
  {
    stage: 27,
    titleAr: 'معدل استهلاك الوقود وتكلفة الرحلة',
    titleEn: 'Fuel Consumption & Trip Cost',
    summaryAr: 'نقسم المسافة على معدل الكيلومترات لكل لتر لإيجاد اللترات ثم نضرب في السعر.',
    summaryEn: 'Divide distance by fuel economy to get liters needed, then multiply by price.',
    ruleTitleAr: 'تكلفة الوقود',
    ruleTitleEn: 'Fuel Cost',
    ruleFormula: 'Liters = Distance / (km per L)',
    examples: [
      { problemAr: 'تستهلك سيارة 1 لتر لكل 12 كم، كم لتراً لـ 180 كم؟', problemEn: '12 km/L over 180 km, liters?', solutionAr: '15 لتراً', solutionEn: '15 L', answer: '15' },
      { problemAr: '15 كم/لتر لمسافة 300 كم، اللترات؟', problemEn: '15 km/L over 300 km?', solutionAr: '20 لتراً', solutionEn: '20 L', answer: '20' },
    ],
    generate: (qIdx, isExam) => {
      const kmPerL = 10 + ((qIdx + (isExam ? 1 : 0)) % 6);
      const liters = 8 + qIdx * 3;
      const dist = kmPerL * liters;
      return measQ(27, qIdx, isExam, `تقطع سيارة ${kmPerL} كم بكل لتر وقود، كم لتراً تحتاج لقطع ${dist} كم؟`, `A car gets ${kmPerL} km per liter. How many liters are needed for ${dist} km?`, String(liters), numericDistractors(liters, [2, -2, 4, -4]), `${dist} ÷ ${kmPerL} = ${liters} لتراً.`, `${dist} / ${kmPerL} = ${liters} L.`);
    },
  },
  {
    stage: 28,
    titleAr: 'تحويل الوحدات المركبة (كم/لتر و كغ/م²)',
    titleEn: 'Compound Unit Rates',
    summaryAr: 'نحسب الكمية الكلية بضرب المعدل في المساحة أو الكتلة المتاحة.',
    summaryEn: 'Multiply compound coverage rates by total area or quantity.',
    ruleTitleAr: 'المعدل المركب',
    ruleTitleEn: 'Coverage Rate',
    ruleFormula: 'Total Material = Rate × Area',
    examples: [
      { problemAr: 'يكفي اللتر لدهان 8 م²، كم لتراً لدهان جدار 4م × 6م؟', problemEn: '1L covers 8 m², liters for 4m×6m wall?', solutionAr: 'المساحة 24 ÷ 8 = 3 لترات', solutionEn: '3 L', answer: '3' },
      { problemAr: 'يكفي الكيس لـ 10 م²، مساحة 50 م²؟', problemEn: '10 m² per bag, 50 m²?', solutionAr: '5 أكياس', solutionEn: '5 bags', answer: '5' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const rate = 6 + (idx % 5);
      const cans = 3 + idx;
      const area = rate * cans;
      return measQ(28, qIdx, isExam, `تغطي علبة الطلاء الواحدة ${rate} م²، كم علبة نحتاج لطلاء سطح مساحته ${area} م²؟`, `One paint can covers ${rate} m². How many cans are needed for ${area} m²?`, String(cans), numericDistractors(cans, [1, -1, 2, -2]), `${area} ÷ ${rate} = ${cans} علب.`, `${area} / ${rate} = ${cans} cans.`);
    },
  },
  {
    stage: 29,
    titleAr: 'حساب الزمن عند تغير السرعة',
    titleEn: 'Speed-Time Inverse Variation',
    summaryAr: 'عند ثبات المسافة يتناسب الزمن عكسياً مع السرعة: v₁t₁ = v₂t₂.',
    summaryEn: 'For a fixed distance, speed and time vary inversely: v₁t₁ = v₂t₂.',
    ruleTitleAr: 'ثبات المسافة',
    ruleTitleEn: 'Constant Distance',
    ruleFormula: 'v₁ × t₁ = v₂ × t₂',
    examples: [
      { problemAr: 'تستغرق رحلة 4 ساعات بسرعة 60 كم/س، كم تستغرق بسرعة 80 كم/س؟', problemEn: '4h at 60 km/h; time at 80 km/h?', solutionAr: '240 ÷ 80 = 3 ساعات', solutionEn: '3 hr', answer: '3' },
      { problemAr: '3 ساعات بسرعة 100 كم/س، بسرعة 75 كم/س؟', problemEn: '3h at 100; at 75?', solutionAr: '4 ساعات', solutionEn: '4 hr', answer: '4' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const cases: [number, number, number][] = [
        [4, 60, 80], [3, 100, 75], [5, 60, 100], [6, 50, 75], [4, 90, 60],
        [3, 80, 60], [6, 70, 105], [5, 80, 100], [4, 75, 50], [8, 60, 120], [5, 90, 75],
      ];
      const [t1, v1, v2] = cases[idx];
      const dist = t1 * v1;
      const t2 = dist / v2;
      return measQ(29, qIdx, isExam, `تقطع سيارة مسافة في ${t1} ساعات بسرعة ${v1} كم/س، كم ساعة تحتاج لقطع نفس المسافة بسرعة ${v2} كم/س؟`, `A car takes ${t1} hr at ${v1} km/h. How many hours at ${v2} km/h?`, String(t2), numericDistractors(t2, [1, -1, 2, -2]), `المسافة = ${dist} كم، إذن الزمن = ${dist} ÷ ${v2} = ${t2} ساعات.`, `Distance = ${dist} km; time = ${dist} / ${v2} = ${t2} hr.`);
    },
  },
  {
    stage: 30,
    titleAr: 'التحدي الشامل للقياس والوحدات',
    titleEn: 'Master Measurement Challenge',
    summaryAr: 'مسائل مركبة تدمج تحويلات الحجم والسعة والكتلة والزمن.',
    summaryEn: 'Integrate volume, capacity, mass, and rate conversions in multi-step problems.',
    ruleTitleAr: 'التكامل القياسي',
    ruleTitleEn: 'Integrated Measurement',
    ruleFormula: 'V(m³) → Liters → Flow Time',
    examples: [
      { problemAr: 'خزان 2 م³ يُملأ بمعدل 50 لتر/دقيقة، الزمن بالدقائق؟', problemEn: '2 m³ tank at 50 L/min, minutes?', solutionAr: '2000 ÷ 50 = 40 دقيقة', solutionEn: '40 min', answer: '40' },
      { problemAr: 'خزان 1.5 م³ بمعدل 30 لتر/دقيقة', problemEn: '1.5 m³ at 30 L/min', solutionAr: '1500 ÷ 30 = 50 دقيقة', solutionEn: '50 min', answer: '50' },
    ],
    generate: (qIdx, isExam) => {
      const m3 = 1 + ((qIdx + (isExam ? 1 : 0)) % 4);
      const rate = [20, 25, 40, 50, 100][qIdx % 5];
      const mins = (m3 * 1000) / rate;
      return measQ(30, qIdx, isExam, `خزان مكعب حجمه ${m3} م³ يضخ فيه الماء بمعدل ${rate} لتراً في الدقيقة، بعد كم دقيقة يمتلئ؟`, `A ${m3} m³ tank is filled at ${rate} L/min. How many minutes until full?`, String(mins), numericDistractors(mins, [10, -10, 5, -5]), `${m3} م³ = ${m3 * 1000} لتر، والزمن = ${m3 * 1000} ÷ ${rate} = ${mins} دقيقة.`, `${m3} m³ = ${m3 * 1000} L; time = ${mins} min.`);
    },
  },
];

export const MEASUREMENT_STAGES: StageDefinition[] = TOPICS.map((spec) => {
  const questions: QuizQuestion[] = [];
  for (let i = 0; i < 10; i++) {
    questions.push(spec.generate(i, false));
  }
  return {
    id: makeStageId('measurement', spec.stage),
    sectionId: 'measurement',
    stageNumber: spec.stage,
    difficulty: getDifficultyForStage(spec.stage),
    titleAr: spec.titleAr,
    titleEn: spec.titleEn,
    lesson: {
      summaryAr: spec.summaryAr,
      summaryEn: spec.summaryEn,
      ruleTitleAr: spec.ruleTitleAr,
      ruleTitleEn: spec.ruleTitleEn,
      ruleFormula: spec.ruleFormula,
      examples: spec.examples,
    },
    questions,
    examQuestion: spec.generate(10, true),
  };
});
