import {
  buildChoiceQuestion,
  getDifficultyForStage,
  makeStageId,
  numericDistractors,
} from '@/src/data/curriculum/helpers';
import type { QuizQuestion, StageDefinition, WorkedExample } from '@/src/types/curriculum';

interface TopicSpec {
  stage: number;
  titleAr: string;
  titleEn: string;
  summaryAr: string;
  summaryEn: string;
  ruleTitleAr: string;
  ruleTitleEn: string;
  ruleFormula: string;
  examples: [WorkedExample, WorkedExample];
  generate: (qIdx: number, isExam: boolean) => QuizQuestion;
}

function algQ(
  stage: number,
  qIdx: number,
  isExam: boolean,
  promptAr: string,
  promptEn: string,
  correct: string,
  distractors: string[],
  explanationAr: string,
  explanationEn: string,
): QuizQuestion {
  const id = isExam ? `algebra-exam-s${stage}` : `algebra-s${stage}-q${qIdx + 1}`;
  return buildChoiceQuestion({
    id,
    promptAr,
    promptEn,
    correctValue: correct,
    distractors,
    explanationAr,
    explanationEn,
    seedKey: `${id}-${promptEn}`,
  });
}

const TOPICS: TopicSpec[] = [
  {
    stage: 1,
    titleAr: 'المتغيرات والتعبيرات الجبرية',
    titleEn: 'Variables & Algebraic Expressions',
    summaryAr: 'المتغير رمز يمثل عدداً مجهولاً مثل x، ونعبر عن العمليات اللفظية بعبارات جبرية.',
    summaryEn: 'A variable represents an unknown number; algebraic expressions translate phrases into math.',
    ruleTitleAr: 'التعويض الجبري',
    ruleTitleEn: 'Expression Evaluation',
    ruleFormula: 'mx + c',
    examples: [
      { problemAr: 'احسب 2x + 3 عندما x = 4', problemEn: 'Evaluate 2x + 3 when x = 4', solutionAr: '2(4) + 3 = 11', solutionEn: '11', answer: '11' },
      { problemAr: 'احسب 5y − 4 عندما y = 3', problemEn: 'Evaluate 5y − 4 when y = 3', solutionAr: '15 − 4 = 11', solutionEn: '11', answer: '11' },
    ],
    generate: (qIdx, isExam) => {
      const m = 2 + (qIdx % 4);
      const c = 1 + ((qIdx + (isExam ? 1 : 0)) % 7);
      const x = 2 + ((qIdx * 2 + (isExam ? 1 : 0)) % 8);
      const ans = m * x + c;
      return algQ(1, qIdx, isExam, `احسب قيمة العبارة ${m}x + ${c} عندما x = ${x}:`, `Evaluate ${m}x + ${c} when x = ${x}:`, String(ans), numericDistractors(ans, [m, -m, c, 2]), `${m}(${x}) + ${c} = ${ans}.`, `${m}(${x}) + ${c} = ${ans}.`);
    },
  },
  {
    stage: 2,
    titleAr: 'التعويض في عبارات بمتغيرين',
    titleEn: 'Two-Variable Substitution',
    summaryAr: 'عند وجود متغيرين x و y نستبدل كل متغير بقيمته ثم نحسب الناتج.',
    summaryEn: 'Replace both x and y with their values and follow order of operations.',
    ruleTitleAr: 'التعويض المزدوج',
    ruleTitleEn: 'Dual Substitution',
    ruleFormula: 'ax + by',
    examples: [
      { problemAr: '3x + 2y عند x=2، y=5', problemEn: '3x + 2y for x=2, y=5', solutionAr: '6 + 10 = 16', solutionEn: '16', answer: '16' },
      { problemAr: '4x − y عند x=3، y=5', problemEn: '4x − y for x=3, y=5', solutionAr: '12 − 5 = 7', solutionEn: '7', answer: '7' },
    ],
    generate: (qIdx, isExam) => {
      const a = 2 + (qIdx % 3);
      const b = 2 + ((qIdx + 1) % 4);
      const x = 1 + ((qIdx + (isExam ? 1 : 0)) % 6);
      const y = 2 + ((qIdx * 2) % 5);
      const ans = a * x + b * y;
      return algQ(2, qIdx, isExam, `إذا كان x = ${x} و y = ${y}، فما قيمة ${a}x + ${b}y؟`, `If x = ${x} and y = ${y}, find ${a}x + ${b}y:`, String(ans), numericDistractors(ans, [a, -a, b, 2]), `${a}(${x}) + ${b}(${y}) = ${ans}.`, `${a}(${x}) + ${b}(${y}) = ${ans}.`);
    },
  },
  {
    stage: 3,
    titleAr: 'تبسيط الحدود المتشابهة',
    titleEn: 'Combining Like Terms',
    summaryAr: 'الحدود المتشابهة لها نفس المتغير والأس، ونجمع معاملاتها فقط.',
    summaryEn: 'Combine coefficients of terms sharing the exact same variable and exponent.',
    ruleTitleAr: 'جمع المعاملات',
    ruleTitleEn: 'Like Terms',
    ruleFormula: 'ax + bx = (a + b)x',
    examples: [
      { problemAr: 'بسّط: 5x + 3x − 2x', problemEn: 'Simplify: 5x + 3x − 2x', solutionAr: '6x', solutionEn: '6x', answer: '6x' },
      { problemAr: 'بسّط: 4a + 2a', problemEn: 'Simplify: 4a + 2a', solutionAr: '6a', solutionEn: '6a', answer: '6a' },
    ],
    generate: (qIdx, isExam) => {
      const a = 3 + (qIdx % 5);
      const b = 2 + ((qIdx + (isExam ? 1 : 0)) % 6);
      const c = 1 + (qIdx % 3);
      const ans = `${a + b - c}x`;
      return algQ(3, qIdx, isExam, `بسّط: ${a}x + ${b}x − ${c}x`, `Simplify: ${a}x + ${b}x − ${c}x`, ans, [`${a + b - c + 1}x`, `${a + b + c}x`, `${a + b - c - 1}x`], `(${a} + ${b} − ${c})x = ${ans}.`, `(${a} + ${b} − ${c})x = ${ans}.`);
    },
  },
  {
    stage: 4,
    titleAr: 'خاصية التوزيع في الجبر',
    titleEn: 'Distributive Property',
    summaryAr: 'نضرب المعامل الخارجي في كل حد داخل القوس.',
    summaryEn: 'Multiply the outer factor across every term inside parentheses.',
    ruleTitleAr: 'قانون التوزيع',
    ruleTitleEn: 'Distribution',
    ruleFormula: 'k(ax + b) = kax + kb',
    examples: [
      { problemAr: 'فك: 3(2x + 5)', problemEn: 'Expand: 3(2x + 5)', solutionAr: '6x + 15', solutionEn: '6x + 15', answer: '6x + 15' },
      { problemAr: 'فك: 4(x + 3)', problemEn: 'Expand: 4(x + 3)', solutionAr: '4x + 12', solutionEn: '4x + 12', answer: '4x + 12' },
    ],
    generate: (qIdx, isExam) => {
      const k = 2 + ((qIdx + (isExam ? 1 : 0)) % 5);
      const a = 2 + (qIdx % 4);
      const b = 1 + ((qIdx * 2) % 6);
      const ans = `${k * a}x + ${k * b}`;
      return algQ(4, qIdx, isExam, `أوجد مفكوك: ${k}(${a}x + ${b})`, `Expand: ${k}(${a}x + ${b})`, ans, [`${k * a}x + ${b}`, `${k + a}x + ${k * b}`, `${k * a}x + ${k + b}`], `${k}×${a}x + ${k}×${b} = ${ans}.`, `Distributing ${k} gives ${ans}.`);
    },
  },
  {
    stage: 5,
    titleAr: 'معادلات الجمع والطرح من خطوة واحدة',
    titleEn: 'One-Step Add/Subtract Equations',
    summaryAr: 'لعزل المتغير x نطبق العملية العكسية على طرفي المعادلة.',
    summaryEn: 'Apply the inverse operation to both sides to isolate x.',
    ruleTitleAr: 'توازن المعادلة',
    ruleTitleEn: 'Equation Balance',
    ruleFormula: 'x + a = b ⟹ x = b − a',
    examples: [
      { problemAr: 'حل: x + 9 = 17', problemEn: 'Solve: x + 9 = 17', solutionAr: 'x = 8', solutionEn: '8', answer: '8' },
      { problemAr: 'حل: x − 6 = 14', problemEn: 'Solve: x − 6 = 14', solutionAr: 'x = 20', solutionEn: '20', answer: '20' },
    ],
    generate: (qIdx, isExam) => {
      const x = 4 + qIdx * 2 + (isExam ? 1 : 0);
      const a = 5 + ((qIdx * 3) % 12);
      const isAdd = qIdx % 2 === 0;
      const rhs = isAdd ? x + a : x - a;
      const eq = isAdd ? `x + ${a} = ${rhs}` : `x − ${a} = ${rhs}`;
      return algQ(5, qIdx, isExam, `حل المعادلة: ${eq}`, `Solve: ${eq}`, String(x), numericDistractors(x, [2, -2, a, 1], true), `x = ${x}.`, `x = ${x}.`);
    },
  },
  {
    stage: 6,
    titleAr: 'معادلات الضرب من خطوة واحدة',
    titleEn: 'One-Step Multiplication Equations',
    summaryAr: 'نقسم الطرفين على معامل المتغير لإيجاد قيمته.',
    summaryEn: 'Divide both sides by the variable coefficient.',
    ruleTitleAr: 'عزل المعامل',
    ruleTitleEn: 'Divide by Coefficient',
    ruleFormula: 'ax = b ⟹ x = b / a',
    examples: [
      { problemAr: 'حل: 6x = 42', problemEn: 'Solve: 6x = 42', solutionAr: 'x = 7', solutionEn: '7', answer: '7' },
      { problemAr: 'حل: 8x = 64', problemEn: 'Solve: 8x = 64', solutionAr: 'x = 8', solutionEn: '8', answer: '8' },
    ],
    generate: (qIdx, isExam) => {
      const a = 3 + ((qIdx + (isExam ? 1 : 0)) % 7);
      const x = 4 + qIdx * 2;
      return algQ(6, qIdx, isExam, `أوجد x: ${a}x = ${a * x}`, `Solve: ${a}x = ${a * x}`, String(x), numericDistractors(x, [1, -1, 2, a]), `x = ${a * x} ÷ ${a} = ${x}.`, `x = ${a * x} / ${a} = ${x}.`);
    },
  },
  {
    stage: 7,
    titleAr: 'المعادلات الخطية من خطوتين',
    titleEn: 'Two-Step Linear Equations',
    summaryAr: 'نتخلص من الجمع أو الطرح أولاً ثم نقسم على المعامل.',
    summaryEn: 'Undo addition/subtraction first, then divide by the coefficient.',
    ruleTitleAr: 'خطوتان للحل',
    ruleTitleEn: 'Two-Step Rule',
    ruleFormula: 'ax + b = c ⟹ x = (c − b) / a',
    examples: [
      { problemAr: 'حل: 3x + 4 = 19', problemEn: 'Solve: 3x + 4 = 19', solutionAr: '3x = 15 ← x = 5', solutionEn: '5', answer: '5' },
      { problemAr: 'حل: 2x + 7 = 21', problemEn: 'Solve: 2x + 7 = 21', solutionAr: '2x = 14 ← x = 7', solutionEn: '7', answer: '7' },
    ],
    generate: (qIdx, isExam) => {
      const a = 2 + (qIdx % 5);
      const x = 2 + ((qIdx * 2 + (isExam ? 1 : 0)) % 9);
      const b = 3 + ((qIdx * 3) % 10);
      const c = a * x + b;
      return algQ(7, qIdx, isExam, `حل المعادلة: ${a}x + ${b} = ${c}`, `Solve: ${a}x + ${b} = ${c}`, String(x), numericDistractors(x, [1, -1, 2, 3]), `${a}x = ${c - b}، ومنها x = ${x}.`, `${a}x = ${c - b}, so x = ${x}.`);
    },
  },
  {
    stage: 8,
    titleAr: 'المتباينات الخطية البسيطة',
    titleEn: 'Basic Linear Inequalities',
    summaryAr: 'تعامل المتباينات كالمعادلات مع تحديد أصغر أو أكبر عدد صحيح يحقق الشرط.',
    summaryEn: 'Solve linear inequalities and find boundary integer solutions.',
    ruleTitleAr: 'حل المتباينة',
    ruleTitleEn: 'Inequality Bound',
    ruleFormula: 'ax > b ⟹ x > b / a',
    examples: [
      { problemAr: 'أصغر عدد صحيح يحقق 2x > 9', problemEn: 'Smallest integer for 2x > 9', solutionAr: 'x > 4.5 ← 5', solutionEn: '5', answer: '5' },
      { problemAr: 'أصغر عدد صحيح يحقق 3x > 14', problemEn: 'Smallest integer for 3x > 14', solutionAr: 'x > 4.66 ← 5', solutionEn: '5', answer: '5' },
    ],
    generate: (qIdx, isExam) => {
      const a = 2 + (qIdx % 4);
      const threshold = 5 + qIdx * 2 + (isExam ? 1 : 0);
      const rhs = a * threshold - 1;
      return algQ(8, qIdx, isExam, `ما أصغر عدد صحيح يحقق ${a}x > ${rhs}؟`, `Smallest integer x satisfying ${a}x > ${rhs}?`, String(threshold), numericDistractors(threshold, [1, -1, 2, -2]), `x > ${(rhs / a).toFixed(2)} ← أصغر عدد صحيح هو ${threshold}.`, `x > ${(rhs / a).toFixed(2)}, so smallest integer is ${threshold}.`);
    },
  },
  {
    stage: 9,
    titleAr: 'التعبيرات التربيعية البسيطة',
    titleEn: 'Quadratic Expressions',
    summaryAr: 'نحسب مربع المتغير أولاً ثم نضرب في المعامل ونجمع الثابت.',
    summaryEn: 'Square the variable first, then multiply by the coefficient and add constant.',
    ruleTitleAr: 'قيمة العبارة التربيعية',
    ruleTitleEn: 'Quadratic Value',
    ruleFormula: 'ax² + c',
    examples: [
      { problemAr: '2x² + 1 عند x = 3', problemEn: '2x² + 1 at x = 3', solutionAr: '18 + 1 = 19', solutionEn: '19', answer: '19' },
      { problemAr: '3x² + 2 عند x = 2', problemEn: '3x² + 2 at x = 2', solutionAr: '12 + 2 = 14', solutionEn: '14', answer: '14' },
    ],
    generate: (qIdx, isExam) => {
      const a = 1 + (qIdx % 3);
      const x = 2 + ((qIdx + (isExam ? 1 : 0)) % 6);
      const c = 1 + ((qIdx * 2) % 7);
      const ans = a * x * x + c;
      return algQ(9, qIdx, isExam, `احسب ${a === 1 ? '' : a}x² + ${c} عندما x = ${x}:`, `Evaluate ${a === 1 ? '' : a}x² + ${c} at x = ${x}:`, String(ans), numericDistractors(ans, [x, -x, 2, 4]), `${a}(${x * x}) + ${c} = ${ans}.`, `${a}(${x * x}) + ${c} = ${ans}.`);
    },
  },
  {
    stage: 10,
    titleAr: 'المتتابعات الحسابية: الحد التالي',
    titleEn: 'Arithmetic Sequences: Next Term',
    summaryAr: 'يزيد أو ينقص كل حد في المتتابعة الحسابية بمقدار ثابت d.',
    summaryEn: 'Each term changes by a constant common difference d.',
    ruleTitleAr: 'الأساس الثابت',
    ruleTitleEn: 'Common Difference',
    ruleFormula: 'aₙ₊₁ = aₙ + d',
    examples: [
      { problemAr: '4, 9, 14, 19, ...', problemEn: '4, 9, 14, 19, ...', solutionAr: '24', solutionEn: '24', answer: '24' },
      { problemAr: '2, 8, 14, 20, ...', problemEn: '2, 8, 14, 20, ...', solutionAr: '26', solutionEn: '26', answer: '26' },
    ],
    generate: (qIdx, isExam) => {
      const s = 2 + qIdx * 2;
      const d = 3 + ((qIdx + (isExam ? 1 : 0)) % 7);
      const terms = [s, s + d, s + 2 * d, s + 3 * d];
      const ans = s + 4 * d;
      return algQ(10, qIdx, isExam, `ما الحد التالي: ${terms.join('، ')}، ...؟`, `Next term: ${terms.join(', ')}, ...?`, String(ans), numericDistractors(ans, [d, -d, 1, 2]), `بإضافة الأساس ${d}: ${terms[3]} + ${d} = ${ans}.`, `Adding d=${d} gives ${ans}.`);
    },
  },
  // --- MEDIUM (11 - 20) ---
  {
    stage: 11,
    titleAr: 'معادلات بمتغيرات في الطرفين',
    titleEn: 'Variables on Both Sides',
    summaryAr: 'نجمع حدود x في طرف والثوابت في الطرف الآخر.',
    summaryEn: 'Move variable terms to one side and constants to the other.',
    ruleTitleAr: 'تجميع المتغير',
    ruleTitleEn: 'Collect Variables',
    ruleFormula: 'ax + b = cx + d ⟹ (a−c)x = d − b',
    examples: [
      { problemAr: '5x + 2 = 3x + 12', problemEn: '5x + 2 = 3x + 12', solutionAr: '2x = 10 ← x = 5', solutionEn: '5', answer: '5' },
      { problemAr: '7x + 1 = 4x + 16', problemEn: '7x + 1 = 4x + 16', solutionAr: '3x = 15 ← x = 5', solutionEn: '5', answer: '5' },
    ],
    generate: (qIdx, isExam) => {
      const x = 2 + qIdx + (isExam ? 1 : 0);
      const c = 2 + (qIdx % 4);
      const a = c + 2 + (qIdx % 3);
      const b = 1 + ((qIdx * 2) % 6);
      const d = (a - c) * x + b;
      return algQ(11, qIdx, isExam, `أوجد x: ${a}x + ${b} = ${c}x + ${d}`, `Solve: ${a}x + ${b} = ${c}x + ${d}`, String(x), numericDistractors(x, [1, -1, 2, 3]), `${a - c}x = ${d - b} ← x = ${x}.`, `${a - c}x = ${d - b} → x = ${x}.`);
    },
  },
  {
    stage: 12,
    titleAr: 'معادلات تحتوي على أقواس',
    titleEn: 'Equations with Parentheses',
    summaryAr: 'نقسم على المعامل الخارجي أو نفك الأقواس بالتوزيع ثم نحل.',
    summaryEn: 'Divide out the factor or distribute first, then solve.',
    ruleTitleAr: 'فك الأقواس',
    ruleTitleEn: 'Parentheses Rule',
    ruleFormula: 'k(x + a) = b ⟹ x = b/k − a',
    examples: [
      { problemAr: '3(x + 4) = 27', problemEn: '3(x + 4) = 27', solutionAr: 'x + 4 = 9 ← x = 5', solutionEn: '5', answer: '5' },
      { problemAr: '5(x + 2) = 35', problemEn: '5(x + 2) = 35', solutionAr: 'x + 2 = 7 ← x = 5', solutionEn: '5', answer: '5' },
    ],
    generate: (qIdx, isExam) => {
      const k = 2 + (qIdx % 4);
      const a = 1 + ((qIdx * 2 + (isExam ? 1 : 0)) % 6);
      const x = 2 + qIdx;
      const rhs = k * (x + a);
      return algQ(12, qIdx, isExam, `حل المعادلة: ${k}(x + ${a}) = ${rhs}`, `Solve: ${k}(x + ${a}) = ${rhs}`, String(x), numericDistractors(x, [1, -1, a, 2]), `x + ${a} = ${x + a}، ومنها x = ${x}.`, `x + ${a} = ${x + a}, so x = ${x}.`);
    },
  },
  {
    stage: 13,
    titleAr: 'قوانين الأسس للرموز الجبرية',
    titleEn: 'Symbolic Exponent Laws',
    summaryAr: 'عند ضرب القوى متحدة الأساس نجمع الأسس، وعند قوة القوة نضرب الأسس.',
    summaryEn: 'Add exponents when multiplying like bases; multiply exponents for power of a power.',
    ruleTitleAr: 'قوانين القوى',
    ruleTitleEn: 'Power Laws',
    ruleFormula: 'xᵃ·xᵇ = xᵃ⁺ᵇ , (xᵃ)ᵇ = xᵃᵇ',
    examples: [
      { problemAr: 'x³ · x⁵', problemEn: 'x³ · x⁵', solutionAr: 'x^8', solutionEn: 'x^8', answer: 'x^8' },
      { problemAr: '(x²)⁴', problemEn: '(x²)⁴', solutionAr: 'x^8', solutionEn: 'x^8', answer: 'x^8' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const cases: [number, number, boolean][] = [
        [2, 3, false], [3, 4, true], [2, 5, false], [4, 2, true], [3, 5, false],
        [2, 4, true], [4, 5, false], [3, 3, true], [5, 2, false], [2, 6, true], [5, 4, false],
      ];
      const [a, b, pow] = cases[idx];
      const exp = pow ? a * b : a + b;
      const expr = pow ? `(x^${a})^${b}` : `x^${a} · x^${b}`;
      const ans = `x^${exp}`;
      return algQ(13, qIdx, isExam, `بسّط: ${expr}`, `Simplify: ${expr}`, ans, [`x^${pow ? a + b : a * b}`, `x^${exp + 1}`, `x^${exp - 1}`], `الناتج هو ${ans}.`, `Result is ${ans}.`);
    },
  },
  {
    stage: 14,
    titleAr: 'ضرب كثيرات الحدود البسيطة',
    titleEn: 'Multiplying Binomials',
    summaryAr: 'مفكوك (x + a)(x + b) يعطي x² + (a+b)x + ab.',
    summaryEn: '(x + a)(x + b) expands to x² + (a+b)x + ab.',
    ruleTitleAr: 'نشر القوسين',
    ruleTitleEn: 'Binomial Product',
    ruleFormula: '(x+a)(x+b) = x² + (a+b)x + ab',
    examples: [
      { problemAr: 'معامل x في (x+3)(x+5)', problemEn: 'x-coeff in (x+3)(x+5)', solutionAr: '8', solutionEn: '8', answer: '8' },
      { problemAr: 'الحد الثابت في (x+4)(x+6)', problemEn: 'Constant in (x+4)(x+6)', solutionAr: '24', solutionEn: '24', answer: '24' },
    ],
    generate: (qIdx, isExam) => {
      const a = 1 + (qIdx % 5);
      const b = 2 + ((qIdx * 2 + (isExam ? 1 : 0)) % 6);
      const askCoef = qIdx % 2 === 0;
      const ans = askCoef ? a + b : a * b;
      return algQ(14, qIdx, isExam, `في مفكوك (x + ${a})(x + ${b})، ما ${askCoef ? 'معامل x' : 'الحد الثابت'}؟`, `In (x + ${a})(x + ${b}), what is the ${askCoef ? 'coefficient of x' : 'constant term'}?`, String(ans), numericDistractors(ans, [askCoef ? a * b - ans : a + b - ans, 1, -1, 2]), `${askCoef ? `${a}+${b}=${ans}` : `${a}×${b}=${ans}`}.`, `${askCoef ? `${a}+${b}=${ans}` : `${a}×${b}=${ans}`}.`);
    },
  },
  {
    stage: 15,
    titleAr: 'التحليل بالعامل المشترك الأكبر',
    titleEn: 'Factoring Out GCF',
    summaryAr: 'نستخرج أكبر قاسم مشترك خارج القوس ونقسم كل حد عليه.',
    summaryEn: 'Factor out the greatest common divisor of all terms.',
    ruleTitleAr: 'العامل المشترك',
    ruleTitleEn: 'Common Factor',
    ruleFormula: 'gx + gb = g(x + b)',
    examples: [
      { problemAr: 'حلّل: 6x + 12', problemEn: 'Factor: 6x + 12', solutionAr: '6(x + 2)', solutionEn: '6(x + 2)', answer: '6(x + 2)' },
      { problemAr: 'حلّل: 5x + 15', problemEn: 'Factor: 5x + 15', solutionAr: '5(x + 3)', solutionEn: '5(x + 3)', answer: '5(x + 3)' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const g = 2 + idx;
      const b = 2 + (idx % 5);
      const ans = `${g}(x + ${b})`;
      return algQ(15, qIdx, isExam, `حلّل: ${g}x + ${g * b}`, `Factor: ${g}x + ${g * b}`, ans, [`${g}(x + ${b + 1})`, `${g + 1}(x + ${b})`, `x(${g} + ${g * b})`], `نخرج ${g} عاملاً مشتركاً ← ${ans}.`, `Factoring ${g} gives ${ans}.`);
    },
  },
  {
    stage: 16,
    titleAr: 'تحليل الفرق بين مربعين',
    titleEn: 'Difference of Squares',
    summaryAr: 'يتحلل فرق المربعين إلى (x − a)(x + a).',
    summaryEn: 'x² − a² factors cleanly into (x − a)(x + a).',
    ruleTitleAr: 'فرق المربعين',
    ruleTitleEn: 'Conjugate Pair',
    ruleFormula: 'x² − a² = (x − a)(x + a)',
    examples: [
      { problemAr: 'حلّل: x² − 25', problemEn: 'Factor: x² − 25', solutionAr: '(x - 5)(x + 5)', solutionEn: '(x - 5)(x + 5)', answer: '(x - 5)(x + 5)' },
      { problemAr: 'حلّل: x² − 49', problemEn: 'Factor: x² − 49', solutionAr: '(x - 7)(x + 7)', solutionEn: '(x - 7)(x + 7)', answer: '(x - 7)(x + 7)' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const a = 2 + idx;
      const ans = `(x - ${a})(x + ${a})`;
      return algQ(16, qIdx, isExam, `حلّل: x² − ${a * a}`, `Factor: x² − ${a * a}`, ans, [`(x - ${a})(x - ${a})`, `(x + ${a})(x + ${a})`, `(x - ${a * a})(x + 1)`], `x² − ${a}² = ${ans}.`, `x² − ${a}² = ${ans}.`);
    },
  },
  {
    stage: 17,
    titleAr: 'تحليل ثلاثي الحدود التربيعي',
    titleEn: 'Factoring Quadratic Trinomials',
    summaryAr: 'نبحث عن عددين مجموعهما b وحاصل ضربهما c.',
    summaryEn: 'Find p and q such that p + q = b and p × q = c.',
    ruleTitleAr: 'المجموع والضرب',
    ruleTitleEn: 'Sum-Product Rule',
    ruleFormula: 'x² + (p+q)x + pq = (x+p)(x+q)',
    examples: [
      { problemAr: 'حلّل: x² + 7x + 12', problemEn: 'Factor: x² + 7x + 12', solutionAr: '(x + 3)(x + 4)', solutionEn: '(x + 3)(x + 4)', answer: '(x + 3)(x + 4)' },
      { problemAr: 'حلّل: x² + 8x + 15', problemEn: 'Factor: x² + 8x + 15', solutionAr: '(x + 3)(x + 5)', solutionEn: '(x + 3)(x + 5)', answer: '(x + 3)(x + 5)' },
    ],
    generate: (qIdx, isExam) => {
      const p = 1 + (qIdx % 5);
      const q = p + 1 + ((qIdx + (isExam ? 1 : 0)) % 4);
      const ans = `(x + ${p})(x + ${q})`;
      return algQ(17, qIdx, isExam, `حلّل: x² + ${p + q}x + ${p * q}`, `Factor: x² + ${p + q}x + ${p * q}`, ans, [`(x + ${p + 1})(x + ${q})`, `(x + 1)(x + ${p * q})`, `(x - ${p})(x - ${q})`], `${p} + ${q} = ${p + q} و ${p}×${q} = ${p * q} ← ${ans}.`, `${p}+${q}=${p + q} and ${p}×${q}=${p * q}: ${ans}.`);
    },
  },
  {
    stage: 18,
    titleAr: 'المتتابعة الحسابية: الحد النوني',
    titleEn: 'Arithmetic Sequence: nth Term',
    summaryAr: 'نحسب أي حد في المتتابعة الحسابية بالصيغة العامة.',
    summaryEn: 'Compute the nth term directly via a₁ + (n − 1)d.',
    ruleTitleAr: 'الحد النوني',
    ruleTitleEn: 'nth Term Formula',
    ruleFormula: 'aₙ = a₁ + (n − 1)d',
    examples: [
      { problemAr: 'الحد 10 في: 3, 7, 11...', problemEn: '10th term of 3, 7, 11...', solutionAr: '3 + 36 = 39', solutionEn: '39', answer: '39' },
      { problemAr: 'الحد 7 في: 5, 8, 11...', problemEn: '7th term of 5, 8, 11...', solutionAr: '5 + 18 = 23', solutionEn: '23', answer: '23' },
    ],
    generate: (qIdx, isExam) => {
      const a1 = 2 + (qIdx % 6);
      const d = 2 + ((qIdx + (isExam ? 1 : 0)) % 5);
      const n = 6 + (qIdx % 6);
      const ans = a1 + (n - 1) * d;
      return algQ(18, qIdx, isExam, `متتابعة حسابية حدها الأول ${a1} وأساسها ${d}، ما الحد رقم ${n}؟`, `Arithmetic sequence with a₁=${a1}, d=${d}. Find term ${n}:`, String(ans), numericDistractors(ans, [d, -d, 1, -1]), `${a1} + (${n}−1)×${d} = ${ans}.`, `${a1} + (${n}−1)×${d} = ${ans}.`);
    },
  },
  {
    stage: 19,
    titleAr: 'الدوال الخطية وحساب f(x)',
    titleEn: 'Linear Functions f(x)',
    summaryAr: 'نعوض قيمة المدخلة x في قاعدة الدالة للحصول على المخرجة f(x).',
    summaryEn: 'Plug input x into f(x) = mx − b to get the output.',
    ruleTitleAr: 'قاعدة الدالة',
    ruleTitleEn: 'Function Evaluation',
    ruleFormula: 'f(x) = mx − b',
    examples: [
      { problemAr: 'f(x) = 4x − 3، أوجد f(5)', problemEn: 'f(x)=4x−3, find f(5)', solutionAr: '17', solutionEn: '17', answer: '17' },
      { problemAr: 'f(x) = 3x − 2، أوجد f(4)', problemEn: 'f(x)=3x−2, find f(4)', solutionAr: '10', solutionEn: '10', answer: '10' },
    ],
    generate: (qIdx, isExam) => {
      const m = 2 + (qIdx % 5);
      const b = 1 + ((qIdx * 2 + (isExam ? 1 : 0)) % 7);
      const x = 3 + qIdx;
      const ans = m * x - b;
      return algQ(19, qIdx, isExam, `إذا كان f(x) = ${m}x − ${b}، أوجد f(${x}):`, `Given f(x) = ${m}x − ${b}, find f(${x}):`, String(ans), numericDistractors(ans, [b * 2, m, -m, 2]), `f(${x}) = ${m}(${x}) − ${b} = ${ans}.`, `f(${x}) = ${ans}.`);
    },
  },
  {
    stage: 20,
    titleAr: 'النمذجة الجبرية للمسائل الكلامية',
    titleEn: 'Algebraic Word Problem Modeling',
    summaryAr: 'نحوّل المعطيات اللفظية إلى معادلة جبرية ونحلها بدقة.',
    summaryEn: 'Convert word statements into a linear equation and solve.',
    ruleTitleAr: 'صياغة المعادلة',
    ruleTitleEn: 'Equation Formulation',
    ruleFormula: 'x + (x + d) = S',
    examples: [
      { problemAr: 'عددان مجموعهما 30 والفرق 6، الأصغر؟', problemEn: 'Sum 30, diff 6. Smaller?', solutionAr: '12', solutionEn: '12', answer: '12' },
      { problemAr: 'عددان مجموعهما 24 والفرق 4، الأصغر؟', problemEn: 'Sum 24, diff 4. Smaller?', solutionAr: '10', solutionEn: '10', answer: '10' },
    ],
    generate: (qIdx, isExam) => {
      const small = 7 + qIdx * 2 + (isExam ? 1 : 0);
      const diff = 4 + ((qIdx * 2) % 8);
      const sum = small * 2 + diff;
      return algQ(20, qIdx, isExam, `عددان مجموعهما ${sum} والفرق بينهما ${diff}، ما العدد الأصغر؟`, `Two numbers sum to ${sum} with difference ${diff}. Smaller number?`, String(small), numericDistractors(small, [diff, 1, -1, 2]), `2x + ${diff} = ${sum} ← x = ${small}.`, `2x + ${diff} = ${sum} → x = ${small}.`);
    },
  },
  // --- HARD (21 - 30) ---
  {
    stage: 21,
    titleAr: 'حل نظام معادلتين خطيتين',
    titleEn: 'Linear Systems by Elimination',
    summaryAr: 'نجمع المعادلتين لحذف y وإيجاد x مباشرة.',
    summaryEn: 'Add equations to eliminate y and solve directly for x.',
    ruleTitleAr: 'الحذف بالجمع',
    ruleTitleEn: 'Elimination',
    ruleFormula: '(x+y) + (x−y) = 2x',
    examples: [
      { problemAr: 'x+y=14، x−y=4', problemEn: 'x+y=14, x-y=4', solutionAr: '2x=18 ← x=9', solutionEn: '9', answer: '9' },
      { problemAr: 'x+y=20، x−y=6', problemEn: 'x+y=20, x-y=6', solutionAr: 'x=13', solutionEn: '13', answer: '13' },
    ],
    generate: (qIdx, isExam) => {
      const x = 4 + qIdx + (isExam ? 2 : 0);
      const y = 2 + ((qIdx * 2) % 7);
      return algQ(21, qIdx, isExam, `إذا كان x + y = ${x + y} و x − y = ${x - y}، فما قيمة x؟`, `If x + y = ${x + y} and x − y = ${x - y}, find x:`, String(x), numericDistractors(x, [2, 1, -1, -2]), `بجمع المعادلتين: 2x = ${2 * x} ← x = ${x}.`, `2x = ${2 * x}, so x = ${x}.`);
    },
  },
  {
    stage: 22,
    titleAr: 'المعادلات التربيعية بالتحليل',
    titleEn: 'Solving Quadratics by Factoring',
    summaryAr: 'نحلل المعادلة التربيعية إلى عاملين ونوجد الجذور عبر خاصية الصفر.',
    summaryEn: 'Factor into (x − r₁)(x − r₂) = 0 to identify the roots.',
    ruleTitleAr: 'الضرب الصفري',
    ruleTitleEn: 'Zero Product',
    ruleFormula: '(x − r₁)(x − r₂) = 0',
    examples: [
      { problemAr: 'الجذر الأكبر لـ x²−9x+14=0', problemEn: 'Larger root of x²−9x+14=0', solutionAr: '7', solutionEn: '7', answer: '7' },
      { problemAr: 'الجذر الأكبر لـ x²−7x+10=0', problemEn: 'Larger root of x²−7x+10=0', solutionAr: '5', solutionEn: '5', answer: '5' },
    ],
    generate: (qIdx, isExam) => {
      const r1 = 1 + (qIdx % 5);
      const r2 = r1 + 2 + ((qIdx + (isExam ? 1 : 0)) % 4);
      return algQ(22, qIdx, isExam, `ما الجذر الأكبر للمعادلة: x² − ${r1 + r2}x + ${r1 * r2} = 0؟`, `Larger root of x² − ${r1 + r2}x + ${r1 * r2} = 0?`, String(r2), numericDistractors(r2, [r1 - r2, 1, -1, 2]), `(x−${r1})(x−${r2})=0 ← الأكبر ${r2}.`, `Roots are ${r1} and ${r2}; larger is ${r2}.`);
    },
  },
  {
    stage: 23,
    titleAr: 'المتطابقة (a + b)² وتطبيقاتها',
    titleEn: 'Square of a Sum Identity',
    summaryAr: 'نحسب x² + y² من (x+y)² − 2xy دون معرفة x و y منفردين.',
    summaryEn: 'Compute x² + y² directly from (x + y)² − 2xy.',
    ruleTitleAr: 'متطابقة المربع الكامل',
    ruleTitleEn: 'Sum-of-Squares Identity',
    ruleFormula: 'x² + y² = (x + y)² − 2xy',
    examples: [
      { problemAr: 'x+y=7، xy=10 ← x²+y²', problemEn: 'x+y=7, xy=10 → x²+y²', solutionAr: '49 − 20 = 29', solutionEn: '29', answer: '29' },
      { problemAr: 'x+y=6، xy=8 ← x²+y²', problemEn: 'x+y=6, xy=8 → x²+y²', solutionAr: '36 − 16 = 20', solutionEn: '20', answer: '20' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const pairs: [number, number][] = [
        [2, 3], [2, 4], [2, 5], [3, 4], [3, 5],
        [3, 6], [4, 5], [4, 6], [4, 7], [5, 6], [5, 7],
      ];
      const [x, y] = pairs[idx];
      const s = x + y;
      const p = x * y;
      const ans = x * x + y * y;
      return algQ(23, qIdx, isExam, `إذا كان x + y = ${s} و xy = ${p}، أوجد x² + y²:`, `If x + y = ${s} and xy = ${p}, find x² + y²:`, String(ans), numericDistractors(ans, [p, -p, 2, 4]), `${s}² − 2(${p}) = ${ans}.`, `${s}² − 2(${p}) = ${ans}.`);
    },
  },
  {
    stage: 24,
    titleAr: 'المعادلات الكسرية البسيطة',
    titleEn: 'Rational Equations',
    summaryAr: 'نستخدم الضرب التبادلي لإزالة المقام وحل المعادلة الخطية الناتجة.',
    summaryEn: 'Cross-multiply to clear denominators and solve for x.',
    ruleTitleAr: 'الضرب التبادلي',
    ruleTitleEn: 'Clear Denominator',
    ruleFormula: 'N / (x + b) = k ⟹ x + b = N / k',
    examples: [
      { problemAr: '12 / (x + 1) = 3', problemEn: '12 / (x + 1) = 3', solutionAr: 'x = 3', solutionEn: '3', answer: '3' },
      { problemAr: '20 / (x + 2) = 4', problemEn: '20 / (x + 2) = 4', solutionAr: 'x = 3', solutionEn: '3', answer: '3' },
    ],
    generate: (qIdx, isExam) => {
      const k = 2 + (qIdx % 5);
      const x = 2 + ((qIdx + (isExam ? 1 : 0)) % 8);
      const b = 1 + (qIdx % 4);
      const num = k * (x + b);
      return algQ(24, qIdx, isExam, `حل المعادلة: ${num} ÷ (x + ${b}) = ${k}`, `Solve: ${num} / (x + ${b}) = ${k}`, String(x), numericDistractors(x, [b, 1, -1, 2]), `x + ${b} = ${x + b} ← x = ${x}.`, `x + ${b} = ${x + b} → x = ${x}.`);
    },
  },
  {
    stage: 25,
    titleAr: 'المتتابعات الهندسية',
    titleEn: 'Geometric Sequences',
    summaryAr: 'نضرب في النسبة الثابتة r للانتقال بين حدود المتتابعة الهندسية.',
    summaryEn: 'Multiply by the constant common ratio r to obtain each next term.',
    ruleTitleAr: 'الحد العام الهندسي',
    ruleTitleEn: 'Geometric Formula',
    ruleFormula: 'aₙ = a₁ · rⁿ⁻¹',
    examples: [
      { problemAr: 'الحد 5 في 2, 6, 18...', problemEn: '5th term of 2, 6, 18...', solutionAr: '162', solutionEn: '162', answer: '162' },
      { problemAr: 'الحد 4 في 5, 10, 20...', problemEn: '4th term of 5, 10, 20...', solutionAr: '40', solutionEn: '40', answer: '40' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const a1 = 2 + idx;
      const r = 2 + (idx % 2);
      const n = 4 + (idx % 2);
      const ans = a1 * Math.pow(r, n - 1);
      return algQ(25, qIdx, isExam, `أوجد الحد رقم ${n} في المتتابعة الهندسية: ${a1}، ${a1 * r}، ${a1 * r * r}، ...`, `Find term ${n} of geometric sequence: ${a1}, ${a1 * r}, ${a1 * r * r}, ...`, String(ans), numericDistractors(ans, [r, -r, a1 * r, 4]), `r = ${r}، إذن الحد = ${a1}×${r}^${n - 1} = ${ans}.`, `r = ${r}, term = ${ans}.`);
    },
  },
  {
    stage: 26,
    titleAr: 'معادلات القيمة المطلقة',
    titleEn: 'Absolute Value Equations',
    summaryAr: 'المعادلة |x − a| = b تعطي حلين متناظرين حول a.',
    summaryEn: '|x − a| = b yields two symmetric roots: a + b and a − b.',
    ruleTitleAr: 'حلا القيمة المطلقة',
    ruleTitleEn: 'Symmetric Roots',
    ruleFormula: '|x − a| = b ⟹ x = a ± b',
    examples: [
      { problemAr: 'أكبر حل لـ |x − 5| = 3', problemEn: 'Largest root of |x − 5| = 3', solutionAr: '8', solutionEn: '8', answer: '8' },
      { problemAr: 'أكبر حل لـ |x − 2| = 7', problemEn: 'Largest root of |x − 2| = 7', solutionAr: '9', solutionEn: '9', answer: '9' },
    ],
    generate: (qIdx, isExam) => {
      const a = 3 + qIdx;
      const b = 2 + ((qIdx + (isExam ? 1 : 0)) % 6);
      const ans = a + b;
      return algQ(26, qIdx, isExam, `ما أكبر حل للمعادلة |x − ${a}| = ${b}؟`, `Largest solution of |x − ${a}| = ${b}?`, String(ans), numericDistractors(ans, [-b, 1, -1, 2]), `الحلان ${a + b} و ${a - b}، والأكبر ${ans}.`, `Solutions are ${a + b} and ${a - b}; largest is ${ans}.`);
    },
  },
  {
    stage: 27,
    titleAr: 'المعادلات الأسية البسيطة',
    titleEn: 'Exponential Equations',
    summaryAr: 'عندما يتساوى الأساسان نساوي الأسين لحل المعادلة.',
    summaryEn: 'Equal bases imply equal exponents.',
    ruleTitleAr: 'مساواة الأسس',
    ruleTitleEn: 'Equal-Base Rule',
    ruleFormula: 'b^(x+s) = b^k ⟹ x + s = k',
    examples: [
      { problemAr: '3^(x+1) = 27', problemEn: '3^(x+1) = 27', solutionAr: 'x = 2', solutionEn: '2', answer: '2' },
      { problemAr: '2^(x+2) = 32', problemEn: '2^(x+2) = 32', solutionAr: 'x = 3', solutionEn: '3', answer: '3' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const cases: [number, number, number][] = [
        [2, 3, 1], [3, 3, 1], [4, 2, 1], [2, 4, 2], [3, 4, 2],
        [4, 3, 2], [2, 5, 3], [3, 3, 2], [4, 3, 1], [2, 6, 2], [5, 3, 1],
      ];
      const [base, exp, shift] = cases[idx];
      const x = exp - shift;
      const rhs = Math.pow(base, exp);
      return algQ(27, qIdx, isExam, `حل المعادلة الأسية: ${base}^(x + ${shift}) = ${rhs}`, `Solve: ${base}^(x + ${shift}) = ${rhs}`, String(x), numericDistractors(x, [1, -1, 2, -2], true), `${rhs} = ${base}^${exp} ← x + ${shift} = ${exp} ← x = ${x}.`, `x = ${x}.`);
    },
  },
  {
    stage: 28,
    titleAr: 'تركيب الدوال الجبرية',
    titleEn: 'Function Composition',
    summaryAr: 'نحسب الدالة الداخلية g(x) أولاً ثم نعوض ناتجها في f.',
    summaryEn: 'Evaluate g(x) first and plug the result into f.',
    ruleTitleAr: 'تركيب دالتين',
    ruleTitleEn: 'Composite Output',
    ruleFormula: '(f ∘ g)(x) = f(g(x))',
    examples: [
      { problemAr: 'f(x)=2x+1، g(x)=x+3، أوجد f(g(2))', problemEn: 'f(x)=2x+1, g(x)=x+3, f(g(2))', solutionAr: 'f(5) = 11', solutionEn: '11', answer: '11' },
      { problemAr: 'f(x)=3x، g(x)=x+2، أوجد f(g(4))', problemEn: 'f(x)=3x, g(x)=x+2, f(g(4))', solutionAr: 'f(6) = 18', solutionEn: '18', answer: '18' },
    ],
    generate: (qIdx, isExam) => {
      const x = 1 + ((qIdx + (isExam ? 1 : 0)) % 6);
      const addG = 2 + (qIdx % 4);
      const multF = 2 + (qIdx % 3);
      const addF = 1 + (qIdx % 5);
      const ans = multF * (x + addG) + addF;
      return algQ(28, qIdx, isExam, `إذا كان f(x) = ${multF}x + ${addF} و g(x) = x + ${addG}، أوجد f(g(${x})):`, `If f(x) = ${multF}x + ${addF} and g(x) = x + ${addG}, find f(g(${x})):`, String(ans), numericDistractors(ans, [multF, -multF, 2, -2]), `g(${x}) = ${x + addG}، ثم f(${x + addG}) = ${ans}.`, `g(${x}) = ${x + addG}, so f(${x + addG}) = ${ans}.`);
    },
  },
  {
    stage: 29,
    titleAr: 'المتباينات المركبة',
    titleEn: 'Compound Inequalities',
    summaryAr: 'نعزل x في الوسط بإجراء العملية العكسية على الأطراف الثلاثة.',
    summaryEn: 'Apply inverse operations to all three parts of the compound inequality.',
    ruleTitleAr: 'المدى الصحيح',
    ruleTitleEn: 'Integer Range',
    ruleFormula: 'a ≤ x + s < b ⟹ a−s ≤ x < b−s',
    examples: [
      { problemAr: 'كم عدداً صحيحاً يحقق 4 ≤ x+2 < 8؟', problemEn: 'Integers in 4 ≤ x+2 < 8?', solutionAr: '2 ≤ x < 6 ← {2,3,4,5} (4)', solutionEn: '4', answer: '4' },
      { problemAr: 'كم عدداً صحيحاً يحقق 1 ≤ x < 4؟', problemEn: 'Integers in 1 ≤ x < 4?', solutionAr: '3', solutionEn: '3', answer: '3' },
    ],
    generate: (qIdx, isExam) => {
      const low = 2 + (qIdx % 5);
      const count = 3 + ((qIdx + (isExam ? 1 : 0)) % 5);
      const shift = 2 + (qIdx % 4);
      return algQ(29, qIdx, isExam, `كم عدداً صحيحاً يحقق: ${low + shift} ≤ x + ${shift} < ${low + count + shift}؟`, `How many integers satisfy ${low + shift} ≤ x + ${shift} < ${low + count + shift}?`, String(count), numericDistractors(count, [1, -1, 2, 3]), `${low} ≤ x < ${low + count}، وعددها ${count}.`, `${low} ≤ x < ${low + count} gives ${count} integers.`);
    },
  },
  {
    stage: 30,
    titleAr: 'التحدي الجبري الشامل',
    titleEn: 'Master Algebra Challenge',
    summaryAr: 'مسائل مركبة تدمج متطابقة فرق المربعين مع أنظمة المعادلات.',
    summaryEn: 'Combine difference of squares with linear relations to solve rapidly.',
    ruleTitleAr: 'التكامل الجبري',
    ruleTitleEn: 'Algebraic Synthesis',
    ruleFormula: 'x² − y² = (x − y)(x + y)',
    examples: [
      { problemAr: 'x−y=4 و x²−y²=32، أوجد x+y', problemEn: 'x−y=4, x²−y²=32, find x+y', solutionAr: '32 ÷ 4 = 8', solutionEn: '8', answer: '8' },
      { problemAr: 'x−y=3 و x²−y²=27، أوجد x+y', problemEn: 'x−y=3, x²−y²=27, find x+y', solutionAr: '9', solutionEn: '9', answer: '9' },
    ],
    generate: (qIdx, isExam) => {
      const diff = 2 + ((qIdx + (isExam ? 1 : 0)) % 6);
      const sum = 5 + qIdx * 2;
      const sqDiff = diff * sum;
      return algQ(30, qIdx, isExam, `إذا كان x − y = ${diff} و x² − y² = ${sqDiff}، ما قيمة x + y؟`, `If x − y = ${diff} and x² − y² = ${sqDiff}, find x + y:`, String(sum), numericDistractors(sum, [diff, 2, -2, 4]), `x + y = ${sqDiff} ÷ ${diff} = ${sum}.`, `x + y = ${sqDiff} / ${diff} = ${sum}.`);
    },
  },
];

export const ALGEBRA_STAGES: StageDefinition[] = TOPICS.map((spec) => {
  const questions: QuizQuestion[] = [];
  for (let i = 0; i < 10; i++) {
    questions.push(spec.generate(i, false));
  }
  return {
    id: makeStageId('algebra', spec.stage),
    sectionId: 'algebra',
    stageNumber: spec.stage,
    difficulty: getDifficultyForStage(spec.stage),
    titleAr: spec.titleAr,
    titleEn: spec.titleEn,
    lesson: {
      summaryAr: spec.summaryAr,
      summaryEn: spec.summaryEn,
      ruleTitleAr: spec.ruleTitleAr,
      ruleTitleEn: spec.ruleTitleEn,
      ruleFormula: spec.ruleFormula,
      examples: spec.examples,
    },
    questions,
    examQuestion: spec.generate(10, true),
  };
});
