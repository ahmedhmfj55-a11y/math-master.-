import {
  buildChoiceQuestion,
  createSeededRng,
  gcd,
  getDifficultyForStage,
  hashString,
  lcm,
  makeStageId,
  numericDistractors,
  randInt,
} from '@/src/data/curriculum/helpers';
import type { QuizQuestion, StageDefinition, WorkedExample } from '@/src/types/curriculum';

interface ArithmeticTopicSpec {
  stage: number;
  titleAr: string;
  titleEn: string;
  summaryAr: string;
  summaryEn: string;
  ruleTitleAr: string;
  ruleTitleEn: string;
  ruleFormula: string;
  generate: (qIdx: number, isExam: boolean) => QuizQuestion;
  examples: [WorkedExample, WorkedExample];
}

function makeQ(
  stage: number,
  qIdx: number,
  isExam: boolean,
  promptAr: string,
  promptEn: string,
  correct: number,
  offsets: number[],
  explanationAr: string,
  explanationEn: string,
  allowNegative = false,
): QuizQuestion {
  const id = isExam ? `arithmetic-exam-s${stage}` : `arithmetic-s${stage}-q${qIdx + 1}`;
  return buildChoiceQuestion({
    id,
    promptAr,
    promptEn,
    correctValue: String(correct),
    distractors: numericDistractors(correct, offsets, allowNegative),
    explanationAr,
    explanationEn,
    seedKey: `${id}-${promptEn}`,
  });
}

const TOPICS: ArithmeticTopicSpec[] = [
  {
    stage: 1,
    titleAr: 'الجمع البسيط ضمن 20',
    titleEn: 'Simple Addition Within 20',
    summaryAr: 'نتعلم جمع عددين صغيرين بإكمال العدد إلى 10 أو بالعد التصاعدي للحصول على المجموع بسرعة.',
    summaryEn: 'Learn to add two small numbers by making ten or counting up accurately.',
    ruleTitleAr: 'قاعدة الجمع الأساسي',
    ruleTitleEn: 'Basic Addition Rule',
    ruleFormula: 'a + b = b + a',
    examples: [
      { problemAr: 'احسب: 7 + 5', problemEn: 'Calculate: 7 + 5', solutionAr: 'نكمل 7 إلى 10 بإضافة 3، ثم نضيف 2 المتبقية: 10 + 2 = 12', solutionEn: 'Make 10 with 7 + 3 = 10, then add remaining 2: 10 + 2 = 12', answer: '12' },
      { problemAr: 'احسب: 8 + 9', problemEn: 'Calculate: 8 + 9', solutionAr: '8 + 9 = 8 + (10 - 1) = 17', solutionEn: '8 + 9 = 8 + 10 - 1 = 17', answer: '17' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const pairs: [number, number][] = [
        [2, 5], [3, 6], [4, 7], [5, 8], [6, 7], [7, 8], [8, 9], [9, 6], [4, 9], [3, 8], [7, 9],
      ];
      const [a, b] = pairs[idx];
      const ans = a + b;
      return makeQ(1, qIdx, isExam, `ما ناتج الجمع: ${a} + ${b}؟`, `What is ${a} + ${b}?`, ans, [1, -1, 2, -2, 10], `نجمع ${a} مع ${b} فنحصل على ${ans}.`, `Adding ${a} and ${b} equals ${ans}.`);
    },
  },
  {
    stage: 2,
    titleAr: 'الطرح البسيط ضمن 20',
    titleEn: 'Simple Subtraction Within 20',
    summaryAr: 'الطرح هو إيجاد الفرق بين عددين أو ما يتبقى بعد إنقاص كمية من أخرى.',
    summaryEn: 'Subtraction finds the difference between two numbers or what remains after taking away.',
    ruleTitleAr: 'علاقة الطرح بالجمع',
    ruleTitleEn: 'Subtraction as Inverse of Addition',
    ruleFormula: 'a - b = c  ⟺  b + c = a',
    examples: [
      { problemAr: 'احسب: 15 - 6', problemEn: 'Calculate: 15 - 6', solutionAr: 'ننقص 5 لنصل إلى 10 ثم ننقص 1: 10 - 1 = 9', solutionEn: 'Subtract 5 to reach 10, then subtract 1: 10 - 1 = 9', answer: '9' },
      { problemAr: 'احسب: 18 - 9', problemEn: 'Calculate: 18 - 9', solutionAr: 'لأن 9 + 9 = 18 فإن 18 - 9 = 9', solutionEn: 'Since 9 + 9 = 18, 18 - 9 = 9', answer: '9' },
    ],
    generate: (qIdx, isExam) => {
      const b = 2 + ((qIdx * 2 + (isExam ? 1 : 0)) % 8);
      const ans = 3 + ((qIdx * 3 + (isExam ? 2 : 0)) % 10);
      const a = b + ans;
      return makeQ(2, qIdx, isExam, `ما ناتج الطرح: ${a} - ${b}؟`, `What is ${a} - ${b}?`, ans, [1, -1, 2, -2, 3], `الفرق بين ${a} و ${b} يساوي ${ans} لأن ${b} + ${ans} = ${a}.`, `${a} minus ${b} equals ${ans} because ${b} + ${ans} = ${a}.`);
    },
  },
  {
    stage: 3,
    titleAr: 'الجمع من منزلتين دون حمل',
    titleEn: 'Two-Digit Addition Without Regrouping',
    summaryAr: 'نجمع الآحاد مع الآحاد والعشرات مع العشرات بشكل مستقل عندما لا يتجاوز المجموع 9 في كل منزلة.',
    summaryEn: 'Add ones with ones and tens with tens separately when no place value exceeds 9.',
    ruleTitleAr: 'جمع المنازل',
    ruleTitleEn: 'Place-Value Addition',
    ruleFormula: '(10a + b) + (10c + d) = 10(a+c) + (b+d)',
    examples: [
      { problemAr: 'احسب: 34 + 25', problemEn: 'Calculate: 34 + 25', solutionAr: 'الآحاد: 4 + 5 = 9، العشرات: 3 + 2 = 5، الناتج 59', solutionEn: 'Ones: 4 + 5 = 9, Tens: 3 + 2 = 5, Total = 59', answer: '59' },
      { problemAr: 'احسب: 41 + 57', problemEn: 'Calculate: 41 + 57', solutionAr: 'الآحاد: 1 + 7 = 8، العشرات: 4 + 5 = 9، الناتج 98', solutionEn: 'Ones: 1 + 7 = 8, Tens: 4 + 5 = 9, Total = 98', answer: '98' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const pairs: [number, number][] = [
        [12, 23], [24, 31], [32, 45], [41, 18], [53, 24],
        [62, 35], [14, 72], [25, 63], [36, 51], [44, 52], [21, 67],
      ];
      const [a, b] = pairs[idx];
      const o1 = a % 10;
      const o2 = b % 10;
      const t1 = Math.floor(a / 10);
      const t2 = Math.floor(b / 10);
      const ans = a + b;
      return makeQ(3, qIdx, isExam, `احسب مجموع العددين: ${a} + ${b}`, `Find the sum: ${a} + ${b}`, ans, [10, -10, 1, -1, 11], `نجمع الآحاد (${o1}+${o2}=${o1 + o2}) والعشرات (${t1}+${t2}=${t1 + t2}) لنحصل على ${ans}.`, `Add ones (${o1}+${o2}=${o1 + o2}) and tens (${t1}+${t2}=${t1 + t2}) to get ${ans}.`);
    },
  },
  {
    stage: 4,
    titleAr: 'الجمع مع إعادة التجميع (الحمل)',
    titleEn: 'Addition with Regrouping (Carrying)',
    summaryAr: 'عندما يساوي مجموع الآحاد 10 أو أكثر، نكتب رقم الآحاد ونحمل 1 إلى منزلة العشرات.',
    summaryEn: 'When the ones sum to 10 or more, keep the ones digit and carry 1 ten to the tens place.',
    ruleTitleAr: 'إعادة التجميع',
    ruleTitleEn: 'Regrouping Rule',
    ruleFormula: '10 ones = 1 ten',
    examples: [
      { problemAr: 'احسب: 48 + 27', problemEn: 'Calculate: 48 + 27', solutionAr: '8 + 7 = 15 (نكتب 5 ونحمل 1)، ثم 1 + 4 + 2 = 7، الناتج 75', solutionEn: '8 + 7 = 15 (write 5, carry 1), then 1 + 4 + 2 = 7 → 75', answer: '75' },
      { problemAr: 'احسب: 65 + 39', problemEn: 'Calculate: 65 + 39', solutionAr: '5 + 9 = 14 (نكتب 4 ونحمل 1)، ثم 1 + 6 + 3 = 10 → 104', solutionEn: '5 + 9 = 14 (write 4, carry 1), then 1 + 6 + 3 = 10 → 104', answer: '104' },
    ],
    generate: (qIdx, isExam) => {
      const a = 26 + qIdx * 6 + (isExam ? 3 : 0);
      const b = 17 + ((qIdx * 7) % 30) + (isExam ? 2 : 0);
      const ans = a + b;
      return makeQ(4, qIdx, isExam, `أوجد ناتج الجمع: ${a} + ${b}`, `Calculate: ${a} + ${b}`, ans, [10, -10, 1, -1, 2], `بجمع الآحاد وحمل العشرة الإضافية نحصل على ${ans}.`, `Adding ones with regrouping into tens yields ${ans}.`);
    },
  },
  {
    stage: 5,
    titleAr: 'الطرح مع الاستلاف',
    titleEn: 'Subtraction with Borrowing',
    summaryAr: 'إذا كان رقم الآحاد المطروح منه أصغر من المطروح، نستلف 1 من منزلة العشرات (يساوي 10 آحاد).',
    summaryEn: 'If the top ones digit is smaller, borrow 1 ten (worth 10 ones) from the tens column.',
    ruleTitleAr: 'قاعدة الاستلاف',
    ruleTitleEn: 'Borrowing Rule',
    ruleFormula: '1 ten → 10 ones',
    examples: [
      { problemAr: 'احسب: 52 - 17', problemEn: 'Calculate: 52 - 17', solutionAr: 'نستلف 10 من 5 فتصبح الآحاد 12 والعشرات 4: 12 - 7 = 5، 4 - 1 = 3 → 35', solutionEn: 'Borrow 1 ten: 12 - 7 = 5 and 4 - 1 = 3 → 35', answer: '35' },
      { problemAr: 'احسب: 80 - 26', problemEn: 'Calculate: 80 - 26', solutionAr: '10 - 6 = 4 و 7 - 2 = 5، الناتج 54', solutionEn: '10 - 6 = 4 and 7 - 2 = 5 → 54', answer: '54' },
    ],
    generate: (qIdx, isExam) => {
      const t1 = 5 + (qIdx % 4);
      const o1 = (qIdx + (isExam ? 1 : 0)) % 4;
      const a = t1 * 10 + o1;
      const t2 = 1 + (qIdx % 3);
      const o2 = 5 + ((qIdx * 2 + (isExam ? 1 : 0)) % 5);
      const b = t2 * 10 + o2;
      const ans = a - b;
      return makeQ(5, qIdx, isExam, `ما ناتج الطرح: ${a} - ${b}؟`, `What is ${a} - ${b}?`, ans, [10, -10, 1, -1, 9], `بعد الاستلاف من منزلة العشرات: ${a} - ${b} = ${ans}.`, `After borrowing 1 ten: ${a} - ${b} = ${ans}.`);
    },
  },
  {
    stage: 6,
    titleAr: 'جدول الضرب للأعداد 2 و 3 و 4',
    titleEn: 'Multiplication Tables: 2, 3, and 4',
    summaryAr: 'الضرب هو جمع متكرر؛ معرفة الجداول الأساسية توفر الوقت في كل العمليات المتقدمة.',
    summaryEn: 'Multiplication is repeated addition; mastering base tables speeds up every calculation.',
    ruleTitleAr: 'مفهوم الضرب',
    ruleTitleEn: 'Repeated Addition',
    ruleFormula: 'a × n = a + a + ... (n times)',
    examples: [
      { problemAr: 'احسب: 3 × 7', problemEn: 'Calculate: 3 × 7', solutionAr: '3 × 7 = 7 + 7 + 7 = 21', solutionEn: '3 × 7 = 7 + 7 + 7 = 21', answer: '21' },
      { problemAr: 'احسب: 4 × 8', problemEn: 'Calculate: 4 × 8', solutionAr: 'مضاعفة 8 مرتين: 16 ثم 32', solutionEn: 'Double 8 twice: 16, then 32', answer: '32' },
    ],
    generate: (qIdx, isExam) => {
      const factors = [2, 3, 4];
      const a = factors[(qIdx + (isExam ? 1 : 0)) % 3];
      const b = 3 + qIdx;
      const ans = a * b;
      return makeQ(6, qIdx, isExam, `أوجد ناتج الضرب: ${a} × ${b}`, `Compute: ${a} × ${b}`, ans, [a, -a, 2, -2, 4], `بتكرار جمع ${b} بمقدار ${a} مرات يكون الناتج ${ans}.`, `Multiplying ${a} by ${b} gives ${ans}.`);
    },
  },
  {
    stage: 7,
    titleAr: 'جدول الضرب للأعداد 5 و 6 و 7',
    titleEn: 'Multiplication Tables: 5, 6, and 7',
    summaryAr: 'مضاعفات 5 تنتهي دائماً بـ 0 أو 5، ويمكن حساب ضرب 6 و 7 بتجزئتهما إلى (5 + 1) أو (5 + 2).',
    summaryEn: 'Multiples of 5 end in 0 or 5; compute ×6 and ×7 by splitting into (5+1) or (5+2).',
    ruleTitleAr: 'التجزئة الذهنية للضرب',
    ruleTitleEn: 'Split Strategy',
    ruleFormula: '6 × n = 5n + n',
    examples: [
      { problemAr: 'احسب: 6 × 8', problemEn: 'Calculate: 6 × 8', solutionAr: '5 × 8 = 40 ثم نضيف 8: 40 + 8 = 48', solutionEn: '5 × 8 = 40, plus 8 = 48', answer: '48' },
      { problemAr: 'احسب: 7 × 9', problemEn: 'Calculate: 7 × 9', solutionAr: '7 × 9 = 63', solutionEn: '7 × 9 = 63', answer: '63' },
    ],
    generate: (qIdx, isExam) => {
      const a = [5, 6, 7][(qIdx + (isExam ? 2 : 0)) % 3];
      const b = 3 + ((qIdx + (isExam ? 1 : 0)) % 10);
      const ans = a * b;
      return makeQ(7, qIdx, isExam, `ما قيمة: ${a} × ${b}؟`, `What is ${a} × ${b}?`, ans, [a, -a, b, -b, 5], `حاصل ضرب ${a} × ${b} يساوي ${ans}.`, `${a} times ${b} equals ${ans}.`);
    },
  },
  {
    stage: 8,
    titleAr: 'جدول الضرب للأعداد 8 و 9 و 10',
    titleEn: 'Multiplication Tables: 8, 9, and 10',
    summaryAr: 'عند الضرب في 9 نضرب في 10 ثم نطرح العدد نفسه، وعند الضرب في 10 نضيف صفراً يمين العدد.',
    summaryEn: 'Multiply by 9 via (10n - n), and multiply by 10 by appending a zero.',
    ruleTitleAr: 'حيلة الضرب في 9',
    ruleTitleEn: 'Multiply by 9 Shortcut',
    ruleFormula: '9 × n = 10n - n',
    examples: [
      { problemAr: 'احسب: 9 × 7', problemEn: 'Calculate: 9 × 7', solutionAr: '10 × 7 - 7 = 70 - 7 = 63', solutionEn: '70 - 7 = 63', answer: '63' },
      { problemAr: 'احسب: 8 × 9', problemEn: 'Calculate: 8 × 9', solutionAr: '80 - 8 = 72', solutionEn: '80 - 8 = 72', answer: '72' },
    ],
    generate: (qIdx, isExam) => {
      const a = [8, 9, 10][(qIdx + (isExam ? 1 : 0)) % 3];
      const b = 2 + qIdx + (isExam ? 1 : 0);
      const ans = a * b;
      return makeQ(8, qIdx, isExam, `احسب ناتج: ${a} × ${b}`, `Calculate: ${a} × ${b}`, ans, [a, -a, 9, -9, 2], `${a} × ${b} = ${ans}.`, `${a} × ${b} = ${ans}.`);
    },
  },
  {
    stage: 9,
    titleAr: 'القسمة الأساسية بدون باقٍ',
    titleEn: 'Basic Exact Division',
    summaryAr: 'القسمة توزيع متساوٍ وهي العملية العكسية للضرب.',
    summaryEn: 'Division splits a quantity into equal groups and is the inverse of multiplication.',
    ruleTitleAr: 'الربط بالضرب',
    ruleTitleEn: 'Inverse Relationship',
    ruleFormula: 'a ÷ b = c  ⟺  b × c = a',
    examples: [
      { problemAr: 'احسب: 42 ÷ 6', problemEn: 'Calculate: 42 ÷ 6', solutionAr: 'لأن 6 × 7 = 42 فإن 42 ÷ 6 = 7', solutionEn: 'Since 6 × 7 = 42, 42 ÷ 6 = 7', answer: '7' },
      { problemAr: 'احسب: 56 ÷ 8', problemEn: 'Calculate: 56 ÷ 8', solutionAr: 'لأن 8 × 7 = 56 فإن 56 ÷ 8 = 7', solutionEn: 'Since 8 × 7 = 56, 56 ÷ 8 = 7', answer: '7' },
    ],
    generate: (qIdx, isExam) => {
      const b = 3 + ((qIdx + (isExam ? 2 : 0)) % 7);
      const ans = 4 + ((qIdx * 2 + (isExam ? 1 : 0)) % 9);
      const a = b * ans;
      return makeQ(9, qIdx, isExam, `ما ناتج القسمة: ${a} ÷ ${b}؟`, `What is ${a} ÷ ${b}?`, ans, [1, -1, 2, -2, 3], `لأن ${b} × ${ans} = ${a}، فإن ${a} ÷ ${b} = ${ans}.`, `Because ${b} × ${ans} = ${a}, ${a} ÷ ${b} = ${ans}.`);
    },
  },
  {
    stage: 10,
    titleAr: 'مقارنة الأعداد والقيمة المنزلية',
    titleEn: 'Place Value & Comparing Numbers',
    summaryAr: 'تتحدد قيمة الرقم حسب منزلته: آحاد، عشرات، مئات، آلاف.',
    summaryEn: 'Each digit has a value determined by its position: ones, tens, hundreds, thousands.',
    ruleTitleAr: 'الصيغة التحليلية',
    ruleTitleEn: 'Expanded Form',
    ruleFormula: 'abc = 100a + 10b + c',
    examples: [
      { problemAr: 'ما القيمة المنزلية للرقم 7 في العدد 4725؟', problemEn: 'What is the place value of 7 in 4725?', solutionAr: 'الرقم 7 في منزلة المئات، فقيمته 700', solutionEn: '7 is in the hundreds place, so its value is 700', answer: '700' },
      { problemAr: 'ما القيمة المنزلية للرقم 3 في العدد 3810؟', problemEn: 'What is the place value of 3 in 3810?', solutionAr: 'الرقم 3 في منزلة الآلاف، فقيمته 3000', solutionEn: '3 is in the thousands place, so its value is 3000', answer: '3000' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const digit = 2 + (idx % 7);
      const pos = idx % 3;
      const mult = pos === 0 ? 10 : pos === 1 ? 100 : 1000;
      const d1 = ((digit + 1) % 7) + 1;
      const d2 = ((digit + 2) % 7) + 1;
      const d3 = ((digit + 3) % 7) + 2 + (idx > 6 ? 1 : 0);
      const safeD3 = d3 === digit ? (d3 % 8) + 1 : d3;
      const num =
        pos === 2
          ? digit * 1000 + d1 * 100 + d2 * 10 + safeD3
          : pos === 1
            ? d1 * 1000 + digit * 100 + d2 * 10 + safeD3
            : d1 * 1000 + d2 * 100 + digit * 10 + safeD3 + (idx >= 8 ? 1000 : 0);
      const ans = digit * mult;
      return makeQ(10, qIdx, isExam, `ما القيمة المنزلية للرقم ${digit} في العدد ${num}؟`, `What is the place value of digit ${digit} in ${num}?`, ans, [digit, digit * 10, digit * 100, digit * 1000], `يقع الرقم ${digit} في منزلة قيمتها ${mult}، لذا قيمته ${ans}.`, `Digit ${digit} sits in the ${mult}s place, so its value is ${ans}.`);
    },
  },
  // --- MEDIUM STAGES (11 - 20) ---
  {
    stage: 11,
    titleAr: 'الجمع والطرح لمئات وآلاف',
    titleEn: 'Three-Digit Addition & Subtraction',
    summaryAr: 'تطبيق قواعد التجميع والاستلاف على أعداد من ثلاث وأربع منازل بدقة.',
    summaryEn: 'Apply carrying and borrowing reliably to 3-digit and 4-digit numbers.',
    ruleTitleAr: 'محاذاة المنازل',
    ruleTitleEn: 'Column Alignment',
    ruleFormula: '100s | 10s | 1s',
    examples: [
      { problemAr: 'احسب: 348 + 275', problemEn: 'Calculate: 348 + 275', solutionAr: '8+5=13، 1+4+7=12، 1+3+2=6 → 623', solutionEn: '8+5=13, 1+4+7=12, 1+3+2=6 → 623', answer: '623' },
      { problemAr: 'احسب: 512 - 168', problemEn: 'Calculate: 512 - 168', solutionAr: '12-8=4، 10-6=4، 4-1=3 → 344', solutionEn: '12-8=4, 10-6=4, 4-1=3 → 344', answer: '344' },
    ],
    generate: (qIdx, isExam) => {
      const a = 240 + qIdx * 37 + (isExam ? 15 : 0);
      const b = 135 + qIdx * 19 + (isExam ? 8 : 0);
      if (qIdx % 2 === 0) {
        const ans = a + b;
        return makeQ(11, qIdx, isExam, `احسب: ${a} + ${b}`, `Calculate: ${a} + ${b}`, ans, [10, -10, 100, -100, 1], `بجمع المنازل من اليمين إلى اليسار: ${a} + ${b} = ${ans}.`, `Adding column by column gives ${ans}.`);
      }
      const ans = a - b;
      return makeQ(11, qIdx, isExam, `احسب: ${a} - ${b}`, `Calculate: ${a} - ${b}`, ans, [10, -10, 100, -100, 2], `بطرح المنازل مع الاستلاف: ${a} - ${b} = ${ans}.`, `Subtracting column by column gives ${ans}.`);
    },
  },
  {
    stage: 12,
    titleAr: 'ضرب عدد من منزلتين في رقم واحد',
    titleEn: 'Multiplying 2-Digit by 1-Digit Numbers',
    summaryAr: 'نوزع الضرب على العشرات والآحاد ثم نجمع الناتجين.',
    summaryEn: 'Distribute the multiplier across tens and ones, then sum both partial products.',
    ruleTitleAr: 'خاصية التوزيع',
    ruleTitleEn: 'Distributive Multiplication',
    ruleFormula: '(10a + b) × c = 10ac + bc',
    examples: [
      { problemAr: 'احسب: 24 × 6', problemEn: 'Calculate: 24 × 6', solutionAr: '(20 × 6) + (4 × 6) = 120 + 24 = 144', solutionEn: '(20 × 6) + (4 × 6) = 120 + 24 = 144', answer: '144' },
      { problemAr: 'احسب: 37 × 4', problemEn: 'Calculate: 37 × 4', solutionAr: '(30 × 4) + (7 × 4) = 120 + 28 = 148', solutionEn: '120 + 28 = 148', answer: '148' },
    ],
    generate: (qIdx, isExam) => {
      const a = 14 + qIdx * 6 + (isExam ? 3 : 0);
      const b = 3 + ((qIdx + (isExam ? 2 : 0)) % 7);
      const ans = a * b;
      return makeQ(12, qIdx, isExam, `ما ناتج الضرب: ${a} × ${b}؟`, `What is ${a} × ${b}?`, ans, [10, -10, b, -b, 20], `باستخدام التوزيع: ${Math.floor(a / 10) * 10}×${b} + ${a % 10}×${b} = ${ans}.`, `Using distribution gives ${ans}.`);
    },
  },
  {
    stage: 13,
    titleAr: 'القسمة مع باقٍ',
    titleEn: 'Division with Remainder',
    summaryAr: 'عندما لا يقبل المقسوم القسمة تماماً يتبقى جزء أصغر من المقسوم عليه يُسمى الباقي.',
    summaryEn: 'When division is not exact, the leftover amount smaller than the divisor is the remainder.',
    ruleTitleAr: 'معادلة القسمة الإقليدية',
    ruleTitleEn: 'Division Algorithm',
    ruleFormula: 'Dividend = Divisor × Quotient + Remainder',
    examples: [
      { problemAr: 'ما باقي قسمة 29 ÷ 4؟', problemEn: 'What is the remainder of 29 ÷ 4?', solutionAr: '4 × 7 = 28، والباقي 29 - 28 = 1', solutionEn: '4 × 7 = 28, remainder = 29 - 28 = 1', answer: '1' },
      { problemAr: 'ما باقي قسمة 47 ÷ 5؟', problemEn: 'What is the remainder of 47 ÷ 5?', solutionAr: '5 × 9 = 45، والباقي 47 - 45 = 2', solutionEn: '5 × 9 = 45, remainder = 2', answer: '2' },
    ],
    generate: (qIdx, isExam) => {
      const d = 4 + ((qIdx + (isExam ? 1 : 0)) % 6);
      const q = 5 + qIdx;
      const r = 1 + ((qIdx * 2 + (isExam ? 1 : 0)) % (d - 1));
      const n = d * q + r;
      return makeQ(13, qIdx, isExam, `ما باقي قسمة ${n} على ${d}؟`, `What is the remainder when ${n} is divided by ${d}?`, r, [1, -1, 2, -2, d - r], `لأن ${d} × ${q} = ${d * q}، فإن الباقي هو ${n} - ${d * q} = ${r}.`, `Since ${d} × ${q} = ${d * q}, the remainder is ${n} - ${d * q} = ${r}.`);
    },
  },
  {
    stage: 14,
    titleAr: 'قابلية القسمة على 2 و 3 و 5 و 9',
    titleEn: 'Divisibility Rules (2, 3, 5, 9)',
    summaryAr: 'يقبل العدد القسمة على 3 أو 9 إذا كان مجموع أرقامه يقبل القسمة عليهما، وعلى 5 إذا انتهى بـ 0 أو 5.',
    summaryEn: 'A number is divisible by 3 or 9 if its digit sum is; by 5 if it ends in 0 or 5.',
    ruleTitleAr: 'اختبار مجموع الأرقام',
    ruleTitleEn: 'Digit-Sum Test',
    ruleFormula: '3 | n ⟺ 3 | sum(digits(n))',
    examples: [
      { problemAr: 'أي رقم يجعل 4_2 يقبل القسمة على 3؟', problemEn: 'Which digit makes 4_2 divisible by 3?', solutionAr: '4 + 2 = 6، إذا وضعنا 3 يصبح المجموع 9 ويقبل على 3', solutionEn: '4 + 2 = 6; putting 3 makes sum 9, divisible by 3', answer: '3' },
      { problemAr: 'ما باقي قسمة 274 على 9؟', problemEn: 'Remainder of 274 ÷ 9?', solutionAr: '2 + 7 + 4 = 13، و 13 ÷ 9 باقيه 4', solutionEn: '2 + 7 + 4 = 13, 13 mod 9 = 4', answer: '4' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const pairs: [number, number][] = [
        [1, 3], [2, 4], [3, 5], [4, 2], [5, 1], [6, 2], [7, 4], [8, 3], [2, 6], [5, 3], [4, 4],
      ];
      const [a, b] = pairs[idx];
      const ans = (9 - ((a + b) % 9)) % 9 || 9;
      return makeQ(14, qIdx, isExam, `ما أصغر رقم غير صفري يوضع مكان (_) ليقبل العدد ${a}_${b} القسمة على 9؟`, `What smallest non-zero digit replaces (_) so ${a}_${b} is divisible by 9?`, ans, [1, -1, 2, -2, 3], `مجموع الأرقام ${a} + ${ans} + ${b} = ${a + ans + b} وهو من مضاعفات 9.`, `Digit sum ${a} + ${ans} + ${b} = ${a + ans + b}, a multiple of 9.`);
    },
  },
  {
    stage: 15,
    titleAr: 'ترتيب العمليات الحسابية',
    titleEn: 'Order of Operations (PEMDAS)',
    summaryAr: 'نبدأ بالأقواس، ثم الأسس، ثم الضرب والقسمة من اليسار لليمين، ثم الجمع والطرح.',
    summaryEn: 'Evaluate parentheses first, then exponents, multiplication/division, and finally addition/subtraction.',
    ruleTitleAr: 'أولوية العمليات',
    ruleTitleEn: 'Operator Precedence',
    ruleFormula: '() → ^ → × ÷ → + −',
    examples: [
      { problemAr: 'احسب: 4 + 3 × 5', problemEn: 'Evaluate: 4 + 3 × 5', solutionAr: 'الضرب أولاً: 3 × 5 = 15 ثم 4 + 15 = 19', solutionEn: 'Multiply first: 3 × 5 = 15, then 4 + 15 = 19', answer: '19' },
      { problemAr: 'احسب: (6 + 2) × 4 - 5', problemEn: 'Evaluate: (6 + 2) × 4 - 5', solutionAr: '8 × 4 - 5 = 32 - 5 = 27', solutionEn: '8 × 4 - 5 = 32 - 5 = 27', answer: '27' },
    ],
    generate: (qIdx, isExam) => {
      const a = 2 + ((qIdx + (isExam ? 1 : 0)) % 6);
      const b = 3 + ((qIdx * 2) % 6);
      const c = 2 + ((qIdx + 2) % 5);
      const ans = a + b * c;
      return makeQ(15, qIdx, isExam, `احسب قيمة العبارة: ${a} + ${b} × ${c}`, `Evaluate: ${a} + ${b} × ${c}`, ans, [(a + b) * c - ans, 2, -2, 4], `الضرب يسبق الجمع: ${b} × ${c} = ${b * c}، ثم ${a} + ${b * c} = ${ans}.`, `Multiply before adding: ${b} × ${c} = ${b * c}, then ${a} + ${b * c} = ${ans}.`);
    },
  },
  {
    stage: 16,
    titleAr: 'ضرب الأعداد من منزلتين',
    titleEn: 'Two-Digit by Two-Digit Multiplication',
    summaryAr: 'نضرب في الآحاد ثم في العشرات (مع إضافة صفر) ونجمع النواتج الجزئية.',
    summaryEn: 'Multiply by ones and tens separately and sum the partial products.',
    ruleTitleAr: 'الضرب العمودي',
    ruleTitleEn: 'Area / Partial Products',
    ruleFormula: '(a+b)(c+d) = ac + ad + bc + bd',
    examples: [
      { problemAr: 'احسب: 23 × 14', problemEn: 'Calculate: 23 × 14', solutionAr: '23×10 + 23×4 = 230 + 92 = 322', solutionEn: '230 + 92 = 322', answer: '322' },
      { problemAr: 'احسب: 15 × 18', problemEn: 'Calculate: 15 × 18', solutionAr: '15×20 - 15×2 = 300 - 30 = 270', solutionEn: '300 - 30 = 270', answer: '270' },
    ],
    generate: (qIdx, isExam) => {
      const a = 12 + qIdx * 3 + (isExam ? 2 : 0);
      const b = 11 + ((qIdx * 2 + (isExam ? 1 : 0)) % 14);
      const ans = a * b;
      return makeQ(16, qIdx, isExam, `أوجد حاصل الضرب: ${a} × ${b}`, `Compute: ${a} × ${b}`, ans, [10, -10, a, -a, 20], `${a} × ${b} = ${ans}.`, `${a} × ${b} = ${ans}.`);
    },
  },
  {
    stage: 17,
    titleAr: 'الأعداد السالبة وجمعها وطرحها',
    titleEn: 'Negative Integers: Addition & Subtraction',
    summaryAr: 'عند جمع عددين سالبين نجمع القيمتين مع إشارة سالبة، وعند اختلاف الإشارتين نطرح ونأخذ إشارة الأكبر.',
    summaryEn: 'Same signs add and keep sign; different signs subtract and keep the larger magnitude sign.',
    ruleTitleAr: 'قواعد الإشارات',
    ruleTitleEn: 'Integer Sign Rules',
    ruleFormula: 'a - (-b) = a + b',
    examples: [
      { problemAr: 'احسب: -8 + 5', problemEn: 'Evaluate: -8 + 5', solutionAr: '8 - 5 = 3 ونأخذ إشارة الأكبر (-) ← -3', solutionEn: '8 - 5 = 3, take sign of -8 → -3', answer: '-3' },
      { problemAr: 'احسب: 6 - (-4)', problemEn: 'Evaluate: 6 - (-4)', solutionAr: '6 + 4 = 10', solutionEn: '6 + 4 = 10', answer: '10' },
    ],
    generate: (qIdx, isExam) => {
      const a = -12 + qIdx * 2 + (isExam ? 1 : 0);
      const b = 5 + ((qIdx * 3 + (isExam ? 2 : 0)) % 11);
      const isSub = qIdx % 2 === 1;
      const ans = isSub ? a - b : a + b;
      const expr = isSub ? `(${a}) - ${b}` : `(${a}) + ${b}`;
      return makeQ(17, qIdx, isExam, `ما ناتج: ${expr}؟`, `Evaluate: ${expr}`, ans, [2, -2, 4, -4, -ans * 2 || 6], `بتطبيق قواعد الأعداد الصحيحة يكون الناتج ${ans}.`, `Applying integer rules yields ${ans}.`, true);
    },
  },
  {
    stage: 18,
    titleAr: 'ضرب وقسمة الأعداد الصحيحة',
    titleEn: 'Multiplying & Dividing Integers',
    summaryAr: 'اتفاق الإشارات يعطي موجباً، واختلاف الإشارات يعطي سالباً.',
    summaryEn: 'Like signs yield a positive result; unlike signs yield a negative result.',
    ruleTitleAr: 'قاعدة الإشارات في الضرب',
    ruleTitleEn: 'Product Sign Rule',
    ruleFormula: '(-) × (-) = (+) ,  (-) × (+) = (-)',
    examples: [
      { problemAr: 'احسب: (-6) × (-4)', problemEn: 'Calculate: (-6) × (-4)', solutionAr: 'سالب × سالب = موجب: +24', solutionEn: 'Negative × Negative = +24', answer: '24' },
      { problemAr: 'احسب: (-36) ÷ 9', problemEn: 'Calculate: (-36) ÷ 9', solutionAr: 'سالب ÷ موجب = سالب: -4', solutionEn: 'Negative ÷ Positive = -4', answer: '-4' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const pairs: [number, number][] = [
        [-2, -3], [-3, 4], [-4, -5], [-5, 6], [-6, -7], [-7, 8], [-8, -9], [-9, 5], [-3, -8], [-4, 7], [-6, 9],
      ];
      const [a, b] = pairs[idx];
      const ans = a * b;
      return makeQ(18, qIdx, isExam, `احسب: (${a}) × (${b})`, `Calculate: (${a}) × (${b})`, ans, [-ans * 2, 2, -2, 6, -6], `بضرب القيم وتطبيق قاعدة الإشارات يكون الناتج ${ans}.`, `Multiplying magnitudes and applying sign rules gives ${ans}.`, true);
    },
  },
  {
    stage: 19,
    titleAr: 'الأعداد الأولية والتحليل إلى عوامل',
    titleEn: 'Prime Numbers & Factorization',
    summaryAr: 'العدد الأولي أكبر من 1 وله قاسمان فقط: 1 ونفسه، ويمكن تحليل أي عدد إلى عوامل أولية.',
    summaryEn: 'A prime number > 1 has exactly two divisors (1 and itself); every integer factors into primes.',
    ruleTitleAr: 'الأعداد الأولية الأولى',
    ruleTitleEn: 'First Primes',
    ruleFormula: '2, 3, 5, 7, 11, 13, 17, 19, 23, 29...',
    examples: [
      { problemAr: 'ما مجموع العوامل الأولية المختلفة للعدد 30؟', problemEn: 'Sum of distinct prime factors of 30?', solutionAr: '30 = 2 × 3 × 5، المجموع = 2 + 3 + 5 = 10', solutionEn: '30 = 2 × 3 × 5, sum = 10', answer: '10' },
      { problemAr: 'أي عدد أولي يقع بين 20 و 25؟', problemEn: 'Which prime lies between 20 and 25?', solutionAr: 'العدد 23 أولي', solutionEn: '23 is prime', answer: '23' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const pairs: [number, number][] = [
        [2, 3], [2, 5], [2, 7], [2, 11], [2, 13],
        [3, 5], [3, 7], [3, 11], [5, 7], [5, 11], [7, 11],
      ];
      const [p1, p2] = pairs[idx];
      const n = p1 * p2;
      const ans = p1 + p2;
      return makeQ(19, qIdx, isExam, `ما مجموع العاملين الأوليين للعدد ${n}؟`, `What is the sum of the two prime factors of ${n}?`, ans, [1, -1, 2, -2, 3], `${n} = ${p1} × ${p2}، ومجموعهما ${p1} + ${p2} = ${ans}.`, `${n} = ${p1} × ${p2}, so their sum is ${ans}.`);
    },
  },
  {
    stage: 20,
    titleAr: 'القاسم المشترك الأكبر والمضاعف المشترك الأصغر',
    titleEn: 'GCD and LCM',
    summaryAr: 'القاسم المشترك الأكبر (ق.م.أ) هو أكبر عدد يقسم العددين، والمضاعف المشترك الأصغر (م.م.أ) أصغر مضاعف مشترك بينهما.',
    summaryEn: 'GCD is the largest common divisor; LCM is the smallest positive common multiple.',
    ruleTitleAr: 'العلاقة بين ق.م.أ و م.م.أ',
    ruleTitleEn: 'GCD × LCM Identity',
    ruleFormula: 'GCD(a, b) × LCM(a, b) = a × b',
    examples: [
      { problemAr: 'أوجد ق.م.أ للعددين 24 و 36', problemEn: 'Find GCD(24, 36)', solutionAr: 'أكبر قاسم مشترك هو 12', solutionEn: 'Greatest common divisor is 12', answer: '12' },
      { problemAr: 'أوجد م.م.أ للعددين 6 و 8', problemEn: 'Find LCM(6, 8)', solutionAr: 'مضاعفات 8: 8، 16، 24 (يقبل على 6) ← 24', solutionEn: 'Multiples of 8: 8, 16, 24 → 24', answer: '24' },
    ],
    generate: (qIdx, isExam) => {
      const base = 2 + ((qIdx + (isExam ? 1 : 0)) % 5);
      const a = base * (2 + (qIdx % 3));
      const b = base * (3 + ((qIdx + 1) % 4));
      if (qIdx % 2 === 0) {
        const ans = gcd(a, b);
        return makeQ(20, qIdx, isExam, `ما القاسم المشترك الأكبر (ق.م.أ) للعددين ${a} و ${b}؟`, `What is the GCD of ${a} and ${b}?`, ans, [1, -1, 2, base + 1], `أكبر عدد يقسم ${a} و ${b} معاً هو ${ans}.`, `The largest divisor shared by ${a} and ${b} is ${ans}.`);
      }
      const ans = lcm(a, b);
      return makeQ(20, qIdx, isExam, `ما المضاعف المشترك الأصغر (م.م.أ) للعددين ${a} و ${b}؟`, `What is the LCM of ${a} and ${b}?`, ans, [base, -base, a * b, 2], `أصغر مضاعف مشترك للعددين ${a} و ${b} هو ${ans}.`, `The smallest common multiple of ${a} and ${b} is ${ans}.`);
    },
  },
  // --- HARD STAGES (21 - 30) ---
  {
    stage: 21,
    titleAr: 'الأسس والقوى الصحيحة',
    titleEn: 'Powers & Exponents',
    summaryAr: 'الأس يحدد عدد مرات ضرب الأساس في نفسه؛ وعند ضرب قوى بنفس الأساس نجمع الأسس.',
    summaryEn: 'An exponent counts repeated multiplication; multiplying like bases adds exponents.',
    ruleTitleAr: 'قانون الأسس',
    ruleTitleEn: 'Exponent Laws',
    ruleFormula: 'aᵐ × aⁿ = aᵐ⁺ⁿ ,  a⁰ = 1',
    examples: [
      { problemAr: 'احسب: 2⁵', problemEn: 'Evaluate: 2⁵', solutionAr: '2×2×2×2×2 = 32', solutionEn: '2×2×2×2×2 = 32', answer: '32' },
      { problemAr: 'احسب: 3³ + 4²', problemEn: 'Evaluate: 3³ + 4²', solutionAr: '27 + 16 = 43', solutionEn: '27 + 16 = 43', answer: '43' },
    ],
    generate: (qIdx, isExam) => {
      const base = 2 + ((qIdx + (isExam ? 1 : 0)) % 4);
      const exp = 2 + ((qIdx * 2) % 3);
      const add = 1 + ((qIdx + (isExam ? 2 : 0)) % 9);
      const ans = Math.pow(base, exp) + add;
      return makeQ(21, qIdx, isExam, `احسب قيمة: ${base}^${exp} + ${add}`, `Evaluate: ${base}^${exp} + ${add}`, ans, [base, -base, 2, -2, 4], `${base}^${exp} = ${Math.pow(base, exp)}، وبإضافة ${add} نحصل على ${ans}.`, `${base}^${exp} = ${Math.pow(base, exp)}; adding ${add} gives ${ans}.`);
    },
  },
  {
    stage: 22,
    titleAr: 'الجذور التربيعية والتكعيبية',
    titleEn: 'Square & Cube Roots',
    summaryAr: 'الجذر التربيعي لعدد موجب هو العدد الذي مربعه يساوي ذلك العدد.',
    summaryEn: 'The square root of a number is the non-negative value whose square equals that number.',
    ruleTitleAr: 'تعريف الجذر',
    ruleTitleEn: 'Root Definition',
    ruleFormula: '√(a²) = a ,  ∛(a³) = a',
    examples: [
      { problemAr: 'احسب: √144 + √25', problemEn: 'Evaluate: √144 + √25', solutionAr: '12 + 5 = 17', solutionEn: '12 + 5 = 17', answer: '17' },
      { problemAr: 'احسب: ∛64 × √9', problemEn: 'Evaluate: ∛64 × √9', solutionAr: '4 × 3 = 12', solutionEn: '4 × 3 = 12', answer: '12' },
    ],
    generate: (qIdx, isExam) => {
      const r1 = 3 + ((qIdx + (isExam ? 1 : 0)) % 10);
      const r2 = 2 + ((qIdx * 2 + (isExam ? 1 : 0)) % 8);
      const ans = r1 + r2;
      return makeQ(22, qIdx, isExam, `ما قيمة: √${r1 * r1} + √${r2 * r2}؟`, `What is √${r1 * r1} + √${r2 * r2}?`, ans, [1, -1, 2, -2, 3], `√${r1 * r1} = ${r1} و √${r2 * r2} = ${r2}، المجموع = ${ans}.`, `√${r1 * r1} = ${r1} and √${r2 * r2} = ${r2}, sum = ${ans}.`);
    },
  },
  {
    stage: 23,
    titleAr: 'القسمة المطولة لأعداد كبيرة',
    titleEn: 'Long Division of Larger Numbers',
    summaryAr: 'نقسم من المنزلة الأعلى قيمة إلى الأقل عبر خطوات: اقسم، اضرب، اطرح، أنزل الرقم التالي.',
    summaryEn: 'Divide from highest place value down: Divide, Multiply, Subtract, Bring down.',
    ruleTitleAr: 'دورة القسمة المطولة',
    ruleTitleEn: 'Long Division Cycle',
    ruleFormula: 'Divide → Multiply → Subtract → Bring Down',
    examples: [
      { problemAr: 'احسب: 756 ÷ 12', problemEn: 'Calculate: 756 ÷ 12', solutionAr: '75÷12=6 (باقي 3)، ننزل 6 → 36÷12=3 ← 63', solutionEn: '75÷12=6 r3, bring down 6 → 36÷12=3 → 63', answer: '63' },
      { problemAr: 'احسب: 945 ÷ 15', problemEn: 'Calculate: 945 ÷ 15', solutionAr: '94÷15=6 (باقي 4)، 45÷15=3 ← 63', solutionEn: '94÷15=6 r4, 45÷15=3 → 63', answer: '63' },
    ],
    generate: (qIdx, isExam) => {
      const d = 11 + ((qIdx + (isExam ? 2 : 0)) % 9);
      const ans = 14 + qIdx * 5 + (isExam ? 3 : 0);
      const n = d * ans;
      return makeQ(23, qIdx, isExam, `احسب ناتج القسمة: ${n} ÷ ${d}`, `Calculate: ${n} ÷ ${d}`, ans, [1, -1, 10, -10, 2], `لأن ${d} × ${ans} = ${n}، فإن الناتج هو ${ans}.`, `Because ${d} × ${ans} = ${n}, the quotient is ${ans}.`);
    },
  },
  {
    stage: 24,
    titleAr: 'الحساب المعياري (باقي القسمة)',
    titleEn: 'Modular Arithmetic Remainders',
    summaryAr: 'باقي قسمة مجموع أو حاصل ضرب عددين يساوي باقي قسمة مجموع أو ضرب بواقيهما.',
    summaryEn: 'The remainder of a sum or product equals the remainder of the sum or product of their remainders.',
    ruleTitleAr: 'خاصية التطابق',
    ruleTitleEn: 'Modular Property',
    ruleFormula: '(a × b) mod m = ((a mod m) × (b mod m)) mod m',
    examples: [
      { problemAr: 'ما باقي قسمة (23 × 19) على 5؟', problemEn: 'Remainder of (23 × 19) ÷ 5?', solutionAr: 'بواقي القسمة على 5 هي 3 و 4: 3×4=12 وباقيها على 5 هو 2', solutionEn: 'Remainders mod 5 are 3 and 4; 3×4=12 ≡ 2 (mod 5)', answer: '2' },
      { problemAr: 'ما باقي قسمة (100 + 37) على 7؟', problemEn: 'Remainder of (100 + 37) ÷ 7?', solutionAr: '100 mod 7 = 2، 37 mod 7 = 2، المجموع 4', solutionEn: '2 + 2 = 4', answer: '4' },
    ],
    generate: (qIdx, isExam) => {
      const m = 5 + ((qIdx + (isExam ? 1 : 0)) % 5);
      const a = 21 + qIdx * 7 + (isExam ? 2 : 0);
      const b = 13 + qIdx * 5 + (isExam ? 3 : 0);
      const ans = (a * b) % m;
      return makeQ(24, qIdx, isExam, `ما باقي قسمة (${a} × ${b}) على ${m}؟`, `What is the remainder of (${a} × ${b}) divided by ${m}?`, ans, [1, -1, 2, -2, 3], `${a} باقيه ${a % m} و ${b} باقيه ${b % m} على ${m}، وضربهما يعطي باقياً ${ans}.`, `Using modular remainders mod ${m}, the remainder is ${ans}.`);
    },
  },
  {
    stage: 25,
    titleAr: 'القيمة المطلقة والعبارات المركبة',
    titleEn: 'Absolute Value Expressions',
    summaryAr: 'القيمة المطلقة تمثل المسافة عن الصفر على خط الأعداد وهي غير سالبة دائماً.',
    summaryEn: 'Absolute value measures distance from zero on the number line and is always non-negative.',
    ruleTitleAr: 'تعريف القيمة المطلقة',
    ruleTitleEn: 'Absolute Value',
    ruleFormula: '|x| = x if x ≥ 0,  -x if x < 0',
    examples: [
      { problemAr: 'احسب: |4 - 11| + |-3|', problemEn: 'Evaluate: |4 - 11| + |-3|', solutionAr: '|-7| + 3 = 7 + 3 = 10', solutionEn: '7 + 3 = 10', answer: '10' },
      { problemAr: 'احسب: 2 × |-6| - |5 - 9|', problemEn: 'Evaluate: 2 × |-6| - |5 - 9|', solutionAr: '2×6 - 4 = 12 - 4 = 8', solutionEn: '12 - 4 = 8', answer: '8' },
    ],
    generate: (qIdx, isExam) => {
      const a = 3 + qIdx;
      const b = 10 + qIdx * 2 + (isExam ? 3 : 0);
      const c = 2 + ((qIdx + (isExam ? 1 : 0)) % 6);
      const ans = Math.abs(a - b) + Math.abs(-c);
      return makeQ(25, qIdx, isExam, `احسب: |${a} - ${b}| + |-${c}|`, `Evaluate: |${a} - ${b}| + |-${c}|`, ans, [2, -2, c * 2, 1, -1], `|${a - b}| = ${Math.abs(a - b)} و |-${c}| = ${c}، المجموع = ${ans}.`, `|${a - b}| = ${Math.abs(a - b)} and |-${c}| = ${c}, sum = ${ans}.`);
    },
  },
  {
    stage: 26,
    titleAr: 'استراتيجيات الحساب الذهني السريع',
    titleEn: 'Mental Math & Algebraic Identities',
    summaryAr: 'نستخدم خاصية الفرق بين مربعين والتعويض الذهني لحساب نواتج الضرب المعقدة بسرعة.',
    summaryEn: 'Use algebraic identities like difference of squares to compute large products mentally.',
    ruleTitleAr: 'فرق المربعين في الحساب',
    ruleTitleEn: 'Mental Product Identity',
    ruleFormula: '(a - b)(a + b) = a² - b²',
    examples: [
      { problemAr: 'احسب ذهنياً: 29 × 31', problemEn: 'Compute mentally: 29 × 31', solutionAr: '(30 - 1)(30 + 1) = 900 - 1 = 899', solutionEn: '30² - 1² = 900 - 1 = 899', answer: '899' },
      { problemAr: 'احسب ذهنياً: 48 × 52', problemEn: 'Compute mentally: 48 × 52', solutionAr: '50² - 2² = 2500 - 4 = 2496', solutionEn: '2500 - 4 = 2496', answer: '2496' },
    ],
    generate: (qIdx, isExam) => {
      const center = (2 + qIdx) * 10;
      const delta = 1 + ((qIdx + (isExam ? 1 : 0)) % 4);
      const a = center - delta;
      const b = center + delta;
      const ans = a * b;
      return makeQ(26, qIdx, isExam, `احسب الناتج: ${a} × ${b}`, `Compute: ${a} × ${b}`, ans, [delta * delta, -delta * delta, 10, -10, 2], `(${center} - ${delta})(${center} + ${delta}) = ${center}² - ${delta}² = ${ans}.`, `Using (${center}-${delta})(${center}+${delta}) = ${center}² - ${delta}² = ${ans}.`);
    },
  },
  {
    stage: 27,
    titleAr: 'العمليات المركبة متعددة الأقواس',
    titleEn: 'Nested Bracket Arithmetic',
    summaryAr: 'في العبارات ذات الأقواس المتداخلة نبدأ من القوس الداخلي أولاً ثم نتدرج للخارج.',
    summaryEn: 'For nested parentheses, always evaluate from the innermost brackets outward.',
    ruleTitleAr: 'من الداخل إلى الخارج',
    ruleTitleEn: 'Inner-to-Outer Rule',
    ruleFormula: '[a × (b + c) - d] ÷ e',
    examples: [
      { problemAr: 'احسب: 3 × [4 + 2 × (7 - 3)]', problemEn: 'Evaluate: 3 × [4 + 2 × (7 - 3)]', solutionAr: '7-3=4 ← 2×4=8 ← 4+8=12 ← 3×12=36', solutionEn: '3 × [4 + 8] = 36', answer: '36' },
      { problemAr: 'احسب: [5 × (6 - 2) + 4] ÷ 6', problemEn: 'Evaluate: [5 × (6 - 2) + 4] ÷ 6', solutionAr: '[20 + 4] ÷ 6 = 4', solutionEn: '24 ÷ 6 = 4', answer: '4' },
    ],
    generate: (qIdx, isExam) => {
      const x = 2 + ((qIdx + (isExam ? 1 : 0)) % 5);
      const y = 1 + (qIdx % 4);
      const m = 2 + ((qIdx * 2) % 4);
      const k = 3 + ((qIdx + 2) % 5);
      const outer = 2 + (qIdx % 3);
      const ans = outer * (k + m * (x + y));
      return makeQ(27, qIdx, isExam, `احسب: ${outer} × [${k} + ${m} × (${x} + ${y})]`, `Evaluate: ${outer} × [${k} + ${m} × (${x} + ${y})]`, ans, [outer, -outer, m, -m, 4], `نبدأ بـ (${x}+${y})=${x + y}، ثم ×${m}=${m * (x + y)}، ثم +${k}=${k + m * (x + y)}، ثم ×${outer}=${ans}.`, `Evaluating from innermost parentheses outward yields ${ans}.`);
    },
  },
  {
    stage: 28,
    titleAr: 'مجموع المتسلسلات الحسابية البسيطة',
    titleEn: 'Sums of Arithmetic Progressions',
    summaryAr: 'يمكن جمع الأعداد المتتالية بضرب عدد الحدود في متوسط الحد الأول والأخير.',
    summaryEn: 'Sum evenly spaced numbers by multiplying the count of terms by the average of first and last.',
    ruleTitleAr: 'صيغة غاوس للمجموع',
    ruleTitleEn: 'Gauss Sum Formula',
    ruleFormula: 'S = n × (first + last) / 2',
    examples: [
      { problemAr: 'ما مجموع الأعداد من 1 إلى 10؟', problemEn: 'Sum of integers 1 to 10?', solutionAr: '10 × (1 + 10) ÷ 2 = 55', solutionEn: '10 × 11 / 2 = 55', answer: '55' },
      { problemAr: 'ما مجموع الأعداد من 1 إلى 20؟', problemEn: 'Sum of integers 1 to 20?', solutionAr: '20 × 21 ÷ 2 = 210', solutionEn: '20 × 21 / 2 = 210', answer: '210' },
    ],
    generate: (qIdx, isExam) => {
      const n = 8 + qIdx * 2 + (isExam ? 1 : 0);
      const ans = (n * (n + 1)) / 2;
      return makeQ(28, qIdx, isExam, `ما مجموع الأعداد الصحيحة من 1 إلى ${n}؟`, `What is the sum of integers from 1 to ${n}?`, ans, [n, -n, 1, -1, 5], `باستخدام صيغة غاوس: ${n} × (${n} + 1) ÷ 2 = ${ans}.`, `Using Gauss formula: ${n} × (${n} + 1) / 2 = ${ans}.`);
    },
  },
  {
    stage: 29,
    titleAr: 'مسائل كلامية متعددة الخطوات',
    titleEn: 'Multi-Step Arithmetic Word Problems',
    summaryAr: 'نترجم المسألة الحياتية إلى خطوات حسابية متسلسلة ونتحقق من معقولية الناتج.',
    summaryEn: 'Translate word scenarios into sequential arithmetic operations and verify the answer.',
    ruleTitleAr: 'خطوات حل المسألة',
    ruleTitleEn: 'Problem Solving Steps',
    ruleFormula: 'Understand → Plan → Compute → Verify',
    examples: [
      { problemAr: 'اشترى سامي 4 دفاتر سعر الواحد 6 ريالات وقلماً بـ 5 ريالات، كم دفع؟', problemEn: 'Sami bought 4 notebooks at 6 each and a pen for 5. Total?', solutionAr: '4 × 6 + 5 = 24 + 5 = 29', solutionEn: '4 × 6 + 5 = 29', answer: '29' },
      { problemAr: 'مع سارة 100 ريال، اشترت 3 كتب بـ 22 ريالاً للكتاب، كم بقي معها؟', problemEn: 'Sara had 100 and bought 3 books at 22 each. Remaining?', solutionAr: '100 - (3 × 22) = 100 - 66 = 34', solutionEn: '100 - 66 = 34', answer: '34' },
    ],
    generate: (qIdx, isExam) => {
      const boxes = 3 + ((qIdx + (isExam ? 1 : 0)) % 6);
      const perBox = 8 + qIdx * 2;
      const given = 5 + ((qIdx * 3) % 15);
      const ans = boxes * perBox - given;
      return makeQ(29, qIdx, isExam, `في مكتبة ${boxes} صناديق في كل منها ${perBox} كتاباً، إذا وزّعت ${given} كتاباً، فكم كتاباً بقي؟`, `A library has ${boxes} boxes of ${perBox} books each. If ${given} books are given out, how many remain?`, ans, [given, -given, perBox, 5, -5], `إجمالي الكتب = ${boxes} × ${perBox} = ${boxes * perBox}، وبعد توزيع ${given} يتبقى ${ans}.`, `Total = ${boxes} × ${perBox} = ${boxes * perBox}; subtracting ${given} leaves ${ans}.`);
    },
  },
  {
    stage: 30,
    titleAr: 'التحدي الشامل للحساب الأساسي',
    titleEn: 'Master Arithmetic Synthesis',
    summaryAr: 'دمج الأسس والجذور والأقواس وباقي القسمة في مسائل حسابية مركبة.',
    summaryEn: 'Combine exponents, roots, nested operations, and integer arithmetic in one challenge.',
    ruleTitleAr: 'التحقق المتكامل',
    ruleTitleEn: 'Integrated Evaluation',
    ruleFormula: 'Roots & Powers → Brackets → × ÷ → + −',
    examples: [
      { problemAr: 'احسب: 2⁴ + √36 × (9 - 4)', problemEn: 'Evaluate: 2⁴ + √36 × (9 - 4)', solutionAr: '16 + 6 × 5 = 16 + 30 = 46', solutionEn: '16 + 6 × 5 = 46', answer: '46' },
      { problemAr: 'احسب: (5² - √49) ÷ 3 + 7', problemEn: 'Evaluate: (5² - √49) ÷ 3 + 7', solutionAr: '(25 - 7) ÷ 3 + 7 = 6 + 7 = 13', solutionEn: '18 ÷ 3 + 7 = 13', answer: '13' },
    ],
    generate: (qIdx, isExam) => {
      const r = 3 + ((qIdx + (isExam ? 1 : 0)) % 6);
      const p = 2 + (qIdx % 3);
      const k = 2 + ((qIdx * 2) % 5);
      const ans = p * p * p + r * k;
      return makeQ(30, qIdx, isExam, `احسب قيمة: ${p}³ + √${r * r} × ${k}`, `Evaluate: ${p}³ + √${r * r} × ${k}`, ans, [r, -r, k, 4, -4], `${p}³ = ${p * p * p} و √${r * r} × ${k} = ${r * k}، المجموع = ${ans}.`, `${p}³ = ${p * p * p} and √${r * r} × ${k} = ${r * k}, giving ${ans}.`);
    },
  },
];

export const ARITHMETIC_STAGES: StageDefinition[] = TOPICS.map((spec) => {
  const questions: QuizQuestion[] = [];
  for (let i = 0; i < 10; i++) {
    questions.push(spec.generate(i, false));
  }
  const examQuestion = spec.generate(10, true);

  return {
    id: makeStageId('arithmetic', spec.stage),
    sectionId: 'arithmetic',
    stageNumber: spec.stage,
    difficulty: getDifficultyForStage(spec.stage),
    titleAr: spec.titleAr,
    titleEn: spec.titleEn,
    lesson: {
      summaryAr: spec.summaryAr,
      summaryEn: spec.summaryEn,
      ruleTitleAr: spec.ruleTitleAr,
      ruleTitleEn: spec.ruleTitleEn,
      ruleFormula: spec.ruleFormula,
      examples: spec.examples,
    },
    questions,
    examQuestion,
  };
});

// Keep rng helper referenced cleanly if needed
void createSeededRng;
void hashString;
void randInt;
