import {
  buildChoiceQuestion,
  formatFraction,
  gcd,
  getDifficultyForStage,
  lcm,
  makeStageId,
  numericDistractors,
} from '@/src/data/curriculum/helpers';
import type { QuizQuestion, StageDefinition, WorkedExample } from '@/src/types/curriculum';

interface TopicSpec {
  stage: number;
  titleAr: string;
  titleEn: string;
  summaryAr: string;
  summaryEn: string;
  ruleTitleAr: string;
  ruleTitleEn: string;
  ruleFormula: string;
  examples: [WorkedExample, WorkedExample];
  generate: (qIdx: number, isExam: boolean) => QuizQuestion;
}

function fracQ(
  stage: number,
  qIdx: number,
  isExam: boolean,
  promptAr: string,
  promptEn: string,
  correct: string,
  distractors: string[],
  explanationAr: string,
  explanationEn: string,
): QuizQuestion {
  const id = isExam ? `fractions-exam-s${stage}` : `fractions-s${stage}-q${qIdx + 1}`;
  return buildChoiceQuestion({
    id,
    promptAr,
    promptEn,
    correctValue: correct,
    distractors,
    explanationAr,
    explanationEn,
    seedKey: `${id}-${promptEn}`,
  });
}

const TOPICS: TopicSpec[] = [
  {
    stage: 1,
    titleAr: 'مفهوم الكسر: البسط والمقام',
    titleEn: 'Understanding Numerator & Denominator',
    summaryAr: 'الكسر يعبّر عن جزء من كل؛ الرقم العلوي هو البسط (الأجزاء المأخوذة) والسفلي هو المقام (إجمالي الأجزاء المتساوية).',
    summaryEn: 'A fraction represents part of a whole: the top is the numerator and the bottom is total equal parts.',
    ruleTitleAr: 'تمثيل الكسر',
    ruleTitleEn: 'Fraction Representation',
    ruleFormula: 'Fraction = Selected Parts / Total Equal Parts',
    examples: [
      { problemAr: 'قُسّمت بيتزا إلى 8 قطع متساوية وأُكلت 3 قطع، ما الكسر المأكول؟', problemEn: 'A pizza has 8 equal slices and 3 are eaten. Fraction eaten?', solutionAr: 'البسط = 3 والمقام = 8 ← 3/8', solutionEn: '3 out of 8 → 3/8', answer: '3/8' },
      { problemAr: 'كيس فيه 10 كرات منها 7 زرقاء، ما كسر الكرات الزرقاء؟', problemEn: '7 blue balls out of 10. Fraction of blue balls?', solutionAr: '7/10', solutionEn: '7/10', answer: '7/10' },
    ],
    generate: (qIdx, isExam) => {
      const den = [5, 7, 9, 11, 13, 8, 10, 12, 15, 16, 17][(qIdx + (isExam ? 1 : 0)) % 11];
      let num = 1 + ((qIdx * 2 + (isExam ? 1 : 0)) % (den - 1));
      while (gcd(num, den) !== 1) num++;
      const ans = `${num}/${den}`;
      return fracQ(1, qIdx, isExam, `قُسّم شريط إلى ${den} أجزاء متساوية وتم تظليل ${num} أجزاء، ما الكسر الذي يمثل الجزء المظلل؟`, `A bar is split into ${den} equal parts and ${num} are shaded. What fraction is shaded?`, ans, [`${den}/${num}`, `${den - num}/${den}`, `${num}/${den + 1}`], `عدد الأجزاء المظللة (${num}) على العدد الكلي (${den}) يعطي ${ans}.`, `${num} shaded parts out of ${den} total parts is ${ans}.`);
    },
  },
  {
    stage: 2,
    titleAr: 'الكسور المتكافئة',
    titleEn: 'Equivalent Fractions',
    summaryAr: 'نحصل على كسر مكافئ بضرب البسط والمقام في العدد غير الصفري نفسه.',
    summaryEn: 'Multiply both numerator and denominator by the same non-zero number to form equivalent fractions.',
    ruleTitleAr: 'قاعدة التكافؤ',
    ruleTitleEn: 'Equivalence Rule',
    ruleFormula: 'a/b = (a×k)/(b×k)',
    examples: [
      { problemAr: 'أكمل: 2/3 = ?/12', problemEn: 'Complete: 2/3 = ?/12', solutionAr: '3×4 = 12، إذن 2×4 = 8', solutionEn: '3×4 = 12, so 2×4 = 8', answer: '8' },
      { problemAr: 'أكمل: 3/5 = ?/20', problemEn: 'Complete: 3/5 = ?/20', solutionAr: '5×4 = 20، إذن 3×4 = 12', solutionEn: '5×4 = 20, so 3×4 = 12', answer: '12' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const den = 3 + (idx % 5);
      const num = 1 + (idx % (den - 1));
      const k = 2 + idx;
      const ans = num * k;
      return fracQ(2, qIdx, isExam, `ما العدد الذي يجعل الكسرين متكافئين: ${num}/${den} = ?/${den * k}`, `Find the missing numerator: ${num}/${den} = ?/${den * k}`, String(ans), numericDistractors(ans, [1, -1, k, 2]), `ضربنا المقام في ${k} لنحصل على ${den * k}، لذا نضرب البسط في ${k}: ${num} × ${k} = ${ans}.`, `Denominator was multiplied by ${k}, so ${num} × ${k} = ${ans}.`);
    },
  },
  {
    stage: 3,
    titleAr: 'تبسيط الكسور لأبسط صورة',
    titleEn: 'Simplifying Fractions',
    summaryAr: 'نبسّط الكسر بقسمة البسط والمقام على القاسم المشترك الأكبر بينهما.',
    summaryEn: 'Divide both numerator and denominator by their GCD to express a fraction in simplest form.',
    ruleTitleAr: 'أبسط صورة',
    ruleTitleEn: 'Lowest Terms',
    ruleFormula: '(a÷d)/(b÷d) where d = GCD(a,b)',
    examples: [
      { problemAr: 'بسّط الكسر 12/18', problemEn: 'Simplify 12/18', solutionAr: 'نقسم على 6 ← 2/3', solutionEn: 'Divide by 6 → 2/3', answer: '2/3' },
      { problemAr: 'بسّط الكسر 15/25', problemEn: 'Simplify 15/25', solutionAr: 'نقسم على 5 ← 3/5', solutionEn: 'Divide by 5 → 3/5', answer: '3/5' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const bases: [number, number][] = [[1, 2], [2, 3], [3, 4], [2, 5], [3, 5], [4, 5], [3, 7], [5, 6], [5, 8], [7, 9], [4, 7]];
      const [n, d] = bases[idx];
      const k = 2 + (idx % 5);
      const ans = `${n}/${d}`;
      return fracQ(3, qIdx, isExam, `اكتب الكسر ${n * k}/${d * k} في أبسط صورة:`, `Simplify ${n * k}/${d * k} to lowest terms:`, ans, [`${n}/${d + 1}`, `${n + 1}/${d}`, `${d}/${n}`], `بقسمة البسط والمقام على ${k} نحصل على أبسط صورة وهي ${ans}.`, `Dividing numerator and denominator by ${k} gives ${ans}.`);
    },
  },
  {
    stage: 4,
    titleAr: 'مقارنة الكسور وترتيبها',
    titleEn: 'Comparing Fractions',
    summaryAr: 'لمقارنة كسرين نوحّد مقاميهما أو نستخدم الضرب التبادلي: a/b > c/d إذا كان a×d > b×c.',
    summaryEn: 'Compare fractions using common denominators or cross-multiplication.',
    ruleTitleAr: 'المقارنة التبادلية',
    ruleTitleEn: 'Cross-Product Comparison',
    ruleFormula: 'a/b > c/d  ⟺  a×d > b×c',
    examples: [
      { problemAr: 'أيهما أكبر: 3/4 أم 5/7؟', problemEn: 'Which is greater: 3/4 or 5/7?', solutionAr: '3×7 = 21 و 4×5 = 20، إذن 3/4 أكبر', solutionEn: '3×7=21 > 4×5=20, so 3/4 is greater', answer: '3/4' },
      { problemAr: 'أيهما أكبر: 2/3 أم 5/8؟', problemEn: 'Which is greater: 2/3 or 5/8?', solutionAr: '2×8 = 16 > 3×5 = 15 ← 2/3', solutionEn: '16 > 15 → 2/3', answer: '2/3' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const pairs: [string, string, string, string][] = [
        ['3/4', '2/3', '5/8', '1/2'],
        ['5/6', '3/4', '2/3', '1/2'],
        ['4/5', '2/3', '3/5', '1/2'],
        ['7/8', '3/4', '5/6', '2/3'],
        ['5/7', '2/3', '1/2', '3/5'],
        ['7/10', '3/5', '1/2', '2/5'],
        ['8/9', '4/5', '3/4', '5/7'],
        ['6/7', '4/5', '2/3', '3/4'],
        ['9/10', '4/5', '3/4', '5/6'],
        ['7/9', '2/3', '3/5', '1/2'],
        ['11/12', '5/6', '3/4', '4/5'],
      ];
      const [maxF, f2, f3, f4] = pairs[idx];
      const all = [maxF, f2, f3, f4];
      const shift = idx % 4;
      const displayList = [...all.slice(shift), ...all.slice(0, shift)].join(' ، ');
      return fracQ(4, qIdx, isExam, `أي من الكسور التالية هو الأكبر قيمة: (${displayList})؟`, `Which fraction is the greatest among (${displayList})?`, maxF, [f2, f3, f4], `بتوحيد المقامات نجد أن ${maxF} يمتلك أكبر قيمة بين الخيارات.`, `With a common denominator, ${maxF} has the largest value.`);
    },
  },
  {
    stage: 5,
    titleAr: 'جمع الكسور متشابهة المقام',
    titleEn: 'Adding Like Fractions',
    summaryAr: 'عندما يتساوى المقامان نجمع البسطين ونبقي المقام كما هو ثم نبسّط الناتج.',
    summaryEn: 'When denominators match, add the numerators and keep the common denominator.',
    ruleTitleAr: 'جمع المقام المتحد',
    ruleTitleEn: 'Like-Denominator Sum',
    ruleFormula: 'a/c + b/c = (a + b)/c',
    examples: [
      { problemAr: 'احسب: 2/7 + 3/7', problemEn: 'Calculate: 2/7 + 3/7', solutionAr: '(2+3)/7 = 5/7', solutionEn: '5/7', answer: '5/7' },
      { problemAr: 'احسب: 3/8 + 1/8', problemEn: 'Calculate: 3/8 + 1/8', solutionAr: '4/8 = 1/2', solutionEn: '4/8 = 1/2', answer: '1/2' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const den = [5, 7, 9, 10, 11, 12, 13, 14, 15, 16, 18][idx];
      const a = 1 + (idx % Math.max(2, Math.floor(den / 2)));
      const b = 1 + ((idx + 1) % Math.max(2, Math.floor(den / 2)));
      const ans = formatFraction(a + b, den);
      return fracQ(5, qIdx, isExam, `ما ناتج الجمع في أبسط صورة: ${a}/${den} + ${b}/${den}؟`, `Add and simplify: ${a}/${den} + ${b}/${den}`, ans, [`${a + b}/${den * 2}`, formatFraction(a + b + 1, den), formatFraction(a + b, den + 1)], `نجمع البسطين: ${a} + ${b} = ${a + b} على المقام ${den} وبالتبسيط نحصل على ${ans}.`, `Add numerators: (${a}+${b})/${den}, simplifying to ${ans}.`);
    },
  },
  {
    stage: 6,
    titleAr: 'طرح الكسور متشابهة المقام',
    titleEn: 'Subtracting Like Fractions',
    summaryAr: 'نطرح البسط الثاني من الأول ونحافظ على المقام الموحد مع التبسيط.',
    summaryEn: 'Subtract the numerators while keeping the same denominator, then simplify.',
    ruleTitleAr: 'طرح المقام المتحد',
    ruleTitleEn: 'Like-Denominator Difference',
    ruleFormula: 'a/c − b/c = (a − b)/c',
    examples: [
      { problemAr: 'احسب: 7/9 − 2/9', problemEn: 'Calculate: 7/9 − 2/9', solutionAr: '5/9', solutionEn: '5/9', answer: '5/9' },
      { problemAr: 'احسب: 5/6 − 1/6', problemEn: 'Calculate: 5/6 − 1/6', solutionAr: '4/6 = 2/3', solutionEn: '4/6 = 2/3', answer: '2/3' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const den = [7, 8, 9, 10, 11, 12, 14, 15, 16, 18, 20][idx];
      const a = Math.floor(den * 0.7) + 1;
      const b = 1 + (idx % Math.max(2, Math.floor(den * 0.4)));
      const ans = formatFraction(a - b, den);
      return fracQ(6, qIdx, isExam, `احسب في أبسط صورة: ${a}/${den} − ${b}/${den}`, `Subtract and simplify: ${a}/${den} − ${b}/${den}`, ans, [formatFraction(a + b, den), formatFraction(a - b + 1, den), `${a - b}/${den + 1}`], `بطرح البسطين: ${a} − ${b} = ${a - b} والمقام ${den}، فيكون الناتج ${ans}.`, `(${a} − ${b})/${den} simplifies to ${ans}.`);
    },
  },
  {
    stage: 7,
    titleAr: 'الأعداد الكسرية والكسور غير الفعلية',
    titleEn: 'Mixed Numbers & Improper Fractions',
    summaryAr: 'نحوّل العدد الكسري إلى كسر غير فعلي بضرب العدد الصحيح في المقام ثم إضافة البسط.',
    summaryEn: 'Convert a mixed number to an improper fraction via (whole × denominator + numerator) / denominator.',
    ruleTitleAr: 'صيغة التحويل',
    ruleTitleEn: 'Conversion Formula',
    ruleFormula: 'W (a/b) = (W×b + a) / b',
    examples: [
      { problemAr: 'حوّل 2 و 3/4 إلى كسر غير فعلي', problemEn: 'Convert 2 3/4 to improper fraction', solutionAr: '(2×4 + 3)/4 = 11/4', solutionEn: '(8 + 3)/4 = 11/4', answer: '11/4' },
      { problemAr: 'حوّل 3 و 1/5 إلى كسر غير فعلي', problemEn: 'Convert 3 1/5', solutionAr: '(3×5 + 1)/5 = 16/5', solutionEn: '16/5', answer: '16/5' },
    ],
    generate: (qIdx, isExam) => {
      const whole = 1 + ((qIdx + (isExam ? 1 : 0)) % 5);
      const den = 3 + (qIdx % 6);
      const num = 1 + ((qIdx * 2) % (den - 1));
      const top = whole * den + num;
      const ans = `${top}/${den}`;
      return fracQ(7, qIdx, isExam, `حوّل العدد الكسري ${whole} و ${num}/${den} إلى كسر غير فعلي:`, `Convert the mixed number ${whole} ${num}/${den} to an improper fraction:`, ans, [`${whole * num + den}/${den}`, `${top + 1}/${den}`, `${top}/${den + 1}`], `(${whole} × ${den}) + ${num} = ${top}، إذن الكسر هو ${ans}.`, `(${whole} × ${den}) + ${num} = ${top}, giving ${ans}.`);
    },
  },
  {
    stage: 8,
    titleAr: 'القيمة المنزلية للأعداد العشرية',
    titleEn: 'Decimal Place Value',
    summaryAr: 'الأرقام يمين الفاصلة العشرية تمثل أجزاء من عشرة، وأجزاء من مئة، وأجزاء من ألف.',
    summaryEn: 'Digits right of the decimal point represent tenths, hundredths, and thousandths.',
    ruleTitleAr: 'منازل الأجزاء العشرية',
    ruleTitleEn: 'Decimal Places',
    ruleFormula: '0.abc = a/10 + b/100 + c/1000',
    examples: [
      { problemAr: 'ما قيمة الرقم 6 في العدد 4.36؟', problemEn: 'Value of 6 in 4.36?', solutionAr: 'في منزلة الأجزاء من مئة ← 0.06', solutionEn: 'Hundredths place → 0.06', answer: '0.06' },
      { problemAr: 'ما قيمة الرقم 5 في 2.58؟', problemEn: 'Value of 5 in 2.58?', solutionAr: 'في منزلة الأعشار ← 0.5', solutionEn: 'Tenths place → 0.5', answer: '0.5' },
    ],
    generate: (qIdx, isExam) => {
      const d = 2 + ((qIdx + (isExam ? 1 : 0)) % 7);
      const tenths = qIdx % 2 === 0;
      const other = ((d + 2) % 8) + 1;
      const whole = 1 + (qIdx % 8);
      const numStr = tenths ? `${whole}.${d}${other}` : `${whole}.${other}${d}`;
      const ans = tenths ? `0.${d}` : `0.0${d}`;
      return fracQ(8, qIdx, isExam, `ما قيمة الرقم ${d} في العدد العشري ${numStr}؟`, `What is the place value of digit ${d} in ${numStr}?`, ans, [tenths ? `0.0${d}` : `0.${d}`, `0.00${d}`, String(d)], `الرقم ${d} يقع في منزلة ${tenths ? 'الأجزاء من عشرة' : 'الأجزاء من مئة'}، لذا قيمته ${ans}.`, `Digit ${d} is in the ${tenths ? 'tenths' : 'hundredths'} place: ${ans}.`);
    },
  },
  {
    stage: 9,
    titleAr: 'تقريب الأعداد العشرية',
    titleEn: 'Rounding Decimals',
    summaryAr: 'ننظر إلى الرقم يمين المنزلة المطلوبة: إذا كان 5 أو أكثر نزيد 1، وإلا نبقي الرقم كما هو.',
    summaryEn: 'Look one digit to the right: if 5 or greater, round up by 1; otherwise keep it.',
    ruleTitleAr: 'قاعدة التقريب',
    ruleTitleEn: 'Rounding Rule',
    ruleFormula: 'digit ≥ 5 → round up;  digit < 5 → keep',
    examples: [
      { problemAr: 'قرّب 3.47 لأقرب جزء من عشرة', problemEn: 'Round 3.47 to nearest tenth', solutionAr: 'الرقم التالي 7 ≥ 5 ← 3.5', solutionEn: 'Next digit 7 ≥ 5 → 3.5', answer: '3.5' },
      { problemAr: 'قرّب 6.82 لأقرب عدد صحيح', problemEn: 'Round 6.82 to nearest integer', solutionAr: '8 ≥ 5 ← 7', solutionEn: '8 ≥ 5 → 7', answer: '7' },
    ],
    generate: (qIdx, isExam) => {
      const w = 2 + qIdx;
      const t = 1 + ((qIdx * 2 + (isExam ? 1 : 0)) % 8);
      const h = (qIdx + (isExam ? 2 : 0)) % 10;
      const num = `${w}.${t}${h}`;
      const rounded = h >= 5 ? `${w}.${t + 1}` : `${w}.${t}`;
      return fracQ(9, qIdx, isExam, `قرّب العدد ${num} إلى أقرب جزء من عشرة (عُشر):`, `Round ${num} to the nearest tenth:`, rounded, [h >= 5 ? `${w}.${t}` : `${w}.${t + 1}`, `${w}`, `${w + 1}`], `بما أن جزء المئة هو ${h} ${h >= 5 ? '≥ 5 فنزيد منزلة الأعشار' : '< 5 فنُبقي منزلة الأعشار'} ليصبح ${rounded}.`, `The hundredths digit is ${h}, rounding to ${rounded}.`);
    },
  },
  {
    stage: 10,
    titleAr: 'التحويل بين الكسور والأعداد العشرية البسيطة',
    titleEn: 'Simple Fraction-Decimal Conversion',
    summaryAr: 'الكسور ذات المقامات 2 و 4 و 5 و 10 تتحول مباشرة إلى أعداد عشرية مألوفة.',
    summaryEn: 'Fractions with denominators 2, 4, 5, 10 convert cleanly into exact decimals.',
    ruleTitleAr: 'القيم المرجعية',
    ruleTitleEn: 'Benchmark Conversions',
    ruleFormula: '1/2 = 0.5 , 1/4 = 0.25 , 1/5 = 0.2',
    examples: [
      { problemAr: 'حوّل 3/4 إلى عدد عشري', problemEn: 'Convert 3/4 to decimal', solutionAr: '3 × 25 / 100 = 0.75', solutionEn: '0.75', answer: '0.75' },
      { problemAr: 'حوّل 2/5 إلى عدد عشري', problemEn: 'Convert 2/5 to decimal', solutionAr: '4/10 = 0.4', solutionEn: '0.4', answer: '0.4' },
    ],
    generate: (qIdx, isExam) => {
      const map: [string, string, string[]][] = [
        ['1/2', '0.5', ['0.2', '0.25', '0.05']],
        ['1/4', '0.25', ['0.4', '0.5', '0.14']],
        ['3/4', '0.75', ['0.34', '0.7', '0.85']],
        ['1/5', '0.2', ['0.5', '0.15', '0.25']],
        ['2/5', '0.4', ['0.25', '0.45', '0.2']],
        ['3/5', '0.6', ['0.35', '0.5', '0.65']],
        ['4/5', '0.8', ['0.45', '0.85', '0.4']],
        ['1/10', '0.1', ['0.01', '0.5', '0.2']],
        ['3/10', '0.3', ['0.03', '0.33', '0.13']],
        ['7/10', '0.7', ['0.07', '0.75', '0.17']],
        ['9/10', '0.9', ['0.09', '0.95', '0.19']],
      ];
      const idx = isExam ? 10 : qIdx;
      const [frac, dec, dist] = map[idx];
      return fracQ(10, qIdx, isExam, `ما الصورة العشرية للكسر ${frac}؟`, `What is ${frac} written as a decimal?`, dec, dist, `بقسمة البسط على المقام في ${frac} نحصل على ${dec}.`, `Dividing numerator by denominator in ${frac} gives ${dec}.`);
    },
  },
  // --- MEDIUM (11 - 20) ---
  {
    stage: 11,
    titleAr: 'جمع الكسور غير متشابهة المقام',
    titleEn: 'Adding Unlike Fractions',
    summaryAr: 'نوحّد المقامات باستخدام المضاعف المشترك الأصغر قبل جمع البسوط.',
    summaryEn: 'Find a common denominator via LCM before adding the numerators.',
    ruleTitleAr: 'توحيد المقامات',
    ruleTitleEn: 'Common Denominator Sum',
    ruleFormula: 'a/b + c/d = (ad + bc) / (bd)',
    examples: [
      { problemAr: 'احسب: 1/2 + 1/3', problemEn: 'Calculate: 1/2 + 1/3', solutionAr: '3/6 + 2/6 = 5/6', solutionEn: '3/6 + 2/6 = 5/6', answer: '5/6' },
      { problemAr: 'احسب: 1/4 + 2/3', problemEn: 'Calculate: 1/4 + 2/3', solutionAr: '3/12 + 8/12 = 11/12', solutionEn: '11/12', answer: '11/12' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const pairs: [number, number, number, number][] = [
        [1, 2, 1, 3], [1, 3, 1, 4], [1, 2, 1, 5], [2, 3, 1, 4], [1, 3, 2, 5],
        [1, 4, 1, 6], [1, 2, 3, 5], [2, 3, 1, 5], [1, 4, 3, 8], [1, 3, 1, 6], [3, 4, 1, 6],
      ];
      const [n1, d1, n2, d2] = pairs[idx];
      const L = lcm(d1, d2);
      const ans = formatFraction(n1 * (L / d1) + n2 * (L / d2), L);
      return fracQ(11, qIdx, isExam, `أوجد ناتج الجمع في أبسط صورة: ${n1}/${d1} + ${n2}/${d2}`, `Add and simplify: ${n1}/${d1} + ${n2}/${d2}`, ans, [`${n1 + n2}/${d1 + d2}`, formatFraction(n1 + n2, L), formatFraction(n1 * d2 + n2 * d1 + 1, d1 * d2)], `نوحد المقامين إلى ${L} ثم نجمع البسطين ونبسّط لنحصل على ${ans}.`, `Converting to common denominator ${L} yields ${ans}.`);
    },
  },
  {
    stage: 12,
    titleAr: 'طرح الكسور غير متشابهة المقام',
    titleEn: 'Subtracting Unlike Fractions',
    summaryAr: 'نوحد المقامات أولاً ثم نطرح البسط الثاني من الأول ونبسّط الناتج.',
    summaryEn: 'Convert to a common denominator first, then subtract numerators and simplify.',
    ruleTitleAr: 'طرح بعد التوحيد',
    ruleTitleEn: 'Unlike Difference',
    ruleFormula: 'a/b − c/d = (ad − bc) / (bd)',
    examples: [
      { problemAr: 'احسب: 3/4 − 1/3', problemEn: 'Calculate: 3/4 − 1/3', solutionAr: '9/12 − 4/12 = 5/12', solutionEn: '5/12', answer: '5/12' },
      { problemAr: 'احسب: 5/6 − 1/2', problemEn: 'Calculate: 5/6 − 1/2', solutionAr: '5/6 − 3/6 = 2/6 = 1/3', solutionEn: '2/6 = 1/3', answer: '1/3' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const pairs: [number, number, number, number][] = [
        [3, 4, 1, 2], [2, 3, 1, 2], [5, 6, 1, 3], [4, 5, 1, 2], [3, 4, 1, 3],
        [5, 6, 1, 4], [7, 8, 1, 4], [4, 5, 1, 3], [5, 8, 1, 2], [2, 3, 1, 6], [7, 10, 1, 5],
      ];
      const [n1, d1, n2, d2] = pairs[idx];
      const L = lcm(d1, d2);
      const ans = formatFraction(n1 * (L / d1) - n2 * (L / d2), L);
      return fracQ(12, qIdx, isExam, `احسب في أبسط صورة: ${n1}/${d1} − ${n2}/${d2}`, `Subtract and simplify: ${n1}/${d1} − ${n2}/${d2}`, ans, [`${Math.abs(n1 - n2) || 1}/${Math.abs(d1 - d2) || 2}`, formatFraction(n1 * (L / d1) + n2 * (L / d2), L), formatFraction(1, d1 + d2)], `نوحد المقامين إلى ${L} ثم نطرح لنحصل على ${ans}.`, `With common denominator ${L}, subtracting gives ${ans}.`);
    },
  },
  {
    stage: 13,
    titleAr: 'ضرب الكسور الاعتيادية',
    titleEn: 'Multiplying Fractions',
    summaryAr: 'في ضرب الكسور نضرب البسط في البسط والمقام في المقام، ثم نبسّط لأبسط صورة.',
    summaryEn: 'Multiply numerator by numerator and denominator by denominator, then simplify.',
    ruleTitleAr: 'قاعدة ضرب الكسور',
    ruleTitleEn: 'Fraction Multiplication',
    ruleFormula: '(a/b) × (c/d) = (a×c) / (b×d)',
    examples: [
      { problemAr: 'احسب: (2/3) × (3/5)', problemEn: 'Calculate: (2/3) × (3/5)', solutionAr: '6/15 = 2/5', solutionEn: '2/5', answer: '2/5' },
      { problemAr: 'احسب: (3/4) × (8/9)', problemEn: 'Calculate: (3/4) × (8/9)', solutionAr: '24/36 = 2/3', solutionEn: '2/3', answer: '2/3' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const cases: [number, number, number, number][] = [
        [2, 3, 3, 4], [3, 5, 5, 6], [2, 5, 3, 4], [4, 7, 7, 8], [3, 4, 2, 9],
        [5, 6, 3, 5], [4, 9, 3, 8], [5, 8, 4, 5], [2, 7, 7, 10], [6, 7, 7, 9], [3, 8, 4, 9],
      ];
      const [n1, d1, n2, d2] = cases[idx];
      const ans = formatFraction(n1 * n2, d1 * d2);
      return fracQ(13, qIdx, isExam, `ما ناتج الضرب في أبسط صورة: (${n1}/${d1}) × (${n2}/${d2})؟`, `Multiply and simplify: (${n1}/${d1}) × (${n2}/${d2})`, ans, [formatFraction(n1 * d2, d1 * n2), formatFraction(n1 + n2, d1 + d2), formatFraction(1, d1 + d2)], `نضرب البسطين (${n1}×${n2}) والمقامين (${d1}×${d2}) ثم نبسّط إلى ${ans}.`, `(${n1}×${n2})/(${d1}×${d2}) simplifies to ${ans}.`);
    },
  },
  {
    stage: 14,
    titleAr: 'قسمة الكسور ومقلوب الكسر',
    titleEn: 'Dividing Fractions (Keep-Change-Flip)',
    summaryAr: 'لقسمة كسر على آخر نثبت الأول ونحوّل القسمة إلى ضرب في مقلوب الكسر الثاني.',
    summaryEn: 'To divide fractions, multiply the first fraction by the reciprocal of the second.',
    ruleTitleAr: 'الضرب في المقلوب',
    ruleTitleEn: 'Reciprocal Rule',
    ruleFormula: '(a/b) ÷ (c/d) = (a/b) × (d/c)',
    examples: [
      { problemAr: 'احسب: (3/4) ÷ (1/2)', problemEn: 'Calculate: (3/4) ÷ (1/2)', solutionAr: '(3/4) × (2/1) = 6/4 = 3/2', solutionEn: '3/2', answer: '3/2' },
      { problemAr: 'احسب: (2/5) ÷ (4/5)', problemEn: 'Calculate: (2/5) ÷ (4/5)', solutionAr: '(2/5) × (5/4) = 2/4 = 1/2', solutionEn: '1/2', answer: '1/2' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const cases: [number, number, number, number][] = [
        [3, 4, 1, 2], [2, 3, 4, 5], [3, 5, 3, 10], [5, 6, 5, 12], [1, 2, 3, 4],
        [4, 7, 2, 7], [5, 8, 5, 4], [3, 4, 9, 8], [2, 9, 4, 3], [7, 10, 7, 5], [3, 7, 6, 7],
      ];
      const [n1, d1, n2, d2] = cases[idx];
      const ans = formatFraction(n1 * d2, d1 * n2);
      return fracQ(14, qIdx, isExam, `احسب في أبسط صورة: (${n1}/${d1}) ÷ (${n2}/${d2})`, `Divide and simplify: (${n1}/${d1}) ÷ (${n2}/${d2})`, ans, [formatFraction(n1 * n2, d1 * d2), formatFraction(d1 * n2, n1 * d2), formatFraction(n1 + n2, d1 + d2)], `نضرب في المقلوب (${n1}/${d1}) × (${d2}/${n2}) لنحصل على ${ans}.`, `Multiplying by the reciprocal (${d2}/${n2}) gives ${ans}.`);
    },
  },
  {
    stage: 15,
    titleAr: 'جمع الأعداد العشرية',
    titleEn: 'Adding Decimals',
    summaryAr: 'نرتب الفواصل العشرية تحت بعضها تماماً ثم نجمع كما في الأعداد الصحيحة.',
    summaryEn: 'Align the decimal points vertically, pad zeros if needed, and add column by column.',
    ruleTitleAr: 'محاذاة الفاصلة',
    ruleTitleEn: 'Decimal Alignment',
    ruleFormula: 'a.bc + d.ef → align decimal points',
    examples: [
      { problemAr: 'احسب: 2.45 + 1.38', problemEn: 'Calculate: 2.45 + 1.38', solutionAr: '3.83', solutionEn: '3.83', answer: '3.83' },
      { problemAr: 'احسب: 4.7 + 0.85', problemEn: 'Calculate: 4.7 + 0.85', solutionAr: '4.70 + 0.85 = 5.55', solutionEn: '5.55', answer: '5.55' },
    ],
    generate: (qIdx, isExam) => {
      const aCents = 125 + qIdx * 37 + (isExam ? 14 : 0);
      const bCents = 85 + qIdx * 23 + (isExam ? 9 : 0);
      const ans = ((aCents + bCents) / 100).toFixed(2);
      const aStr = (aCents / 100).toFixed(2);
      const bStr = (bCents / 100).toFixed(2);
      return fracQ(15, qIdx, isExam, `ما ناتج الجمع: ${aStr} + ${bStr}؟`, `Calculate: ${aStr} + ${bStr}`, ans, [((aCents + bCents + 10) / 100).toFixed(2), ((aCents + bCents - 10) / 100).toFixed(2), ((aCents + bCents + 100) / 100).toFixed(2)], `بمحاذاة الفواصل وجمع الأجزاء العشرية: ${aStr} + ${bStr} = ${ans}.`, `Aligning decimal points gives ${ans}.`);
    },
  },
  {
    stage: 16,
    titleAr: 'طرح الأعداد العشرية',
    titleEn: 'Subtracting Decimals',
    summaryAr: 'نضع أصفاراً يمين الجزء العشري عند الحاجة لتساوي عدد المنازل ثم نطرح.',
    summaryEn: 'Match decimal lengths with trailing zeros if needed, align decimal points, and subtract.',
    ruleTitleAr: 'تساوي المنازل العشرية',
    ruleTitleEn: 'Decimal Padding',
    ruleFormula: '5.4 − 1.28 = 5.40 − 1.28',
    examples: [
      { problemAr: 'احسب: 6.4 − 2.15', problemEn: 'Calculate: 6.4 − 2.15', solutionAr: '6.40 − 2.15 = 4.25', solutionEn: '4.25', answer: '4.25' },
      { problemAr: 'احسب: 10.0 − 3.47', problemEn: 'Calculate: 10 − 3.47', solutionAr: '6.53', solutionEn: '6.53', answer: '6.53' },
    ],
    generate: (qIdx, isExam) => {
      const aCents = 540 + qIdx * 45 + (isExam ? 20 : 0);
      const bCents = 125 + qIdx * 18 + (isExam ? 7 : 0);
      const ans = ((aCents - bCents) / 100).toFixed(2);
      const aStr = (aCents / 100).toFixed(2);
      const bStr = (bCents / 100).toFixed(2);
      return fracQ(16, qIdx, isExam, `احسب: ${aStr} − ${bStr}`, `Calculate: ${aStr} − ${bStr}`, ans, [((aCents - bCents + 10) / 100).toFixed(2), ((aCents - bCents - 10) / 100).toFixed(2), ((aCents - bCents + 100) / 100).toFixed(2)], `بطرح المنازل العشرية مع الاستلاف عند الحاجة: ${aStr} − ${bStr} = ${ans}.`, `Subtracting aligned decimals gives ${ans}.`);
    },
  },
  {
    stage: 17,
    titleAr: 'ضرب الأعداد العشرية',
    titleEn: 'Multiplying Decimals',
    summaryAr: 'نضرب الأعداد دون فواصل ثم نعد إجمالي المنازل العشرية في العاملين لنضع الفاصلة في الناتج.',
    summaryEn: 'Multiply ignoring decimal points, then place the decimal point using the total decimal digits.',
    ruleTitleAr: 'عد المنازل العشرية',
    ruleTitleEn: 'Decimal Place Count',
    ruleFormula: '0.a × 0.b = (a×b) / 100',
    examples: [
      { problemAr: 'احسب: 0.4 × 0.6', problemEn: 'Calculate: 0.4 × 0.6', solutionAr: '4 × 6 = 24، منزلتان عشريتان ← 0.24', solutionEn: '4×6=24 with 2 decimal places → 0.24', answer: '0.24' },
      { problemAr: 'احسب: 1.5 × 0.3', problemEn: 'Calculate: 1.5 × 0.3', solutionAr: '15 × 3 = 45 ← 0.45', solutionEn: '0.45', answer: '0.45' },
    ],
    generate: (qIdx, isExam) => {
      const a = 2 + ((qIdx + (isExam ? 1 : 0)) % 8);
      const b = 3 + ((qIdx * 2 + (isExam ? 1 : 0)) % 7);
      const ans = ((a * b) / 100).toFixed(2);
      return fracQ(17, qIdx, isExam, `ما ناتج: 0.${a} × 0.${b}؟`, `What is 0.${a} × 0.${b}?`, ans, [`${((a * b) / 10).toFixed(1)}`, `0.0${a * b}`, `${((a + b) / 10).toFixed(1)}`], `نضرب ${a} × ${b} = ${a * b} ونضع الفاصلة بعد منزلتين لنحصل على ${ans}.`, `${a} × ${b} = ${a * b} with two decimal places gives ${ans}.`);
    },
  },
  {
    stage: 18,
    titleAr: 'ضرب وقسمة الأعداد العشرية في قوى العشرة',
    titleEn: 'Multiplying & Dividing by 10, 100, 1000',
    summaryAr: 'الضرب في 10 أو 100 يحرك الفاصلة لليمين، والقسمة تحرك الفاصلة لليسار بعدد الأصفار.',
    summaryEn: 'Multiplying by powers of 10 shifts the decimal point right; dividing shifts it left.',
    ruleTitleAr: 'إزاحة الفاصلة',
    ruleTitleEn: 'Decimal Shift',
    ruleFormula: '× 10ⁿ → shift right n;  ÷ 10ⁿ → shift left n',
    examples: [
      { problemAr: 'احسب: 3.48 × 100', problemEn: 'Calculate: 3.48 × 100', solutionAr: 'نزيح الفاصلة منزلتين لليمين ← 348', solutionEn: 'Shift 2 places right → 348', answer: '348' },
      { problemAr: 'احسب: 45.2 ÷ 10', problemEn: 'Calculate: 45.2 ÷ 10', solutionAr: 'نزيح الفاصلة منزلة لليسار ← 4.52', solutionEn: 'Shift 1 place left → 4.52', answer: '4.52' },
    ],
    generate: (qIdx, isExam) => {
      const base = (12 + qIdx * 7 + (isExam ? 3 : 0)) / 10;
      const mult = qIdx % 2 === 0;
      const factor = qIdx % 3 === 0 ? 100 : 10;
      const ansNum = mult ? Number((base * factor).toFixed(4)) : Number((base / factor).toFixed(4));
      const ans = String(ansNum);
      return fracQ(18, qIdx, isExam, `احسب: ${base} ${mult ? '×' : '÷'} ${factor}`, `Calculate: ${base} ${mult ? '×' : '÷'} ${factor}`, ans, [String(Number((base * (mult ? 1 : 10)).toFixed(4)) + 0.1), String(Number((ansNum * 10).toFixed(4))), String(Number((ansNum / 10).toFixed(5)))], `بإزاحة الفاصلة ${factor === 100 ? 'منزلتين' : 'منزلة'} ${mult ? 'لليمين' : 'لليسار'} نحصل على ${ans}.`, `Shifting the decimal point yields ${ans}.`);
    },
  },
  {
    stage: 19,
    titleAr: 'قسمة الأعداد العشرية',
    titleEn: 'Dividing Decimals',
    summaryAr: 'نتخلص من الفاصلة في المقسوم عليه بضرب الطرفين في 10 أو 100 ثم نقسم بشكل طبيعي.',
    summaryEn: 'Multiply both dividend and divisor by a power of 10 to make the divisor a whole number.',
    ruleTitleAr: 'تحويل المقسوم عليه لعدد صحيح',
    ruleTitleEn: 'Whole Divisor Scaling',
    ruleFormula: 'a ÷ b = (10k·a) ÷ (10k·b)',
    examples: [
      { problemAr: 'احسب: 4.8 ÷ 0.6', problemEn: 'Calculate: 4.8 ÷ 0.6', solutionAr: '48 ÷ 6 = 8', solutionEn: '48 ÷ 6 = 8', answer: '8' },
      { problemAr: 'احسب: 0.72 ÷ 0.9', problemEn: 'Calculate: 0.72 ÷ 0.9', solutionAr: '7.2 ÷ 9 = 0.8', solutionEn: '0.8', answer: '0.8' },
    ],
    generate: (qIdx, isExam) => {
      const divisor = 2 + ((qIdx + (isExam ? 1 : 0)) % 8);
      const ans = 3 + ((qIdx * 2 + (isExam ? 1 : 0)) % 9);
      const dividend = ((divisor * ans) / 10).toFixed(1);
      const divisorStr = `0.${divisor}`;
      return fracQ(19, qIdx, isExam, `ما ناتج القسمة: ${dividend} ÷ ${divisorStr}؟`, `Calculate: ${dividend} ÷ ${divisorStr}`, String(ans), numericDistractors(ans, [1, -1, 2, -2]), `نضرب المقسوم والمقسوم عليه في 10 فتصبح ${divisor * ans} ÷ ${divisor} = ${ans}.`, `Multiplying both by 10 gives ${divisor * ans} ÷ ${divisor} = ${ans}.`);
    },
  },
  {
    stage: 20,
    titleAr: 'جمع وطرح الأعداد الكسرية',
    titleEn: 'Adding & Subtracting Mixed Numbers',
    summaryAr: 'نجمع أو نطرح الأجزاء الصحيحة والكسور بعد توحيد المقامات، أو نحوّلها لكسور غير فعلية.',
    summaryEn: 'Convert mixed numbers to improper fractions with a common denominator, then operate.',
    ruleTitleAr: 'طريقة التحويل الشاملة',
    ruleTitleEn: 'Improper Fraction Method',
    ruleFormula: 'A(b/c) + D(e/f) → common denominator',
    examples: [
      { problemAr: 'احسب: 1 1/2 + 2 1/4', problemEn: 'Calculate: 1 1/2 + 2 1/4', solutionAr: '3/2 + 9/4 = 6/4 + 9/4 = 15/4', solutionEn: '15/4', answer: '15/4' },
      { problemAr: 'احسب: 3 1/3 − 1 2/3', problemEn: 'Calculate: 3 1/3 − 1 2/3', solutionAr: '10/3 − 5/3 = 5/3', solutionEn: '5/3', answer: '5/3' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const cases: [number, number, number, number, number][] = [
        [1, 1, 3, 1, 1], [1, 1, 4, 2, 1], [1, 2, 5, 1, 2], [2, 1, 3, 1, 1],
        [1, 3, 4, 2, 1], [2, 2, 5, 1, 1], [1, 1, 6, 2, 5], [2, 3, 8, 1, 1],
        [1, 2, 7, 2, 3], [3, 1, 4, 1, 1], [2, 1, 5, 2, 3],
      ];
      const [w1, n1, d, w2, n2] = cases[idx];
      const top = w1 * d + n1 + (w2 * d + n2);
      const ans = formatFraction(top, d);
      return fracQ(20, qIdx, isExam, `احسب مجموع العددين الكسريين (بصورة كسر مبسط): (${w1} و ${n1}/${d}) + (${w2} و ${n2}/${d})`, `Add and express as a simplified fraction: ${w1} ${n1}/${d} + ${w2} ${n2}/${d}`, ans, [formatFraction(top + 1, d), formatFraction(top - 1, d), `${w1 + w2}/${d}`], `نحوّل كل عدد كسري إلى كسر غير فعلي ثم نجمع ونبسّط: ${ans}.`, `Converting to improper fractions and summing yields ${ans}.`);
    },
  },
  // --- HARD (21 - 30) ---
  {
    stage: 21,
    titleAr: 'ضرب وقسمة الأعداد الكسرية',
    titleEn: 'Multiplying & Dividing Mixed Numbers',
    summaryAr: 'يجب تحويل الأعداد الكسرية دائماً إلى كسور غير فعلية قبل إجراء الضرب أو القسمة.',
    summaryEn: 'Always convert mixed numbers into improper fractions before multiplying or dividing.',
    ruleTitleAr: 'التحويل قبل الضرب',
    ruleTitleEn: 'Convert First Rule',
    ruleFormula: 'A(b/c) × D(e/f) = [(Ac+b)/c] × [(Df+e)/f]',
    examples: [
      { problemAr: 'احسب: 1 1/2 × 2 2/3', problemEn: 'Calculate: 1 1/2 × 2 2/3', solutionAr: '(3/2) × (8/3) = 4', solutionEn: '4', answer: '4' },
      { problemAr: 'احسب: 2 1/4 ÷ 1 1/2', problemEn: 'Calculate: 2 1/4 ÷ 1 1/2', solutionAr: '(9/4) × (2/3) = 3/2', solutionEn: '3/2', answer: '3/2' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const cases: [number, number, number, number, number, number][] = [
        [1, 1, 2, 1, 1, 3], [1, 1, 3, 1, 1, 2], [2, 1, 2, 1, 1, 5], [1, 2, 3, 1, 1, 5],
        [2, 1, 4, 1, 1, 3], [1, 3, 4, 1, 1, 7], [2, 1, 3, 1, 2, 7], [1, 1, 4, 1, 3, 5],
        [1, 1, 2, 2, 2, 3], [2, 1, 2, 1, 1, 2], [1, 2, 5, 1, 3, 7],
      ];
      const [w1, n1, d1, w2, n2, d2] = cases[idx];
      const f1 = w1 * d1 + n1;
      const f2 = w2 * d2 + n2;
      const ans = formatFraction(f1 * f2, d1 * d2);
      return fracQ(21, qIdx, isExam, `احسب في أبسط صورة: (${w1} و ${n1}/${d1}) × (${w2} و ${n2}/${d2})`, `Multiply and simplify: (${w1} ${n1}/${d1}) × (${w2} ${n2}/${d2})`, ans, [formatFraction(f1 * f2 + 1, d1 * d2), `${w1 * w2 + 1}`, formatFraction(f1 + f2, d1 * d2)], `نحوّل إلى (${f1}/${d1}) × (${f2}/${d2}) ثم نبسّط الناتج إلى ${ans}.`, `Convert to (${f1}/${d1}) × (${f2}/${d2}) and simplify to ${ans}.`);
    },
  },
  {
    stage: 22,
    titleAr: 'الربط بين الكسر والعدد العشري والنسبة المئوية',
    titleEn: 'Fractions, Decimals & Percentages',
    summaryAr: 'النسبة المئوية هي كسر مقامه 100؛ وللتحويل من عدد عشري لنسبة مئوية نضرب في 100.',
    summaryEn: 'Percent means per hundred; multiply a decimal or fraction by 100 to express as a percentage.',
    ruleTitleAr: 'مثلث التحويلات',
    ruleTitleEn: 'Conversion Triangle',
    ruleFormula: 'Fraction × 100 = Percentage (%)',
    examples: [
      { problemAr: 'حوّل 3/8 إلى عدد عشري', problemEn: 'Convert 3/8 to decimal', solutionAr: '0.375', solutionEn: '0.375', answer: '0.375' },
      { problemAr: 'ما الكسر المكافئ للعدد العشري 0.65 في أبسط صورة؟', problemEn: 'Simplify 0.65 as a fraction', solutionAr: '65/100 = 13/20', solutionEn: '13/20', answer: '13/20' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const items: [string, string, string[]][] = [
        ['0.125', '1/8', ['1/4', '1/12', '3/8']],
        ['0.375', '3/8', ['3/10', '1/3', '5/8']],
        ['0.625', '5/8', ['3/5', '5/12', '7/8']],
        ['0.875', '7/8', ['7/10', '4/5', '5/8']],
        ['0.35', '7/20', ['7/10', '3/5', '1/3']],
        ['0.45', '9/20', ['4/5', '9/10', '2/5']],
        ['0.55', '11/20', ['5/9', '11/10', '1/2']],
        ['0.65', '13/20', ['3/5', '13/25', '7/10']],
        ['0.85', '17/20', ['4/5', '17/25', '9/10']],
        ['0.16', '4/25', ['1/6', '4/10', '8/25']],
        ['0.28', '7/25', ['2/7', '7/20', '14/25']],
      ];
      const [dec, frac, dist] = items[idx];
      return fracQ(22, qIdx, isExam, `اكتب العدد العشري ${dec} على صورة كسر اعتيادي في أبسط صورة:`, `Express ${dec} as a simplified fraction:`, frac, dist, `بتحويل ${dec} إلى كسر مقامه 100 أو 1000 والتبسيط نحصل على ${frac}.`, `Writing ${dec} over 100 or 1000 and simplifying gives ${frac}.`);
    },
  },
  {
    stage: 23,
    titleAr: 'مقارنة الأعداد العشرية والكسور معاً',
    titleEn: 'Ordering Mixed Fractions & Decimals',
    summaryAr: 'للمقارنة بين كسور وأعداد عشرية نحوّل الجميع إلى صيغة موحدة (عشرية عادةً).',
    summaryEn: 'Convert both fractions and decimals into the same form before comparing.',
    ruleTitleAr: 'توحيد الصيغة',
    ruleTitleEn: 'Uniform Format',
    ruleFormula: 'Compare via decimal expansion',
    examples: [
      { problemAr: 'أيهما أكبر: 0.72 أم 3/4؟', problemEn: 'Greater: 0.72 or 3/4?', solutionAr: '3/4 = 0.75 > 0.72 ← 3/4', solutionEn: '3/4 = 0.75 > 0.72', answer: '3/4' },
      { problemAr: 'أيهما أصغر: 0.38 أم 2/5؟', problemEn: 'Smaller: 0.38 or 2/5?', solutionAr: '2/5 = 0.40 ← 0.38 أصغر', solutionEn: '0.38 < 0.40', answer: '0.38' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const sets: [string, string, string, string][] = [
        ['0.78', '3/4', '0.7', '2/3'],
        ['4/5', '0.75', '0.72', '3/4'],
        ['0.63', '3/5', '0.58', '1/2'],
        ['7/8', '0.85', '4/5', '0.82'],
        ['0.42', '2/5', '0.39', '3/8'],
        ['5/8', '0.6', '0.59', '1/2'],
        ['0.91', '7/8', '0.89', '4/5'],
        ['3/4', '0.72', '0.68', '5/8'],
        ['0.52', '1/2', '2/5', '0.49'],
        ['0.82', '4/5', '3/4', '0.79'],
        ['0.68', '2/3', '5/8', '0.64'],
      ];
      const [maxVal, a, b, c] = sets[idx];
      const all = [maxVal, a, b, c];
      const shift = idx % 4;
      const displayList = [...all.slice(shift), ...all.slice(0, shift)].join(' ، ');
      return fracQ(23, qIdx, isExam, `أي قيمة من القيم التالية هي الأكبر: (${displayList})؟`, `Which value is greatest among (${displayList})?`, maxVal, [a, b, c], `بتحويل الكسور إلى أعداد عشرية نجد أن ${maxVal} هو الأكبر.`, `Converting all entries to decimals shows ${maxVal} is largest.`);
    },
  },
  {
    stage: 24,
    titleAr: 'الكسور المركبة (كسر على كسر)',
    titleEn: 'Complex Fractions',
    summaryAr: 'الكسر المركب يعني قسمة الكسر في البسط على الكسر في المقام.',
    summaryEn: 'A complex fraction represents dividing the numerator expression by the denominator expression.',
    ruleTitleAr: 'تبسيط الكسر المركب',
    ruleTitleEn: 'Complex Fraction Rule',
    ruleFormula: '(a/b) / (c/d) = (a·d) / (b·c)',
    examples: [
      { problemAr: 'بسّط: (2/3) / (4/9)', problemEn: 'Simplify: (2/3) / (4/9)', solutionAr: '(2/3) × (9/4) = 18/12 = 3/2', solutionEn: '3/2', answer: '3/2' },
      { problemAr: 'بسّط: (3/5) / (6/5)', problemEn: 'Simplify: (3/5) / (6/5)', solutionAr: '3/6 = 1/2', solutionEn: '1/2', answer: '1/2' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const items: [number, number, number, number][] = [
        [2, 3, 4, 9], [3, 4, 9, 8], [1, 2, 3, 8], [5, 6, 5, 3], [2, 5, 4, 15],
        [3, 7, 6, 7], [4, 5, 2, 5], [5, 8, 5, 4], [7, 9, 14, 3], [1, 3, 2, 9], [3, 8, 3, 4],
      ];
      const [a, b, c, d] = items[idx];
      const ans = formatFraction(a * d, b * c);
      return fracQ(24, qIdx, isExam, `بسّط الكسر المركب: (${a}/${b}) ÷ (${c}/${d})`, `Simplify the complex fraction: (${a}/${b}) / (${c}/${d})`, ans, [formatFraction(a * c, b * d), formatFraction(b * c, a * d), formatFraction(a + c, b + d)], `(${a}/${b}) × (${d}/${c}) = ${ans}.`, `(${a}/${b}) × (${d}/${c}) = ${ans}.`);
    },
  },
  {
    stage: 25,
    titleAr: 'العمليات الحسابية على الكسور السالبة',
    titleEn: 'Negative Fractions Arithmetic',
    summaryAr: 'تطبق نفس قواعد إشارات الأعداد الصحيحة عند جمع وضرب وقسمة الكسور السالبة.',
    summaryEn: 'Apply integer sign rules consistently when adding, subtracting, or multiplying negative fractions.',
    ruleTitleAr: 'إشارات الكسور',
    ruleTitleEn: 'Signed Fractions',
    ruleFormula: '-(a/b) + (c/b) = (c − a)/b',
    examples: [
      { problemAr: 'احسب: (-3/4) + (1/2)', problemEn: 'Evaluate: (-3/4) + (1/2)', solutionAr: '-3/4 + 2/4 = -1/4', solutionEn: '-1/4', answer: '-1/4' },
      { problemAr: 'احسب: (-2/3) × (-3/5)', problemEn: 'Evaluate: (-2/3) × (-3/5)', solutionAr: '+2/5', solutionEn: '2/5', answer: '2/5' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const cases: [number, number, number][] = [
        [1, 3, 4], [1, 5, 6], [3, 7, 8], [1, 7, 10], [5, 11, 12],
        [2, 5, 7], [3, 8, 9], [1, 4, 5], [3, 10, 11], [5, 9, 14], [7, 11, 16],
      ];
      const [n1, n2, den] = cases[idx];
      const ans = formatFraction(n1 - n2, den);
      return fracQ(25, qIdx, isExam, `احسب: (${n1}/${den}) − (${n2}/${den})`, `Evaluate: (${n1}/${den}) − (${n2}/${den})`, ans, [formatFraction(n2 - n1, den), formatFraction(-(n1 + n2), den), formatFraction(n1 - n2, den * 2)], `(${n1} − ${n2})/${den} = ${ans}.`, `(${n1} − ${n2})/${den} = ${ans}.`);
    },
  },
  {
    stage: 26,
    titleAr: 'ترتيب العمليات مع الكسور والأعداد العشرية',
    titleEn: 'Order of Operations with Fractions & Decimals',
    summaryAr: 'ننفذ الضرب والقسمة بين الكسور قبل الجمع والطرح مع توحيد الصيغ.',
    summaryEn: 'Evaluate fraction multiplication/division before addition/subtraction.',
    ruleTitleAr: 'أسبقية العمليات للكسور',
    ruleTitleEn: 'Fraction Precedence',
    ruleFormula: 'a/b + (c/d × e/f)',
    examples: [
      { problemAr: 'احسب: 1/2 + (1/3 × 3/4)', problemEn: 'Evaluate: 1/2 + (1/3 × 3/4)', solutionAr: '1/2 + 1/4 = 3/4', solutionEn: '3/4', answer: '3/4' },
      { problemAr: 'احسب: 0.5 + 0.25 × 2', problemEn: 'Evaluate: 0.5 + 0.25 × 2', solutionAr: '0.5 + 0.5 = 1', solutionEn: '1', answer: '1' },
    ],
    generate: (qIdx, isExam) => {
      const k = 2 + ((qIdx + (isExam ? 1 : 0)) % 5);
      const a = 0.5 + qIdx * 0.2;
      const b = 0.25;
      const ans = Number((a + b * k).toFixed(2));
      return fracQ(26, qIdx, isExam, `احسب: ${a.toFixed(1)} + ${b} × ${k}`, `Evaluate: ${a.toFixed(1)} + ${b} × ${k}`, String(ans), [String(Number(((a + b) * k).toFixed(2))), String(Number((ans + 0.5).toFixed(2))), String(Number((ans - 0.25).toFixed(2)))], `الضرب أولاً: ${b} × ${k} = ${(b * k).toFixed(2)}، ثم + ${a.toFixed(1)} = ${ans}.`, `Multiply first: ${b} × ${k} = ${(b * k).toFixed(2)}, then add ${a.toFixed(1)} = ${ans}.`);
    },
  },
  {
    stage: 27,
    titleAr: 'الكسور الدورية وتحويلها لكسور اعتيادية',
    titleEn: 'Repeating Decimals to Fractions',
    summaryAr: 'العدد العشري الدوري مثل ...0.333 يساوي 1/3، و ...0.abab يساوي ab/99.',
    summaryEn: 'A single-digit repeating decimal 0.ddd... equals d/9.',
    ruleTitleAr: 'قاعدة الكسر الدوري',
    ruleTitleEn: 'Repeating Decimal Rule',
    ruleFormula: '0.d̄ = d/9 ,  0.āb̄ = ab/99',
    examples: [
      { problemAr: 'حوّل ...0.333 إلى كسر', problemEn: 'Convert 0.333... to fraction', solutionAr: '3/9 = 1/3', solutionEn: '1/3', answer: '1/3' },
      { problemAr: 'حوّل ...0.666 إلى كسر', problemEn: 'Convert 0.666... to fraction', solutionAr: '6/9 = 2/3', solutionEn: '2/3', answer: '2/3' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const cases: [string, string, string[], string][] = [
        ['0.111...', '1/9', ['1/10', '1/11', '2/9'], '1/9'],
        ['0.222...', '2/9', ['1/5', '2/11', '1/3'], '2/9'],
        ['0.333...', '1/3', ['3/10', '1/4', '2/3'], '3/9'],
        ['0.444...', '4/9', ['2/5', '4/11', '5/9'], '4/9'],
        ['0.555...', '5/9', ['1/2', '5/11', '4/9'], '5/9'],
        ['0.666...', '2/3', ['3/5', '6/11', '1/3'], '6/9'],
        ['0.777...', '7/9', ['7/10', '7/11', '8/9'], '7/9'],
        ['0.888...', '8/9', ['4/5', '8/11', '7/9'], '8/9'],
        ['0.121212...', '4/33', ['3/25', '1/8', '12/101'], '12/99'],
        ['0.151515...', '5/33', ['3/20', '1/6', '15/98'], '15/99'],
        ['0.212121...', '7/33', ['21/100', '1/5', '2/9'], '21/99'],
      ];
      const [rep, ans, dist, rawFrac] = cases[idx];
      return fracQ(27, qIdx, isExam, `ما الكسر الاعتيادي المكافئ للعدد الدوري ${rep}؟`, `What simplified fraction equals the repeating decimal ${rep}?`, ans, dist, `${rep} = ${rawFrac} وبالتبسيط يعطي ${ans}.`, `${rep} = ${rawFrac}, which simplifies to ${ans}.`);
    },
  },
  {
    stage: 28,
    titleAr: 'حساب كسر من كمية',
    titleEn: 'Finding a Fraction of a Quantity',
    summaryAr: 'لإيجاد كسر من عدد نضرب الكسر في ذلك العدد (نقسم على المقام ثم نضرب في البسط).',
    summaryEn: 'Multiply the fraction by the whole quantity: divide by the denominator, then multiply by numerator.',
    ruleTitleAr: 'كسر من عدد',
    ruleTitleEn: 'Fraction of Whole',
    ruleFormula: '(a/b) of N = (N ÷ b) × a',
    examples: [
      { problemAr: 'ما 3/5 من 45؟', problemEn: 'What is 3/5 of 45?', solutionAr: '(45 ÷ 5) × 3 = 9 × 3 = 27', solutionEn: '9 × 3 = 27', answer: '27' },
      { problemAr: 'ما 4/7 من 63؟', problemEn: 'What is 4/7 of 63?', solutionAr: '9 × 4 = 36', solutionEn: '36', answer: '36' },
    ],
    generate: (qIdx, isExam) => {
      const den = 3 + ((qIdx + (isExam ? 1 : 0)) % 7);
      const num = 2 + (qIdx % (den - 1));
      const unit = 4 + qIdx;
      const total = den * unit;
      const ans = num * unit;
      return fracQ(28, qIdx, isExam, `ما قيمة ${num}/${den} من العدد ${total}؟`, `What is ${num}/${den} of ${total}?`, String(ans), numericDistractors(ans, [unit, -unit, num, -num]), `(${total} ÷ ${den}) × ${num} = ${unit} × ${num} = ${ans}.`, `(${total} ÷ ${den}) × ${num} = ${ans}.`);
    },
  },
  {
    stage: 29,
    titleAr: 'مسائل كلامية في الكسور والأعداد العشرية',
    titleEn: 'Fraction & Decimal Word Problems',
    summaryAr: 'تطبيق جمع وطرح وضرب الكسور في الميزانيات والمسافات والكميات اليومية.',
    summaryEn: 'Apply fraction and decimal operations to real-world measurements and sharing problems.',
    ruleTitleAr: 'الجزء المتبقي',
    ruleTitleEn: 'Remaining Fraction',
    ruleFormula: 'Remaining = 1 − Used Fraction',
    examples: [
      { problemAr: 'قرأ طالب 2/5 من كتاب في اليوم الأول و 1/5 في الثاني، ما الكسر المتبقي؟', problemEn: 'Read 2/5 on day 1 and 1/5 on day 2. Remaining fraction?', solutionAr: '1 − 3/5 = 2/5', solutionEn: '2/5', answer: '2/5' },
      { problemAr: 'خزان فيه 12.5 لتراً أضيف إليه 3.75 لتراً، كم أصبح فيه؟', problemEn: '12.5 L plus 3.75 L?', solutionAr: '16.25 لتراً', solutionEn: '16.25 L', answer: '16.25' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const den = 5 + idx;
      const p1 = 1 + (idx % 2);
      const p2 = 1 + ((idx + 1) % 2);
      const ans = formatFraction(den - p1 - p2, den);
      return fracQ(29, qIdx, isExam, `أنجز مهندس ${p1}/${den} من المشروع في الأسبوع الأول و ${p2}/${den} في الأسبوع الثاني، ما الكسر المتبقي لإتمام المشروع؟`, `An engineer completed ${p1}/${den} of a project in week 1 and ${p2}/${den} in week 2. What fraction remains?`, ans, [formatFraction(den - p1 - p2 - 1, den), formatFraction(den - 1, den), formatFraction(1, den + 1)], `المتبقي = 1 − (${p1 + p2}/${den}) = ${ans}.`, `Remaining = 1 − ${p1 + p2}/${den} = ${ans}.`);
    },
  },
  {
    stage: 30,
    titleAr: 'التحدي المتكامل للكسور والأعداد العشرية',
    titleEn: 'Master Fractions & Decimals Challenge',
    summaryAr: 'حل مسائل مركبة تجمع التحويلات العشرية مع جمع وضرب وقسمة الكسور.',
    summaryEn: 'Solve multi-step expressions combining fraction division, multiplication, and decimals.',
    ruleTitleAr: 'التكامل الكسري والعشري',
    ruleTitleEn: 'Integrated Rational Arithmetic',
    ruleFormula: '(a/b + dec) × c/d',
    examples: [
      { problemAr: 'احسب: (1/2 + 0.25) × 8', problemEn: 'Evaluate: (1/2 + 0.25) × 8', solutionAr: '0.75 × 8 = 6', solutionEn: '6', answer: '6' },
      { problemAr: 'احسب: (3/4 − 0.25) ÷ (1/6)', problemEn: 'Evaluate: (3/4 − 0.25) ÷ (1/6)', solutionAr: '0.5 × 6 = 3', solutionEn: '3', answer: '3' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const mult = 4 * (1 + idx);
      const dec = idx % 2 === 0 ? 0.25 : 0.75;
      const fracStr = idx % 2 === 0 ? '1/2' : '1/4';
      const sum = idx % 2 === 0 ? 0.75 : 1;
      const ans = Math.round(sum * mult);
      return fracQ(30, qIdx, isExam, `احسب قيمة: (${fracStr} + ${dec}) × ${mult}`, `Evaluate: (${fracStr} + ${dec}) × ${mult}`, String(ans), numericDistractors(ans, [2, -2, 4, -4]), `${fracStr} + ${dec} = ${sum}، وبضرب الناتج في ${mult} نحصل على ${ans}.`, `${fracStr} + ${dec} = ${sum}; multiplying by ${mult} gives ${ans}.`);
    },
  },
];

export const FRACTIONS_STAGES: StageDefinition[] = TOPICS.map((spec) => {
  const questions: QuizQuestion[] = [];
  for (let i = 0; i < 10; i++) {
    questions.push(spec.generate(i, false));
  }
  const examQuestion = spec.generate(10, true);

  return {
    id: makeStageId('fractions', spec.stage),
    sectionId: 'fractions',
    stageNumber: spec.stage,
    difficulty: getDifficultyForStage(spec.stage),
    titleAr: spec.titleAr,
    titleEn: spec.titleEn,
    lesson: {
      summaryAr: spec.summaryAr,
      summaryEn: spec.summaryEn,
      ruleTitleAr: spec.ruleTitleAr,
      ruleTitleEn: spec.ruleTitleEn,
      ruleFormula: spec.ruleFormula,
      examples: spec.examples,
    },
    questions,
    examQuestion,
  };
});
