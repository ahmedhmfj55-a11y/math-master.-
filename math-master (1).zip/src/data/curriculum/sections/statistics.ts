import {
  buildChoiceQuestion,
  formatFraction,
  getDifficultyForStage,
  makeStageId,
  numericDistractors,
} from '@/src/data/curriculum/helpers';
import type { QuizQuestion, StageDefinition, WorkedExample } from '@/src/types/curriculum';

interface StatsTopicSpec {
  stage: number;
  titleAr: string;
  titleEn: string;
  summaryAr: string;
  summaryEn: string;
  ruleTitleAr: string;
  ruleTitleEn: string;
  ruleFormula: string;
  examples: [WorkedExample, WorkedExample];
  generate: (qIdx: number, isExam: boolean) => QuizQuestion;
}

function makeNumericQ(
  stage: number,
  qIdx: number,
  isExam: boolean,
  promptAr: string,
  promptEn: string,
  correct: number,
  offsets: number[],
  explanationAr: string,
  explanationEn: string,
): QuizQuestion {
  const id = isExam ? `statistics-exam-s${stage}` : `statistics-s${stage}-q${qIdx + 1}`;
  return buildChoiceQuestion({
    id,
    promptAr,
    promptEn,
    correctValue: String(correct),
    distractors: numericDistractors(correct, offsets, false),
    explanationAr,
    explanationEn,
    seedKey: `${id}-${promptEn}`,
  });
}

function makeTextQ(
  stage: number,
  qIdx: number,
  isExam: boolean,
  promptAr: string,
  promptEn: string,
  correctValue: string,
  distractors: string[],
  explanationAr: string,
  explanationEn: string,
): QuizQuestion {
  const id = isExam ? `statistics-exam-s${stage}` : `statistics-s${stage}-q${qIdx + 1}`;
  return buildChoiceQuestion({
    id,
    promptAr,
    promptEn,
    correctValue,
    distractors,
    explanationAr,
    explanationEn,
    seedKey: `${id}-${promptEn}`,
  });
}

const TOPICS: StatsTopicSpec[] = [
  // EASY (1..10)
  {
    stage: 1,
    titleAr: 'قراءة الجداول التكرارية',
    titleEn: 'Reading Frequency Tables',
    summaryAr: 'الجدول التكراري ينظم البيانات ويعرض عدد مرات تكرار كل فئة أو قيمة لتسهيل تحليلها ومجموعها.',
    summaryEn: 'A frequency table organizes data by showing how many times each value or category occurs.',
    ruleTitleAr: 'مجموع التكرارات',
    ruleTitleEn: 'Total Frequency',
    ruleFormula: 'المجموع الكلي = مجموع جميع التكرارات',
    examples: [
      { problemAr: 'تكرارات الألوان (أحمر: 5، أزرق: 8، أخضر: 7)، ما العدد الكلي؟', problemEn: 'Frequencies (Red: 5, Blue: 8, Green: 7). Total count?', solutionAr: '5 + 8 + 7 = 20.', solutionEn: '5 + 8 + 7 = 20.', answer: '20' },
      { problemAr: 'إذا كان المجموع 30 وتكرار فئتين 12 و10، فما تكرار الثالثة؟', problemEn: 'Total 30, two classes are 12 and 10. Third?', solutionAr: '30 - (12 + 10) = 8.', solutionEn: '30 - 22 = 8.', answer: '8' },
    ],
    generate: (qIdx, isExam) => {
      const a = 4 + (qIdx % 5);
      const b = 6 + ((qIdx + 2) % 6);
      const c = 5 + ((qIdx + (isExam ? 3 : 1)) % 7);
      const total = a + b + c;
      return makeNumericQ(
        1, qIdx, isExam,
        `في استطلاع لرياضة مفضلة كانت التكرارات: كرة القدم ${a}، السباحة ${b}، الجري ${c}. ما العدد الكلي للمشاركين؟`,
        `In a survey, votes were Football: ${a}, Swimming: ${b}, Running: ${c}. How many participants in total?`,
        total,
        [2, -2, 4, -1],
        `نجمع التكرارات: ${a} + ${b} + ${c} = ${total}.`,
        `Sum the frequencies: ${a} + ${b} + ${c} = ${total}.`,
      );
    },
  },
  {
    stage: 2,
    titleAr: 'المنوال (القيمة الأكثر تكراراً)',
    titleEn: 'The Mode',
    summaryAr: 'المنوال هو القيمة الأكثر شيوعاً أو تكراراً في مجموعة البيانات.',
    summaryEn: 'The mode is the value that appears most frequently in a data set.',
    ruleTitleAr: 'تعريف المنوال',
    ruleTitleEn: 'Mode Definition',
    ruleFormula: 'المنوال = القيمة ذات التكرار الأعلى',
    examples: [
      { problemAr: 'ما المنوال للبيانات: 4، 7، 4، 9، 6، 4؟', problemEn: 'Mode of: 4, 7, 4, 9, 6, 4?', solutionAr: 'العدد 4 تكرر 3 مرات، فهو المنوال.', solutionEn: '4 appears 3 times, so the mode is 4.', answer: '4' },
      { problemAr: 'ما المنوال للبيانات: 12، 15، 15، 10، 15، 12؟', problemEn: 'Mode of: 12, 15, 15, 10, 15, 12?', solutionAr: '15 تكرر 3 مرات، أكثر من 12 (مرتين).', solutionEn: '15 appears 3 times.', answer: '15' },
    ],
    generate: (qIdx, isExam) => {
      const mode = 5 + qIdx + (isExam ? 2 : 0);
      const o1 = mode + 3;
      const o2 = mode - 2;
      const o3 = mode + 6;
      const list = [o1, mode, o2, mode, o3, mode, o1];
      return makeNumericQ(
        2, qIdx, isExam,
        `ما المنوال لمجموعة القيم التالية: ${list.join('، ')}؟`,
        `What is the mode of the data set: ${list.join(', ')}?`,
        mode,
        [3, -2, 6, 1],
        `القيمة ${mode} تكررت 3 مرات وهي الأكثر تكراراً.`,
        `The value ${mode} appears 3 times, more than any other value.`,
      );
    },
  },
  {
    stage: 3,
    titleAr: 'المدى وتشتت البيانات',
    titleEn: 'The Range of Data',
    summaryAr: 'المدى يقيس انتشار البيانات ويساوي الفرق بين أكبر قيمة وأصغر قيمة في المجموعة.',
    summaryEn: 'The range measures data spread by taking the difference between the maximum and minimum values.',
    ruleTitleAr: 'قانون المدى',
    ruleTitleEn: 'Range Formula',
    ruleFormula: 'المدى = أكبر قيمة - أصغر قيمة',
    examples: [
      { problemAr: 'أوجد المدى للبيانات: 12، 5، 19، 8، 14', problemEn: 'Find the range of: 12, 5, 19, 8, 14', solutionAr: '19 - 5 = 14.', solutionEn: '19 - 5 = 14.', answer: '14' },
      { problemAr: 'أعلى درجة 95 وأدنى درجة 62، ما المدى؟', problemEn: 'Highest 95, lowest 62. Range?', solutionAr: '95 - 62 = 33.', solutionEn: '95 - 62 = 33.', answer: '33' },
    ],
    generate: (qIdx, isExam) => {
      const minVal = 4 + qIdx * 2;
      const range = 12 + qIdx * 3 + (isExam ? 4 : 0);
      const maxVal = minVal + range;
      const mid1 = minVal + 4;
      const mid2 = maxVal - 3;
      return makeNumericQ(
        3, qIdx, isExam,
        `احسب المدى للقيم التالية: ${mid1}، ${maxVal}، ${minVal}، ${mid2}، ${minVal + 2}`,
        `Find the range of: ${mid1}, ${maxVal}, ${minVal}, ${mid2}, ${minVal + 2}`,
        range,
        [2, -2, minVal, 5],
        `المدى = أكبر قيمة (${maxVal}) - أصغر قيمة (${minVal}) = ${range}.`,
        `Range = max (${maxVal}) - min (${minVal}) = ${range}.`,
      );
    },
  },
  {
    stage: 4,
    titleAr: 'الوسيط لعدد فردي من القيم',
    titleEn: 'Median (Odd Count)',
    summaryAr: 'لإيجاد الوسيط نرتب القيم تصاعدياً أو تنازلياً ثم نختار القيمة التي تقع في المنتصف تماماً.',
    summaryEn: 'Sort the data in order; for an odd count, the median is the exact middle number.',
    ruleTitleAr: 'موقع الوسيط',
    ruleTitleEn: 'Median Position',
    ruleFormula: 'نرتب القيم ← الوسيط هو القيمة الوسطى',
    examples: [
      { problemAr: 'أوجد الوسيط للقيم: 9، 3، 7، 1، 5', problemEn: 'Median of: 9, 3, 7, 1, 5', solutionAr: 'بعد الترتيب: 1، 3، 5، 7، 9 ← الوسطى 5.', solutionEn: 'Sorted: 1, 3, 5, 7, 9 → middle is 5.', answer: '5' },
      { problemAr: 'الوسيط للأعداد 14، 10، 18، 12، 20', problemEn: 'Median of 14, 10, 18, 12, 20', solutionAr: 'بعد الترتيب: 10، 12، 14، 18، 20 ← 14.', solutionEn: 'Sorted middle is 14.', answer: '14' },
    ],
    generate: (qIdx, isExam) => {
      const a = 3 + qIdx;
      const b = a + 3;
      const med = b + 4 + (isExam ? 1 : 0);
      const d = med + 5;
      const e = d + 6;
      const shuffled = [d, a, e, med, b];
      return makeNumericQ(
        4, qIdx, isExam,
        `ما الوسيط للقيم التالية: ${shuffled.join('، ')}؟`,
        `What is the median of: ${shuffled.join(', ')}?`,
        med,
        [b - med, d - med, 2, -2],
        `بعد الترتيب تصاعدياً: ${a}، ${b}، ${med}، ${d}، ${e}، القيمة الوسطى هي ${med}.`,
        `Sorted: ${a}, ${b}, ${med}, ${d}, ${e}. The middle value is ${med}.`,
      );
    },
  },
  {
    stage: 5,
    titleAr: 'الوسيط لعدد زوجي من القيم',
    titleEn: 'Median (Even Count)',
    summaryAr: 'إذا كان عدد القيم زوجياً، نرتبها ثم نحسب المتوسط الحسابي للقيمتين الواقعتين في المنتصف.',
    summaryEn: 'For an even number of sorted values, the median is the average of the two middle values.',
    ruleTitleAr: 'الوسيط للعدد الزوجي',
    ruleTitleEn: 'Even-Count Median',
    ruleFormula: 'الوسيط = (الأوسط الأول + الأوسط الثاني) ÷ 2',
    examples: [
      { problemAr: 'الوسيط للقيم: 4، 8، 12، 16', problemEn: 'Median of: 4, 8, 12, 16', solutionAr: '(8 + 12) ÷ 2 = 10.', solutionEn: '(8 + 12) ÷ 2 = 10.', answer: '10' },
      { problemAr: 'الوسيط للقيم: 20، 6، 14، 10', problemEn: 'Median of: 20, 6, 14, 10', solutionAr: 'الترتيب: 6، 10، 14، 20 → (10 + 14)÷2 = 12.', solutionEn: 'Sorted: 6, 10, 14, 20 → (10+14)/2 = 12.', answer: '12' },
    ],
    generate: (qIdx, isExam) => {
      const m1 = 8 + qIdx * 2 + (isExam ? 2 : 0);
      const m2 = m1 + 4;
      const med = (m1 + m2) / 2;
      const low = m1 - 5;
      const high = m2 + 6;
      const arr = [high, m1, low, m2];
      return makeNumericQ(
        5, qIdx, isExam,
        `احسب الوسيط للقيم التالية: ${arr.join('، ')}`,
        `Find the median of: ${arr.join(', ')}`,
        med,
        [2, -2, 4, -4],
        `بعد الترتيب: ${low}، ${m1}، ${m2}، ${high}. الوسيط = (${m1} + ${m2}) ÷ 2 = ${med}.`,
        `Sorted: ${low}, ${m1}, ${m2}, ${high}. Median = (${m1} + ${m2}) ÷ 2 = ${med}.`,
      );
    },
  },
  {
    stage: 6,
    titleAr: 'المتوسط الحسابي (المعدل)',
    titleEn: 'The Arithmetic Mean',
    summaryAr: 'المتوسط الحسابي يساوي مجموع القيم مقسوماً على عددها.',
    summaryEn: 'The arithmetic mean equals the sum of all values divided by the number of values.',
    ruleTitleAr: 'قانون المتوسط الحسابي',
    ruleTitleEn: 'Mean Formula',
    ruleFormula: 'المتوسط = مجموع القيم ÷ عددها',
    examples: [
      { problemAr: 'أوجد المتوسط الحسابي للأعداد: 6، 8، 10، 12', problemEn: 'Find the mean of: 6, 8, 10, 12', solutionAr: 'المجموع 36 ÷ 4 = 9.', solutionEn: 'Sum 36 ÷ 4 = 9.', answer: '9' },
      { problemAr: 'المتوسط للأعداد: 15، 20، 25', problemEn: 'Mean of: 15, 20, 25', solutionAr: '60 ÷ 3 = 20.', solutionEn: '60 ÷ 3 = 20.', answer: '20' },
    ],
    generate: (qIdx, isExam) => {
      const mean = 10 + qIdx * 3 + (isExam ? 2 : 0);
      const vals = [mean - 4, mean - 1, mean + 2, mean + 3];
      return makeNumericQ(
        6, qIdx, isExam,
        `ما المتوسط الحسابي للأعداد: ${vals.join('، ')}؟`,
        `What is the arithmetic mean of: ${vals.join(', ')}?`,
        mean,
        [1, -1, 2, -2, 3],
        `المجموع = ${mean * 4}، وعدد القيم 4، إذن المتوسط = ${mean * 4} ÷ 4 = ${mean}.`,
        `Sum = ${mean * 4}, divided by 4 values gives ${mean}.`,
      );
    },
  },
  {
    stage: 7,
    titleAr: 'قراءة الأعمدة والخطوط البيانية',
    titleEn: 'Interpreting Bar & Line Charts',
    summaryAr: 'تُقارن الأعمدة البيانية بين الفئات وتُظهر الخطوط البيانية التغيّر عبر الزمن.',
    summaryEn: 'Bar charts compare categories while line graphs track changes across time intervals.',
    ruleTitleAr: 'تحليل الفروق في الرسوم',
    ruleTitleEn: 'Chart Comparison',
    ruleFormula: 'الزيادة = القيمة العليا - القيمة الدنيا',
    examples: [
      { problemAr: 'مبيعات يناير 40 وفبراير 65 ومارس 55، ما الفرق بين الأعلى والأدنى؟', problemEn: 'Sales: Jan 40, Feb 65, Mar 55. Difference between max and min?', solutionAr: '65 - 40 = 25.', solutionEn: '65 - 40 = 25.', answer: '25' },
      { problemAr: 'كم إجمالي المبيعات في الأشهر الثلاثة؟', problemEn: 'Total sales across the 3 months?', solutionAr: '40 + 65 + 55 = 160.', solutionEn: '40 + 65 + 55 = 160.', answer: '160' },
    ],
    generate: (qIdx, isExam) => {
      const v1 = 20 + qIdx * 4;
      const v2 = v1 + 15 + (isExam ? 5 : 0);
      const v3 = v1 + 8;
      const v4 = v2 + 10;
      const diff = v4 - v1;
      return makeNumericQ(
        7, qIdx, isExam,
        `يمثل رسم بالأعمدة درجات الحرارة لأربعة أيام: ${v1}، ${v2}، ${v3}، ${v4}. ما الفرق بين أعلى درجة وأدنى درجة؟`,
        `A bar chart shows temperatures over 4 days: ${v1}, ${v2}, ${v3}, ${v4}. What is the difference between the highest and lowest?`,
        diff,
        [5, -5, 10, -4],
        `أعلى درجة ${v4} وأدنى درجة ${v1}، الفرق = ${v4} - ${v1} = ${diff}.`,
        `Highest is ${v4} and lowest is ${v1}; difference = ${diff}.`,
      );
    },
  },
  {
    stage: 8,
    titleAr: 'مقدمة في الاحتمال البسيط',
    titleEn: 'Basic Probability',
    summaryAr: 'الاحتمال هو نسبة عدد النتائج المواتية إلى العدد الكلي للنتائج الممكنة، ويتراوح بين 0 و1.',
    summaryEn: 'Probability is the number of favorable outcomes divided by total equally likely outcomes, from 0 to 1.',
    ruleTitleAr: 'قانون الاحتمال',
    ruleTitleEn: 'Probability Formula',
    ruleFormula: 'P(A) = عدد نواتج A ÷ العدد الكلي للنواتج',
    examples: [
      { problemAr: 'كيس فيه 3 كرات حمراء و5 زرقاء، ما احتمال سحب كرة حمراء؟', problemEn: 'Bag has 3 red and 5 blue balls. Probability of red?', solutionAr: '3 ÷ (3 + 5) = 3/8.', solutionEn: '3 ÷ 8 = 3/8.', answer: '3/8' },
      { problemAr: 'ما احتمال ظهور عدد زوجي عند رمي حجر نرد؟', problemEn: 'Probability of even number on a fair die?', solutionAr: 'الأعداد الزوجية {2,4,6} أي 3/6 = 1/2.', solutionEn: '3/6 = 1/2.', answer: '1/2' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const fav = 2 + (idx % 4);
      const other = 4 + idx;
      const total = fav + other;
      const ans = formatFraction(fav, total);
      return makeTextQ(
        8, qIdx, isExam,
        `صندوق يحوي ${fav} بطاقات خضراء و${other} بطاقات صفراء. ما احتمال سحب بطاقة خضراء عشوائياً؟`,
        `A box contains ${fav} green cards and ${other} yellow cards. What is the probability of drawing a green card?`,
        ans,
        [formatFraction(other, total), formatFraction(fav, other), formatFraction(fav + 1, total + 1)],
        `العدد الكلي = ${total}، إذن الاحتمال = ${fav}/${total} = ${ans}.`,
        `Total = ${total}, so probability = ${fav}/${total} = ${ans}.`,
      );
    },
  },
  {
    stage: 9,
    titleAr: 'الحدث المستحيل والحدث المؤكد',
    titleEn: 'Certain, Likely & Impossible Events',
    summaryAr: 'احتمال الحدث المستحيل يساوي 0، واحتمال الحدث المؤكد يساوي 1 (أو 100%).',
    summaryEn: 'An impossible event has probability 0, while a certain event has probability 1.',
    ruleTitleAr: 'حدود الاحتمال',
    ruleTitleEn: 'Probability Bounds',
    ruleFormula: '0 ≤ P(A) ≤ 1',
    examples: [
      { problemAr: 'حجر نرد مرقم 1 إلى 6، ما احتمال ظهور العدد 7؟', problemEn: 'Rolling a 1–6 die, probability of rolling 7?', solutionAr: 'لا يوجد 7، الحدث مستحيل واحتماله 0.', solutionEn: 'Impossible → 0.', answer: '0' },
      { problemAr: 'ما احتمال ظهور عدد أصغر من 10 على حجر النرد؟', problemEn: 'Probability of rolling a number less than 10 on a die?', solutionAr: 'جميع النواتج أصغر من 10، فهو مؤكد = 1.', solutionEn: 'All faces are < 10 → 1.', answer: '1' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const threshold = 7 + idx;
      const isImpossible = idx % 2 === 0;
      if (isImpossible) {
        return makeNumericQ(
          9, qIdx, isExam,
          `عند رمي حجر نرد عادي مرقم من 1 إلى 6، ما احتمال ظهور العدد ${threshold}؟`,
          `When rolling a standard 1–6 die, what is the probability of rolling ${threshold}?`,
          0,
          [1, 6, 2, 3],
          `العدد ${threshold} غير موجود على حجر النرد، لذا فهو حدث مستحيل احتماله 0.`,
          `${threshold} is not on a 1–6 die, so the event is impossible with probability 0.`,
        );
      }
      return makeNumericQ(
        9, qIdx, isExam,
        `عند رمي حجر نرد عادي (1 إلى 6)، ما احتمال ظهور عدد أقل من ${threshold}؟`,
        `When rolling a standard 1–6 die, what is the probability of rolling a number less than ${threshold}?`,
        1,
        [0, 6, 2, 5],
        `جميع الأرقام من 1 إلى 6 أقل من ${threshold}، لذا فهو حدث مؤكد احتماله 1.`,
        `All outcomes 1–6 are less than ${threshold}, so it is certain with probability 1.`,
      );
    },
  },
  {
    stage: 10,
    titleAr: 'مبدأ العد البسيط (الاحتمالات الثنائية)',
    titleEn: 'Simple Counting Principle',
    summaryAr: 'إذا كان لدينا m خيار للأولى وn خيار للثانية، فإن العدد الكلي للتراكيب الممكنة يساوي m × n.',
    summaryEn: 'If step 1 has m choices and step 2 has n choices, total combinations equal m × n.',
    ruleTitleAr: 'مبدأ العد الأساسي',
    ruleTitleEn: 'Counting Principle',
    ruleFormula: 'عدد النواتج = m × n',
    examples: [
      { problemAr: '3 قمصان و4 سراويل، كم إطلالة مختلفة يمكن تكوينها؟', problemEn: '3 shirts and 4 pants. How many outfits?', solutionAr: '3 × 4 = 12 إطلالة.', solutionEn: '3 × 4 = 12 outfits.', answer: '12' },
      { problemAr: 'رمي عملة وحجر نرد معاً، كم عدد النواتج الكلي؟', problemEn: 'Toss a coin and roll a die. Total outcomes?', solutionAr: '2 × 6 = 12 ناتجاً.', solutionEn: '2 × 6 = 12 outcomes.', answer: '12' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const m = 3 + (idx % 5);
      const n = 4 + idx;
      const total = m * n;
      return makeNumericQ(
        10, qIdx, isExam,
        `يقدّم مطعم ${m} أطباق رئيسية و${n} عصائر مختلفة. بكم طريقة يمكن اختيار وجبة تتكون من طبق واحد وعصير واحد؟`,
        `A café offers ${m} main dishes and ${n} drinks. How many different meal pairs of 1 dish and 1 drink are possible?`,
        total,
        [m + n, 2, -2, m],
        `حسب مبدأ العد: ${m} × ${n} = ${total} طريقة.`,
        `By the counting principle: ${m} × ${n} = ${total} choices.`,
      );
    },
  },

  // MEDIUM (11..20)
  {
    stage: 11,
    titleAr: 'الاحتمال المتمم',
    titleEn: 'Complementary Events',
    summaryAr: 'احتمال عدم وقوع الحدث يساوي 1 مطروحاً منه احتمال وقوعه.',
    summaryEn: 'The probability that an event does NOT occur is 1 minus the probability that it occurs.',
    ruleTitleAr: 'احتمال الحدث المتمم',
    ruleTitleEn: 'Complement Rule',
    ruleFormula: 'P(ليس A) = 1 - P(A)',
    examples: [
      { problemAr: 'إذا كان احتمال هطول المطر 35%، فما احتمال عدم هطوله؟', problemEn: 'If chance of rain is 35%, probability of no rain?', solutionAr: '100% - 35% = 65%.', solutionEn: '100% - 35% = 65%.', answer: '65%' },
      { problemAr: 'إذا كان P(A) = 2/7، ما قيمة P(ليس A)؟', problemEn: 'If P(A) = 2/7, find P(not A)', solutionAr: '1 - 2/7 = 5/7.', solutionEn: '1 - 2/7 = 5/7.', answer: '5/7' },
    ],
    generate: (qIdx, isExam) => {
      const pPct = 15 + qIdx * 6 + (isExam ? 3 : 0);
      const comp = 100 - pPct;
      return makeTextQ(
        11, qIdx, isExam,
        `إذا كان احتمال فوز فريق في مباراة هو ${pPct}%، فما احتمال ألا يفوز؟`,
        `If the probability of a team winning is ${pPct}%, what is the probability of NOT winning?`,
        `${comp}%`,
        [`${comp + 10}%`, `${Math.max(5, comp - 10)}%`, `${pPct}%`],
        `الحدث المتمم = 100% - ${pPct}% = ${comp}%.`,
        `Complement = 100% - ${pPct}% = ${comp}%.`,
      );
    },
  },
  {
    stage: 12,
    titleAr: 'إيجاد قيمة مفقودة بمعلومية المتوسط',
    titleEn: 'Finding a Missing Value from the Mean',
    summaryAr: 'بضرب المتوسط في عدد القيم نحصل على المجموع الكلي، ثم نطرح القيم المعروفة لإيجاد القيمة المفقودة.',
    summaryEn: 'Multiply the mean by the count of numbers to get the total sum, then subtract the known values.',
    ruleTitleAr: 'علاقة المجموع بالمتوسط',
    ruleTitleEn: 'Sum from Mean',
    ruleFormula: 'المفقود = (المتوسط × العدد) - مجموع القيم المعلومة',
    examples: [
      { problemAr: 'متوسط 4 أعداد هو 10، وثلاثة منها 8، 9، 11. ما الرابع؟', problemEn: 'Mean of 4 numbers is 10. Three are 8, 9, 11. Fourth?', solutionAr: 'المجموع = 40، الرابع = 40 - 28 = 12.', solutionEn: 'Sum = 40, fourth = 40 - 28 = 12.', answer: '12' },
      { problemAr: 'متوسط 3 اختبارات 80، حصلت على 75 و85، ما الثالث؟', problemEn: 'Mean of 3 tests is 80; two are 75 and 85. Third?', solutionAr: '240 - 160 = 80.', solutionEn: '240 - 160 = 80.', answer: '80' },
    ],
    generate: (qIdx, isExam) => {
      const mean = 12 + qIdx * 2 + (isExam ? 3 : 0);
      const a = mean - 3;
      const b = mean + 1;
      const c = mean - 2;
      const missing = 4 * mean - (a + b + c);
      return makeNumericQ(
        12, qIdx, isExam,
        `المتوسط الحسابي لأربعة أعداد هو ${mean}. إذا كانت ثلاثة منها هي ${a}، ${b}، ${c}، فما العدد الرابع؟`,
        `The mean of 4 numbers is ${mean}. If three of them are ${a}, ${b}, and ${c}, what is the fourth number?`,
        missing,
        [2, -2, 4, -3],
        `المجموع الكلي = 4 × ${mean} = ${4 * mean}. العدد الرابع = ${4 * mean} - ${a + b + c} = ${missing}.`,
        `Total sum = 4 × ${mean} = ${4 * mean}. Fourth = ${4 * mean} - ${a + b + c} = ${missing}.`,
      );
    },
  },
  {
    stage: 13,
    titleAr: 'القطاعات الدائرية وزواياها',
    titleEn: 'Pie Charts & Sector Angles',
    summaryAr: 'مجموع زوايا الدائرة 360°، ولإيجاد زاوية قطاع نضرب نسبته المئوية في 360°.',
    summaryEn: 'A full circle is 360°. Multiply a category’s fraction or percentage by 360° to find its central angle.',
    ruleTitleAr: 'زاوية القطاع الدائري',
    ruleTitleEn: 'Sector Angle Formula',
    ruleFormula: 'الزاوية = (النسبة% ÷ 100) × 360°',
    examples: [
      { problemAr: 'قطاع يمثل 25% من الدائرة، ما قياس زاويته بالدرجات؟', problemEn: 'A sector represents 25%. What is its angle?', solutionAr: '0.25 × 360 = 90°.', solutionEn: '0.25 × 360 = 90°.', answer: '90' },
      { problemAr: 'زاوية قطاع 72°، ما نسبته المئوية؟', problemEn: 'Angle is 72°. What percent?', solutionAr: '(72 ÷ 360) × 100 = 20%.', solutionEn: '20%.', answer: '20%' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const pcts = [10, 15, 20, 25, 30, 35, 40, 45, 50, 60, 75];
      const pct = pcts[idx];
      const angle = (pct * 360) / 100;
      return makeNumericQ(
        13, qIdx, isExam,
        `في مخطط القطاعات الدائرية، ما قياس الزاوية المركزية لقطاع يمثل ${pct}% من البيانات (بالدرجات)؟`,
        `In a pie chart, what is the central angle (in degrees) of a sector representing ${pct}%?`,
        angle,
        [18, -18, 36, -10],
        `الزاوية = (${pct} ÷ 100) × 360° = ${angle}°.`,
        `Angle = (${pct} ÷ 100) × 360° = ${angle}°.`,
      );
    },
  },
  {
    stage: 14,
    titleAr: 'تأثير التعديل على مقاييس النزعة المركزية',
    titleEn: 'How Adding a Constant Shifts Statistics',
    summaryAr: 'عند إضافة ثابت k لجميع القيم يزداد المتوسط والوسيط والمنوال بمقدار k، بينما يبقى المدى ثابتاً.',
    summaryEn: 'Adding a constant k to every data value shifts the mean, median, and mode by +k, while the range stays unchanged.',
    ruleTitleAr: 'قاعدة الإزاحة الخطية',
    ruleTitleEn: 'Data Shift Rule',
    ruleFormula: 'المتوسط الجديد = القديم + k ، والمدى لا يتغير',
    examples: [
      { problemAr: 'متوسط 5 أعداد 20، أُضيف 4 لكل عدد، ما المتوسط الجديد؟', problemEn: 'Mean is 20; 4 is added to each number. New mean?', solutionAr: '20 + 4 = 24.', solutionEn: '20 + 4 = 24.', answer: '24' },
      { problemAr: 'مدى بيانات 15، أُضيف 7 لكل قيمة، ما المدى الجديد؟', problemEn: 'Range is 15; add 7 to each. New range?', solutionAr: 'يبقى المدى 15 دون تغيير.', solutionEn: 'Range remains 15.', answer: '15' },
    ],
    generate: (qIdx, isExam) => {
      const oldMean = 18 + qIdx * 3;
      const k = 4 + (qIdx % 6) + (isExam ? 2 : 0);
      const newMean = oldMean + k;
      return makeNumericQ(
        14, qIdx, isExam,
        `إذا كان المتوسط الحسابي لدرجات طلاب يساوي ${oldMean}، وتمت إضافة ${k} درجات لكل طالب، فكم يصبح المتوسط الجديد؟`,
        `The mean of student scores is ${oldMean}. If ${k} bonus points are added to every student, what is the new mean?`,
        newMean,
        [-k, 2, k * 2, oldMean - k],
        `إضافة ثابت ${k} لجميع القيم يرفع المتوسط بالمقدار نفسه: ${oldMean} + ${k} = ${newMean}.`,
        `Adding ${k} to every value increases the mean by ${k}: ${oldMean} + ${k} = ${newMean}.`,
      );
    },
  },
  {
    stage: 15,
    titleAr: 'الأحداث المتنافية واحتمال الاتحاد',
    titleEn: 'Mutually Exclusive Events (OR Rule)',
    summaryAr: 'إذا كان الحدثان متنافيين (لا يقعان معاً)، فإن احتمال وقوع أحدهما أو الآخر يساوي مجموع احتماليهما.',
    summaryEn: 'For mutually exclusive events A and B, P(A or B) = P(A) + P(B).',
    ruleTitleAr: 'جمع الاحتمالات المتنافية',
    ruleTitleEn: 'Addition Rule',
    ruleFormula: 'P(A أو B) = P(A) + P(B)',
    examples: [
      { problemAr: 'كيس فيه 3 حمراء و4 خضراء و5 زرقاء، ما احتمال سحب حمراء أو خضراء؟', problemEn: '3 red, 4 green, 5 blue. P(red or green)?', solutionAr: '(3 + 4) / 12 = 7/12.', solutionEn: '7/12.', answer: '7/12' },
      { problemAr: 'حجر نرد: احتمال ظهور 1 أو 6؟', problemEn: 'Fair die: P(1 or 6)?', solutionAr: '1/6 + 1/6 = 2/6 = 1/3.', solutionEn: '1/3.', answer: '1/3' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const r = 2 + (idx % 4);
      const g = 3 + ((idx + 1) % 4);
      const b = 3 + idx;
      const total = r + g + b;
      const ans = formatFraction(r + g, total);
      return makeTextQ(
        15, qIdx, isExam,
        `في وعاء ${r} كرات حمراء و${g} خضراء و${b} بيضاء. ما احتمال سحب كرة حمراء أو خضراء؟`,
        `A jar has ${r} red, ${g} green, and ${b} white marbles. What is the probability of drawing red or green?`,
        ans,
        [formatFraction(r, total), formatFraction(g, total), formatFraction(b, total)],
        `P(حمراء أو خضراء) = (${r} + ${g}) ÷ ${total} = ${r + g}/${total} = ${ans}.`,
        `P(red or green) = (${r} + ${g}) / ${total} = ${ans}.`,
      );
    },
  },
  {
    stage: 16,
    titleAr: 'الأحداث المستقلة واحتمال التقاطع',
    titleEn: 'Independent Events (AND Rule)',
    summaryAr: 'عند وقوع حدثين مستقلين معاً (مع الإرجاع أو رمي قطعتين)، نضرب احتمال الأول في احتمال الثاني.',
    summaryEn: 'For independent events, the probability that both occur is P(A) × P(B).',
    ruleTitleAr: 'ضرب الاحتمالات المستقلة',
    ruleTitleEn: 'Multiplication Rule',
    ruleFormula: 'P(A و B) = P(A) × P(B)',
    examples: [
      { problemAr: 'رمي عملتين معدنيتين، ما احتمال ظهور صورة في كلتيهما؟', problemEn: 'Toss two coins. Probability of two heads?', solutionAr: '1/2 × 1/2 = 1/4.', solutionEn: '1/2 × 1/2 = 1/4.', answer: '1/4' },
      { problemAr: 'رمي عملة وحجر نرد، احتمال صورة والعدد 6؟', problemEn: 'Coin and die: P(Heads and 6)?', solutionAr: '1/2 × 1/6 = 1/12.', solutionEn: '1/12.', answer: '1/12' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const a = 1 + (idx % 2);
      const d1 = 3 + (idx % 3);
      const b = 1 + (idx % 2);
      const d2 = 4 + idx;
      const ans = formatFraction(a * b, d1 * d2);
      return makeTextQ(
        16, qIdx, isExam,
        `احتمال الحدث المستقل الأول ${a}/${d1} واحتمال الثاني ${b}/${d2}. ما احتمال وقوعهما معاً؟`,
        `Two independent events have probabilities ${a}/${d1} and ${b}/${d2}. What is the probability that both occur?`,
        ans,
        [formatFraction(a + b, d1 + d2), formatFraction(a * b, d1 + d2), formatFraction(a, d1 * d2)],
        `نضرب الاحتمالين: (${a}/${d1}) × (${b}/${d2}) = ${ans}.`,
        `Multiply probabilities: (${a}/${d1}) × (${b}/${d2}) = ${ans}.`,
      );
    },
  },
  {
    stage: 17,
    titleAr: 'التوقع التكراري من الاحتمال',
    titleEn: 'Expected Frequency',
    summaryAr: 'التوقع لعدد مرات حدوث نتيجة خلال N تجربة يساوي احتمال النتيجة مضروباً في N.',
    summaryEn: 'Expected count over N trials equals Probability × N.',
    ruleTitleAr: 'قانون التكرار المتوقع',
    ruleTitleEn: 'Expected Count Formula',
    ruleFormula: 'التوقع = N × P(A)',
    examples: [
      { problemAr: 'رمينا حجر نرد 60 مرة، كم مرة نتوقع ظهور العدد 5؟', problemEn: 'Roll a die 60 times. Expected number of 5s?', solutionAr: '60 × (1/6) = 10 مرات.', solutionEn: '60 × (1/6) = 10.', answer: '10' },
      { problemAr: 'احتمال النجاح 0.8 من 150 محاولة، ما العدد المتوقع؟', problemEn: 'Success prob 0.8 in 150 trials. Expected?', solutionAr: '150 × 0.8 = 120.', solutionEn: '150 × 0.8 = 120.', answer: '120' },
    ],
    generate: (qIdx, isExam) => {
      const den = [4, 5, 6, 8, 10][qIdx % 5];
      const num = 1 + (qIdx % (den - 1));
      const trials = den * (10 + qIdx * 2 + (isExam ? 3 : 0));
      const expected = (trials * num) / den;
      return makeNumericQ(
        17, qIdx, isExam,
        `احتمال إصابة الهدف في كل رمية هو ${num}/${den}. إذا سُددت ${trials} رمية، فكم إصابة متوقعة؟`,
        `The probability of hitting a target is ${num}/${den}. In ${trials} shots, what is the expected number of hits?`,
        expected,
        [10, -10, 5, -5],
        `التوقع = ${trials} × (${num}/${den}) = ${expected}.`,
        `Expected = ${trials} × (${num}/${den}) = ${expected}.`,
      );
    },
  },
  {
    stage: 18,
    titleAr: 'مبدأ العد الأساسي المتعدد',
    titleEn: 'Multi-Step Counting & Passcodes',
    summaryAr: 'لحساب عدد الرموز أو الطرق ذات المراحل المتعددة نضرب عدد خيارات كل منزلة في الأخرى.',
    summaryEn: 'Multiply the number of available choices for each position to find total multi-step arrangements.',
    ruleTitleAr: 'الضرب في مبدأ العد',
    ruleTitleEn: 'Sequential Counting',
    ruleFormula: 'العدد الكلي = n₁ × n₂ × n₃',
    examples: [
      { problemAr: 'رمز من 3 خانات حيث كل خانة لها 5 أرقام (مع التكرار)، كم رمزاً ممكناً؟', problemEn: '3-digit code with 5 choices per digit (repeats allowed). Total?', solutionAr: '5 × 5 × 5 = 125.', solutionEn: '5 × 5 × 5 = 125.', answer: '125' },
      { problemAr: 'اختيار رقم من {1,2,3} دون تكرار لتكوين عدد من منزلتين', problemEn: '2-digit number from {1,2,3} without repetition', solutionAr: '3 × 2 = 6 أعداد.', solutionEn: '3 × 2 = 6.', answer: '6' },
    ],
    generate: (qIdx, isExam) => {
      const c1 = 2 + (qIdx % 4);
      const c2 = 3 + (qIdx % 3);
      const c3 = 4 + ((qIdx + (isExam ? 1 : 0)) % 4);
      const total = c1 * c2 * c3;
      return makeNumericQ(
        18, qIdx, isExam,
        `كلمة مرور تتكون من ${c1} خيارات للخانة الأولى، و${c2} للثانية، و${c3} للثالثة. كم كلمة مرور مختلفة يمكن تكوينها؟`,
        `A code has ${c1} choices for the 1st slot, ${c2} for the 2nd, and ${c3} for the 3rd. How many codes are possible?`,
        total,
        [c1 + c2 + c3, 4, -4, c1 * c2],
        `العدد الكلي = ${c1} × ${c2} × ${c3} = ${total}.`,
        `Total = ${c1} × ${c2} × ${c3} = ${total}.`,
      );
    },
  },
  {
    stage: 19,
    titleAr: 'المتوسط المرجّح (الموزون)',
    titleEn: 'Weighted Mean',
    summaryAr: 'عند دمج مجموعتين بأحجام مختلفة، لا نأخذ متوسط المتوسطين، بل نحسب المجموع الكلي ÷ العدد الكلي.',
    summaryEn: 'When combining groups of different sizes, divide the combined total sum by the combined count.',
    ruleTitleAr: 'قانون المتوسط الموزون',
    ruleTitleEn: 'Weighted Average Formula',
    ruleFormula: 'المتوسط العام = (n₁x̄₁ + n₂x̄₂) ÷ (n₁ + n₂)',
    examples: [
      { problemAr: 'متوسط 4 طلاب 80، ومتوسط 6 طلاب 90، ما متوسط الجميع؟', problemEn: '4 students avg 80, 6 students avg 90. Combined mean?', solutionAr: '(320 + 540) ÷ 10 = 86.', solutionEn: '860 ÷ 10 = 86.', answer: '86' },
      { problemAr: '2 أعداد متوسطها 10 و3 أعداد متوسطها 20', problemEn: '2 numbers avg 10, 3 avg 20', solutionAr: '(20 + 60) ÷ 5 = 16.', solutionEn: '80 ÷ 5 = 16.', answer: '16' },
    ],
    generate: (qIdx, isExam) => {
      const n1 = 2 + (qIdx % 3);
      const n2 = n1 + 2;
      const m1 = 10 + qIdx * 2;
      const m2 = m1 + (n1 + n2) * (1 + (isExam ? 1 : 0));
      const combined = (n1 * m1 + n2 * m2) / (n1 + n2);
      return makeNumericQ(
        19, qIdx, isExam,
        `متوسط ${n1} أعداد هو ${m1}، ومتوسط ${n2} أعداد أخرى هو ${m2}. ما المتوسط الحسابي لجميع الأعداد معاً؟`,
        `The mean of ${n1} numbers is ${m1}, and the mean of ${n2} other numbers is ${m2}. What is the combined mean?`,
        combined,
        [Math.round((m1 + m2) / 2) - combined || 2, -2, 4, -4],
        `المجموع الكلي = (${n1}×${m1}) + (${n2}×${m2}) = ${n1 * m1 + n2 * m2}، وبالقسمة على ${n1 + n2} ينتج ${combined}.`,
        `Combined sum = ${n1 * m1 + n2 * m2}, divided by ${n1 + n2} = ${combined}.`,
      );
    },
  },
  {
    stage: 20,
    titleAr: 'الربيعيات والمدى الربيعي',
    titleEn: 'Quartiles & Interquartile Range (IQR)',
    summaryAr: 'المدى الربيعي هو الفرق بين الربيع الثالث Q₃ والربيع الأول Q₁، ويقيس تشتت النصف الأوسط من البيانات.',
    summaryEn: 'The interquartile range (IQR = Q₃ − Q₁) measures the spread of the middle 50% of data.',
    ruleTitleAr: 'قانون المدى الربيعي',
    ruleTitleEn: 'IQR Formula',
    ruleFormula: 'IQR = Q₃ − Q₁',
    examples: [
      { problemAr: 'للقيم المرتبة: 2، 4، 6، 8، 10، 12، 14 ما قيمة IQR؟', problemEn: 'Sorted: 2, 4, 6, 8, 10, 12, 14. Find IQR.', solutionAr: 'الوسيط 8، النصف الأدنى {2,4,6} ← Q₁=4، النصف الأعلى {10,12,14} ← Q₃=12. IQR = 12 - 4 = 8.', solutionEn: 'Q₁=4, Q₃=12, IQR = 8.', answer: '8' },
      { problemAr: 'إذا كان Q₁ = 15 و Q₃ = 27 فما المدى الربيعي؟', problemEn: 'Q₁ = 15 and Q₃ = 27. IQR?', solutionAr: '27 - 15 = 12.', solutionEn: '27 - 15 = 12.', answer: '12' },
    ],
    generate: (qIdx, isExam) => {
      const start = 2 + qIdx * 2;
      const step = 2 + ((qIdx + (isExam ? 1 : 0)) % 4);
      const data = Array.from({ length: 7 }, (_, i) => start + i * step);
      const q1 = data[1];
      const q3 = data[5];
      const iqr = q3 - q1;
      return makeNumericQ(
        20, qIdx, isExam,
        `أوجد المدى الربيعي (IQR = Q₃ - Q₁) للبيانات المرتبة: ${data.join('، ')}`,
        `Find the interquartile range (IQR) of the sorted data: ${data.join(', ')}`,
        iqr,
        [data[6] - data[0] - iqr, 2, -2, step],
        `Q₁ = ${q1} و Q₃ = ${q3}، إذن IQR = ${q3} - ${q1} = ${iqr}.`,
        `Q₁ = ${q1} and Q₃ = ${q3}, so IQR = ${q3} - ${q1} = ${iqr}.`,
      );
    },
  },

  // HARD (21..30)
  {
    stage: 21,
    titleAr: 'التباديل والترتيب الخطي (!n)',
    titleEn: 'Permutations & Factorials',
    summaryAr: 'عدد طرق ترتيب n عنصراً مختلفاً في صف هو مضروب العدد n! = n × (n-1) × ... × 1، وترتيب r من n هو P(n,r).',
    summaryEn: 'The number of ordered arrangements of r items chosen from n distinct items is P(n, r) = n! / (n − r)!.',
    ruleTitleAr: 'قانون التباديل',
    ruleTitleEn: 'Permutation Formula',
    ruleFormula: 'P(n, r) = n × (n-1) × ... × (n-r+1)',
    examples: [
      { problemAr: 'بكم طريقة يقف 4 طلاب في صف واحد؟', problemEn: 'How many ways can 4 students stand in a line?', solutionAr: '4! = 4 × 3 × 2 × 1 = 24.', solutionEn: '4! = 24.', answer: '24' },
      { problemAr: 'اختيار رئيس ونائب من بين 5 أعضاء؟', problemEn: 'Choose President and VP from 5 members?', solutionAr: '5 × 4 = 20.', solutionEn: '5 × 4 = 20.', answer: '20' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const n = 4 + idx;
      const r = 2 + (idx % 2);
      const ans = r === 2 ? n * (n - 1) : n * (n - 1) * (n - 2);
      return makeNumericQ(
        21, qIdx, isExam,
        `بكم طريقة يمكن ترتيب ${r} كتب مختلفة على رف من أصل ${n} كتب متميزة (الترتيب مهم)؟`,
        `In how many ordered ways can ${r} books be arranged on a shelf from ${n} distinct books?`,
        ans,
        [n * r, Math.round(ans / 2), 6, -4],
        `باستخدام التباديل P(${n},${r}) = ${r === 2 ? `${n}×${n - 1}` : `${n}×${n - 1}×${n - 2}`} = ${ans}.`,
        `Permutation P(${n},${r}) = ${ans}.`,
      );
    },
  },
  {
    stage: 22,
    titleAr: 'التوافيق والاختيار دون ترتيب',
    titleEn: 'Combinations (Order Does Not Matter)',
    summaryAr: 'التوافيق تحسب عدد طرق اختيار مجموعة جزئية من العناصر عندما لا يكون الترتيب مهماً.',
    summaryEn: 'Combinations count subsets of size r from n items when selection order does not matter.',
    ruleTitleAr: 'قانون التوافيق',
    ruleTitleEn: 'Combination Formula',
    ruleFormula: 'C(n, r) = n! / (r! × (n - r)!)',
    examples: [
      { problemAr: 'بكم طريقة نختار فريقاً من طالبين من بين 5 طلاب؟', problemEn: 'Choose a team of 2 from 5 students?', solutionAr: 'C(5,2) = (5 × 4) ÷ 2 = 10.', solutionEn: 'C(5,2) = 10.', answer: '10' },
      { problemAr: 'اختيار لجنة من 3 من أصل 5 أعضاء', problemEn: 'Committee of 3 from 5', solutionAr: '(5×4×3) ÷ 6 = 10.', solutionEn: '10.', answer: '10' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const n = 5 + idx;
      const r = idx % 2 === 0 ? 2 : 3;
      const ans = r === 2 ? (n * (n - 1)) / 2 : (n * (n - 1) * (n - 2)) / 6;
      return makeNumericQ(
        22, qIdx, isExam,
        `بكم طريقة يمكن اختيار لجنة مكوّنة من ${r} أشخاص من بين ${n} متقدمين (دون اعتبار للترتيب)؟`,
        `How many ways can a committee of ${r} be chosen from ${n} candidates?`,
        ans,
        [n * (n - 1) - ans || 5, 3, -2, 6],
        `باستخدام التوافيق C(${n}, ${r}) = ${ans}.`,
        `Using combinations C(${n}, ${r}) = ${ans}.`,
      );
    },
  },
  {
    stage: 23,
    titleAr: 'الأحداث غير المستقلة (السحب دون إرجاع)',
    titleEn: 'Dependent Events Without Replacement',
    summaryAr: 'عند سحب عنصر دون إرجاعه يتغير العدد الكلي للعناصر، مما يؤثر على احتمال السحبة الثانية.',
    summaryEn: 'Drawing without replacement decreases the total pool, changing the probability of the second draw.',
    ruleTitleAr: 'احتمال السحب المتتالي دون إرجاع',
    ruleTitleEn: 'Dependent Probability',
    ruleFormula: 'P(أولاً ثم ثانياً) = P(الأول) × P(الثاني | الأول)',
    examples: [
      { problemAr: 'كيس فيه 4 حمراء و2 زرقاء، سُحبت كرتان دون إرجاع. احتمال كلتيهما حمراء؟', problemEn: '4 red, 2 blue. Draw 2 without replacement. P(both red)?', solutionAr: '(4/6) × (3/5) = 12/30 = 2/5.', solutionEn: '(4/6)×(3/5) = 2/5.', answer: '2/5' },
      { problemAr: '3 جوائز و2 فارغة، سُحبت بطاقتان دون إرجاع، احتمال فوزهما معاً؟', problemEn: '3 winning, 2 blank. Draw 2 without replacement, P(both win)?', solutionAr: '(3/5) × (2/4) = 3/10.', solutionEn: '3/10.', answer: '3/10' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const red = 3 + (idx % 4);
      const blue = 2 + idx;
      const total = red + blue;
      const ans = formatFraction(red * (red - 1), total * (total - 1));
      return makeTextQ(
        23, qIdx, isExam,
        `يحتوي صندوق على ${red} كرات حمراء و${blue} زرقاء. سُحبت كرتان على التوالي دون إرجاع. ما احتمال أن تكون الكرتان حمراوين؟`,
        `A box has ${red} red and ${blue} blue balls. Two are drawn sequentially without replacement. Probability both are red?`,
        ans,
        [
          formatFraction(red * red, total * total),
          formatFraction(red, total),
          formatFraction(blue * (blue - 1), total * (total - 1)),
        ],
        `(${red}/${total}) × (${red - 1}/${total - 1}) = ${ans}.`,
        `(${red}/${total}) × (${red - 1}/${total - 1}) = ${ans}.`,
      );
    },
  },
  {
    stage: 24,
    titleAr: 'مبدأ التضمين والاستبعاد في الاحتمال',
    titleEn: 'Non-Mutually Exclusive Events (Inclusion–Exclusion)',
    summaryAr: 'عند وجود تقاطع بين حدثين، نجمع احتماليهما ثم نطرح احتمال تقاطعهما حتى لا يُحسب مرتين.',
    summaryEn: 'When events overlap, add their individual probabilities and subtract the overlap: P(A or B) = P(A) + P(B) − P(A and B).',
    ruleTitleAr: 'قانون الاتحاد العام',
    ruleTitleEn: 'General Addition Rule',
    ruleFormula: 'P(A ∪ B) = P(A) + P(B) - P(A ∩ B)',
    examples: [
      { problemAr: 'من 1 إلى 10: ما احتمال اختيار عدد زوجي أو أكبر من 6؟', problemEn: 'From 1..10: P(even or > 6)?', solutionAr: 'الزوجية 5، الأكبر من 6 هي 4، المشتركة {8,10}=2. الإجابة (5+4-2)/10 = 7/10.', solutionEn: '(5 + 4 - 2)/10 = 7/10.', answer: '7/10' },
      { problemAr: 'P(A)=0.5 و P(B)=0.4 و P(A∩B)=0.2، أوجد P(A∪B)', problemEn: 'P(A)=0.5, P(B)=0.4, P(A∩B)=0.2. P(A∪B)?', solutionAr: '0.5 + 0.4 - 0.2 = 0.7.', solutionEn: '0.7.', answer: '0.7' },
    ],
    generate: (qIdx, isExam) => {
      const nA = 12 + qIdx;
      const nB = 10 + (qIdx % 5);
      const both = 4 + ((qIdx + (isExam ? 1 : 0)) % 4);
      const union = nA + nB - both;
      return makeNumericQ(
        24, qIdx, isExam,
        `في مجموعة طلاب، يدرس ${nA} الرياضيات ويدرس ${nB} الفيزياء ويدرس ${both} المادتين معاً. كم طالباً يدرس الرياضيات أو الفيزياء على الأقل؟`,
        `In a club, ${nA} study Math, ${nB} study Physics, and ${both} study both. How many study at least one of the two subjects?`,
        union,
        [nA + nB, both, -both, 2],
        `باستخدام التضمين والاستبعاد: ${nA} + ${nB} - ${both} = ${union}.`,
        `By inclusion-exclusion: ${nA} + ${nB} - ${both} = ${union}.`,
      );
    },
  },
  {
    stage: 25,
    titleAr: 'القيمة المتوقعة لمتغير عشوائي',
    titleEn: 'Expected Value of a Random Variable',
    summaryAr: 'القيمة المتوقعة تساوي مجموع حاصل ضرب كل نتيجة ممكنة في احتمال حدوثها.',
    summaryEn: 'Expected value equals the sum of each outcome multiplied by its probability.',
    ruleTitleAr: 'قانون القيمة المتوقعة',
    ruleTitleEn: 'Expected Value Formula',
    ruleFormula: 'E(X) = Σ [xᵢ × P(xᵢ)]',
    examples: [
      { problemAr: 'لعبة تربح فيها 10 باحتمال 0.4 أو 20 باحتمال 0.6، ما القيمة المتوقعة؟', problemEn: 'Win 10 (prob 0.4) or 20 (prob 0.6). Expected value?', solutionAr: '(10×0.4) + (20×0.6) = 4 + 12 = 16.', solutionEn: '4 + 12 = 16.', answer: '16' },
      { problemAr: 'جائزة 40 باحتمال 1/4 و 0 باحتمال 3/4', problemEn: 'Prize 40 (1/4) or 0 (3/4)', solutionAr: '40 × 1/4 = 10.', solutionEn: '10.', answer: '10' },
    ],
    generate: (qIdx, isExam) => {
      const p1 = 20 + qIdx * 10;
      const p2 = 60 + qIdx * 10 + (isExam ? 20 : 0);
      const w1 = 0.5;
      const w2 = 0.5;
      // Vary weights cleanly by tenths
      const k = 2 + (qIdx % 7); // 0.2..0.8
      const ev = (p1 * k + p2 * (10 - k)) / 10;
      return makeNumericQ(
        25, qIdx, isExam,
        `تمنح مسابقة ${p1} نقطة باحتمال ${k * 10}% أو ${p2} نقطة باحتمال ${(10 - k) * 10}%. ما القيمة المتوقعة للنقاط؟`,
        `A game awards ${p1} points with ${k * 10}% chance or ${p2} points with ${(10 - k) * 10}% chance. What is the expected value?`,
        ev,
        [Math.round(w1 * p1 + w2 * p2) - ev || 5, 10, -10, 4],
        `E(X) = (${p1} × 0.${k}) + (${p2} × 0.${10 - k}) = ${ev}.`,
        `E(X) = (${p1} × 0.${k}) + (${p2} × 0.${10 - k}) = ${ev}.`,
      );
    },
  },
  {
    stage: 26,
    titleAr: 'متوسط الانحراف المطلق (MAD)',
    titleEn: 'Mean Absolute Deviation (MAD)',
    summaryAr: 'يقيس متوسط الانحراف المطلق معدل بُعد القيم عن متوسطها الحسابي بأخذ القيمة المطلقة للفروق.',
    summaryEn: 'MAD finds the average absolute distance of all data values from their arithmetic mean.',
    ruleTitleAr: 'قانون متوسط الانحراف',
    ruleTitleEn: 'MAD Formula',
    ruleFormula: 'MAD = Σ|xᵢ − x̄| ÷ n',
    examples: [
      { problemAr: 'أوجد MAD للقيم: 4، 6، 8، 10', problemEn: 'Find MAD of: 4, 6, 8, 10', solutionAr: 'المتوسط 7، الفروق المطلقة: 3، 1، 1، 3 ومجموعها 8 ÷ 4 = 2.', solutionEn: 'Mean 7, distances 3,1,1,3 → 8/4 = 2.', answer: '2' },
      { problemAr: 'للقيم 10، 12، 14، ما قيمة MAD؟', problemEn: 'MAD of 10, 12, 14?', solutionAr: 'المتوسط 12، الفروق 2، 0، 2 → 4/3 (نختار أمثلة بأعداد صحيحة).', solutionEn: 'Mean 12.', answer: '4/3' },
    ],
    generate: (qIdx, isExam) => {
      const mean = 10 + qIdx * 3 + (isExam ? 2 : 0);
      const d = 2 + (qIdx % 4) * 2;
      const vals = [mean - d, mean - d, mean + d, mean + d];
      return makeNumericQ(
        26, qIdx, isExam,
        `احسب متوسط الانحراف المطلق (MAD) للقيم التالية: ${vals.join('، ')}`,
        `Calculate the Mean Absolute Deviation (MAD) for: ${vals.join(', ')}`,
        d,
        [1, -1, 2, d * 2],
        `المتوسط = ${mean}، وكل قيمة تبعد عن المتوسط بمقدار ${d}، إذن MAD = ${d}.`,
        `Mean = ${mean}, every value is ${d} away from the mean, so MAD = ${d}.`,
      );
    },
  },
  {
    stage: 27,
    titleAr: 'الاحتمال الشرطي من الجداول',
    titleEn: 'Conditional Probability from Two-Way Tables',
    summaryAr: 'الاحتمال الشرطي P(A | B) يعني احتمال A بشرط تحقق B، فنحصر المقام في عناصر B فقط.',
    summaryEn: 'Conditional probability P(A | B) narrows the sample space strictly to outcomes where B is true.',
    ruleTitleAr: 'الاحتمال الشرطي',
    ruleTitleEn: 'Conditional Probability',
    ruleFormula: 'P(A | B) = عدد (A و B) ÷ عدد B',
    examples: [
      { problemAr: 'من بين 15 طالباً يرتدون نظارات، 6 يفضلون العلوم. ما احتمال تفضيل العلوم بشرط ارتداء نظارات؟', problemEn: 'Out of 15 students with glasses, 6 like science. P(science | glasses)?', solutionAr: '6 ÷ 15 = 2/5.', solutionEn: '6 / 15 = 2/5.', answer: '2/5' },
      { problemAr: 'في جدول ثنائي، عدد الذكور 20 منهم 12 رياضياً. P(رياضي | ذكر)؟', problemEn: '20 boys, 12 are athletes. P(athlete | boy)?', solutionAr: '12/20 = 3/5.', solutionEn: '3/5.', answer: '3/5' },
    ],
    generate: (qIdx, isExam) => {
      const subTotal = 12 + (qIdx % 4) * 3 + (isExam ? 3 : 0);
      const both = 4 + (qIdx % 5);
      const ans = formatFraction(both, subTotal);
      const otherTotal = subTotal + 8;
      return makeTextQ(
        27, qIdx, isExam,
        `في استبيان شمل ${subTotal} طالباً و${otherTotal} طالبة، اختار ${both} من الطلاب السباحة. إذا اختير أحد الطلاب (الذكور) عشوائياً، فما احتمال أن يفضل السباحة؟`,
        `In a survey of ${subTotal} boys and ${otherTotal} girls, ${both} boys chose swimming. Given a student is a boy, what is the probability he chose swimming?`,
        ans,
        [
          formatFraction(both, subTotal + otherTotal),
          formatFraction(subTotal - both, subTotal),
          formatFraction(both + 1, subTotal + 1),
        ],
        `نحصر المقام في الطلاب فقط (${subTotal})، فيكون الاحتمال الشرطي = ${both}/${subTotal} = ${ans}.`,
        `Restrict denominator to boys (${subTotal}): ${both}/${subTotal} = ${ans}.`,
      );
    },
  },
  {
    stage: 28,
    titleAr: 'الاحتمال في رمي حجري نرد',
    titleEn: 'Probability with Two Fair Dice',
    summaryAr: 'عند رمي حجري نرد معاً يوجد 36 ناتجاً ممكناً متساوي الاحتمال، نعد منها الأزواج التي تحقق الشرط.',
    summaryEn: 'Rolling two fair 6-sided dice yields 36 equally likely ordered pairs (a, b).',
    ruleTitleAr: 'فضاء العينة لنردين',
    ruleTitleEn: 'Two-Dice Sample Space',
    ruleFormula: 'عدد النواتج الكلي = 6 × 6 = 36',
    examples: [
      { problemAr: 'ما احتمال أن يكون مجموع حجري النرد 7؟', problemEn: 'Probability that sum of two dice is 7?', solutionAr: 'الأزواج (1,6),(2,5),(3,4),(4,3),(5,2),(6,1) وعددها 6 ← 6/36 = 1/6.', solutionEn: '6 pairs out of 36 = 1/6.', answer: '1/6' },
      { problemAr: 'احتمال تساوي الرقمين على الوجهين؟', problemEn: 'Probability of rolling doubles?', solutionAr: '6 أزواج متساوية → 6/36 = 1/6.', solutionEn: '6/36 = 1/6.', answer: '1/6' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const targets: [number, number][] = [
        [2, 1], [3, 2], [4, 3], [5, 4], [6, 5], [7, 6], [8, 5], [9, 4], [10, 3], [11, 2], [12, 1],
      ];
      const [sumTarget, count] = targets[idx];
      const ans = formatFraction(count, 36);
      return makeTextQ(
        28, qIdx, isExam,
        `عند رمي حجري نرد منتظمين معاً، ما احتمال أن يكون مجموع الوجهين الظاهرين يساوي ${sumTarget}؟`,
        `When rolling two fair dice, what is the probability that the sum is ${sumTarget}?`,
        ans,
        [
          formatFraction(count + 1, 36),
          formatFraction(Math.max(1, count - 1), 36),
          formatFraction(sumTarget, 36),
        ],
        `عدد الأزواج التي مجموعها ${sumTarget} هو ${count} من أصل 36 ناتجاً، أي ${ans}.`,
        `There are ${count} pairs summing to ${sumTarget} out of 36 outcomes: ${ans}.`,
      );
    },
  },
  {
    stage: 29,
    titleAr: 'التجارب المتكررة (احتمال حدث واحد على الأقل)',
    titleEn: 'Probability of "At Least One"',
    summaryAr: 'لحساب احتمال وقوع الحدث مرة واحدة على الأقل، نستخدم الحدث المتمم: 1 − احتمال عدم وقوعه في كل المحاولات.',
    summaryEn: 'Use the complement rule for "at least one": 1 − P(none in all trials).',
    ruleTitleAr: 'قاعدة مرة واحدة على الأقل',
    ruleTitleEn: 'At Least One Rule',
    ruleFormula: 'P(واحد على الأقل) = 1 − [P(عدم الوقوع)]ⁿ',
    examples: [
      { problemAr: 'رمينا عملة 3 مرات، ما احتمال ظهور صورة مرة واحدة على الأقل؟', problemEn: 'Toss a coin 3 times. P(at least one Head)?', solutionAr: 'احتمال عدم ظهور صورة (كلها كتابة) = (1/2)³ = 1/8، إذن الجواب 1 - 1/8 = 7/8.', solutionEn: '1 - (1/2)³ = 7/8.', answer: '7/8' },
      { problemAr: 'رمي عملتين: احتمال صورة واحدة على الأقل؟', problemEn: '2 coins: P(at least one Head)?', solutionAr: '1 - 1/4 = 3/4.', solutionEn: '3/4.', answer: '3/4' },
    ],
    generate: (qIdx, isExam) => {
      const idx = isExam ? 10 : qIdx;
      const cases: [number, number][] = [
        [2, 2], [3, 2], [4, 2], [2, 3], [3, 3],
        [4, 3], [5, 2], [6, 2], [2, 4], [3, 4], [5, 3],
      ];
      const [denFail, n] = cases[idx];
      const failDenPow = denFail ** n;
      const ans = formatFraction(failDenPow - 1, failDenPow);
      return makeTextQ(
        29, qIdx, isExam,
        `احتمال نجاح محاولة واحدة هو ${denFail - 1}/${denFail} (واحتمال فشلها 1/${denFail}). ما احتمال النجاح مرة واحدة على الأقل في ${n} محاولات مستقلة؟`,
        `A trial succeeds with probability ${denFail - 1}/${denFail} (fails 1/${denFail}). What is the probability of at least one success in ${n} independent trials?`,
        ans,
        [
          formatFraction(1, failDenPow),
          formatFraction(denFail - 1, denFail),
          formatFraction(failDenPow - 2, failDenPow),
        ],
        `احتمال الفشل في كل المحاولات = (1/${denFail})^${n} = 1/${failDenPow}، لذا المتمم = ${ans}.`,
        `P(all fail) = (1/${denFail})^${n} = 1/${failDenPow}, so P(at least one) = ${ans}.`,
      );
    },
  },
  {
    stage: 30,
    titleAr: 'التحدي الشامل للإحصاء والاحتمالات',
    titleEn: 'Statistics & Probability Mastery',
    summaryAr: 'يدمج هذا التحدي التحليل الإحصائي للمتوسط والوسيط مع العدّ والاحتمالات الشرطية والمركبة.',
    summaryEn: 'Synthesizes statistical inference, missing-data averages, combinatorics, and multi-event probability.',
    ruleTitleAr: 'التكامل الإحصائي والاحتمالي',
    ruleTitleEn: 'Integrated Mastery',
    ruleFormula: 'تحليل البيانات + حساب الفضاء العيني ← الاستنتاج الدقيق',
    examples: [
      { problemAr: 'مجموعة من 5 أعداد متوسطها 14 ووسيطها 12؛ إذا تغيرت أصغر قيمة وزادت 10 فكم يصبح المتوسط الجديد؟', problemEn: 'Mean of 5 numbers is 14. Increase smallest by 10. New mean?', solutionAr: 'المجموع يزيد 10، فالمتوسط يزيد 10÷5 = 2 ليصبح 16.', solutionEn: 'Sum increases by 10 → mean increases by 2 to 16.', answer: '16' },
      { problemAr: 'صندوق فيه 6 كرات: كم زوجاً مختلفاً من كرتين يمكن اختياره؟', problemEn: '6 balls: how many pairs of 2?', solutionAr: 'C(6,2) = 15.', solutionEn: '15.', answer: '15' },
    ],
    generate: (qIdx, isExam) => {
      const count = 4 + (qIdx % 3);
      const oldMean = 15 + qIdx * 2 + (isExam ? 1 : 0);
      const bumpPerUnit = 2 + (qIdx % 4);
      const addedTotal = count * bumpPerUnit;
      const newMean = oldMean + bumpPerUnit;
      return makeNumericQ(
        30, qIdx, isExam,
        `مجموعة مكوّنة من ${count} أعداد متوسطها الحسابي ${oldMean}. أُضيف العدد ${addedTotal} لأحد الأعداد فقط (وبقيت البقية ثابتة). ما المتوسط الحسابي الجديد للمجموعة؟`,
        `A set of ${count} numbers has a mean of ${oldMean}. If ${addedTotal} is added to just one of the numbers, what is the new mean?`,
        newMean,
        [addedTotal, bumpPerUnit * 2, -bumpPerUnit, 1],
        `المجموع الكلي زاد بمقدار ${addedTotal} مع بقاء العدد ${count}، فيزيد المتوسط بمقدار ${addedTotal}÷${count} = ${bumpPerUnit} ليصبح ${newMean}.`,
        `Total sum increases by ${addedTotal} across ${count} items, raising mean by ${bumpPerUnit} to ${newMean}.`,
      );
    },
  },
];

export const STATISTICS_STAGES: StageDefinition[] = TOPICS.map((topic) => ({
  id: makeStageId('statistics', topic.stage),
  sectionId: 'statistics',
  stageNumber: topic.stage,
  difficulty: getDifficultyForStage(topic.stage),
  titleAr: topic.titleAr,
  titleEn: topic.titleEn,
  lesson: {
    summaryAr: topic.summaryAr,
    summaryEn: topic.summaryEn,
    ruleTitleAr: topic.ruleTitleAr,
    ruleTitleEn: topic.ruleTitleEn,
    ruleFormula: topic.ruleFormula,
    examples: topic.examples,
  },
  questions: Array.from({ length: 10 }, (_, qIdx) => topic.generate(qIdx, false)),
  examQuestion: topic.generate(10, true),
}));
