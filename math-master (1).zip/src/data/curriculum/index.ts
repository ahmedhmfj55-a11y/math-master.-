import { ADVANCED_STAGES } from '@/src/data/curriculum/sections/advanced';
import { ALGEBRA_STAGES } from '@/src/data/curriculum/sections/algebra';
import { ARITHMETIC_STAGES } from '@/src/data/curriculum/sections/arithmetic';
import { FRACTIONS_STAGES } from '@/src/data/curriculum/sections/fractions';
import { GEOMETRY_STAGES } from '@/src/data/curriculum/sections/geometry';
import { MEASUREMENT_STAGES } from '@/src/data/curriculum/sections/measurement';
import { RATIOS_STAGES } from '@/src/data/curriculum/sections/ratios';
import { STATISTICS_STAGES } from '@/src/data/curriculum/sections/statistics';
import type {
  QuizQuestion,
  SectionDefinition,
  SectionId,
  StageDefinition,
} from '@/src/types/curriculum';

export const PASS_SCORE_THRESHOLD = 70;
export const STAGE_FIRST_WIN_POINTS = 100;
export const STAGE_PERFECT_BONUS_POINTS = 50;
export const EXAM_FIRST_WIN_POINTS = 200;
export const EXAM_PERFECT_BONUS_POINTS = 50;
export const SECTION_COMPLETE_POINTS = 500;
export const STAGES_PER_SECTION = 30;
export const QUESTIONS_PER_STAGE = 10;
export const EXAM_QUESTIONS_COUNT = 30;
export const EXAM_DURATION_SECONDS = 1800;

export const CURRICULUM_SECTIONS: SectionDefinition[] = [
  {
    id: 'arithmetic',
    order: 1,
    titleAr: 'الحساب الأساسي',
    titleEn: 'Basic Arithmetic',
    descriptionAr: 'الجمع والطرح والضرب والقسمة والأولويات الحسابية والقواسم.',
    descriptionEn: 'Addition, subtraction, multiplication, division, order of operations, and factors.',
    accentFrom: '#3B82F6',
    accentTo: '#6366F1',
    symbol: '+−×÷',
  },
  {
    id: 'fractions',
    order: 2,
    titleAr: 'الكسور والأعداد العشرية',
    titleEn: 'Fractions & Decimals',
    descriptionAr: 'تبسيط الكسور وعملياتها والتحويل إلى الأعداد العشرية والمقارنات.',
    descriptionEn: 'Simplifying fractions, operations, decimal conversions, and comparisons.',
    accentFrom: '#6366F1',
    accentTo: '#8B5CF6',
    symbol: '¾',
  },
  {
    id: 'algebra',
    order: 3,
    titleAr: 'الجبر والمعادلات',
    titleEn: 'Algebra & Equations',
    descriptionAr: 'العبارات الجبرية، حل المعادلات والمتباينات، الدوال والمعادلات التربيعية.',
    descriptionEn: 'Algebraic expressions, linear & quadratic equations, inequalities, and functions.',
    accentFrom: '#8B5CF6',
    accentTo: '#A855F7',
    symbol: 'x²',
  },
  {
    id: 'geometry',
    order: 4,
    titleAr: 'الهندسة',
    titleEn: 'Geometry',
    descriptionAr: 'الزوايا والمضلعات والمثلثات والدوائر وفيثاغورس والمجسمات.',
    descriptionEn: 'Angles, polygons, triangles, circles, Pythagorean theorem, and 3D solids.',
    accentFrom: '#0EA5E9',
    accentTo: '#6366F1',
    symbol: '△',
  },
  {
    id: 'measurement',
    order: 5,
    titleAr: 'القياس والوحدات',
    titleEn: 'Measurement & Units',
    descriptionAr: 'تحويلات الطول والكتلة والسعة والزمن والسرعة والقياسات المركبة.',
    descriptionEn: 'Conversions of length, mass, capacity, time, speed, and compound units.',
    accentFrom: '#2563EB',
    accentTo: '#7C3AED',
    symbol: 'cm',
  },
  {
    id: 'ratios',
    order: 6,
    titleAr: 'النسب والتناسب',
    titleEn: 'Ratios & Proportions',
    descriptionAr: 'معدلات الوحدة، التناسب الطردي والعكسي، النسب المئوية، والخصم والربح.',
    descriptionEn: 'Unit rates, direct & inverse proportions, percentages, discounts, and interest.',
    accentFrom: '#4F46E5',
    accentTo: '#9333EA',
    symbol: '%',
  },
  {
    id: 'statistics',
    order: 7,
    titleAr: 'الإحصاء والاحتمالات',
    titleEn: 'Statistics & Probability',
    descriptionAr: 'المتوسط والوسيط والمنوال والمدى والاحتمالات والتباديل والتوافيق.',
    descriptionEn: 'Mean, median, mode, range, probability, permutations, and combinations.',
    accentFrom: '#38BDF8',
    accentTo: '#818CF8',
    symbol: 'P(A)',
  },
  {
    id: 'advanced',
    order: 8,
    titleAr: 'التحديات المتقدمة',
    titleEn: 'Advanced Challenges',
    descriptionAr: 'المتسلسلات، نظرية الأعداد، المنطق الرياضي، ومسائل الأولمبياد.',
    descriptionEn: 'Series, number theory, logical invariants, and Olympiad-level challenges.',
    accentFrom: '#7C3AED',
    accentTo: '#EC4899',
    symbol: '∑',
  },
];

export const ALL_STAGES_BY_SECTION: Record<SectionId, StageDefinition[]> = {
  arithmetic: ARITHMETIC_STAGES,
  fractions: FRACTIONS_STAGES,
  algebra: ALGEBRA_STAGES,
  geometry: GEOMETRY_STAGES,
  measurement: MEASUREMENT_STAGES,
  ratios: RATIOS_STAGES,
  statistics: STATISTICS_STAGES,
  advanced: ADVANCED_STAGES,
};

export function getSectionById(sectionId: SectionId): SectionDefinition {
  return CURRICULUM_SECTIONS.find((s) => s.id === sectionId) ?? CURRICULUM_SECTIONS[0];
}

export function getSectionStages(sectionId: SectionId): StageDefinition[] {
  return ALL_STAGES_BY_SECTION[sectionId];
}

export function getStageDefinition(
  sectionId: SectionId,
  stageNumber: number,
): StageDefinition | undefined {
  return ALL_STAGES_BY_SECTION[sectionId].find((s) => s.stageNumber === stageNumber);
}

/**
 * Returns the 30 diverse final exam questions drawn deterministically—one distinct
 * dedicated question from each of the 30 lessons in the section.
 */
export function buildSectionFinalExam(sectionId: SectionId): QuizQuestion[] {
  return ALL_STAGES_BY_SECTION[sectionId].map((stage) => stage.examQuestion);
}
