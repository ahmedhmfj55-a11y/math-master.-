import { CURRICULUM_SECTIONS } from '@/src/data/curriculum';
import type {
  AchievementCatalogItem,
  EarnedRecordId,
} from '@/src/types/achievements';
import type { SectionId } from '@/src/types/curriculum';
import type { DailyStreakStatsRecord, SectionProgressRecord } from '@/src/types/progress';

export const ACHIEVEMENTS_CATALOG: AchievementCatalogItem[] = [
  {
    id: 'ach-first-stage',
    kind: 'achievement',
    titleAr: 'الخطوة الأولى نحو القمة',
    titleEn: 'First Stage Cleared',
    descriptionAr: 'بداية رحلتك الناجحة بالفوز في أول مرحلة تعليمية.',
    descriptionEn: 'Marked the start of your journey by clearing your first stage.',
    conditionAr: 'اجتياز مرحلة واحدة بنجاح',
    conditionEn: 'Pass 1 learning stage',
    targetValue: 1,
    accentFrom: 'from-sky-400',
    accentTo: 'to-blue-600',
    ringColor: 'border-sky-300/45',
    iconKey: 'stage1',
  },
  {
    id: 'ach-10-stages',
    kind: 'achievement',
    titleAr: 'متسلق الأرقام',
    titleEn: '10 Stages Conqueror',
    descriptionAr: 'بناء أساس رياضي صلب عبر إتمام 10 مراحل بنجاح.',
    descriptionEn: 'Built a strong mathematical foundation by clearing 10 stages.',
    conditionAr: 'اجتياز 10 مراحل بنجاح',
    conditionEn: 'Pass 10 stages',
    targetValue: 10,
    accentFrom: 'from-amber-600',
    accentTo: 'to-orange-700',
    ringColor: 'border-amber-400/40',
    iconKey: 'stage10',
  },
  {
    id: 'ach-50-stages',
    kind: 'achievement',
    titleAr: 'باحث المعرفة المتقدم',
    titleEn: '50 Stages Strategist',
    descriptionAr: 'ثبات وتفوق واضح عبر إتمام 50 مرحلة في المنهج.',
    descriptionEn: 'Consistent mastery demonstrated across 50 completed stages.',
    conditionAr: 'اجتياز 50 مرحلة بنجاح',
    conditionEn: 'Pass 50 stages',
    targetValue: 50,
    accentFrom: 'from-slate-300',
    accentTo: 'to-indigo-500',
    ringColor: 'border-slate-200/45',
    iconKey: 'stage50',
  },
  {
    id: 'ach-100-stages',
    kind: 'achievement',
    titleAr: 'عميد المئة مرحلة',
    titleEn: 'Centurion of 100 Stages',
    descriptionAr: 'إنجاز رفيع المستوى باجتياز 100 مرحلة تعليمية.',
    descriptionEn: 'Major academic milestone reached by clearing 100 stages.',
    conditionAr: 'اجتياز 100 مرحلة بنجاح',
    conditionEn: 'Pass 100 stages',
    targetValue: 100,
    accentFrom: 'from-yellow-400',
    accentTo: 'to-amber-600',
    ringColor: 'border-yellow-300/50',
    iconKey: 'stage100',
  },
  {
    id: 'ach-section-complete',
    kind: 'achievement',
    titleAr: 'مُتقن قسم متكامل',
    titleEn: 'Section Mastered',
    descriptionAr: 'إتمام جميع المراحل الثلاثين لقسم تعليمي واحد بالكامل.',
    descriptionEn: 'Completed every single one of the 30 stages in a full section.',
    conditionAr: 'إكمال 30/30 مرحلة في قسم واحد',
    conditionEn: 'Complete all 30 stages in 1 section',
    targetValue: 1,
    accentFrom: 'from-emerald-400',
    accentTo: 'to-teal-600',
    ringColor: 'border-emerald-300/45',
    iconKey: 'section1',
  },
  {
    id: 'ach-all-sections',
    kind: 'achievement',
    titleAr: 'إتمام جميع الأقسام الثمانية',
    titleEn: 'Grand 8-Section Completion',
    descriptionAr: 'إنجاز المنهج العالمي بأكمله بإكمال 240 مرحلة عبر 8 أقسام.',
    descriptionEn: 'Conquered the entire 8-section, 240-stage curriculum.',
    conditionAr: 'إكمال جميع الأقسام الثمانية (8/8)',
    conditionEn: 'Complete all 8 sections (8/8)',
    targetValue: 8,
    accentFrom: 'from-amber-300',
    accentTo: 'to-violet-600',
    ringColor: 'border-amber-300/60',
    iconKey: 'section8',
  },
  {
    id: 'ach-exam-perfect',
    kind: 'achievement',
    titleAr: 'الدقة المطلقة في الامتحان',
    titleEn: 'Perfect 100/100 Exam Score',
    descriptionAr: 'تحقيق العلامة الكاملة 100 من 100 في امتحان قسم شامل.',
    descriptionEn: 'Achieved a flawless 100/100 score in a 30-question section exam.',
    conditionAr: 'الحصول على 100/100 في امتحان قسم',
    conditionEn: 'Score 100/100 in any section final exam',
    targetValue: 1,
    accentFrom: 'from-violet-400',
    accentTo: 'to-fuchsia-600',
    ringColor: 'border-violet-300/50',
    iconKey: 'perfectExam',
  },
  {
    id: 'ach-daily-7',
    kind: 'achievement',
    titleAr: 'أسبوع التحدي المتواصل',
    titleEn: '7-Day Daily Streak',
    descriptionAr: 'الفوز بالتحدي اليومي لمدة 7 أيام متتالية دون انقطاع.',
    descriptionEn: 'Won the Daily Math Challenge for 7 consecutive days.',
    conditionAr: 'إكمال 7 تحديات يومية متتالية',
    conditionEn: 'Win 7 consecutive Daily Challenges',
    targetValue: 7,
    accentFrom: 'from-orange-400',
    accentTo: 'to-rose-600',
    ringColor: 'border-orange-300/45',
    iconKey: 'streak7',
  },
  {
    id: 'ach-daily-30',
    kind: 'achievement',
    titleAr: 'أسطورة الشهر المتتالي',
    titleEn: '30-Day Daily Streak',
    descriptionAr: 'الانضباط الاستثنائي بالفوز بـ 30 تحدياً يومياً على التوالي.',
    descriptionEn: 'Extraordinary consistency with 30 consecutive Daily Challenge wins.',
    conditionAr: 'إكمال 30 تحدياً يومياً متتالياً',
    conditionEn: 'Win 30 consecutive Daily Challenges',
    targetValue: 30,
    accentFrom: 'from-amber-400',
    accentTo: 'to-red-600',
    ringColor: 'border-amber-300/55',
    iconKey: 'streak30',
  },
];

export const MEDALS_CATALOG: AchievementCatalogItem[] = [
  {
    id: 'medal-bronze',
    kind: 'medal',
    titleAr: 'وسام البرونز',
    titleEn: 'Bronze Medal',
    descriptionAr: 'وسام الشرف البرونزي يُمنح عند الفوز بـ 10 مراحل تعليمية.',
    descriptionEn: 'Bronze honor crest awarded upon clearing 10 learning stages.',
    conditionAr: 'الفوز بـ 10 مراحل تعليمية',
    conditionEn: 'Clear 10 stages',
    targetValue: 10,
    accentFrom: 'from-amber-700',
    accentTo: 'to-orange-900',
    ringColor: 'border-amber-500/50',
    iconKey: 'bronze',
  },
  {
    id: 'medal-silver',
    kind: 'medal',
    titleAr: 'وسام الفضة',
    titleEn: 'Silver Medal',
    descriptionAr: 'وسام الفضة اللامع يُمنح للمتفوقين الذين أتموا 50 مرحلة.',
    descriptionEn: 'Lustrous Silver Medal earned after clearing 50 stages.',
    conditionAr: 'الفوز بـ 50 مرحلة تعليمية',
    conditionEn: 'Clear 50 stages',
    targetValue: 50,
    accentFrom: 'from-slate-200',
    accentTo: 'to-slate-500',
    ringColor: 'border-slate-200/55',
    iconKey: 'silver',
  },
  {
    id: 'medal-gold',
    kind: 'medal',
    titleAr: 'وسام الذهب',
    titleEn: 'Gold Medal',
    descriptionAr: 'وسام الذهب الخالص يُمنح عند بلوغ 100 مرحلة مكتملة بنجاح.',
    descriptionEn: 'Radiant Gold Medal awarded upon mastering 100 stages.',
    conditionAr: 'الفوز بـ 100 مرحلة تعليمية',
    conditionEn: 'Clear 100 stages',
    targetValue: 100,
    accentFrom: 'from-yellow-300',
    accentTo: 'to-amber-500',
    ringColor: 'border-yellow-300/65',
    iconKey: 'gold',
  },
  {
    id: 'medal-genius',
    kind: 'medal',
    titleAr: 'وسام العبقرية',
    titleEn: 'Genius Medal',
    descriptionAr: 'وسام نادر يُمنح لمن يحصد العلامة الكاملة 100/100 في الامتحان الشامل.',
    descriptionEn: 'Rare crystalline medal earned by scoring 100/100 in a Section Exam.',
    conditionAr: 'تحقيق 100/100 في امتحان قسم شامل',
    conditionEn: 'Score 100/100 on any Section Final Exam',
    targetValue: 1,
    accentFrom: 'from-cyan-400',
    accentTo: 'to-violet-600',
    ringColor: 'border-cyan-300/60',
    iconKey: 'genius',
  },
  {
    id: 'medal-math-king',
    kind: 'medal',
    titleAr: 'وسام ملك الرياضيات',
    titleEn: 'King of Mathematics Medal',
    descriptionAr: 'التاج الأعلى في Math Master لإتمام جميع الأقسام الثمانية كاملة.',
    descriptionEn: 'Supreme crown crest bestowed for completing all 8 math sections.',
    conditionAr: 'إكمال جميع الأقسام الثمانية (240 مرحلة)',
    conditionEn: 'Complete all 8 sections (240 stages)',
    targetValue: 8,
    accentFrom: 'from-amber-300',
    accentTo: 'to-emerald-500',
    ringColor: 'border-amber-300/70',
    iconKey: 'king',
  },
  {
    id: 'medal-challenge',
    kind: 'medal',
    titleAr: 'وسام التحدي',
    titleEn: 'Challenge Medal',
    descriptionAr: 'وسام العزيمة لأبطال التحدي اليومي بعد 7 أيام متتالية.',
    descriptionEn: 'Flame crest honoring 7 consecutive Daily Challenge victories.',
    conditionAr: 'سلسلة 7 أيام في التحدي اليومي',
    conditionEn: '7-day Daily Challenge streak',
    targetValue: 7,
    accentFrom: 'from-orange-400',
    accentTo: 'to-rose-600',
    ringColor: 'border-orange-300/55',
    iconKey: 'challenge',
  },
  {
    id: 'medal-excellence',
    kind: 'medal',
    titleAr: 'وسام التفوق',
    titleEn: 'Excellence Medal',
    descriptionAr: 'وسام الإتقان المعتمد لإكمال قسم كامل واجتياز امتحانه الشامل.',
    descriptionEn: 'Distinguished seal for mastering a full section and passing its exam.',
    conditionAr: 'إكمال قسم كامل + اجتياز امتحانه الشامل',
    conditionEn: 'Complete a section & pass its Final Exam',
    targetValue: 1,
    accentFrom: 'from-emerald-400',
    accentTo: 'to-blue-600',
    ringColor: 'border-emerald-300/55',
    iconKey: 'excellence',
  },
];

export const ALL_ACHIEVEMENT_AND_MEDAL_ITEMS: AchievementCatalogItem[] = [
  ...MEDALS_CATALOG,
  ...ACHIEVEMENTS_CATALOG,
];

export function getCatalogItemById(id: EarnedRecordId): AchievementCatalogItem | undefined {
  return ALL_ACHIEVEMENT_AND_MEDAL_ITEMS.find((item) => item.id === id);
}

export interface ProgressSnapshotForEvaluation {
  completedStagesCount: number;
  completedSectionsCount: number;
  certificatesCount: number;
  sectionProgressMap: Partial<Record<SectionId, SectionProgressRecord>>;
  dailyStats: DailyStreakStatsRecord | null;
}

export interface EvaluatedMilestoneState {
  earned: boolean;
  current: number;
  target: number;
  triggerRef: string;
}

export function evaluateCatalogItemProgress(
  item: AchievementCatalogItem,
  snapshot: ProgressSnapshotForEvaluation,
): EvaluatedMilestoneState {
  const {
    completedStagesCount,
    completedSectionsCount,
    certificatesCount,
    sectionProgressMap,
    dailyStats,
  } = snapshot;

  const longestStreak = dailyStats?.longestStreak ?? 0;

  let perfectExamSectionId: SectionId | null = null;
  for (const sec of CURRICULUM_SECTIONS) {
    const rec = sectionProgressMap[sec.id];
    if (rec && rec.examBestScore === 100) {
      perfectExamSectionId = sec.id;
      break;
    }
  }

  switch (item.id) {
    case 'ach-first-stage':
      return {
        earned: completedStagesCount >= 1,
        current: Math.min(1, completedStagesCount),
        target: 1,
        triggerRef: 'stages-1',
      };
    case 'ach-10-stages':
    case 'medal-bronze':
      return {
        earned: completedStagesCount >= 10,
        current: Math.min(10, completedStagesCount),
        target: 10,
        triggerRef: 'stages-10',
      };
    case 'ach-50-stages':
    case 'medal-silver':
      return {
        earned: completedStagesCount >= 50,
        current: Math.min(50, completedStagesCount),
        target: 50,
        triggerRef: 'stages-50',
      };
    case 'ach-100-stages':
    case 'medal-gold':
      return {
        earned: completedStagesCount >= 100,
        current: Math.min(100, completedStagesCount),
        target: 100,
        triggerRef: 'stages-100',
      };
    case 'ach-section-complete':
      return {
        earned: completedSectionsCount >= 1,
        current: Math.min(1, completedSectionsCount),
        target: 1,
        triggerRef: 'sections-1',
      };
    case 'ach-all-sections':
    case 'medal-math-king':
      return {
        earned: completedSectionsCount >= 8,
        current: Math.min(8, completedSectionsCount),
        target: 8,
        triggerRef: 'sections-8',
      };
    case 'medal-excellence':
      return {
        earned: completedSectionsCount >= 1 && certificatesCount >= 1,
        current: completedSectionsCount >= 1 && certificatesCount >= 1 ? 1 : 0,
        target: 1,
        triggerRef: 'section-exam-passed',
      };
    case 'ach-exam-perfect':
    case 'medal-genius':
      return {
        earned: perfectExamSectionId !== null,
        current: perfectExamSectionId !== null ? 1 : 0,
        target: 1,
        triggerRef: perfectExamSectionId ?? 'none',
      };
    case 'ach-daily-7':
    case 'medal-challenge':
      return {
        earned: Boolean(dailyStats?.badge7Unlocked || longestStreak >= 7),
        current: Math.min(7, longestStreak),
        target: 7,
        triggerRef: 'daily-streak-7',
      };
    case 'ach-daily-30':
      return {
        earned: Boolean(dailyStats?.badge30Unlocked || longestStreak >= 30),
        current: Math.min(30, longestStreak),
        target: 30,
        triggerRef: 'daily-streak-30',
      };
  }
}
