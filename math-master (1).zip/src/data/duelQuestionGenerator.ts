import { getSectionStages } from '@/src/data/curriculum';
import type { SectionId } from '@/src/types/curriculum';
import type { DuelQuestionCount, DuelQuestionItem } from '@/src/types/duels';

function mulberry32(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state = (state + 0x6d2b79f5) | 0;
    let t = Math.imul(state ^ (state >>> 15), 1 | state);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hashSeed(sectionId: SectionId, questionSeed: number): number {
  let h = questionSeed >>> 0;
  for (let i = 0; i < sectionId.length; i += 1) {
    h = Math.imul(h ^ sectionId.charCodeAt(i), 2654435761) >>> 0;
  }
  return h;
}

/**
 * Deterministically produces identical balanced questions (easy, medium, hard)
 * for both competitors from the shared match seed and chosen curriculum section.
 */
export function buildDuelQuestions(
  sectionId: SectionId,
  questionCount: DuelQuestionCount,
  questionSeed: number,
): DuelQuestionItem[] {
  const stages = getSectionStages(sectionId);
  const rand = mulberry32(hashSeed(sectionId, questionSeed));

  const easyStages = stages.filter((s) => s.difficulty === 'easy');
  const mediumStages = stages.filter((s) => s.difficulty === 'medium');
  const hardStages = stages.filter((s) => s.difficulty === 'hard');

  const easyNeed = questionCount === 5 ? 2 : questionCount === 10 ? 3 : 5;
  const mediumNeed = questionCount === 5 ? 2 : questionCount === 10 ? 4 : 5;
  const hardNeed = questionCount - easyNeed - mediumNeed;

  const pickFromBand = (
    bandStages: typeof stages,
    count: number,
  ): DuelQuestionItem[] => {
    const shuffled = [...bandStages].sort(() => rand() - 0.5);
    const chosen = shuffled.slice(0, count);
    return chosen.map((stage) => {
      const qIdx = Math.floor(rand() * stage.questions.length);
      const q = stage.questions[qIdx] ?? stage.examQuestion;
      return {
        id: `duel-${sectionId}-${stage.stageNumber}-${q.id}`,
        questionNumber: 0,
        difficulty: stage.difficulty,
        stageTitleAr: stage.titleAr,
        stageTitleEn: stage.titleEn,
        promptAr: q.promptAr,
        promptEn: q.promptEn,
        options: q.options,
        correctIndex: q.correctIndex,
        explanationAr: q.explanationAr,
        explanationEn: q.explanationEn,
      };
    });
  };

  const combined = [
    ...pickFromBand(easyStages, easyNeed),
    ...pickFromBand(mediumStages, mediumNeed),
    ...pickFromBand(hardStages, hardNeed),
  ];

  return combined.map((item, idx) => ({
    ...item,
    questionNumber: idx + 1,
  }));
}
