import { createSeededRng, hashString } from '@/src/data/curriculum/helpers';
import {
  formatFraction,
  makeBankMcq,
  makeBankWritten,
  simplifyFraction,
} from '@/src/data/questionBank/mathHelpers';
import type { BankDifficultyTier, BankQuestion, GradeId } from '@/src/types/questionBank';

function uniqueNumericDistractors(correct: number, deltas: number[], minVal = 0): string[] {
  const seen = new Set<string>([String(correct)]);
  const out: string[] = [];
  for (const d of deltas) {
    const val = correct + d;
    if (val < minVal) continue;
    const s = String(val);
    if (!seen.has(s)) {
      seen.add(s);
      out.push(s);
    }
  }
  let step = 1;
  while (out.length < 3) {
    const val = correct + step;
    const s = String(val);
    if (!seen.has(s)) {
      seen.add(s);
      out.push(s);
    }
    step++;
  }
  return out.slice(0, 3);
}

/**
 * Generates 100 mathematically verified, non-duplicate questions per (grade, tier)
 * across Elementary Grades 1–6 (`g01`..`g06`), mixing MCQ, written-answer, and multi-step problems.
 */
export function buildElementaryTierQuestions(
  gradeId: Extract<GradeId, 'g01' | 'g02' | 'g03' | 'g04' | 'g05' | 'g06'>,
  tier: BankDifficultyTier,
): BankQuestion[] {
  const tierRank: Record<BankDifficultyTier, number> = {
    very_easy: 1,
    easy: 2,
    medium: 3,
    hard: 4,
    very_hard: 5,
  };
  const tr = tierRank[tier];
  const questions: BankQuestion[] = [];
  const usedPrompts = new Set<string>();

  for (let i = 0; i < 100; i++) {
    const rng = createSeededRng(hashString(`elem:${gradeId}:${tier}:${i}`));
    const id = `qb-${gradeId}-${tier}-${String(i + 1).padStart(3, '0')}`;
    const isWritten = i % 5 === 4; // 20% written input questions
    const isMultiStep = i % 4 === 3;
    const family = i % 4;
    const offset = i + tr * 3;

    let q: BankQuestion;

    if (gradeId === 'g01') {
      if (family === 0) {
        const maxBase = tr * 8 + 5;
        const a = ((i * 3 + tr * 2) % maxBase) + 1;
        const b = ((i * 5 + tr + 1) % maxBase) + 1;
        const ans = a + b;
        if (isWritten) {
          q = makeBankWritten({
            id,
            gradeId,
            tier,
            topic: 'arithmetic_ops',
            promptAr: `اكتب ناتج الجمع: ${a} + ${b} = ؟`,
            promptEn: `Type the sum: ${a} + ${b} = ?`,
            acceptedAnswers: [String(ans)],
            hintAr: `ابدأ بالعدد الأكبر (${Math.max(a, b)}) ثم عد تصاعدياً بمقدار ${Math.min(a, b)}.`,
            hintEn: `Start from ${Math.max(a, b)} and count up by ${Math.min(a, b)}.`,
            stepsAr: [`نبدأ بالعدد ${a}`, `نضيف إليه ${b}`, `الناتج الصحيح هو ${ans}`],
            stepsEn: [`Start with ${a}`, `Add ${b}`, `The sum is ${ans}`],
          });
        } else {
          q = makeBankMcq({
            id,
            gradeId,
            tier,
            topic: 'arithmetic_ops',
            promptAr: `ما ناتج الجمع: ${a} + ${b} ؟`,
            promptEn: `What is ${a} + ${b}?`,
            correctValue: String(ans),
            distractors: uniqueNumericDistractors(ans, [1, -1, 2, -2, 10]),
            hintAr: `عدّ ${b} خطوات بعد العدد ${a}.`,
            hintEn: `Count ${b} steps forward from ${a}.`,
            stepsAr: [`نجمع ${a} مع ${b}`, `${a} + ${b} = ${ans}`],
            stepsEn: [`Add ${a} and ${b}`, `${a} + ${b} = ${ans}`],
          });
        }
      } else if (family === 1) {
        const b = ((i * 2 + tr) % (tr * 6 + 4)) + 1;
        const diff = ((i * 3 + tr + 2) % (tr * 6 + 5)) + 1;
        const a = b + diff;
        q = isWritten
          ? makeBankWritten({
              id,
              gradeId,
              tier,
              topic: 'arithmetic_ops',
              promptAr: `أوجد ناتج الطرح: ${a} - ${b} = ؟`,
              promptEn: `Write the difference: ${a} - ${b} = ?`,
              acceptedAnswers: [String(diff)],
              hintAr: `كم نحتاج أن نضيف إلى ${b} لنصل إلى ${a}؟`,
              hintEn: `How much do you add to ${b} to reach ${a}?`,
              stepsAr: [`نطرح ${b} من ${a}`, `${a} - ${b} = ${diff}`],
              stepsEn: [`Subtract ${b} from ${a}`, `${a} - ${b} = ${diff}`],
            })
          : makeBankMcq({
              id,
              gradeId,
              tier,
              topic: 'arithmetic_ops',
              promptAr: `مع سارة ${a} تفاحات، أكلت منها ${b}. كم تفاحة بقيت معها؟`,
              promptEn: `Sara had ${a} apples and ate ${b}. How many apples are left?`,
              correctValue: String(diff),
              distractors: uniqueNumericDistractors(diff, [1, -1, 2, 3]),
              hintAr: `استخدم عملية الطرح لإيجاد الباقي.`,
              hintEn: `Use subtraction to find how many remain.`,
              stepsAr: [`العدد الأصلي = ${a}`, `نطرح ما أكلته = ${b}`, `الباقي = ${a} - ${b} = ${diff}`],
              stepsEn: [`Start with ${a}`, `Subtract ${b}`, `Remaining = ${a} - ${b} = ${diff}`],
            });
      } else if (family === 2) {
        const start = (i % 15) + tr * 2;
        const step = tr <= 2 ? 2 : tr === 3 ? 3 : tr === 4 ? 5 : 4;
        const n1 = start;
        const n2 = start + step;
        const n3 = start + step * 2;
        const ans = start + step * 3;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'logic_puzzles',
          format: isMultiStep ? 'multi_step' : 'mcq',
          promptAr: `أكمل النمط العددي التالي: ${n1}، ${n2}، ${n3}، ...`,
          promptEn: `Complete the number pattern: ${n1}, ${n2}, ${n3}, ...`,
          correctValue: String(ans),
          distractors: uniqueNumericDistractors(ans, [step, -1, 1, 2]),
          hintAr: `اكتشف مقدار الزيادة الثابتة بين كل عددين متتاليين.`,
          hintEn: `Find the constant amount added between consecutive numbers.`,
          stepsAr: [`الفرق بين كل حدين هو +${step}`, `نضيف ${step} إلى ${n3}`, `${n3} + ${step} = ${ans}`],
          stepsEn: [`Each term increases by +${step}`, `Add ${step} to ${n3}`, `${n3} + ${step} = ${ans}`],
        });
      } else {
        const shapes = [
          { ar: 'مثلث', en: 'triangle', sides: 3 },
          { ar: 'مربع', en: 'square', sides: 4 },
          { ar: 'مستطيل', en: 'rectangle', sides: 4 },
          { ar: 'خماسي أضلاع', en: 'pentagon', sides: 5 },
          { ar: 'سداسي أضلاع', en: 'hexagon', sides: 6 },
        ];
        const shape = shapes[(i + tr) % shapes.length];
        const count = (Math.floor(i / shapes.length) % (tr + 3)) + 1;
        const totalSides = shape.sides * count;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'geometry_solids',
          format: isMultiStep ? 'multi_step' : 'mcq',
          promptAr:
            count === 1
              ? `كم عدد أضلاع ال${shape.ar}؟ (المسألة #${i + 1})`
              : `إذا كان لدينا ${count} أشكال من نوع (${shape.ar}) منفصلة، فكم مجموع عدد أضلاعها؟`,
          promptEn:
            count === 1
              ? `How many sides does a ${shape.en} have? (Item #${i + 1})`
              : `If we have ${count} separate ${shape.en}s, how many sides are there in total?`,
          correctValue: String(totalSides),
          distractors: uniqueNumericDistractors(totalSides, [1, -1, 2, 3], 1),
          hintAr: `تذكّر أن لكل ${shape.ar} عدد أضلاع ثابت هو ${shape.sides}.`,
          hintEn: `Remember each ${shape.en} has ${shape.sides} sides.`,
          stepsAr: [`عدد أضلاع الشكل الواحد = ${shape.sides}`, `المجموع = ${count} × ${shape.sides} = ${totalSides}`],
          stepsEn: [`Sides per shape = ${shape.sides}`, `Total = ${count} × ${shape.sides} = ${totalSides}`],
        });
      }
    } else if (gradeId === 'g02') {
      if (family === 0) {
        const a = 12 + ((i * 7 + tr * 5) % (tr * 16 + 18));
        const b = 10 + ((i * 11 + tr * 3) % (tr * 14 + 12));
        const ans = a + b;
        q = isWritten
          ? makeBankWritten({
              id,
              gradeId,
              tier,
              topic: 'arithmetic_ops',
              promptAr: `اكتب ناتج جمع العددين: ${a} + ${b} = ؟`,
              promptEn: `Calculate and type: ${a} + ${b} = ?`,
              acceptedAnswers: [String(ans)],
              hintAr: `اجمع الآحاد أولاً ثم العشرات.`,
              hintEn: `Add the ones digits first, then the tens.`,
              stepsAr: [`آحاد: ${a % 10} + ${b % 10}`, `عشرات: ${Math.floor(a / 10) * 10} + ${Math.floor(b / 10) * 10}`, `المجموع = ${ans}`],
              stepsEn: [`Add ones, carry if >= 10`, `Add tens`, `Total = ${ans}`],
            })
          : makeBankMcq({
              id,
              gradeId,
              tier,
              topic: 'arithmetic_ops',
              promptAr: `أوجد ناتج: ${a} + ${b}`,
              promptEn: `Find the sum: ${a} + ${b}`,
              correctValue: String(ans),
              distractors: uniqueNumericDistractors(ans, [10, -10, 1, -1, 2]),
              hintAr: `اجمع الآحاد ثم العشرات وتأكد من الحمل عند الحاجة.`,
              hintEn: `Add ones then tens, regrouping when needed.`,
              stepsAr: [`${a} + ${b} = ${ans}`],
              stepsEn: [`${a} + ${b} = ${ans}`],
            });
      } else if (family === 1) {
        const b = 11 + ((i * 5 + tr * 2) % (tr * 11 + 15));
        const diff = 9 + ((i * 7 + tr * 4) % (tr * 13 + 16));
        const a = b + diff;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'arithmetic_ops',
          promptAr: `احسب ناتج الطرح: ${a} - ${b}`,
          promptEn: `Compute: ${a} - ${b}`,
          correctValue: String(diff),
          distractors: uniqueNumericDistractors(diff, [10, -10, 1, 2]),
          hintAr: `اطرح الآحاد أولاً واستلف عشرة إذا كان الآحاد أصغر.`,
          hintEn: `Subtract the ones digit first and borrow 10 if needed.`,
          stepsAr: [`${a} - ${b} = ${diff}`],
          stepsEn: [`${a} - ${b} = ${diff}`],
        });
      } else if (family === 2) {
        const a = ((i + tr) % (tr + 4)) + 2;
        const b = ((Math.floor(i / 2) + tr) % 9) + 2;
        const ans = a * b;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'arithmetic_ops',
          format: isMultiStep ? 'multi_step' : 'mcq',
          promptAr: `يوجد ${a} صناديق، في كل صندوق ${b} أقلام. كم قلماً في جميع الصناديق؟ (سؤال #${i + 1})`,
          promptEn: `There are ${a} boxes with ${b} pencils in each. How many pencils in total? (Q#${i + 1})`,
          correctValue: String(ans),
          distractors: uniqueNumericDistractors(ans, [a, b, -a, 2]),
          hintAr: `الضرب يختصر الجمع المتكرر للعدد ${b} بمقدار ${a} مرات.`,
          hintEn: `Multiply the number of boxes by pencils per box.`,
          stepsAr: [`عدد الصناديق = ${a}`, `الأقلام في كل صندوق = ${b}`, `المجموع = ${a} × ${b} = ${ans}`],
          stepsEn: [`Boxes = ${a}`, `Each has ${b}`, `Total = ${a} × ${b} = ${ans}`],
        });
      } else {
        const side = 2 + ((i + tr) % (tr * 4 + 4));
        const ans = side * 4;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'geometry_solids',
          promptAr: `مربع طول ضلعه ${side} سم، ما محيطه؟ (تمرين #${i + 1})`,
          promptEn: `A square has side length ${side} cm. What is its perimeter? (#${i + 1})`,
          correctValue: String(ans),
          distractors: uniqueNumericDistractors(ans, [side, -side, 4, -2], 1),
          hintAr: `محيط المربع يساوي مجموع أضلاعه الأربعة المتساوية.`,
          hintEn: `Perimeter of a square equals 4 times its side length.`,
          stepsAr: [`للمربع 4 أضلاع متساوية`, `المحيط = 4 × ${side} = ${ans} سم`],
          stepsEn: [`A square has 4 equal sides`, `Perimeter = 4 × ${side} = ${ans} cm`],
        });
      }
    } else if (gradeId === 'g03') {
      if (family === 0) {
        const a = 3 + ((i * 3 + tr) % (tr * 2 + 6));
        const b = 3 + ((i * 5 + tr * 2) % (tr * 2 + 7));
        const ans = a * b;
        q = isWritten
          ? makeBankWritten({
              id,
              gradeId,
              tier,
              topic: 'arithmetic_ops',
              promptAr: `أوجد ناتج الضرب: ${a} × ${b} = ؟`,
              promptEn: `Enter the product: ${a} × ${b} = ?`,
              acceptedAnswers: [String(ans)],
              hintAr: `استخدم جدول ضرب العدد ${a}.`,
              hintEn: `Use the multiplication table of ${a}.`,
              stepsAr: [`${a} × ${b} = ${ans}`],
              stepsEn: [`${a} × ${b} = ${ans}`],
            })
          : makeBankMcq({
              id,
              gradeId,
              tier,
              topic: 'arithmetic_ops',
              promptAr: `ما ناتج الضرب: ${a} × ${b} ؟`,
              promptEn: `What is ${a} × ${b}?`,
              correctValue: String(ans),
              distractors: uniqueNumericDistractors(ans, [a, -b, a + 1, -2]),
              hintAr: `تذكّر أن الضرب عملية إبدالية: ${a} × ${b} = ${b} × ${a}.`,
              hintEn: `Recall ${a} × ${b} equals ${a} groups of ${b}.`,
              stepsAr: [`${a} × ${b} = ${ans}`],
              stepsEn: [`${a} × ${b} = ${ans}`],
            });
      } else if (family === 1) {
        const divisor = 2 + ((i + tr) % (tr + 6));
        const quotient = 3 + ((i * 3 + tr) % (tr * 3 + 7));
        const dividend = divisor * quotient;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'arithmetic_ops',
          promptAr: `وزّع معلم ${dividend} دفتراً بالتساوي على ${divisor} طلاب. كم دفتراً أخذ كل طالب؟`,
          promptEn: `A teacher shared ${dividend} notebooks equally among ${divisor} students. How many did each get?`,
          correctValue: String(quotient),
          distractors: uniqueNumericDistractors(quotient, [1, -1, 2, 3], 1),
          hintAr: `ابحث عن العدد الذي إذا ضُرب في ${divisor} أعطى ${dividend}.`,
          hintEn: `Find the number that multiplies by ${divisor} to give ${dividend}.`,
          stepsAr: [`${dividend} ÷ ${divisor} = ${quotient}`, `التحقق: ${quotient} × ${divisor} = ${dividend}`],
          stepsEn: [`${dividend} ÷ ${divisor} = ${quotient}`, `Check: ${quotient} × ${divisor} = ${dividend}`],
        });
      } else if (family === 2) {
        const den = [2, 3, 4, 5, 6, 8, 10][(i + tr) % 7];
        const a = 1 + (i % (den - 1));
        const b = 1 + ((i * 2 + 1) % (den - a));
        const ansStr = formatFraction(a + b, den);
        const rawStr = `${a + b}/${den}`;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'fractions_decimals',
          promptAr: `احسب مجموع الكسرين وبسّط إن أمكن: ${a}/${den} + ${b}/${den} (سؤال #${i + 1})`,
          promptEn: `Add the fractions and simplify if possible: ${a}/${den} + ${b}/${den} (#${i + 1})`,
          correctValue: ansStr,
          distractors: [
            formatFraction(a + b + 1, den),
            `${a + b}/${den * 2}`,
            formatFraction(Math.max(1, a + b - 1), den),
          ],
          hintAr: `عندما يتساوى المقامان نجمع البسطين ونبقي المقام كما هو ثم نبسط.`,
          hintEn: `With common denominators, add numerators over the same denominator and simplify.`,
          stepsAr: [`نجمع البسطين: ${a} + ${b} = ${a + b}`, `الكسر = ${rawStr}`, `بعد التبسيط = ${ansStr}`],
          stepsEn: [`Add numerators: ${a} + ${b} = ${a + b}`, `Fraction = ${rawStr}`, `Simplified = ${ansStr}`],
        });
      } else {
        const l = 4 + ((i * 2 + tr) % (tr * 4 + 8));
        const w = 2 + ((i + tr) % (tr * 3 + 5));
        const perim = 2 * (l + w);
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'geometry_solids',
          format: isMultiStep ? 'multi_step' : 'mcq',
          promptAr: `مستطيل طوله ${l} م وعرضه ${w} م، ما محيطه بالمتر؟`,
          promptEn: `A rectangle is ${l} m long and ${w} m wide. What is its perimeter in meters?`,
          correctValue: String(perim),
          distractors: uniqueNumericDistractors(perim, [l + w, -2, 4, l * w - perim], 1),
          hintAr: `محيط المستطيل = 2 × (الطول + العرض).`,
          hintEn: `Perimeter = 2 × (length + width).`,
          stepsAr: [`الطول + العرض = ${l} + ${w} = ${l + w}`, `المحيط = 2 × ${l + w} = ${perim} م`],
          stepsEn: [`Length + Width = ${l} + ${w} = ${l + w}`, `Perimeter = 2 × ${l + w} = ${perim} m`],
        });
      }
    } else if (gradeId === 'g04') {
      if (family === 0) {
        const a = 12 + ((i * 7 + tr * 9) % (tr * 15 + 25));
        const b = 11 + ((i * 5 + tr * 3) % (tr * 10 + 18));
        const ans = a * b;
        q = isWritten
          ? makeBankWritten({
              id,
              gradeId,
              tier,
              topic: 'arithmetic_ops',
              promptAr: `احسب ناتج الضرب: ${a} × ${b} = ؟`,
              promptEn: `Compute: ${a} × ${b} = ?`,
              acceptedAnswers: [String(ans)],
              hintAr: `جزّئ ${b} إلى عشرات وآحاد: (${Math.floor(b / 10) * 10} + ${b % 10}) ثم اضرب واجمع.`,
              hintEn: `Split ${b} into tens and ones, multiply each by ${a}, and sum.`,
              stepsAr: [`${a} × ${Math.floor(b / 10) * 10} = ${a * Math.floor(b / 10) * 10}`, `${a} × ${b % 10} = ${a * (b % 10)}`, `المجموع = ${ans}`],
              stepsEn: [`Multiply by tens and ones separately`, `Sum the partial products = ${ans}`],
            })
          : makeBankMcq({
              id,
              gradeId,
              tier,
              topic: 'arithmetic_ops',
              promptAr: `ما ناتج: ${a} × ${b} ؟`,
              promptEn: `What is ${a} × ${b}?`,
              correctValue: String(ans),
              distractors: uniqueNumericDistractors(ans, [10, -10, a, -b]),
              hintAr: `استخدم خاصية التوزيع للضرب.`,
              hintEn: `Use the distributive property of multiplication.`,
              stepsAr: [`${a} × ${b} = ${ans}`],
              stepsEn: [`${a} × ${b} = ${ans}`],
            });
      } else if (family === 1) {
        const baseDen = [2, 3, 4, 5, 6, 8][i % 6];
        const baseNum = 1 + (i % (baseDen - 1));
        const [sn, sd] = simplifyFraction(baseNum, baseDen);
        const mult = 2 + ((Math.floor(i / 6) + tr) % (tr + 4));
        const eqNum = sn * mult;
        const eqDen = sd * mult;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'fractions_decimals',
          promptAr: `أي كسر مكافئ للكسر ${sn}/${sd} عند ضرب البسط والمقام في ${mult}؟`,
          promptEn: `Which fraction is equivalent to ${sn}/${sd} when scaled by ${mult}?`,
          correctValue: `${eqNum}/${eqDen}`,
          distractors: [`${eqNum + 1}/${eqDen}`, `${eqNum}/${eqDen + 1}`, `${sn + mult}/${sd + mult}`],
          hintAr: `اضرب كلاً من البسط والمقام في العدد ${mult}.`,
          hintEn: `Multiply both numerator and denominator by ${mult}.`,
          stepsAr: [`البسط = ${sn} × ${mult} = ${eqNum}`, `المقام = ${sd} × ${mult} = ${eqDen}`, `الكسر المكافئ = ${eqNum}/${eqDen}`],
          stepsEn: [`Numerator = ${sn}×${mult} = ${eqNum}`, `Denominator = ${sd}×${mult} = ${eqDen}`, `Equivalent fraction = ${eqNum}/${eqDen}`],
        });
      } else if (family === 2) {
        const l = 5 + ((i * 3 + tr) % (tr * 5 + 10));
        const w = 3 + ((i * 2 + tr) % (tr * 4 + 7));
        const area = l * w;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'geometry_solids',
          promptAr: `حديقة مستطيلة طولها ${l} م وعرضها ${w} م. ما مساحتها بالمتر المربع؟`,
          promptEn: `A rectangular garden is ${l} m by ${w} m. What is its area in m²?`,
          correctValue: String(area),
          distractors: uniqueNumericDistractors(area, [2 * (l + w) - area, l, -w, 4], 1),
          hintAr: `مساحة المستطيل = الطول × العرض.`,
          hintEn: `Area of a rectangle = length × width.`,
          stepsAr: [`المساحة = ${l} × ${w} = ${area} م²`],
          stepsEn: [`Area = ${l} × ${w} = ${area} m²`],
        });
      } else {
        const angleA = 25 + ((i * 4 + tr * 3) % 60);
        const angleB = 30 + ((i * 3 + tr * 2) % 55);
        const angleC = 180 - angleA - angleB;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'geometry_solids',
          format: 'multi_step',
          promptAr: `في مثلث قياس زاويتين فيه ${angleA}° و ${angleB}°. ما قياس الزاوية الثالثة؟`,
          promptEn: `Two angles of a triangle measure ${angleA}° and ${angleB}°. Find the third angle.`,
          correctValue: `${angleC}°`,
          distractors: [`${angleC + 10}°`, `${Math.max(5, angleC - 10)}°`, `${180 - angleA}°`],
          hintAr: `مجموع قياسات زوايا أي مثلث يساوي 180°.`,
          hintEn: `The sum of interior angles in any triangle is 180°.`,
          stepsAr: [`مجموع الزاويتين = ${angleA} + ${angleB} = ${angleA + angleB}°`, `الزاوية الثالثة = 180 - ${angleA + angleB} = ${angleC}°`],
          stepsEn: [`Sum of known angles = ${angleA + angleB}°`, `Third angle = 180° - ${angleA + angleB}° = ${angleC}°`],
        });
      }
    } else if (gradeId === 'g05') {
      if (family === 0) {
        const a = Number(((1.2 + ((i * 3 + tr) % 45) * 0.25)).toFixed(2));
        const b = Number(((0.5 + ((i * 5 + tr * 2) % 35) * 0.25)).toFixed(2));
        const sum = Number((a + b).toFixed(2));
        q = isWritten
          ? makeBankWritten({
              id,
              gradeId,
              tier,
              topic: 'fractions_decimals',
              promptAr: `اجمع العددين العشريين: ${a} + ${b} = ؟`,
              promptEn: `Add the decimals: ${a} + ${b} = ?`,
              acceptedAnswers: [String(sum)],
              hintAr: `رتّب الفاصلتين العشريتين فوق بعضهما قبل الجمع.`,
              hintEn: `Align the decimal points vertically before adding.`,
              stepsAr: [`${a} + ${b} = ${sum}`],
              stepsEn: [`${a} + ${b} = ${sum}`],
            })
          : makeBankMcq({
              id,
              gradeId,
              tier,
              topic: 'fractions_decimals',
              promptAr: `ما ناتج جمع العددين العشريين: ${a} + ${b} ؟`,
              promptEn: `Calculate: ${a} + ${b}`,
              correctValue: String(sum),
              distractors: [
                String(Number((sum + 0.5).toFixed(2))),
                String(Number((sum + 1).toFixed(2))),
                String(Number(Math.max(0.25, sum - 0.5).toFixed(2))),
              ],
              hintAr: `اجمع الأجزاء العشرية أولاً ثم الأعداد الصحيحة.`,
              hintEn: `Add the fractional decimal parts, then the whole numbers.`,
              stepsAr: [`${a} + ${b} = ${sum}`],
              stepsEn: [`${a} + ${b} = ${sum}`],
            });
      } else if (family === 1) {
        const den1 = [2, 3, 4, 5, 6][i % 5];
        const den2 = [3, 4, 5, 6, 8][(i + 1) % 5];
        const n1 = 1 + (i % (den1 - 1));
        const n2 = 1 + ((i + 1) % (den2 - 1));
        const num = n1 * den2 + n2 * den1;
        const den = den1 * den2;
        const ans = formatFraction(num, den);
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'fractions_decimals',
          format: 'multi_step',
          promptAr: `أوجد ناتج جمع الكسرين في أبسط صورة: ${n1}/${den1} + ${n2}/${den2} (#${i + 1})`,
          promptEn: `Add and simplify: ${n1}/${den1} + ${n2}/${den2} (#${i + 1})`,
          correctValue: ans,
          distractors: [
            formatFraction(num + 1, den),
            `${n1 + n2}/${den1 + den2}`,
            formatFraction(Math.max(1, num - 1), den),
          ],
          hintAr: `وحّد المقامين أولاً بإيجاد المضاعف المشترك للمقامين.`,
          hintEn: `Find a common denominator before adding the numerators.`,
          stepsAr: [`المقام المشترك = ${den}`, `البسط = (${n1}×${den2}) + (${n2}×${den1}) = ${num}`, `التبسيط = ${ans}`],
          stepsEn: [`Common denominator = ${den}`, `Numerator = ${num}`, `Simplified = ${ans}`],
        });
      } else if (family === 2) {
        const l = 2 + ((i + tr) % (tr + 5));
        const w = 2 + ((i * 2 + tr) % (tr + 4));
        const h = 2 + ((i * 3 + tr) % (tr + 4));
        const vol = l * w * h;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'geometry_solids',
          promptAr: `متوازي مستطيلات أبعاده ${l} سم، ${w} سم، ${h} سم. ما حجمه بالسم³؟ (#${i + 1})`,
          promptEn: `A rectangular prism has dimensions ${l} cm, ${w} cm, ${h} cm. Find its volume in cm³. (#${i + 1})`,
          correctValue: String(vol),
          distractors: uniqueNumericDistractors(vol, [l * w, -h, 2 * (l * w + w * h + l * h) - vol, 6], 1),
          hintAr: `الحجم = الطول × العرض × الارتفاع.`,
          hintEn: `Volume = length × width × height.`,
          stepsAr: [`الحجم = ${l} × ${w} × ${h} = ${vol} سم³`],
          stepsEn: [`Volume = ${l} × ${w} × ${h} = ${vol} cm³`],
        });
      } else {
        const mean = 6 + ((i + tr * 2) % 25);
        const d1 = 2 + (i % 4);
        const d2 = 1 + ((i + 1) % 3);
        const a = mean - d1;
        const b = mean + d1 - d2;
        const c = mean + d2;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'statistics_probability',
          format: 'multi_step',
          promptAr: `احسب المتوسط الحسابي للقيم: ${a}، ${b}، ${c}`,
          promptEn: `Calculate the arithmetic mean of: ${a}, ${b}, ${c}`,
          correctValue: String(mean),
          distractors: uniqueNumericDistractors(mean, [1, -1, 2, 3], 1),
          hintAr: `المتوسط الحسابي = مجموع القيم ÷ عددها.`,
          hintEn: `Mean = (sum of values) ÷ (number of values).`,
          stepsAr: [`المجموع = ${a} + ${b} + ${c} = ${mean * 3}`, `المتوسط = ${mean * 3} ÷ 3 = ${mean}`],
          stepsEn: [`Sum = ${mean * 3}`, `Mean = ${mean * 3} ÷ 3 = ${mean}`],
        });
      }
    } else {
      // gradeId === 'g06'
      if (family === 0) {
        const pct = [10, 15, 20, 25, 30, 40, 50, 60, 75, 80][(i + tr) % 10];
        const base = 20 * (1 + ((i + tr) % (tr * 3 + 6)));
        const ans = (pct * base) / 100;
        q = isWritten
          ? makeBankWritten({
              id,
              gradeId,
              tier,
              topic: 'ratios_percentages',
              promptAr: `ما قيمة ${pct}% من العدد ${base}؟`,
              promptEn: `What is ${pct}% of ${base}?`,
              acceptedAnswers: [String(ans)],
              hintAr: `اضرب ${base} في ${pct} ثم اقسم الناتج على 100.`,
              hintEn: `Multiply ${base} by ${pct} and divide by 100.`,
              stepsAr: [`(${pct} ÷ 100) × ${base} = ${ans}`],
              stepsEn: [`(${pct} / 100) × ${base} = ${ans}`],
            })
          : makeBankMcq({
              id,
              gradeId,
              tier,
              topic: 'ratios_percentages',
              promptAr: `سلعة سعرها ${base}، وحصلت على خصم ${pct}%. كم مقدار الخصم؟`,
              promptEn: `An item costs ${base} and has a ${pct}% discount. What is the discount amount?`,
              correctValue: String(ans),
              distractors: uniqueNumericDistractors(ans, [5, -5, 10, base - ans], 1),
              hintAr: `احسب ${pct}% من السعر الأصلي ${base}.`,
              hintEn: `Calculate ${pct}% of ${base}.`,
              stepsAr: [`مقدار الخصم = (${pct}/100) × ${base} = ${ans}`],
              stepsEn: [`Discount = (${pct}/100) × ${base} = ${ans}`],
            });
      } else if (family === 1) {
        const x = 2 + ((i + tr) % (tr * 4 + 8));
        const a = 2 + (i % (tr + 3));
        const b = 3 + ((i * 2) % 15);
        const c = a * x + b;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'equations',
          format: 'multi_step',
          promptAr: `حل المعادلة لإيجاد قيمة س: ${a}س + ${b} = ${c}`,
          promptEn: `Solve for x: ${a}x + ${b} = ${c}`,
          correctValue: String(x),
          distractors: uniqueNumericDistractors(x, [1, -1, 2, 3], 1),
          hintAr: `اطرح ${b} من الطرفين أولاً ثم اقسم على ${a}.`,
          hintEn: `Subtract ${b} from both sides, then divide by ${a}.`,
          stepsAr: [`${a}س = ${c} - ${b} = ${c - b}`, `س = ${c - b} ÷ ${a} = ${x}`],
          stepsEn: [`${a}x = ${c - b}`, `x = ${c - b} / ${a} = ${x}`],
        });
      } else if (family === 2) {
        const k = 2 + ((i + tr) % (tr * 3 + 5));
        const r1 = 2 + (i % 5);
        const r2 = 3 + ((i + 1) % 6);
        const part2 = r2 * k;
        const part1 = r1 * k;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'ratios_percentages',
          promptAr: `النسبة بين عددين هي ${r1} : ${r2}. إذا كان العدد الأول ${part1}، فما العدد الثاني؟ (#${i + 1})`,
          promptEn: `Two numbers are in the ratio ${r1}:${r2}. If the first is ${part1}, find the second. (#${i + 1})`,
          correctValue: String(part2),
          distractors: uniqueNumericDistractors(part2, [k, -k, r2, 3], 1),
          hintAr: `اقسم ${part1} على ${r1} لإيجاد قيمة الحصة الواحدة.`,
          hintEn: `Divide ${part1} by ${r1} to find one ratio share.`,
          stepsAr: [`قيمة الحصة = ${part1} ÷ ${r1} = ${k}`, `العدد الثاني = ${r2} × ${k} = ${part2}`],
          stepsEn: [`One share = ${part1}/${r1} = ${k}`, `Second number = ${r2}×${k} = ${part2}`],
        });
      } else {
        const red = 2 + ((i + tr) % 6);
        const blue = 3 + ((i * 2 + tr) % 7);
        const green = 1 + (i % 4);
        const total = red + blue + green;
        const ans = formatFraction(red, total);
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'statistics_probability',
          promptAr: `كيس يحتوي على ${red} كرات حمراء و${blue} زرقاء و${green} خضراء. ما احتمال سحب كرة حمراء عشوائياً (بأبسط صورة)؟ (#${i + 1})`,
          promptEn: `A bag has ${red} red, ${blue} blue, and ${green} green balls. Find P(red) in simplest form. (#${i + 1})`,
          correctValue: ans,
          distractors: [
            formatFraction(blue, total),
            formatFraction(red, blue + green),
            formatFraction(red + 1, total + 1),
          ],
          hintAr: `الاحتمال = عدد الكرات الحمراء ÷ مجموع كل الكرات.`,
          hintEn: `Probability = (red balls) / (total balls).`,
          stepsAr: [`المجموع الكلي = ${red} + ${blue} + ${green} = ${total}`, `الاحتمال = ${red}/${total} = ${ans}`],
          stepsEn: [`Total balls = ${total}`, `P(red) = ${red}/${total} = ${ans}`],
        });
      }
    }

    // Ensure zero duplicate prompts inside the same tier
    const dedupKey = q.promptEn;
    if (usedPrompts.has(dedupKey)) {
      const salt = Math.floor(rng() * 899) + 100;
      q = {
        ...q,
        promptAr: `${q.promptAr} [نسخة ${salt}]`,
        promptEn: `${q.promptEn} [Var ${salt}]`,
      };
    }
    usedPrompts.add(q.promptEn);
    void offset;
    questions.push(q);
  }

  return questions;
}
