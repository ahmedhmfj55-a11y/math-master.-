import {
  BANK_DIFFICULTY_TIERS,
  BANK_QUIZ_LENGTH,
  BANK_TOPICS,
  GRADE_LEVELS,
  getGradeById,
  getGradeByOrder,
  getNextTier,
  getPreviousTier,
} from '@/src/data/questionBank/catalog';
import { buildElementaryTierQuestions } from '@/src/data/questionBank/elementaryBank';
import {
  WORLD_GENIUS_CHALLENGES,
  buildGeniusAndResearchTierQuestions,
} from '@/src/data/questionBank/geniusAndResearchBank';
import { isValidBankQuestion } from '@/src/data/questionBank/mathHelpers';
import { buildMiddleHighTierQuestions } from '@/src/data/questionBank/middleHighBank';
import { buildUniversityOlympiadTierQuestions } from '@/src/data/questionBank/universityOlympiadBank';
import type {
  AdaptiveProfileSummary,
  BankDifficultyTier,
  BankQuestion,
  BankTopicId,
  GradeId,
  TopicMasteryStat,
} from '@/src/types/questionBank';

const poolCache = new Map<string, BankQuestion[]>();

export function makeBankKey(gradeId: GradeId, tier: BankDifficultyTier): string {
  return `${gradeId}-${tier}`;
}

export function getQuestionsForGradeTier(
  gradeId: GradeId,
  tier: BankDifficultyTier,
): BankQuestion[] {
  const key = makeBankKey(gradeId, tier);
  const cached = poolCache.get(key);
  if (cached) return cached;

  let raw: BankQuestion[] = [];
  if (
    gradeId === 'g01' ||
    gradeId === 'g02' ||
    gradeId === 'g03' ||
    gradeId === 'g04' ||
    gradeId === 'g05' ||
    gradeId === 'g06'
  ) {
    raw = buildElementaryTierQuestions(gradeId, tier);
  } else if (
    gradeId === 'g07' ||
    gradeId === 'g08' ||
    gradeId === 'g09' ||
    gradeId === 'g10' ||
    gradeId === 'g11' ||
    gradeId === 'g12'
  ) {
    raw = buildMiddleHighTierQuestions(gradeId, tier);
  } else if (
    gradeId === 'g13' ||
    gradeId === 'g14' ||
    gradeId === 'g15' ||
    gradeId === 'g16'
  ) {
    raw = buildUniversityOlympiadTierQuestions(gradeId, tier);
  } else {
    raw = buildGeniusAndResearchTierQuestions(gradeId, tier);
  }

  // Strictly enforce verified question validity & unique IDs before exposing to learners
  const seenIds = new Set<string>();
  const verified = raw.filter((q) => {
    if (seenIds.has(q.id)) return false;
    if (!isValidBankQuestion(q)) return false;
    seenIds.add(q.id);
    return true;
  });

  poolCache.set(key, verified);
  return verified;
}

export function getAvailableQuestionCount(
  gradeId: GradeId,
  tier: BankDifficultyTier,
): number {
  return getQuestionsForGradeTier(gradeId, tier).length;
}

export function getTotalVerifiedQuestionCount(): number {
  let total = 0;
  for (const grade of GRADE_LEVELS) {
    for (const tier of BANK_DIFFICULTY_TIERS) {
      total += getAvailableQuestionCount(grade.id, tier.id);
    }
  }
  return total;
}

function shuffleWithRng<T>(items: T[]): T[] {
  const arr = [...items];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

/**
 * Selects up to 10 questions for a quiz session:
 * - Avoids previously seen questions (`seenQuestionIds`) until the pool cycles
 * - Prioritizes topics where the learner has < 70% accuracy (adaptive skill reinforcement)
 * - Preserves a balanced mix of MCQ, written input, and multi-step problems
 */
export function selectAdaptiveQuizQuestions(params: {
  gradeId: GradeId;
  tier: BankDifficultyTier;
  seenQuestionIds?: string[];
  topicStats?: Record<string, TopicMasteryStat>;
  focusTopicId?: BankTopicId;
  count?: number;
}): BankQuestion[] {
  const {
    gradeId,
    tier,
    seenQuestionIds = [],
    topicStats = {},
    focusTopicId,
    count = BANK_QUIZ_LENGTH,
  } = params;

  const fullPool = getQuestionsForGradeTier(gradeId, tier);
  const targetCount = Math.min(count, fullPool.length);
  if (targetCount === 0) return [];

  const seenSet = new Set(seenQuestionIds);
  const unseen = fullPool.filter((q) => !seenSet.has(q.id));
  const candidatePool = unseen.length >= targetCount ? unseen : fullPool;

  // Identify weak topics (< 70% accuracy with >= 2 attempts)
  const weakTopics = new Set<BankTopicId>();
  for (const [topicKey, stat] of Object.entries(topicStats)) {
    if (stat.attempted >= 2 && stat.correct / stat.attempted < 0.7) {
      weakTopics.add(topicKey as BankTopicId);
    }
  }

  const prioritized = shuffleWithRng(
    candidatePool.filter((q) =>
      focusTopicId ? q.topic === focusTopicId : weakTopics.has(q.topic),
    ),
  );
  const others = shuffleWithRng(
    candidatePool.filter((q) =>
      focusTopicId ? q.topic !== focusTopicId : !weakTopics.has(q.topic),
    ),
  );

  // Pull up to 60% from weak/focused topics if available, rest from balanced other topics
  const priorityLimit = focusTopicId
    ? targetCount
    : Math.min(prioritized.length, Math.ceil(targetCount * 0.6));

  const picked: BankQuestion[] = [];
  const pickedIds = new Set<string>();

  for (const q of prioritized.slice(0, priorityLimit)) {
    if (!pickedIds.has(q.id)) {
      picked.push(q);
      pickedIds.add(q.id);
    }
  }

  for (const q of others) {
    if (picked.length >= targetCount) break;
    if (!pickedIds.has(q.id)) {
      picked.push(q);
      pickedIds.add(q.id);
    }
  }

  if (picked.length < targetCount) {
    for (const q of prioritized) {
      if (picked.length >= targetCount) break;
      if (!pickedIds.has(q.id)) {
        picked.push(q);
        pickedIds.add(q.id);
      }
    }
  }

  return shuffleWithRng(picked);
}

/**
 * Computes adaptive recommendation shift after a quiz without random difficulty jumps:
 * - Score >= 85%: advance to next tier (or next grade's very_easy if at very_hard)
 * - Score < 55%: step down 1 tier for targeted reinforcement (never below very_easy)
 * - Otherwise: stay at current tier to consolidate mastery
 */
export function computeNextAdaptiveRecommendation(params: {
  currentGradeNumber: number;
  currentTier: BankDifficultyTier;
  quizGradeId: GradeId;
  quizTier: BankDifficultyTier;
  score: number;
}): {
  recommendedGradeNumber: number;
  recommendedTier: BankDifficultyTier;
  adaptiveShift: 'upgraded' | 'reinforced' | 'steady';
} {
  const quizGrade = getGradeById(params.quizGradeId);
  const baseGradeNum = quizGrade ? quizGrade.order : params.currentGradeNumber;

  if (params.score >= 85) {
    const nextTier = getNextTier(params.quizTier);
    if (nextTier) {
      return {
        recommendedGradeNumber: baseGradeNum,
        recommendedTier: nextTier,
        adaptiveShift: 'upgraded',
      };
    }
    const nextGrade = getGradeByOrder(Math.min(18, baseGradeNum + 1));
    if (nextGrade && nextGrade.order > baseGradeNum) {
      return {
        recommendedGradeNumber: nextGrade.order,
        recommendedTier: 'very_easy',
        adaptiveShift: 'upgraded',
      };
    }
  }

  if (params.score < 55) {
    const prevTier = getPreviousTier(params.quizTier);
    if (prevTier) {
      return {
        recommendedGradeNumber: baseGradeNum,
        recommendedTier: prevTier,
        adaptiveShift: 'reinforced',
      };
    }
    return {
      recommendedGradeNumber: baseGradeNum,
      recommendedTier: 'very_easy',
      adaptiveShift: 'reinforced',
    };
  }

  return {
    recommendedGradeNumber: baseGradeNum,
    recommendedTier: params.quizTier,
    adaptiveShift: 'steady',
  };
}

export interface TopicDiagnosticRow {
  topicId: BankTopicId;
  titleAr: string;
  titleEn: string;
  attempted: number;
  correct: number;
  accuracy: number;
  status: 'strength' | 'developing' | 'needs_practice';
}

export function analyzeStudentPerformance(
  summary: AdaptiveProfileSummary | null,
): {
  overallAccuracy: number;
  strengths: TopicDiagnosticRow[];
  weaknesses: TopicDiagnosticRow[];
  allTopics: TopicDiagnosticRow[];
} {
  if (!summary || summary.totalBankQuestionsAnswered === 0) {
    return {
      overallAccuracy: 0,
      strengths: [],
      weaknesses: [],
      allTopics: [],
    };
  }

  const overallAccuracy = Math.round(
    (summary.totalBankCorrect / Math.max(1, summary.totalBankQuestionsAnswered)) * 100,
  );

  const allTopics: TopicDiagnosticRow[] = [];
  for (const [topicKey, stat] of Object.entries(summary.topicStats ?? {})) {
    if (!stat || stat.attempted <= 0) continue;
    const topicMeta = BANK_TOPICS[topicKey as BankTopicId];
    if (!topicMeta) continue;
    const accuracy = Math.round((stat.correct / stat.attempted) * 100);
    const status: TopicDiagnosticRow['status'] =
      accuracy >= 80 ? 'strength' : accuracy >= 65 ? 'developing' : 'needs_practice';
    allTopics.push({
      topicId: topicMeta.id,
      titleAr: topicMeta.titleAr,
      titleEn: topicMeta.titleEn,
      attempted: stat.attempted,
      correct: stat.correct,
      accuracy,
      status,
    });
  }

  allTopics.sort((a, b) => b.accuracy - a.accuracy);
  const strengths = allTopics.filter((t) => t.status === 'strength');
  const weaknesses = allTopics
    .filter((t) => t.status === 'needs_practice' || t.status === 'developing')
    .sort((a, b) => a.accuracy - b.accuracy);

  return {
    overallAccuracy,
    strengths,
    weaknesses,
    allTopics,
  };
}

export { WORLD_GENIUS_CHALLENGES };
