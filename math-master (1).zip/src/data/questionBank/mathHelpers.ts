import { createSeededRng, gcd, hashString } from '@/src/data/curriculum/helpers';
import type {
  BankDifficultyTier,
  BankQuestion,
  BankQuestionFormat,
  BankTopicId,
  GradeId,
  ProblemVerificationStatus,
} from '@/src/types/questionBank';

export function isPrime(n: number): boolean {
  if (n < 2) return false;
  if (n === 2) return true;
  if (n % 2 === 0) return false;
  for (let i = 3; i * i <= n; i += 2) {
    if (n % i === 0) return false;
  }
  return true;
}

export function modPow(base: number, exp: number, mod: number): number {
  let result = 1 % mod;
  let b = ((base % mod) + mod) % mod;
  let e = exp;
  while (e > 0) {
    if (e % 2 === 1) result = (result * b) % mod;
    b = (b * b) % mod;
    e = Math.floor(e / 2);
  }
  return result;
}

export function eulerPhi(n: number): number {
  let result = n;
  let temp = n;
  for (let p = 2; p * p <= temp; p++) {
    if (temp % p === 0) {
      while (temp % p === 0) temp = Math.floor(temp / p);
      result -= Math.floor(result / p);
    }
  }
  if (temp > 1) result -= Math.floor(result / temp);
  return result;
}

export function simplifyFraction(num: number, den: number): [number, number] {
  if (den === 0) throw new Error('Zero denominator');
  const sign = den < 0 ? -1 : 1;
  const g = gcd(Math.abs(num), Math.abs(den));
  return [(sign * num) / g, Math.abs(den) / g];
}

export function formatFraction(num: number, den: number): string {
  const [n, d] = simplifyFraction(num, den);
  return d === 1 ? `${n}` : `${n}/${d}`;
}

export function nCr(n: number, r: number): number {
  if (r < 0 || r > n) return 0;
  const k = Math.min(r, n - r);
  let res = 1;
  for (let i = 1; i <= k; i++) {
    res = Math.round((res * (n - k + i)) / i);
  }
  return res;
}

export function det2(a: number, b: number, c: number, d: number): number {
  return a * d - b * c;
}

export function det3(m: [number, number, number][]): number {
  return (
    m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) -
    m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) +
    m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0])
  );
}

/**
 * Converts Arabic/Persian digits and common Unicode math symbols into canonical ASCII form.
 */
export function normalizeMathAnswer(raw: string): string {
  const arabicDigits = '٠١٢٣٤٥٦٧٨٩';
  const persianDigits = '۰۱۲۳۴۵۶۷۸۹';
  let out = raw.trim().toLowerCase();

  for (let i = 0; i < 10; i++) {
    out = out.split(arabicDigits[i]).join(String(i));
    out = out.split(persianDigits[i]).join(String(i));
  }

  return out
    .replace(/[−–—]/g, '-')
    .replace(/[×·]/g, '*')
    .replace(/[÷⁄]/g, '/')
    .replace(/π/g, 'pi')
    .replace(/√/g, 'sqrt')
    .replace(/²/g, '^2')
    .replace(/³/g, '^3')
    .replace(/[،,]/g, '')
    .replace(/\s+/g, '')
    .replace(/^\+/, '');
}

function tryParseNumericOrFraction(str: string): number | null {
  const norm = normalizeMathAnswer(str);
  if (!norm) return null;
  if (/^-?\d+(\.\d+)?$/.test(norm)) {
    const val = Number(norm);
    return Number.isFinite(val) ? val : null;
  }
  const fracMatch = norm.match(/^(-?\d+)\/(-?\d+)$/);
  if (fracMatch) {
    const num = Number(fracMatch[1]);
    const den = Number(fracMatch[2]);
    if (den !== 0 && Number.isFinite(num / den)) {
      return num / den;
    }
  }
  return null;
}

export function isWrittenAnswerCorrect(rawInput: string, acceptedAnswers: string[]): boolean {
  const normInput = normalizeMathAnswer(rawInput);
  if (!normInput) return false;

  const inputNum = tryParseNumericOrFraction(normInput);
  for (const acc of acceptedAnswers) {
    const normAcc = normalizeMathAnswer(acc);
    if (normInput === normAcc) return true;
    const accNum = tryParseNumericOrFraction(normAcc);
    if (inputNum !== null && accNum !== null && Math.abs(inputNum - accNum) < 1e-6) {
      return true;
    }
  }
  return false;
}

export function makeBankMcq(params: {
  id: string;
  gradeId: GradeId;
  tier: BankDifficultyTier;
  topic: BankTopicId;
  format?: 'mcq' | 'multi_step' | 'proof';
  status?: ProblemVerificationStatus;
  promptAr: string;
  promptEn: string;
  correctValue: string;
  distractors: string[];
  hintAr: string;
  hintEn: string;
  stepsAr: string[];
  stepsEn: string[];
  explanationAr?: string;
  explanationEn?: string;
}): BankQuestion {
  const rng = createSeededRng(hashString(params.id));
  const uniqueDistractors: string[] = [];
  for (const d of params.distractors) {
    if (d !== params.correctValue && !uniqueDistractors.includes(d)) {
      uniqueDistractors.push(d);
    }
    if (uniqueDistractors.length === 3) break;
  }

  // Numeric safety padding if any distractor collided
  let delta = 1;
  const parsedCorrect = Number(params.correctValue);
  while (uniqueDistractors.length < 3) {
    const candidate = Number.isFinite(parsedCorrect)
      ? String(parsedCorrect + delta)
      : `${params.correctValue} (${delta})`;
    if (candidate !== params.correctValue && !uniqueDistractors.includes(candidate)) {
      uniqueDistractors.push(candidate);
    }
    delta++;
  }

  const pool = [
    { value: params.correctValue, isCorrect: true },
    { value: uniqueDistractors[0], isCorrect: false },
    { value: uniqueDistractors[1], isCorrect: false },
    { value: uniqueDistractors[2], isCorrect: false },
  ];

  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }

  const correctIndex = pool.findIndex((p) => p.isCorrect) as 0 | 1 | 2 | 3;

  return {
    id: params.id,
    gradeId: params.gradeId,
    tier: params.tier,
    topic: params.topic,
    format: params.format ?? 'mcq',
    status: params.status ?? 'solved_verified',
    promptAr: params.promptAr,
    promptEn: params.promptEn,
    options: [pool[0].value, pool[1].value, pool[2].value, pool[3].value],
    correctIndex,
    displayAnswer: params.correctValue,
    hintAr: params.hintAr,
    hintEn: params.hintEn,
    stepsAr: params.stepsAr,
    stepsEn: params.stepsEn,
    explanationAr: params.explanationAr ?? params.stepsAr.join(' ← '),
    explanationEn: params.explanationEn ?? params.stepsEn.join(' -> '),
  };
}

export function makeBankWritten(params: {
  id: string;
  gradeId: GradeId;
  tier: BankDifficultyTier;
  topic: BankTopicId;
  format?: BankQuestionFormat;
  status?: ProblemVerificationStatus;
  promptAr: string;
  promptEn: string;
  acceptedAnswers: string[];
  displayAnswer?: string;
  hintAr: string;
  hintEn: string;
  stepsAr: string[];
  stepsEn: string[];
  explanationAr?: string;
  explanationEn?: string;
}): BankQuestion {
  const displayAnswer = params.displayAnswer ?? params.acceptedAnswers[0];
  return {
    id: params.id,
    gradeId: params.gradeId,
    tier: params.tier,
    topic: params.topic,
    format: params.format ?? 'written',
    status: params.status ?? 'solved_verified',
    promptAr: params.promptAr,
    promptEn: params.promptEn,
    acceptedAnswers: params.acceptedAnswers,
    displayAnswer,
    hintAr: params.hintAr,
    hintEn: params.hintEn,
    stepsAr: params.stepsAr,
    stepsEn: params.stepsEn,
    explanationAr: params.explanationAr ?? params.stepsAr.join(' ← '),
    explanationEn: params.explanationEn ?? params.stepsEn.join(' -> '),
  };
}

export function isValidBankQuestion(q: BankQuestion): boolean {
  if (!q.id || !q.promptAr || !q.promptEn || !q.hintAr || !q.hintEn || !q.displayAnswer) {
    return false;
  }
  if (q.format === 'written') {
    return Array.isArray(q.acceptedAnswers) && q.acceptedAnswers.length > 0;
  }
  if (!q.options || q.options.length !== 4 || q.correctIndex === undefined) {
    return false;
  }
  return new Set(q.options).size === 4;
}
