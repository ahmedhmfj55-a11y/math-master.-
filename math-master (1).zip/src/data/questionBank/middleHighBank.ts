import {
  formatFraction,
  makeBankMcq,
  makeBankWritten,
  nCr,
} from '@/src/data/questionBank/mathHelpers';
import type { BankDifficultyTier, BankQuestion, GradeId } from '@/src/types/questionBank';

function uniqueNumericDistractors(correct: number, deltas: number[]): string[] {
  const seen = new Set<string>([String(correct)]);
  const out: string[] = [];
  for (const d of deltas) {
    const s = String(correct + d);
    if (!seen.has(s)) {
      seen.add(s);
      out.push(s);
    }
  }
  let step = 1;
  while (out.length < 3) {
    const s = String(correct + step);
    if (!seen.has(s)) {
      seen.add(s);
      out.push(s);
    }
    step++;
  }
  return out.slice(0, 3);
}

/**
 * Generates 100 mathematically verified, distinct questions per (grade, tier)
 * for Middle & High School Grades 7–12 (`g07`..`g12`).
 */
export function buildMiddleHighTierQuestions(
  gradeId: Extract<GradeId, 'g07' | 'g08' | 'g09' | 'g10' | 'g11' | 'g12'>,
  tier: BankDifficultyTier,
): BankQuestion[] {
  const tierRank: Record<BankDifficultyTier, number> = {
    very_easy: 1,
    easy: 2,
    medium: 3,
    hard: 4,
    very_hard: 5,
  };
  const tr = tierRank[tier];
  const questions: BankQuestion[] = [];
  const usedPrompts = new Set<string>();

  for (let i = 0; i < 100; i++) {
    const id = `qb-${gradeId}-${tier}-${String(i + 1).padStart(3, '0')}`;
    const isWritten = i % 5 === 4;
    const isMultiStep = i % 4 === 3;
    const family = i % 4;
    let q: BankQuestion;

    if (gradeId === 'g07') {
      if (family === 0) {
        const a = -1 * (2 + ((i + tr) % (tr * 4 + 8)));
        const b = 3 + ((i * 3 + tr * 2) % (tr * 5 + 10));
        const c = -1 * (1 + ((i * 2) % (tr * 3 + 5)));
        const ans = a * b + c;
        q = isWritten
          ? makeBankWritten({
              id,
              gradeId,
              tier,
              topic: 'arithmetic_ops',
              promptAr: `احسب قيمة العبارة: (${a}) × ${b} + (${c}) = ؟`,
              promptEn: `Evaluate: (${a}) × ${b} + (${c}) = ?`,
              acceptedAnswers: [String(ans)],
              hintAr: `نفّذ الضرب أولاً مع مراعاة قاعدة الإشارات، ثم اجمع.`,
              hintEn: `Multiply first respecting sign rules, then add.`,
              stepsAr: [`(${a}) × ${b} = ${a * b}`, `${a * b} + (${c}) = ${ans}`],
              stepsEn: [`(${a}) × ${b} = ${a * b}`, `${a * b} + (${c}) = ${ans}`],
            })
          : makeBankMcq({
              id,
              gradeId,
              tier,
              topic: 'arithmetic_ops',
              promptAr: `ما قيمة: (${a}) × ${b} + (${c}) ؟`,
              promptEn: `Evaluate: (${a}) × ${b} + (${c})`,
              correctValue: String(ans),
              distractors: uniqueNumericDistractors(ans, [Math.abs(ans) * 2 || 2, 2, -2, c * -2]),
              hintAr: `الضرب يسبق الجمع في ترتيب العمليات.`,
              hintEn: `Multiplication takes precedence over addition.`,
              stepsAr: [`${a * b} + (${c}) = ${ans}`],
              stepsEn: [`${a * b} + (${c}) = ${ans}`],
            });
      } else if (family === 1) {
        const x = (i % (tr * 4 + 6)) - 4;
        const a = 2 + (i % (tr + 3));
        const b = 1 + ((i * 2) % 9);
        const c = (i % 3) + 1;
        // a(x + b) - c = rhs
        const rhs = a * (x + b) - c;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'equations',
          format: 'multi_step',
          promptAr: `حل المعادلة التالية لإيجاد x: ${a}(x + ${b}) - ${c} = ${rhs}`,
          promptEn: `Solve for x: ${a}(x + ${b}) - ${c} = ${rhs}`,
          correctValue: String(x),
          distractors: uniqueNumericDistractors(x, [1, -1, 2, -2]),
          hintAr: `أضف ${c} إلى الطرفين ثم اقسم على ${a} قبل طرح ${b}.`,
          hintEn: `Add ${c} to both sides, divide by ${a}, then subtract ${b}.`,
          stepsAr: [
            `${a}(x + ${b}) = ${rhs + c}`,
            `x + ${b} = ${(rhs + c) / a}`,
            `x = ${(rhs + c) / a} - ${b} = ${x}`,
          ],
          stepsEn: [
            `${a}(x + ${b}) = ${rhs + c}`,
            `x + ${b} = ${(rhs + c) / a}`,
            `x = ${x}`,
          ],
        });
      } else if (family === 2) {
        const base = 20 * (2 + ((i + tr) % (tr * 4 + 5)));
        const pct = 5 + ((i * 5) % 45);
        const isIncrease = i % 2 === 0;
        const delta = (base * pct) / 100;
        const ans = isIncrease ? base + delta : base - delta;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'ratios_percentages',
          promptAr: isIncrease
            ? `زاد عدد طلاب نادٍ من ${base} بنسبة ${pct}%. كم أصبح العدد الجديد؟ (#${i + 1})`
            : `انخفض سعر جهاز من ${base} بنسبة ${pct}%. ما السعر الجديد؟ (#${i + 1})`,
          promptEn: isIncrease
            ? `A club of ${base} members grew by ${pct}%. What is the new size? (#${i + 1})`
            : `An item priced at ${base} dropped by ${pct}%. What is the new price? (#${i + 1})`,
          correctValue: String(ans),
          distractors: uniqueNumericDistractors(ans, [delta, -delta, 10, -10]),
          hintAr: `احسب مقدار التغيّر (${pct}% × ${base}) ثم أضفه أو اطرحه.`,
          hintEn: `Compute ${pct}% of ${base}, then add or subtract it.`,
          stepsAr: [`مقدار التغيّر = ${delta}`, `الناتج = ${base} ${isIncrease ? '+' : '-'} ${delta} = ${ans}`],
          stepsEn: [`Change = ${delta}`, `Result = ${ans}`],
        });
      } else {
        const a = 30 + ((i * 5 + tr * 3) % 85);
        const supp = 180 - a;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'geometry_solids',
          promptAr: `زاويتان متكاملتان، قياس إحداهما ${a}°. ما قياس الزاوية الأخرى؟ (#${i + 1})`,
          promptEn: `Two angles are supplementary and one is ${a}°. Find the other angle. (#${i + 1})`,
          correctValue: `${supp}°`,
          distractors: [`${Math.abs(90 - a)}°`, `${supp + 15}°`, `${Math.max(5, supp - 15)}°`],
          hintAr: `مجموع قياس الزاويتين المتكاملتين يساوي 180°.`,
          hintEn: `Supplementary angles sum to 180°.`,
          stepsAr: [`180° - ${a}° = ${supp}°`],
          stepsEn: [`180° - ${a}° = ${supp}°`],
        });
      }
    } else if (gradeId === 'g08') {
      if (family === 0) {
        const triples: [number, number, number][] = [
          [3, 4, 5],
          [5, 12, 13],
          [8, 15, 17],
          [7, 24, 25],
          [9, 40, 41],
        ];
        const [ta, tb, tc] = triples[i % triples.length];
        const scale = 1 + (Math.floor(i / triples.length) % (tr + 3));
        const a = ta * scale;
        const b = tb * scale;
        const c = tc * scale;
        q = isWritten
          ? makeBankWritten({
              id,
              gradeId,
              tier,
              topic: 'geometry_solids',
              promptAr: `مثلث قائم الزاوية طولا ضلعي القائمة فيه ${a} و ${b}. احسب طول الوتر: (#${i + 1})`,
              promptEn: `A right triangle has legs ${a} and ${b}. Find the hypotenuse: (#${i + 1})`,
              acceptedAnswers: [String(c)],
              hintAr: `طبّق نظرية فيثاغورس: الوتر² = أ² + ب².`,
              hintEn: `Apply the Pythagorean theorem: c² = a² + b².`,
              stepsAr: [`${a}² + ${b}² = ${a * a} + ${b * b} = ${c * c}`, `الوتر = √${c * c} = ${c}`],
              stepsEn: [`c² = ${a * a} + ${b * b} = ${c * c}`, `c = ${c}`],
            })
          : makeBankMcq({
              id,
              gradeId,
              tier,
              topic: 'geometry_solids',
              promptAr: `في مثلث قائم الزاوية، الوتر ${c} وأحد الضلعين ${a}. ما طول الضلع الآخر؟ (#${i + 1})`,
              promptEn: `In a right triangle with hypotenuse ${c} and leg ${a}, find the other leg. (#${i + 1})`,
              correctValue: String(b),
              distractors: uniqueNumericDistractors(b, [1, -1, 2, c - a === b ? 3 : c - a - b]),
              hintAr: `استخدم ب² = الوتر² - أ².`,
              hintEn: `Use b² = c² - a².`,
              stepsAr: [`ب² = ${c}² - ${a}² = ${c * c - a * a}`, `ب = ${b}`],
              stepsEn: [`b² = ${c * c} - ${a * a} = ${b * b}`, `b = ${b}`],
            });
      } else if (family === 1) {
        const x1 = (i % 7) - 2;
        const y1 = (i * 2 + tr) % 10;
        const dx = 1 + (i % 5);
        const slope = ((i + tr) % 7) - 3 || 2;
        const x2 = x1 + dx;
        const y2 = y1 + slope * dx;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'equations',
          promptAr: `ما ميل المستقيم المار بالنقطتين (${x1}, ${y1}) و (${x2}, ${y2})؟`,
          promptEn: `Find the slope of the line passing through (${x1}, ${y1}) and (${x2}, ${y2}).`,
          correctValue: String(slope),
          distractors: uniqueNumericDistractors(slope, [1, -1, 2, -2]),
          hintAr: `الميل = (ص₂ - ص₁) ÷ (س₂ - س₁).`,
          hintEn: `Slope m = (y₂ - y₁) / (x₂ - x₁).`,
          stepsAr: [`Δص = ${y2} - ${y1} = ${y2 - y1}`, `Δس = ${x2} - ${x1} = ${dx}`, `الميل = ${y2 - y1} ÷ ${dx} = ${slope}`],
          stepsEn: [`m = (${y2} - ${y1}) / (${x2} - ${x1}) = ${slope}`],
        });
      } else if (family === 2) {
        const x = 1 + ((i + tr) % (tr * 3 + 6));
        const y = 1 + ((i * 2 + tr) % (tr * 3 + 5));
        const sum = x + y;
        const diff = x - y;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'equations',
          format: 'multi_step',
          promptAr: `إذا كان x + y = ${sum} و x - y = ${diff}، فما قيمة x؟ (#${i + 1})`,
          promptEn: `If x + y = ${sum} and x - y = ${diff}, what is x? (#${i + 1})`,
          correctValue: String(x),
          distractors: uniqueNumericDistractors(x, [1, -1, y - x === 0 ? 2 : y - x, 3]),
          hintAr: `اجمع المعادلتين معاً لحذف المتغير y.`,
          hintEn: `Add both equations together to eliminate y.`,
          stepsAr: [`بالجمع: 2x = ${sum} + (${diff}) = ${2 * x}`, `x = ${x}`],
          stepsEn: [`Adding gives 2x = ${2 * x}`, `x = ${x}`],
        });
      } else {
        const a1 = 2 + ((i + tr) % 10);
        const d = 2 + ((i * 2 + tr) % (tr + 5));
        const n = 5 + (i % (tr * 3 + 6));
        const an = a1 + (n - 1) * d;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'sequences_series',
          promptAr: `متتالية حسابية حدها الأول ${a1} وأساسها ${d}. ما الحد رقم ${n}؟`,
          promptEn: `An arithmetic sequence has first term ${a1} and common difference ${d}. Find term #${n}.`,
          correctValue: String(an),
          distractors: uniqueNumericDistractors(an, [d, -d, a1, 2]),
          hintAr: `استخدم القانون: حₙ = أ + (ن - 1) × د.`,
          hintEn: `Use aₙ = a₁ + (n - 1)d.`,
          stepsAr: [`ح_${n} = ${a1} + (${n} - 1)×${d} = ${a1} + ${(n - 1) * d} = ${an}`],
          stepsEn: [`a_${n} = ${a1} + ${n - 1}×${d} = ${an}`],
        });
      }
    } else if (gradeId === 'g09') {
      if (family === 0) {
        const r1 = 1 + ((i + tr) % (tr * 2 + 5));
        const r2 = r1 + 1 + ((i * 2) % 6);
        const b = -(r1 + r2);
        const c = r1 * r2;
        const larger = Math.max(r1, r2);
        q = isWritten
          ? makeBankWritten({
              id,
              gradeId,
              tier,
              topic: 'equations',
              promptAr: `حل المعادلة التربيعية x² ${b >= 0 ? `+ ${b}` : `- ${Math.abs(b)}`}x + ${c} = 0، واكتب الجذر الأكبر:`,
              promptEn: `Solve x² ${b >= 0 ? `+ ${b}` : `- ${Math.abs(b)}`}x + ${c} = 0 and enter the larger root:`,
              acceptedAnswers: [String(larger)],
              hintAr: `ابحث عن عددين مجموعهما ${r1 + r2} وحاصل ضربهما ${c}.`,
              hintEn: `Find two numbers summing to ${r1 + r2} with product ${c}.`,
              stepsAr: [`(x - ${r1})(x - ${r2}) = 0`, `الجذران: ${r1} و ${r2}`, `الجذر الأكبر = ${larger}`],
              stepsEn: [`(x - ${r1})(x - ${r2}) = 0`, `Roots are ${r1} and ${r2}`, `Larger root = ${larger}`],
            })
          : makeBankMcq({
              id,
              gradeId,
              tier,
              topic: 'equations',
              promptAr: `ما حاصل جمع جذري المعادلة: x² - ${r1 + r2}x + ${c} = 0 ؟`,
              promptEn: `What is the sum of the roots of x² - ${r1 + r2}x + ${c} = 0?`,
              correctValue: String(r1 + r2),
              distractors: uniqueNumericDistractors(r1 + r2, [1, -1, c - (r1 + r2), -2 * (r1 + r2)]),
              hintAr: `في المعادلة ax² + bx + c = 0، مجموع الجذرين = -b/a.`,
              hintEn: `By Vieta's formulas, the sum of roots equals -b/a.`,
              stepsAr: [`مجموع الجذرين = -(-${r1 + r2})/1 = ${r1 + r2}`],
              stepsEn: [`Sum of roots = -b/a = ${r1 + r2}`],
            });
      } else if (family === 1) {
        const a = 2 + (i % (tr + 3));
        const b = 1 + ((i * 3) % 7);
        const k = 1 + ((i + tr) % 5);
        // P(x) = a x^2 + b x - k; evaluate at x = x0
        const x0 = 2 + (i % 4);
        const ans = a * x0 * x0 + b * x0 - k;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'advanced_algebra',
          promptAr: `إذا كانت P(x) = ${a}x² + ${b}x - ${k}، فأوجد قيمة P(${x0}):`,
          promptEn: `If P(x) = ${a}x² + ${b}x - ${k}, evaluate P(${x0}):`,
          correctValue: String(ans),
          distractors: uniqueNumericDistractors(ans, [a, -b, 2 * k, -4]),
          hintAr: `عوّض كل x بالعدد ${x0} مع حساب التربيع أولاً.`,
          hintEn: `Substitute x = ${x0} and compute powers before multiplying.`,
          stepsAr: [`P(${x0}) = ${a}(${x0 * x0}) + ${b}(${x0}) - ${k} = ${ans}`],
          stepsEn: [`P(${x0}) = ${a * x0 * x0} + ${b * x0} - ${k} = ${ans}`],
        });
      } else if (family === 2) {
        const r = 2 + ((i + tr) % (tr * 3 + 8));
        const cCoeff = 2 * r;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'geometry_solids',
          promptAr: `دائرة نصف قطرها ${r} سم. ما محيطها بدلالة π؟ (#${i + 1})`,
          promptEn: `A circle has radius ${r} cm. What is its circumference in terms of π? (#${i + 1})`,
          correctValue: `${cCoeff}π`,
          distractors: [`${r * r}π`, `${r}π`, `${cCoeff + 2}π`],
          hintAr: `محيط الدائرة = 2πr.`,
          hintEn: `Circumference = 2πr.`,
          stepsAr: [`المحيط = 2 × ${r} × π = ${cCoeff}π سم`],
          stepsEn: [`C = 2π(${r}) = ${cCoeff}π cm`],
        });
      } else {
        const sides = 3 + ((i + tr) % 4);
        const adj = sides === 3 ? 4 : sides === 4 ? 3 : sides === 5 ? 12 : 15;
        const hyp = sides === 3 || sides === 4 ? 5 : sides === 5 ? 13 : 17;
        const scale = 1 + (Math.floor(i / 4) % 4);
        const opp = sides * scale;
        const h = hyp * scale;
        const ans = formatFraction(opp, h);
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'trigonometry',
          promptAr: `في مثلث قائم الزاوية، المقابل للزاوية θ يساوي ${opp} والوتر يساوي ${h} (والمجاور ${adj * scale}). ما قيمة sin(θ)؟`,
          promptEn: `In a right triangle with opposite ${opp}, adjacent ${adj * scale}, and hypotenuse ${h}, find sin(θ).`,
          correctValue: ans,
          distractors: [
            formatFraction(adj * scale, h),
            formatFraction(opp, adj * scale),
            formatFraction(h, opp),
          ],
          hintAr: `sin(θ) = المقابل ÷ الوتر.`,
          hintEn: `sin(θ) = opposite / hypotenuse.`,
          stepsAr: [`sin(θ) = ${opp}/${h} = ${ans}`],
          stepsEn: [`sin(θ) = ${opp}/${h} = ${ans}`],
        });
      }
    } else if (gradeId === 'g10') {
      if (family === 0) {
        const base = [2, 3, 5, 10][i % 4];
        const exp = 1 + (Math.floor(i / 4 + tr) % (base === 2 ? 7 : 5));
        const val = Math.pow(base, exp);
        q = isWritten
          ? makeBankWritten({
              id,
              gradeId,
              tier,
              topic: 'advanced_algebra',
              promptAr: `أوجد قيمة اللوغاريتم: log_${base}(${val}) = ؟`,
              promptEn: `Evaluate the logarithm: log_${base}(${val}) = ?`,
              acceptedAnswers: [String(exp)],
              hintAr: `اسأل نفسك: ما الأس الذي نرفع له ${base} لنحصل على ${val}؟`,
              hintEn: `Find the exponent k such that ${base}^k = ${val}.`,
              stepsAr: [`بما أن ${base}^${exp} = ${val}`, `إذن log_${base}(${val}) = ${exp}`],
              stepsEn: [`Since ${base}^${exp} = ${val}`, `log_${base}(${val}) = ${exp}`],
            })
          : makeBankMcq({
              id,
              gradeId,
              tier,
              topic: 'advanced_algebra',
              promptAr: `ما قيمة: log_${base}(${val}) ؟`,
              promptEn: `What is log_${base}(${val})?`,
              correctValue: String(exp),
              distractors: uniqueNumericDistractors(exp, [1, -1, 2, base]),
              hintAr: `حوّل الصورة اللوغاريتمية إلى صورة أسية.`,
              hintEn: `Convert the logarithm into exponential form.`,
              stepsAr: [`${base}^${exp} = ${val} ⟹ الناتج = ${exp}`],
              stepsEn: [`${base}^${exp} = ${val} => ${exp}`],
            });
      } else if (family === 1) {
        const angles = [
          { deg: 0, sin: '0', cos: '1', tan: '0' },
          { deg: 30, sin: '1/2', cos: '√3/2', tan: '1/√3' },
          { deg: 45, sin: '√2/2', cos: '√2/2', tan: '1' },
          { deg: 60, sin: '√3/2', cos: '1/2', tan: '√3' },
          { deg: 90, sin: '1', cos: '0', tan: 'غير معرف' },
        ];
        const a = angles[(i + tr) % 4];
        const k = 2 + (Math.floor(i / 4) % 8);
        // k * (sin^2(theta) + cos^2(theta)) = k always! Or 2*sin(30)*k = k
        if (i % 2 === 0) {
          q = makeBankMcq({
            id,
            gradeId,
            tier,
            topic: 'trigonometry',
            format: 'multi_step',
            promptAr: `احسب قيمة المقدار: ${k}·sin²(${a.deg + i}°) + ${k}·cos²(${a.deg + i}°)`,
            promptEn: `Evaluate: ${k}·sin²(${a.deg + i}°) + ${k}·cos²(${a.deg + i}°)`,
            correctValue: String(k),
            distractors: uniqueNumericDistractors(k, [1, -1, k, 2]),
            hintAr: `أخرج ${k} عاملاً مشتركاً وتذكّر متطابقة فيثاغورس المثلثية.`,
            hintEn: `Factor out ${k} and apply the Pythagorean identity sin²θ + cos²θ = 1.`,
            stepsAr: [`${k}(sin²θ + cos²θ) = ${k}(1) = ${k}`],
            stepsEn: [`${k}(sin²θ + cos²θ) = ${k}×1 = ${k}`],
          });
        } else {
          const mult = 2 * k;
          q = makeBankMcq({
            id,
            gradeId,
            tier,
            topic: 'trigonometry',
            promptAr: `احسب قيمة: ${mult} · sin(30°) + ${i % 5}`,
            promptEn: `Evaluate: ${mult} · sin(30°) + ${i % 5}`,
            correctValue: String(k + (i % 5)),
            distractors: uniqueNumericDistractors(k + (i % 5), [k, 1, -1, 2]),
            hintAr: `تذكّر أن sin(30°) = 1/2.`,
            hintEn: `Recall sin(30°) = 1/2.`,
            stepsAr: [`${mult} × (1/2) = ${k}`, `${k} + ${i % 5} = ${k + (i % 5)}`],
            stepsEn: [`${mult} × (1/2) + ${i % 5} = ${k + (i % 5)}`],
          });
        }
      } else if (family === 2) {
        const vx = 1 + ((i + tr) % 9);
        const vy = 1 + ((i * 2 + tr) % 9);
        const wx = 1 + ((i * 3) % 8);
        const wy = 1 + ((i + 4) % 8);
        const dot = vx * wx + vy * wy;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'geometry_solids',
          promptAr: `أوجد الضرب القياسي (Dot Product) للمتجهين u = (${vx}, ${vy}) و v = (${wx}, ${wy}):`,
          promptEn: `Find the dot product of vectors u = (${vx}, ${vy}) and v = (${wx}, ${wy}):`,
          correctValue: String(dot),
          distractors: uniqueNumericDistractors(dot, [vx * wy - vy * wx || 3, 2, -2, 5]),
          hintAr: `u · v = u₁v₁ + u₂v₂.`,
          hintEn: `u · v = u₁v₁ + u₂v₂.`,
          stepsAr: [`${vx}×${wx} + ${vy}×${wy} = ${vx * wx} + ${vy * wy} = ${dot}`],
          stepsEn: [`${vx * wx} + ${vy * wy} = ${dot}`],
        });
      } else {
        const n = 10 + ((i + tr) % 15);
        const a = 4 + (i % 5);
        const b = 3 + ((i * 2) % 5);
        // |A U B| = |A| + |B| - |A ∩ B|
        const inter = 1 + (i % 3);
        const union = a + b - inter;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'logic_puzzles',
          format: 'multi_step',
          promptAr: `في صف من ${n} طالباً، يحب ${a} طلاب الجبر و${b} طلاب الهندسة، و${inter} طلاب يحبون كليهما. كم طالباً يحب الجبر أو الهندسة؟`,
          promptEn: `In a class of ${n} students, ${a} like Algebra, ${b} like Geometry, and ${inter} like both. How many like Algebra or Geometry?`,
          correctValue: String(union),
          distractors: uniqueNumericDistractors(union, [inter, -inter, 1, 2]),
          hintAr: `استخدم مبدأ التضمين والاستبعاد: |A ∪ B| = |A| + |B| - |A ∩ B|.`,
          hintEn: `Use inclusion-exclusion: |A ∪ B| = |A| + |B| - |A ∩ B|.`,
          stepsAr: [`${a} + ${b} - ${inter} = ${union}`],
          stepsEn: [`${a} + ${b} - ${inter} = ${union}`],
        });
      }
    } else if (gradeId === 'g11') {
      if (family === 0) {
        const n = 5 + ((i + tr) % 6);
        const r = 2 + (i % 3);
        const ans = nCr(n, r);
        q = isWritten
          ? makeBankWritten({
              id,
              gradeId,
              tier,
              topic: 'statistics_probability',
              promptAr: `احسب عدد التوافيق C(${n}, ${r}) لاختيار ${r} عناصر من أصل ${n}:`,
              promptEn: `Compute the combination C(${n}, ${r}):`,
              acceptedAnswers: [String(ans)],
              hintAr: `C(n, r) = n! / (r! · (n - r)!).`,
              hintEn: `Use C(n, r) = n! / (r!(n - r)!).`,
              stepsAr: [`C(${n}, ${r}) = ${ans}`],
              stepsEn: [`C(${n}, ${r}) = ${ans}`],
            })
          : makeBankMcq({
              id,
              gradeId,
              tier,
              topic: 'statistics_probability',
              promptAr: `بكم طريقة يمكن اختيار لجنة من ${r} طلاب من بين ${n} طلاب؟`,
              promptEn: `In how many ways can a committee of ${r} be chosen from ${n} students?`,
              correctValue: String(ans),
              distractors: uniqueNumericDistractors(ans, [r, -r, n, -1]),
              hintAr: `بما أن الترتيب غير مهم نستخدم التوافيق C(${n}, ${r}).`,
              hintEn: `Order does not matter, so compute C(${n}, ${r}).`,
              stepsAr: [`C(${n}, ${r}) = ${ans}`],
              stepsEn: [`C(${n}, ${r}) = ${ans}`],
            });
      } else if (family === 1) {
        const a1 = 1 + (i % 4);
        const r = 2 + ((i + tr) % 3);
        const terms = 3 + (i % 3);
        // Sum of geometric series a1 * (r^terms - 1) / (r - 1)
        const sum = Math.round((a1 * (Math.pow(r, terms) - 1)) / (r - 1));
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'sequences_series',
          format: 'multi_step',
          promptAr: `أوجد مجموع أول ${terms} حدود من متتالية هندسية حدها الأول ${a1} وأساسها ${r}:`,
          promptEn: `Find the sum of the first ${terms} terms of a geometric series with a₁ = ${a1} and r = ${r}:`,
          correctValue: String(sum),
          distractors: uniqueNumericDistractors(sum, [a1, -a1, r, 4]),
          hintAr: `استخدم قانون مجموع المتسلسلة الهندسية: Sₙ = a₁(rⁿ - 1) / (r - 1).`,
          hintEn: `Use Sₙ = a₁(rⁿ - 1) / (r - 1).`,
          stepsAr: [`S_${terms} = ${a1}(${r}^${terms} - 1)/(${r} - 1) = ${sum}`],
          stepsEn: [`S_${terms} = ${sum}`],
        });
      } else if (family === 2) {
        const c = 1 + ((i + tr) % 9);
        const a = 2 + (i % 5);
        const b = 1 + ((i * 2) % 7);
        // lim x->c of (a x^2 - a c^2)/(x - c) + b = 2ac + b
        const ans = 2 * a * c + b;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'calculus',
          promptAr: `أوجد النهاية: lim(x → ${c}) [ (${a}x² - ${a * c * c}) / (x - ${c}) + ${b} ]`,
          promptEn: `Evaluate: lim(x → ${c}) [ (${a}x² - ${a * c * c}) / (x - ${c}) + ${b} ]`,
          correctValue: String(ans),
          distractors: uniqueNumericDistractors(ans, [b, -b, a, c]),
          hintAr: `حلّل البسط كفرق بين مربعين ثم اختصر (x - ${c}).`,
          hintEn: `Factor ${a}(x² - ${c}²) as ${a}(x - ${c})(x + ${c}) and cancel (x - ${c}).`,
          stepsAr: [`${a}(x + ${c}) + ${b} عند x = ${c}`, `= ${a}(${2 * c}) + ${b} = ${ans}`],
          stepsEn: [`Simplifies to ${a}(x + ${c}) + ${b}`, `At x = ${c}: ${ans}`],
        });
      } else {
        const m11 = 1 + ((i + tr) % 7);
        const m12 = 1 + (i % 5);
        const m21 = 1 + ((i * 2) % 4);
        const m22 = 2 + ((i + tr) % 6);
        const det = m11 * m22 - m12 * m21;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'advanced_algebra',
          promptAr: `أوجد محددة المصفوفة [[${m11}, ${m12}], [${m21}, ${m22}]]:`,
          promptEn: `Find the determinant of [[${m11}, ${m12}], [${m21}, ${m22}]]:`,
          correctValue: String(det),
          distractors: uniqueNumericDistractors(det, [m12 * m21 * 2 || 4, 2, -2, 3]),
          hintAr: `المحددة لمصفوفة 2×2 هي (ad - bc).`,
          hintEn: `For a 2×2 matrix [[a, b], [c, d]], det = ad - bc.`,
          stepsAr: [`(${m11} × ${m22}) - (${m12} × ${m21}) = ${m11 * m22} - ${m12 * m21} = ${det}`],
          stepsEn: [`det = ${m11 * m22} - ${m12 * m21} = ${det}`],
        });
      }
    } else {
      // gradeId === 'g12'
      if (family === 0) {
        const a = 2 + (i % (tr + 4));
        const b = 1 + ((i * 3 + tr) % 9);
        const x0 = 1 + (i % 5);
        // f(x) = a x^3 + b x => f'(x) = 3 a x^2 + b
        const deriv = 3 * a * x0 * x0 + b;
        q = isWritten
          ? makeBankWritten({
              id,
              gradeId,
              tier,
              topic: 'calculus',
              promptAr: `إذا كان f(x) = ${a}x³ + ${b}x، فأوجد قيمة المشتقة f'(${x0}):`,
              promptEn: `If f(x) = ${a}x³ + ${b}x, compute f'(${x0}):`,
              acceptedAnswers: [String(deriv)],
              hintAr: `اشتق كل حد باستخدام قاعدة القوى: d/dx(xⁿ) = n·xⁿ⁻¹.`,
              hintEn: `Differentiate using the power rule d/dx(xⁿ) = n·xⁿ⁻¹.`,
              stepsAr: [`f'(x) = ${3 * a}x² + ${b}`, `f'(${x0}) = ${3 * a}(${x0 * x0}) + ${b} = ${deriv}`],
              stepsEn: [`f'(x) = ${3 * a}x² + ${b}`, `f'(${x0}) = ${deriv}`],
            })
          : makeBankMcq({
              id,
              gradeId,
              tier,
              topic: 'calculus',
              promptAr: `أوجد قيمة f'(${x0}) للدالة f(x) = ${a}x³ + ${b}x:`,
              promptEn: `Find f'(${x0}) for f(x) = ${a}x³ + ${b}x:`,
              correctValue: String(deriv),
              distractors: uniqueNumericDistractors(deriv, [b, -b, a * x0, 6]),
              hintAr: `اشتق الدالة أولاً ثم عوّض x = ${x0}.`,
              hintEn: `Differentiate first, then substitute x = ${x0}.`,
              stepsAr: [`f'(x) = ${3 * a}x² + ${b}`, `f'(${x0}) = ${deriv}`],
              stepsEn: [`f'(x) = ${3 * a}x² + ${b}`, `f'(${x0}) = ${deriv}`],
            });
      } else if (family === 1) {
        const k = 1 + ((i + tr) % 6);
        const upper = 1 + (i % 4);
        // Integral from 0 to upper of 3*k*x^2 dx = k * upper^3
        const ans = k * Math.pow(upper, 3);
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'calculus',
          format: 'multi_step',
          promptAr: `احسب التكامل المحدود: ∫ من 0 إلى ${upper} للدالة (${3 * k}x²) dx`,
          promptEn: `Evaluate the definite integral: ∫₀^${upper} ${3 * k}x² dx`,
          correctValue: String(ans),
          distractors: uniqueNumericDistractors(ans, [k, -k, 3 * k, 6]),
          hintAr: `الدالة الأصلية لـ ${3 * k}x² هي ${k}x³.`,
          hintEn: `An antiderivative of ${3 * k}x² is ${k}x³.`,
          stepsAr: [`[${k}x³] من 0 إلى ${upper} = ${k}×${Math.pow(upper, 3)} - 0 = ${ans}`],
          stepsEn: [`[${k}x³]₀^${upper} = ${ans}`],
        });
      } else if (family === 2) {
        const re = 3 + ((i + tr) % 4 === 0 ? 0 : 0);
        const im = 4;
        const scale = 1 + (i % (tr + 4));
        const a = (i % 2 === 0 ? re : 5) * scale;
        const b = (i % 2 === 0 ? im : 12) * scale;
        const mod = (i % 2 === 0 ? 5 : 13) * scale;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'advanced_algebra',
          promptAr: `ما مقياس العدد المركب z = ${a} + ${b}i ؟`,
          promptEn: `Find the modulus |z| of the complex number z = ${a} + ${b}i:`,
          correctValue: String(mod),
          distractors: uniqueNumericDistractors(mod, [1, -1, a + b - mod || 3, 2]),
          hintAr: `|a + bi| = √(a² + b²).`,
          hintEn: `Use |z| = √(a² + b²).`,
          stepsAr: [`|z| = √(${a}² + ${b}²) = √${a * a + b * b} = ${mod}`],
          stepsEn: [`|z| = √(${a * a + b * b}) = ${mod}`],
        });
      } else {
        const k = 2 + ((i + tr) % 8);
        const y0 = 1 + (i % 5);
        // dy/dx = k * y, y(0) = y0 => y'(0) = k * y0
        const ans = k * y0;
        q = makeBankMcq({
          id,
          gradeId,
          tier,
          topic: 'differential_equations',
          promptAr: `للمعادلة التفاضلية dy/dx = ${k}y مع الشرط y(0) = ${y0}، ما قيمة dy/dx عند x = 0؟ (#${i + 1})`,
          promptEn: `For dy/dx = ${k}y with y(0) = ${y0}, find dy/dx at x = 0. (#${i + 1})`,
          correctValue: String(ans),
          distractors: uniqueNumericDistractors(ans, [k, y0, -k, 2]),
          hintAr: `عوّض قيمة y(0) مباشرة في المعادلة التفاضلية.`,
          hintEn: `Substitute y(0) directly into the differential equation.`,
          stepsAr: [`dy/dx|_{x=0} = ${k} × y(0) = ${k} × ${y0} = ${ans}`],
          stepsEn: [`dy/dx(0) = ${k} × ${y0} = ${ans}`],
        });
      }
    }

    if (usedPrompts.has(q.promptEn)) {
      q = {
        ...q,
        promptAr: `${q.promptAr} [مسألة #${i + 1}]`,
        promptEn: `${q.promptEn} [Problem #${i + 1}]`,
      };
    }
    usedPrompts.add(q.promptEn);
    questions.push(q);
  }

  return questions;
}
