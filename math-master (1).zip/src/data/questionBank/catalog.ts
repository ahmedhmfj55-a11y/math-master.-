import type {
  BankDifficultyTier,
  BankTopicDefinition,
  BankTopicId,
  GradeId,
  GradeLevelDefinition,
} from '@/src/types/questionBank';

export const BANK_TIER_MASTERY_POINTS = 50;
export const GENIUS_SOLVE_POINTS = 100;
export const BANK_QUIZ_LENGTH = 10;
export const BANK_MASTERY_THRESHOLD = 70;
export const BANK_TIER_TARGET_COUNT = 100;

export const BANK_DIFFICULTY_TIERS: {
  id: BankDifficultyTier;
  order: number;
  titleAr: string;
  titleEn: string;
  accentClass: string;
}[] = [
  {
    id: 'very_easy',
    order: 1,
    titleAr: 'سهل جداً',
    titleEn: 'Very Easy',
    accentClass: 'from-emerald-500/80 to-teal-500/80 border-emerald-300/40 text-emerald-200',
  },
  {
    id: 'easy',
    order: 2,
    titleAr: 'سهل',
    titleEn: 'Easy',
    accentClass: 'from-sky-500/80 to-cyan-500/80 border-sky-300/40 text-sky-200',
  },
  {
    id: 'medium',
    order: 3,
    titleAr: 'متوسط',
    titleEn: 'Medium',
    accentClass: 'from-blue-500/80 to-indigo-500/80 border-blue-300/40 text-blue-200',
  },
  {
    id: 'hard',
    order: 4,
    titleAr: 'صعب',
    titleEn: 'Hard',
    accentClass: 'from-violet-500/80 to-fuchsia-500/80 border-violet-300/40 text-violet-200',
  },
  {
    id: 'very_hard',
    order: 5,
    titleAr: 'صعب جداً',
    titleEn: 'Very Hard',
    accentClass: 'from-amber-500/80 to-rose-500/80 border-amber-300/40 text-amber-200',
  },
];

export const BANK_TOPICS: Record<BankTopicId, BankTopicDefinition> = {
  arithmetic_ops: {
    id: 'arithmetic_ops',
    titleAr: 'الجمع والطرح والضرب والقسمة',
    titleEn: 'Arithmetic Operations',
  },
  fractions_decimals: {
    id: 'fractions_decimals',
    titleAr: 'الكسور والأعداد العشرية',
    titleEn: 'Fractions & Decimals',
  },
  ratios_percentages: {
    id: 'ratios_percentages',
    titleAr: 'النسب والتناسب والنسب المئوية',
    titleEn: 'Ratios & Percentages',
  },
  equations: {
    id: 'equations',
    titleAr: 'المعادلات الرياضية',
    titleEn: 'Mathematical Equations',
  },
  advanced_algebra: {
    id: 'advanced_algebra',
    titleAr: 'الجبر المتقدم',
    titleEn: 'Advanced Algebra',
  },
  geometry_solids: {
    id: 'geometry_solids',
    titleAr: 'الهندسة والمجسمات',
    titleEn: 'Geometry & Solids',
  },
  trigonometry: {
    id: 'trigonometry',
    titleAr: 'المثلثات وحساب المثلثات',
    titleEn: 'Trigonometry',
  },
  statistics_probability: {
    id: 'statistics_probability',
    titleAr: 'الإحصاء والاحتمالات',
    titleEn: 'Statistics & Probability',
  },
  sequences_series: {
    id: 'sequences_series',
    titleAr: 'المتتاليات والمتسلسلات',
    titleEn: 'Sequences & Series',
  },
  calculus: {
    id: 'calculus',
    titleAr: 'التفاضل والتكامل',
    titleEn: 'Calculus',
  },
  linear_algebra: {
    id: 'linear_algebra',
    titleAr: 'الجبر الخطي',
    titleEn: 'Linear Algebra',
  },
  number_theory: {
    id: 'number_theory',
    titleAr: 'نظرية الأعداد',
    titleEn: 'Number Theory',
  },
  discrete_math: {
    id: 'discrete_math',
    titleAr: 'الرياضيات المتقطعة',
    titleEn: 'Discrete Mathematics',
  },
  mathematical_analysis: {
    id: 'mathematical_analysis',
    titleAr: 'التحليل الرياضي',
    titleEn: 'Mathematical Analysis',
  },
  differential_equations: {
    id: 'differential_equations',
    titleAr: 'المعادلات التفاضلية',
    titleEn: 'Differential Equations',
  },
  logic_puzzles: {
    id: 'logic_puzzles',
    titleAr: 'المسائل المنطقية والألغاز الرياضية',
    titleEn: 'Logic & Math Puzzles',
  },
  olympiad_problems: {
    id: 'olympiad_problems',
    titleAr: 'مسائل الأولمبياد الرياضي',
    titleEn: 'Olympiad Problems',
  },
};

export const GRADE_LEVELS: GradeLevelDefinition[] = [
  {
    id: 'g01',
    order: 1,
    band: 'elementary',
    titleAr: 'الصف الأول الابتدائي',
    titleEn: 'Grade 1 Elementary',
    subtitleAr: 'العد، الجمع والطرح الأساسي، المقارنة، والأشكال الأولية',
    subtitleEn: 'Counting, basic addition & subtraction, comparison, and basic shapes',
    topics: ['arithmetic_ops', 'geometry_solids', 'logic_puzzles'],
    accentFrom: 'from-emerald-500',
    accentTo: 'to-teal-600',
  },
  {
    id: 'g02',
    order: 2,
    band: 'elementary',
    titleAr: 'الصف الثاني الابتدائي',
    titleEn: 'Grade 2 Elementary',
    subtitleAr: 'جمع وطرح الأعداد من منزلتين، مقدمات الضرب، والأنماط العددية',
    subtitleEn: 'Two-digit addition & subtraction, intro multiplication, and patterns',
    topics: ['arithmetic_ops', 'geometry_solids', 'logic_puzzles'],
    accentFrom: 'from-teal-500',
    accentTo: 'to-cyan-600',
  },
  {
    id: 'g03',
    order: 3,
    band: 'elementary',
    titleAr: 'الصف الثالث الابتدائي',
    titleEn: 'Grade 3 Elementary',
    subtitleAr: 'جداول الضرب والقسمة، بدايات الكسور، ومحيط الأشكال',
    subtitleEn: 'Multiplication & division tables, intro fractions, and perimeter',
    topics: ['arithmetic_ops', 'fractions_decimals', 'geometry_solids', 'logic_puzzles'],
    accentFrom: 'from-cyan-500',
    accentTo: 'to-sky-600',
  },
  {
    id: 'g04',
    order: 4,
    band: 'elementary',
    titleAr: 'الصف الرابع الابتدائي',
    titleEn: 'Grade 4 Elementary',
    subtitleAr: 'العمليات متعددة الخانات، الكسور المتكافئة، المساحة والزوايا',
    subtitleEn: 'Multi-digit operations, equivalent fractions, area, and angles',
    topics: ['arithmetic_ops', 'fractions_decimals', 'geometry_solids', 'logic_puzzles'],
    accentFrom: 'from-sky-500',
    accentTo: 'to-blue-600',
  },
  {
    id: 'g05',
    order: 5,
    band: 'elementary',
    titleAr: 'الصف الخامس الابتدائي',
    titleEn: 'Grade 5 Elementary',
    subtitleAr: 'الكسور والأعداد العشرية، المتوسط الحسابي، والحجوم الأساسية',
    subtitleEn: 'Fractions & decimals, arithmetic mean, and basic volumes',
    topics: ['arithmetic_ops', 'fractions_decimals', 'geometry_solids', 'statistics_probability'],
    accentFrom: 'from-blue-500',
    accentTo: 'to-indigo-600',
  },
  {
    id: 'g06',
    order: 6,
    band: 'elementary',
    titleAr: 'الصف السادس الابتدائي',
    titleEn: 'Grade 6 Elementary',
    subtitleAr: 'النسب والتناسب، النسبة المئوية، المعادلات البسيطة، والمجسمات',
    subtitleEn: 'Ratios, percentages, simple equations, and 3D solids',
    topics: ['fractions_decimals', 'ratios_percentages', 'equations', 'geometry_solids', 'statistics_probability'],
    accentFrom: 'from-indigo-500',
    accentTo: 'to-violet-600',
  },
  {
    id: 'g07',
    order: 7,
    band: 'middle',
    titleAr: 'الصف الأول المتوسط',
    titleEn: 'Grade 7 (Middle 1)',
    subtitleAr: 'الأعداد الصحيحة والنسبية، المعادلات الخطية، والزوايا الهندسية',
    subtitleEn: 'Integers & rationals, linear equations, and geometric angles',
    topics: ['arithmetic_ops', 'ratios_percentages', 'equations', 'geometry_solids', 'statistics_probability'],
    accentFrom: 'from-violet-500',
    accentTo: 'to-purple-600',
  },
  {
    id: 'g08',
    order: 8,
    band: 'middle',
    titleAr: 'الصف الثاني المتوسط',
    titleEn: 'Grade 8 (Middle 2)',
    subtitleAr: 'نظرية فيثاغورس، الدوال الخطية، الميل، ونظم المعادلات البسيطة',
    subtitleEn: 'Pythagorean theorem, linear functions, slope, and systems',
    topics: ['equations', 'geometry_solids', 'statistics_probability', 'sequences_series'],
    accentFrom: 'from-purple-500',
    accentTo: 'to-fuchsia-600',
  },
  {
    id: 'g09',
    order: 9,
    band: 'middle',
    titleAr: 'الصف الثالث المتوسط',
    titleEn: 'Grade 9 (Middle 3)',
    subtitleAr: 'كثيرات الحدود، المعادلات التربيعية، الدائرة، والاحتمالات',
    subtitleEn: 'Polynomials, quadratic equations, circle theorems, and probability',
    topics: ['equations', 'advanced_algebra', 'geometry_solids', 'trigonometry', 'statistics_probability'],
    accentFrom: 'from-fuchsia-500',
    accentTo: 'to-pink-600',
  },
  {
    id: 'g10',
    order: 10,
    band: 'high',
    titleAr: 'الصف الرابع الإعدادي',
    titleEn: 'Grade 10 (High School 1)',
    subtitleAr: 'حساب المثلثات، اللوغاريتمات، المتجهات، والهندسة التحليلية',
    subtitleEn: 'Trigonometry, logarithms, vectors, and analytic geometry',
    topics: ['advanced_algebra', 'trigonometry', 'geometry_solids', 'logic_puzzles'],
    accentFrom: 'from-pink-500',
    accentTo: 'to-rose-600',
  },
  {
    id: 'g11',
    order: 11,
    band: 'high',
    titleAr: 'الصف الخامس الإعدادي',
    titleEn: 'Grade 11 (High School 2)',
    subtitleAr: 'المتتاليات والمتسلسلات، النهايات، التوافيق والتباديل، والمصفوفات',
    subtitleEn: 'Sequences & series, limits, combinatorics, and matrices',
    topics: ['advanced_algebra', 'trigonometry', 'sequences_series', 'statistics_probability', 'calculus'],
    accentFrom: 'from-rose-500',
    accentTo: 'to-orange-600',
  },
  {
    id: 'g12',
    order: 12,
    band: 'high',
    titleAr: 'الصف السادس الإعدادي',
    titleEn: 'Grade 12 (High School 3)',
    subtitleAr: 'التفاضل والتكامل، الأعداد المركبة، والمعادلات التفاضلية الأولية',
    subtitleEn: 'Differential & integral calculus, complex numbers, and intro ODEs',
    topics: ['calculus', 'advanced_algebra', 'trigonometry', 'differential_equations'],
    accentFrom: 'from-amber-500',
    accentTo: 'to-orange-600',
  },
  {
    id: 'g13',
    order: 13,
    band: 'university_research',
    titleAr: 'المستوى الجامعي',
    titleEn: 'University Level',
    subtitleAr: 'التفاضل والتكامل متعدد المتغيرات، الجبر الخطي، والاحتمالات الجامعية',
    subtitleEn: 'Multivariable calculus, linear algebra, and university probability',
    topics: ['calculus', 'linear_algebra', 'differential_equations', 'statistics_probability'],
    accentFrom: 'from-blue-600',
    accentTo: 'to-cyan-600',
  },
  {
    id: 'g14',
    order: 14,
    band: 'university_research',
    titleAr: 'المستوى الجامعي المتقدم',
    titleEn: 'Advanced University Level',
    subtitleAr: 'نظرية الأعداد، الرياضيات المتقطعة، الجبر المجرد، والتحليل الرياضي',
    subtitleEn: 'Number theory, discrete mathematics, abstract algebra, and analysis',
    topics: ['number_theory', 'discrete_math', 'mathematical_analysis', 'linear_algebra', 'differential_equations'],
    accentFrom: 'from-indigo-600',
    accentTo: 'to-blue-700',
  },
  {
    id: 'g15',
    order: 15,
    band: 'university_research',
    titleAr: 'مستوى الأولمبياد الدولي للرياضيات',
    titleEn: 'International Mathematical Olympiad (IMO)',
    subtitleAr: 'مسائل الأولمبياد في الجبر، التوافقيات، الهندسة التركيبية، ونظرية الأعداد',
    subtitleEn: 'Olympiad algebra, combinatorics, synthetic geometry, and number theory',
    topics: ['olympiad_problems', 'number_theory', 'discrete_math', 'advanced_algebra', 'geometry_solids'],
    accentFrom: 'from-amber-500',
    accentTo: 'to-yellow-600',
  },
  {
    id: 'g16',
    order: 16,
    band: 'university_research',
    titleAr: 'مستوى الرياضيات المتقدمة',
    titleEn: 'Advanced Mathematics',
    subtitleAr: 'التحليل الحقيقي والمركب، التحويلات التكاملية، والطوبولوجيا والجبر الخطي المتقدم',
    subtitleEn: 'Real & complex analysis, integral transforms, and advanced linear algebra',
    topics: ['mathematical_analysis', 'linear_algebra', 'differential_equations', 'number_theory'],
    accentFrom: 'from-violet-600',
    accentTo: 'to-purple-700',
  },
  {
    id: 'g17',
    order: 17,
    band: 'university_research',
    titleAr: 'مستوى التحديات الرياضية العالمية',
    titleEn: 'Global Math Challenges',
    subtitleAr: 'مسائل بوتنام ومسابقات الجامعات العالمية ذات الحلول الدقيقة متعددة الخطوات',
    subtitleEn: 'Putnam & international collegiate competition challenges with verified proofs',
    topics: ['olympiad_problems', 'number_theory', 'mathematical_analysis', 'logic_puzzles'],
    accentFrom: 'from-fuchsia-600',
    accentTo: 'to-rose-700',
  },
  {
    id: 'g18',
    order: 18,
    band: 'university_research',
    titleAr: 'مستوى المسائل البحثية المتقدمة',
    titleEn: 'Advanced Research Problems',
    subtitleAr: 'مسائل بحثية مفتوحة وحدسيات رياضية كبرى مميّزة بوضوح عن المسائل المحلولة',
    subtitleEn: 'Open research conjectures and frontier mathematical problems clearly distinguished from solved theorems',
    topics: ['number_theory', 'mathematical_analysis', 'discrete_math', 'olympiad_problems'],
    accentFrom: 'from-slate-600',
    accentTo: 'to-indigo-800',
  },
];

export function getGradeById(gradeId: GradeId): GradeLevelDefinition | undefined {
  return GRADE_LEVELS.find((g) => g.id === gradeId);
}

export function getGradeByOrder(order: number): GradeLevelDefinition | undefined {
  return GRADE_LEVELS.find((g) => g.order === order);
}

export function getTierMeta(tier: BankDifficultyTier) {
  return BANK_DIFFICULTY_TIERS.find((t) => t.id === tier)!;
}

export function getNextTier(tier: BankDifficultyTier): BankDifficultyTier | null {
  const idx = BANK_DIFFICULTY_TIERS.findIndex((t) => t.id === tier);
  if (idx === -1 || idx >= BANK_DIFFICULTY_TIERS.length - 1) return null;
  return BANK_DIFFICULTY_TIERS[idx + 1].id;
}

export function getPreviousTier(tier: BankDifficultyTier): BankDifficultyTier | null {
  const idx = BANK_DIFFICULTY_TIERS.findIndex((t) => t.id === tier);
  if (idx <= 0) return null;
  return BANK_DIFFICULTY_TIERS[idx - 1].id;
}
