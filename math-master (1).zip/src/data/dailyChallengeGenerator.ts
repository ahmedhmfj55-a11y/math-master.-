import {
  buildChoiceQuestion,
  createSeededRng,
  formatFraction,
  gcd,
  hashString,
  numericDistractors,
  randInt,
} from '@/src/data/curriculum/helpers';
import type { DailyChallengeQuestion } from '@/src/types/progress';

export const DAILY_CHALLENGE_QUESTIONS_COUNT = 10;
export const DAILY_CHALLENGE_DURATION_SECONDS = 600; // 10 minutes
export const DAILY_CHALLENGE_PASS_THRESHOLD = 70;
export const DAILY_CHALLENGE_WIN_POINTS = 50;
export const DAILY_CHALLENGE_PERFECT_BONUS_POINTS = 25;

/**
 * Returns local calendar date formatted as YYYY-MM-DD.
 */
export function getTodayDateKey(now: Date = new Date()): string {
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Computes previous calendar day in YYYY-MM-DD safely without DST drift.
 */
export function getPreviousDateKey(dateKey: string): string {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dateKey);
  if (!match) return '';
  const utc = Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
  const prev = new Date(utc - 86_400_000);
  const y = prev.getUTCFullYear();
  const m = String(prev.getUTCMonth() + 1).padStart(2, '0');
  const d = String(prev.getUTCDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

/**
 * Computes effective streak count to show today before today's win:
 * stays active if user won today or yesterday; otherwise resets to 0.
 */
export function getEffectiveActiveStreak(
  currentStreak: number,
  lastWonDate: string | undefined,
  todayKey: string,
): number {
  if (!lastWonDate || currentStreak <= 0) return 0;
  if (lastWonDate === todayKey || lastWonDate === getPreviousDateKey(todayKey)) {
    return currentStreak;
  }
  return 0;
}

interface BuiltTopicQuestion {
  topicAr: string;
  topicEn: string;
  promptAr: string;
  promptEn: string;
  correctValue: string;
  distractors: string[];
  explanationAr: string;
  explanationEn: string;
}

function buildEasyQuestion(slot: number, rng: () => number): BuiltTopicQuestion {
  const variant = slot % 3;

  if (variant === 0) {
    // Arithmetic: Order of operations / multi-digit arithmetic
    const a = randInt(rng, 14, 48);
    const b = randInt(rng, 3, 9);
    const c = randInt(rng, 4, 9);
    const d = randInt(rng, 6, 19);
    const prod = b * c;
    const ans = a + prod - d;
    return {
      topicAr: 'الحساب الأساسي',
      topicEn: 'Basic Arithmetic',
      promptAr: `ما ناتج العبارة الحسابية التالية: ${a} + ${b} × ${c} − ${d} ؟`,
      promptEn: `Evaluate the arithmetic expression: ${a} + ${b} × ${c} − ${d}`,
      correctValue: String(ans),
      distractors: numericDistractors(ans, [
        (a + b) * c - d - ans,
        b + c,
        -b,
        d,
        -c,
      ]),
      explanationAr: `نبدأ بالضرب أولاً: ${b} × ${c} = ${prod}، ثم نحسب ${a} + ${prod} − ${d} = ${ans}.`,
      explanationEn: `Multiply first: ${b} × ${c} = ${prod}, then compute ${a} + ${prod} − ${d} = ${ans}.`,
    };
  }

  if (variant === 1) {
    // Fractions & Decimals: Fraction addition with clean denominator
    const den = [4, 5, 6, 8, 10][randInt(rng, 0, 4)];
    const n1 = randInt(rng, 1, den - 1);
    const n2 = randInt(rng, 1, den - 1);
    const sumNum = n1 + n2;
    const ans = formatFraction(sumNum, den);
    return {
      topicAr: 'الكسور والأعداد العشرية',
      topicEn: 'Fractions & Decimals',
      promptAr: `اجمع الكسرين وبسّط الناتج إلى أبسط صورة: ${n1}/${den} + ${n2}/${den}`,
      promptEn: `Add the fractions and simplify: ${n1}/${den} + ${n2}/${den}`,
      correctValue: ans,
      distractors: [
        `${sumNum}/${den * 2}`,
        formatFraction(sumNum + 1, den),
        formatFraction(Math.max(1, Math.abs(n1 - n2)), den),
        formatFraction(sumNum + 2, den + 1),
      ],
      explanationAr: `المقام موحد (${den})، نجمع البسطين: (${n1} + ${n2}) / ${den} = ${sumNum}/${den}، وبالتبسيط يكون الناتج ${ans}.`,
      explanationEn: `With common denominator ${den}, add numerators: (${n1} + ${n2})/${den} = ${sumNum}/${den}, which simplifies to ${ans}.`,
    };
  }

  // Ratios / Measurement: Simple direct unit rate
  const qty = randInt(rng, 3, 8);
  const unitPrice = randInt(rng, 4, 15);
  const totalCost = qty * unitPrice;
  const targetQty = randInt(rng, qty + 2, qty + 7);
  const ans = targetQty * unitPrice;
  return {
    topicAr: 'النسب والتناسب',
    topicEn: 'Ratios & Unit Rates',
    promptAr: `إذا كان ثمن ${qty} دفاتر متساوية هو ${totalCost} ريال، فما ثمن ${targetQty} دفاتر من النوع نفسه؟`,
    promptEn: `If ${qty} identical notebooks cost $${totalCost}, how much do ${targetQty} notebooks cost?`,
    correctValue: String(ans),
    distractors: numericDistractors(ans, [unitPrice, -unitPrice, unitPrice * 2, totalCost - ans]),
    explanationAr: `سعر الدفتر الواحد = ${totalCost} ÷ ${qty} = ${unitPrice}، إذن ثمن ${targetQty} دفاتر = ${targetQty} × ${unitPrice} = ${ans}.`,
    explanationEn: `Unit price = ${totalCost} ÷ ${qty} = ${unitPrice}. Cost for ${targetQty} notebooks = ${targetQty} × ${unitPrice} = ${ans}.`,
  };
}

function buildMediumQuestion(slot: number, rng: () => number): BuiltTopicQuestion {
  const variant = slot % 4;

  if (variant === 0) {
    // Linear equation ax + b = c
    const x = randInt(rng, 3, 16);
    const a = randInt(rng, 2, 7);
    const b = randInt(rng, 5, 24);
    const c = a * x + b;
    return {
      topicAr: 'الجبر والمعادلات',
      topicEn: 'Algebra & Equations',
      promptAr: `حل المعادلة الخطية لإيجاد قيمة x: ${a}x + ${b} = ${c}`,
      promptEn: `Solve the linear equation for x: ${a}x + ${b} = ${c}`,
      correctValue: String(x),
      distractors: numericDistractors(x, [2, -2, a, Math.round((c + b) / a) - x, 4]),
      explanationAr: `نطرح ${b} من الطرفين: ${a}x = ${c - b}، ثم نقسم على ${a} لنحصل على x = ${x}.`,
      explanationEn: `Subtract ${b} from both sides: ${a}x = ${c - b}. Divide by ${a} to get x = ${x}.`,
    };
  }

  if (variant === 1) {
    // Geometry: Triangle missing angle / Rectangle perimeter-area
    const angleA = randInt(rng, 35, 78);
    const angleB = randInt(rng, 32, 75);
    const angleC = 180 - angleA - angleB;
    return {
      topicAr: 'الهندسة',
      topicEn: 'Geometry',
      promptAr: `في مثلث، قياس زاويتين فيه ${angleA}° و ${angleB}°. ما قياس الزاوية الثالثة بالدرجات؟`,
      promptEn: `Two angles of a triangle measure ${angleA}° and ${angleB}°. Find the third angle in degrees.`,
      correctValue: `${angleC}°`,
      distractors: [
        `${angleC + 10}°`,
        `${Math.max(10, angleC - 10)}°`,
        `${Math.abs(angleA - angleB)}°`,
        `${360 - angleA - angleB}°`,
      ],
      explanationAr: `مجموع زوايا المثلث 180°، إذن الزاوية الثالثة = 180° − (${angleA}° + ${angleB}°) = ${angleC}°.`,
      explanationEn: `Triangle angles sum to 180°. Third angle = 180° − (${angleA}° + ${angleB}°) = ${angleC}°.`,
    };
  }

  if (variant === 2) {
    // Percentages & Discounts
    const pct = [10, 15, 20, 25, 30, 40][randInt(rng, 0, 5)];
    const base = randInt(rng, 4, 24) * 20;
    const discount = (base * pct) / 100;
    const finalPrice = base - discount;
    return {
      topicAr: 'النسب المئوية والخصم',
      topicEn: 'Percentages & Discounts',
      promptAr: `حاسوب لوحي سعره الأصلي ${base}، طُبّق عليه خصم بنسبة ${pct}%. كم يصبح سعره بعد الخصم؟`,
      promptEn: `A tablet originally costs ${base} and is discounted by ${pct}%. What is the sale price?`,
      correctValue: String(finalPrice),
      distractors: numericDistractors(finalPrice, [discount - finalPrice, pct, -pct, 20, -20]),
      explanationAr: `قيمة الخصم = ${base} × ${pct}% = ${discount}، والسعر بعد الخصم = ${base} − ${discount} = ${finalPrice}.`,
      explanationEn: `Discount amount = ${base} × ${pct}% = ${discount}. Sale price = ${base} − ${discount} = ${finalPrice}.`,
    };
  }

  // Measurement: Speed = Distance / Time & Unit conversion
  const hours = randInt(rng, 2, 5);
  const speed = randInt(rng, 45, 95);
  const distance = speed * hours;
  const targetMinutes = hours * 60;
  return {
    topicAr: 'القياس والوحدات',
    topicEn: 'Measurement & Speed',
    promptAr: `تقطع سيارة مسافة ${distance} كم في ${targetMinutes} دقيقة. ما سرعتها المتوسطة بوحدة كم/ساعة؟`,
    promptEn: `A car travels ${distance} km in ${targetMinutes} minutes. What is its average speed in km/h?`,
    correctValue: `${speed} km/h`,
    distractors: [
      `${speed + 10} km/h`,
      `${Math.max(15, speed - 10)} km/h`,
      `${Math.round(distance / (hours + 1))} km/h`,
      `${speed * 2} km/h`,
    ],
    explanationAr: `نحوّل ${targetMinutes} دقيقة إلى ساعات: ${targetMinutes} ÷ 60 = ${hours} ساعات. السرعة = ${distance} ÷ ${hours} = ${speed} كم/ساعة.`,
    explanationEn: `Convert ${targetMinutes} min to hours: ${targetMinutes} ÷ 60 = ${hours} h. Speed = ${distance} ÷ ${hours} = ${speed} km/h.`,
  };
}

function buildHardQuestion(slot: number, rng: () => number): BuiltTopicQuestion {
  const variant = slot % 3;

  if (variant === 0) {
    // Hard: System / Quadratic / Arithmetic sequence sum or nth term
    const r = randInt(rng, 2, 6);
    const a1 = randInt(rng, 3, 12);
    const n = randInt(rng, 7, 11);
    const nth = a1 + (n - 1) * r;
    const sum = ((a1 + nth) * n) / 2;
    return {
      topicAr: 'التحديات المتقدمة والمتتابعات',
      topicEn: 'Advanced Sequences',
      promptAr: `في متتابعة حسابية حدّها الأول ${a1} وأساسها ${r}، ما مجموع أول ${n} حدود منها؟`,
      promptEn: `In an arithmetic sequence with first term ${a1} and common difference ${r}, find the sum of the first ${n} terms.`,
      correctValue: String(sum),
      distractors: numericDistractors(sum, [nth - sum, r * n, -r * n, a1 * n - sum]),
      explanationAr: `الحد رقم ${n} هو ${a1} + ${n - 1} × ${r} = ${nth}. المجموع = (${a1} + ${nth}) × ${n} ÷ 2 = ${sum}.`,
      explanationEn: `The ${n}th term is ${a1} + ${n - 1} × ${r} = ${nth}. Sum = (${a1} + ${nth}) × ${n} ÷ 2 = ${sum}.`,
    };
  }

  if (variant === 1) {
    // Hard: Statistics & Probability (Mean or Two-stage / Marble Probability)
    const red = randInt(rng, 3, 7);
    const blue = randInt(rng, 4, 8);
    const green = randInt(rng, 2, 5);
    const total = red + blue + green;
    const favorable = red + green;
    const g = gcd(favorable, total);
    const ans = `${favorable / g}/${total / g}`;
    return {
      topicAr: 'الإحصاء والاحتمالات',
      topicEn: 'Statistics & Probability',
      promptAr: `يحتوي صندوق على ${red} كرات حمراء و${blue} زرقاء و${green} خضراء. إذا سُحبت كرة عشوائياً، فما احتمال أن تكون حمراء أو خضراء (في أبسط صورة)؟`,
      promptEn: `A box contains ${red} red, ${blue} blue, and ${green} green balls. One ball is drawn at random. What is the probability it is red or green (in lowest terms)?`,
      correctValue: ans,
      distractors: [
        formatFraction(blue, total),
        formatFraction(red, total),
        formatFraction(Math.max(1, favorable - 1), total),
        formatFraction(favorable, total + 2),
      ],
      explanationAr: `عدد الحالات المواتية = ${red} + ${green} = ${favorable} من إجمالي ${total} كرة، إذن الاحتمال = ${favorable}/${total} = ${ans}.`,
      explanationEn: `Favorable outcomes = ${red} + ${green} = ${favorable} out of ${total} balls. Simplified probability = ${ans}.`,
    };
  }

  // Hard: Pythagoras & Area or LCM/GCD Olympiad puzzle
  const triples: [number, number, number][] = [
    [3, 4, 5],
    [6, 8, 10],
    [5, 12, 13],
    [8, 15, 17],
    [9, 12, 15],
  ];
  const [a, b, c] = triples[randInt(rng, 0, triples.length - 1)];
  const area = (a * b) / 2;
  return {
    topicAr: 'الهندسة المتقدمة',
    topicEn: 'Advanced Geometry',
    promptAr: `مثلث قائم الزاوية طول وتره ${c} سم وطول أحد ضلعي القائمة ${a} سم. ما مساحة هذا المثلث بوحدة سم²؟`,
    promptEn: `A right triangle has hypotenuse ${c} cm and one leg measuring ${a} cm. What is its area in cm²?`,
    correctValue: `${area} cm²`,
    distractors: [
      `${a * b} cm²`,
      `${Math.round((a * c) / 2)} cm²`,
      `${area + a} cm²`,
      `${a + b + c} cm²`,
    ],
    explanationAr: `من نظرية فيثاغورس: الضلع الثاني = √(${c}² − ${a}²) = ${b} سم. المساحة = ½ × ${a} × ${b} = ${area} سم².`,
    explanationEn: `By the Pythagorean theorem, the other leg is √(${c}² − ${a}²) = ${b} cm. Area = ½ × ${a} × ${b} = ${area} cm².`,
  };
}

/**
 * Generates a deterministic daily set of 10 distinct mathematics MCQ questions
 * for a given YYYY-MM-DD calendar date.
 * - Q1..Q3: Easy
 * - Q4..Q7: Medium
 * - Q8..Q10: Hard
 */
export function buildDailyChallengeForDate(dateKey: string): DailyChallengeQuestion[] {
  const rng = createSeededRng(hashString(`daily-challenge-v1-${dateKey}`));
  const usedPrompts = new Set<string>();
  const questions: DailyChallengeQuestion[] = [];

  for (let i = 0; i < DAILY_CHALLENGE_QUESTIONS_COUNT; i++) {
    const difficulty: 'easy' | 'medium' | 'hard' =
      i < 3 ? 'easy' : i < 7 ? 'medium' : 'hard';

    let built: BuiltTopicQuestion | null = null;
    for (let attempt = 0; attempt < 15; attempt++) {
      const candidate =
        difficulty === 'easy'
          ? buildEasyQuestion(i + attempt, rng)
          : difficulty === 'medium'
            ? buildMediumQuestion(i - 3 + attempt, rng)
            : buildHardQuestion(i - 7 + attempt, rng);

      if (!usedPrompts.has(candidate.promptEn)) {
        usedPrompts.add(candidate.promptEn);
        built = candidate;
        break;
      }
    }

    // Fallback guaranteed unique variant
    if (!built) {
      built = buildEasyQuestion(i, rng);
    }

    const qId = `daily-${dateKey}-q${i + 1}`;
    const choice = buildChoiceQuestion({
      id: qId,
      promptAr: built.promptAr,
      promptEn: built.promptEn,
      correctValue: built.correctValue,
      distractors: built.distractors,
      explanationAr: built.explanationAr,
      explanationEn: built.explanationEn,
      seedKey: `${dateKey}-opt-${i + 1}`,
    });

    questions.push({
      id: choice.id,
      questionNumber: i + 1,
      difficulty,
      topicAr: built.topicAr,
      topicEn: built.topicEn,
      promptAr: choice.promptAr,
      promptEn: choice.promptEn,
      options: choice.options,
      correctIndex: choice.correctIndex,
      explanationAr: choice.explanationAr,
      explanationEn: choice.explanationEn,
    });
  }

  return questions;
}
