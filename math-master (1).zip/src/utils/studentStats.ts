import { getCatalogItemById } from '@/src/data/achievementsCatalog';
import { CURRICULUM_SECTIONS, getSectionById } from '@/src/data/curriculum';
import { getRewardById } from '@/src/data/rewardsCatalog';
import type { EarnedRecordId, UserAchievementRecord } from '@/src/types/achievements';
import type { SectionDefinition, SectionId } from '@/src/types/curriculum';
import type {
  DailyChallengeAttemptRecord,
  DailyStreakStatsRecord,
  ExamAttemptRecord,
  SectionProgressRecord,
  StageProgressRecord,
} from '@/src/types/progress';
import type { PointTransactionRecord } from '@/src/types/rewards';

export interface StudentLevelInfo {
  level: number;
  titleAr: string;
  titleEn: string;
  totalXp: number;
  currentLevelMinXp: number;
  nextLevelMinXp: number;
  xpIntoLevel: number;
  xpSpanForLevel: number;
  progressPct: number;
}

export interface StudentAnalyticsSummary {
  levelInfo: StudentLevelInfo;
  completedStages: number;
  totalStages: number;
  unlockedStages: number;
  lockedStages: number;
  completedSections: number;
  totalSections: number;
  examsPassed: number;
  examsFailed: number;
  totalExamAttempts: number;
  bestExamScore: number;
  dailyCompleted: number;
  dailyAttempted: number;
  totalCorrect: number;
  totalWrong: number;
  totalAnswered: number;
  overallPassRate: number;
}

export interface SectionAnalyticsItem {
  section: SectionDefinition;
  unlockedStage: number;
  completedStages: number;
  completionPct: number;
  totalStars: number;
  examBestScore: number;
  examPassed: boolean;
  examAttempts: number;
}

export interface PointsProgressionNode {
  id: string;
  stepIndex: number;
  cumulativeEarned: number;
  delta: number;
  type: PointTransactionRecord['type'];
  timestampMs: number;
}

export interface RecentActivityItem {
  id: string;
  kind: 'point' | 'exam' | 'daily' | 'achievement';
  timestampMs: number;
  titleAr: string;
  titleEn: string;
  subtitleAr: string;
  subtitleEn: string;
  badgeText?: string;
  tone: 'emerald' | 'blue' | 'amber' | 'rose' | 'violet';
}

const TOTAL_CURRICULUM_STAGES = 240;
const TOTAL_CURRICULUM_SECTIONS = CURRICULUM_SECTIONS.length; // 8

function xpThresholdForLevel(level: number): number {
  if (level <= 1) return 0;
  return 50 * (level - 1) * level;
}

function getLevelTierTitle(level: number): { titleAr: string; titleEn: string } {
  if (level >= 22) return { titleAr: 'أسطورة Math Master', titleEn: 'Math Master Legend' };
  if (level >= 15) return { titleAr: 'عبقري الرياضيات', titleEn: 'Math Prodigy' };
  if (level >= 10) return { titleAr: 'خبير المعادلات', titleEn: 'Equation Specialist' };
  if (level >= 6) return { titleAr: 'باحث متمرس', titleEn: 'Dedicated Scholar' };
  if (level >= 3) return { titleAr: 'مستكشف الأرقام', titleEn: 'Number Explorer' };
  return { titleAr: 'متعلم صاعد', titleEn: 'Rising Learner' };
}

export function computeStudentLevel(totalEarnedPoints: number): StudentLevelInfo {
  const safeXp = Math.max(0, Math.floor(totalEarnedPoints || 0));
  let level = 1;
  while (xpThresholdForLevel(level + 1) <= safeXp && level < 99) {
    level += 1;
  }
  const currentLevelMinXp = xpThresholdForLevel(level);
  const nextLevelMinXp = xpThresholdForLevel(level + 1);
  const xpIntoLevel = Math.max(0, safeXp - currentLevelMinXp);
  const xpSpanForLevel = Math.max(100, nextLevelMinXp - currentLevelMinXp);
  const progressPct = Math.min(100, Math.max(0, Math.round((xpIntoLevel / xpSpanForLevel) * 100)));
  const { titleAr, titleEn } = getLevelTierTitle(level);

  return {
    level,
    titleAr,
    titleEn,
    totalXp: safeXp,
    currentLevelMinXp,
    nextLevelMinXp,
    xpIntoLevel,
    xpSpanForLevel,
    progressPct,
  };
}

export function computeStudentAnalytics(params: {
  totalEarnedPoints: number;
  sectionProgressMap: Partial<Record<SectionId, SectionProgressRecord>>;
  stageProgressMap: Record<string, StageProgressRecord>;
  examAttempts: ExamAttemptRecord[];
  dailyHistory: DailyChallengeAttemptRecord[];
  dailyStats: DailyStreakStatsRecord | null;
}): StudentAnalyticsSummary {
  const {
    totalEarnedPoints,
    sectionProgressMap,
    stageProgressMap,
    examAttempts,
    dailyHistory,
    dailyStats,
  } = params;

  let completedStages = 0;
  let unlockedStages = 0;
  let completedSections = 0;
  let bestExamScore = 0;
  let legacyPassedSections = 0;

  for (const sec of CURRICULUM_SECTIONS) {
    const rec = sectionProgressMap[sec.id];
    const secCompleted = rec?.completedStagesCount ?? 0;
    const secUnlocked = Math.max(1, Math.min(30, rec?.unlockedStage ?? 1));
    completedStages += secCompleted;
    unlockedStages += secUnlocked;
    if (secCompleted >= 30) {
      completedSections += 1;
    }
    if (rec?.examBestScore && rec.examBestScore > bestExamScore) {
      bestExamScore = rec.examBestScore;
    }
    if (rec?.examPassed) {
      legacyPassedSections += 1;
    }
  }

  const lockedStages = Math.max(0, TOTAL_CURRICULUM_STAGES - unlockedStages);

  const attemptPassed = examAttempts.filter((a) => a.passed).length;
  const attemptFailed = examAttempts.filter((a) => !a.passed).length;
  const examsPassed = Math.max(attemptPassed, legacyPassedSections);
  const examsFailed = attemptFailed;
  const totalExamAttempts = Math.max(examAttempts.length, examsPassed + examsFailed);

  for (const attempt of examAttempts) {
    if (attempt.score > bestExamScore) {
      bestExamScore = attempt.score;
    }
  }

  const dailyCompleted = Math.max(
    dailyStats?.totalDailyCompleted ?? 0,
    dailyHistory.filter((d) => d.passed).length,
  );
  const dailyAttempted = Math.max(
    dailyStats?.totalDailyAttempted ?? 0,
    dailyHistory.length,
  );

  let totalCorrect = 0;
  let totalWrong = 0;

  for (const stage of Object.values(stageProgressMap)) {
    if (typeof stage.totalCorrect === 'number' && typeof stage.totalWrong === 'number') {
      totalCorrect += stage.totalCorrect;
      totalWrong += stage.totalWrong;
    } else {
      // Clean fallback for stage records written prior to cumulative answer tracking
      const estCorrect = Math.min(10, Math.max(0, Math.round((stage.lastScore ?? 0) / 10)));
      totalCorrect += estCorrect;
      totalWrong += 10 - estCorrect;
    }
  }

  for (const exam of examAttempts) {
    totalCorrect += exam.correctCount ?? 0;
    totalWrong += exam.wrongCount ?? 0;
  }

  for (const daily of dailyHistory) {
    totalCorrect += daily.correctCount ?? 0;
    totalWrong += daily.wrongCount ?? 0;
  }

  const totalAnswered = totalCorrect + totalWrong;
  const overallPassRate = totalAnswered > 0 ? Math.round((totalCorrect / totalAnswered) * 100) : 0;

  return {
    levelInfo: computeStudentLevel(totalEarnedPoints),
    completedStages,
    totalStages: TOTAL_CURRICULUM_STAGES,
    unlockedStages,
    lockedStages,
    completedSections,
    totalSections: TOTAL_CURRICULUM_SECTIONS,
    examsPassed,
    examsFailed,
    totalExamAttempts,
    bestExamScore,
    dailyCompleted,
    dailyAttempted,
    totalCorrect,
    totalWrong,
    totalAnswered,
    overallPassRate,
  };
}

export function computeSectionBreakdown(
  sectionProgressMap: Partial<Record<SectionId, SectionProgressRecord>>,
): SectionAnalyticsItem[] {
  return CURRICULUM_SECTIONS.map((section) => {
    const rec = sectionProgressMap[section.id];
    const completedStages = rec?.completedStagesCount ?? 0;
    const unlockedStage = Math.max(1, Math.min(30, rec?.unlockedStage ?? 1));
    return {
      section,
      unlockedStage,
      completedStages,
      completionPct: Math.round((completedStages / 30) * 100),
      totalStars: rec?.totalStars ?? 0,
      examBestScore: rec?.examBestScore ?? 0,
      examPassed: Boolean(rec?.examPassed),
      examAttempts: rec?.examAttempts ?? 0,
    };
  });
}

export function buildPointsProgressionSeries(
  transactions: PointTransactionRecord[],
): PointsProgressionNode[] {
  const earnedOnly = [...transactions]
    .filter((tx) => tx.amount > 0)
    .sort((a, b) => {
      const aMs = a.createdAt?.toMillis?.() ?? (a.createdAt?.seconds ?? 0) * 1000;
      const bMs = b.createdAt?.toMillis?.() ?? (b.createdAt?.seconds ?? 0) * 1000;
      return aMs - bMs;
    });

  let cumulativeEarned = 0;
  return earnedOnly.map((tx, idx) => {
    cumulativeEarned += tx.amount;
    const timestampMs = tx.createdAt?.toMillis?.() ?? (tx.createdAt?.seconds ?? 0) * 1000;
    return {
      id: tx.txId,
      stepIndex: idx + 1,
      cumulativeEarned,
      delta: tx.amount,
      type: tx.type,
      timestampMs,
    };
  });
}

export function buildRecentActivityFeed(params: {
  transactions: PointTransactionRecord[];
  examAttempts: ExamAttemptRecord[];
  dailyHistory: DailyChallengeAttemptRecord[];
  achievementsMap: Partial<Record<EarnedRecordId, UserAchievementRecord>>;
}): RecentActivityItem[] {
  const items: RecentActivityItem[] = [];

  for (const tx of params.transactions.slice(0, 20)) {
    const timestampMs = tx.createdAt?.toMillis?.() ?? (tx.createdAt?.seconds ?? 0) * 1000;
    let titleAr = 'عملية نقاط';
    let titleEn = 'Point Activity';
    let subtitleAr = `الرصيد بعد العملية: ${tx.balanceAfter}`;
    let subtitleEn = `Balance after: ${tx.balanceAfter}`;
    let tone: RecentActivityItem['tone'] = tx.amount > 0 ? 'emerald' : 'amber';

    switch (tx.type) {
      case 'stage_win':
        titleAr = `إتمام مرحلة (${tx.refId.toUpperCase()})`;
        titleEn = `Stage Cleared (${tx.refId.toUpperCase()})`;
        tone = 'blue';
        break;
      case 'stage_perfect':
        titleAr = `علامة كاملة بالمرحلة (${tx.refId.toUpperCase()})`;
        titleEn = `Perfect Stage 100/100 (${tx.refId.toUpperCase()})`;
        tone = 'emerald';
        break;
      case 'section_complete': {
        const sec = getSectionById(tx.refId as SectionId);
        titleAr = `إكمال قسم: ${sec.titleAr}`;
        titleEn = `Section Mastered: ${sec.titleEn}`;
        tone = 'violet';
        break;
      }
      case 'exam_pass': {
        const sec = getSectionById(tx.refId as SectionId);
        titleAr = `اجتياز امتحان: ${sec.titleAr}`;
        titleEn = `Exam Passed: ${sec.titleEn}`;
        tone = 'emerald';
        break;
      }
      case 'exam_perfect': {
        const sec = getSectionById(tx.refId as SectionId);
        titleAr = `علامة كاملة بالامتحان: ${sec.titleAr}`;
        titleEn = `Perfect Exam: ${sec.titleEn}`;
        tone = 'amber';
        break;
      }
      case 'daily_win':
        titleAr = `الفوز بالتحدي اليومي (${tx.refId})`;
        titleEn = `Daily Challenge Cleared (${tx.refId})`;
        tone = 'amber';
        break;
      case 'daily_perfect':
        titleAr = `تحدٍ يومي مثالي (${tx.refId})`;
        titleEn = `Perfect Daily Challenge (${tx.refId})`;
        tone = 'amber';
        break;
      case 'duel_win':
        titleAr = 'فوز في التحدي التنافسي';
        titleEn = 'Competitive Duel Victory';
        tone = 'emerald';
        break;
      case 'duel_draw':
        titleAr = 'تعادل في التحدي التنافسي';
        titleEn = 'Competitive Duel Draw';
        tone = 'blue';
        break;
      case 'duel_part':
        titleAr = 'مشاركة في التحدي التنافسي';
        titleEn = 'Competitive Duel Participation';
        tone = 'blue';
        break;
      case 'bank_tier_mastery':
        titleAr = `إتقان مستوى في بنك الأسئلة (${tx.refId.toUpperCase()})`;
        titleEn = `Question Bank Mastery (${tx.refId.toUpperCase()})`;
        tone = 'emerald';
        break;
      case 'genius_solve':
        titleAr = 'حل تحدي العباقرة العالمي';
        titleEn = 'World Genius Challenge Solved';
        tone = 'amber';
        break;
      case 'shop_purchase': {
        const reward = getRewardById(tx.refId);
        titleAr = `استبدال مكافأة: ${reward ? reward.nameAr : tx.refId}`;
        titleEn = `Shop Redemption: ${reward ? reward.nameEn : tx.refId}`;
        tone = 'violet';
        break;
      }
    }

    items.push({
      id: `tx-${tx.txId}`,
      kind: 'point',
      timestampMs,
      titleAr,
      titleEn,
      subtitleAr,
      subtitleEn,
      badgeText: tx.amount > 0 ? `+${tx.amount}` : `${tx.amount}`,
      tone,
    });
  }

  for (const exam of params.examAttempts.slice(0, 8)) {
    const sec = getSectionById(exam.sectionId);
    const timestampMs = exam.submittedAt?.toMillis?.() ?? (exam.submittedAt?.seconds ?? 0) * 1000;
    items.push({
      id: `exam-${exam.attemptId}`,
      kind: 'exam',
      timestampMs,
      titleAr: exam.passed
        ? `نجاح في امتحان ${sec.titleAr}`
        : `محاولة امتحان ${sec.titleAr}`,
      titleEn: exam.passed
        ? `Passed ${sec.titleEn} Exam`
        : `${sec.titleEn} Exam Attempt`,
      subtitleAr: `الدرجة: ${exam.score}/100 · صحيح: ${exam.correctCount}/30`,
      subtitleEn: `Score: ${exam.score}/100 · Correct: ${exam.correctCount}/30`,
      badgeText: `${exam.score}%`,
      tone: exam.passed ? 'emerald' : 'rose',
    });
  }

  for (const daily of params.dailyHistory.slice(0, 6)) {
    const timestampMs = daily.submittedAt?.toMillis?.() ?? (daily.submittedAt?.seconds ?? 0) * 1000;
    items.push({
      id: `daily-${daily.dateKey}`,
      kind: 'daily',
      timestampMs,
      titleAr: daily.passed ? `تحدي يوم ${daily.dateKey} (ناجح)` : `تحدي يوم ${daily.dateKey}`,
      titleEn: daily.passed ? `Daily Challenge ${daily.dateKey} (Won)` : `Daily Challenge ${daily.dateKey}`,
      subtitleAr: `النتيجة: ${daily.score}/100 · إجابات صحيحة: ${daily.correctCount}/10`,
      subtitleEn: `Score: ${daily.score}/100 · Correct: ${daily.correctCount}/10`,
      badgeText: `${daily.score}%`,
      tone: daily.passed ? 'amber' : 'rose',
    });
  }

  for (const ach of Object.values(params.achievementsMap)) {
    if (!ach) continue;
    const item = getCatalogItemById(ach.achievementId);
    if (!item) continue;
    const timestampMs = ach.unlockedAt?.toMillis?.() ?? (ach.unlockedAt?.seconds ?? 0) * 1000;
    items.push({
      id: `ach-${ach.achievementId}`,
      kind: 'achievement',
      timestampMs,
      titleAr: item.kind === 'medal' ? `وسام شرفي: ${item.titleAr}` : `إنجاز جديد: ${item.titleAr}`,
      titleEn: item.kind === 'medal' ? `Medal Earned: ${item.titleEn}` : `Achievement: ${item.titleEn}`,
      subtitleAr: item.descriptionAr,
      subtitleEn: item.descriptionEn,
      tone: 'violet',
    });
  }

  return items.sort((a, b) => b.timestampMs - a.timestampMs).slice(0, 14);
}
