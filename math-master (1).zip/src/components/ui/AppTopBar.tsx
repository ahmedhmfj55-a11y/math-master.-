import {
  Award,
  Bell,
  BookOpen,
  ClipboardCheck,
  GraduationCap,
  Home,
  Settings,
  ShoppingBag,
  Swords,
  Trophy,
  UserCheck,
} from 'lucide-react';
import { LanguageSwitcher } from '@/src/components/ui/LanguageSwitcher';
import { MathMasterLogo } from '@/src/components/ui/MathMasterLogo';
import { PWAInstallButton } from '@/src/components/ui/PWAInstallButton';
import { useDuels } from '@/src/contexts/DuelsContext';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useNotifications } from '@/src/contexts/NotificationsContext';
import type { AppScreen } from '@/src/types/navigation';

export type HubTab = Extract<
  AppScreen,
  | 'home'
  | 'sections'
  | 'question-bank'
  | 'duels'
  | 'exams'
  | 'achievements'
  | 'leaderboard'
  | 'shop'
  | 'profile'
  | 'notifications'
  | 'settings'
>;

interface AppTopBarProps {
  activeTab: HubTab;
  onNavigate: (tab: HubTab) => void;
}

export function AppTopBar({ activeTab, onNavigate }: AppTopBarProps) {
  const { t } = useLanguage();
  const { unreadCount } = useNotifications();
  const { pendingActionCount } = useDuels();

  const navItems: { id: HubTab; label: string; Icon: typeof Home; badge?: number }[] = [
    { id: 'home', label: t.navHome, Icon: Home },
    { id: 'sections', label: t.navSections, Icon: BookOpen },
    { id: 'question-bank', label: t.navQuestionBank, Icon: GraduationCap },
    { id: 'duels', label: t.navDuels, Icon: Swords, badge: pendingActionCount },
    { id: 'exams', label: t.navExams, Icon: ClipboardCheck },
    { id: 'achievements', label: t.navAchievements, Icon: Award },
    { id: 'leaderboard', label: t.navLeaderboard, Icon: Trophy },
    { id: 'shop', label: t.navShop, Icon: ShoppingBag },
    { id: 'profile', label: t.navProfile, Icon: UserCheck },
  ];

  return (
    <header className="flex items-center justify-between gap-2 sm:gap-3">
      {/* Zone 1: Brand */}
      <button
        type="button"
        onClick={() => onNavigate('home')}
        className="flex items-center gap-2.5 shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-400 rounded-2xl"
      >
        <MathMasterLogo size="sm" />
        <span
          className="font-display text-base sm:text-lg font-bold tracking-tight text-white whitespace-nowrap"
          dir="ltr"
        >
          {t.brandName}
        </span>
      </button>

      {/* Zone 2: Desktop Single-Line Primary Navigation */}
      <nav
        aria-label="Primary"
        className="hidden md:flex items-center gap-0.5 lg:gap-1 p-1 rounded-2xl liquid-glass-subtle overflow-x-auto max-w-full"
      >
        {navItems.map(({ id, label, Icon, badge }) => {
          const active = activeTab === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => onNavigate(id)}
              className={`relative min-h-[38px] px-2.5 lg:px-3 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-all ${
                active
                  ? 'bg-gradient-to-r from-blue-500/85 to-violet-600/85 text-white shadow-[0_4px_16px_rgba(99,102,241,0.35)]'
                  : 'text-slate-300 hover:text-white hover:bg-white/[0.06]'
              }`}
            >
              <Icon className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              <span>{label}</span>
              {badge !== undefined && badge > 0 && (
                <span className="min-w-[18px] h-[18px] px-1 rounded-full bg-rose-500 text-white text-[10px] font-bold font-math inline-flex items-center justify-center leading-none keep-white">
                  {badge > 9 ? '9+' : badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Zone 3: Notifications Bell, Settings Gear, Language Switcher */}
      <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
        <button
          type="button"
          onClick={() => onNavigate('notifications')}
          aria-label={t.navNotifications}
          title={t.navNotifications}
          className={`relative min-h-[40px] min-w-[40px] px-2.5 rounded-2xl inline-flex items-center justify-center transition-all ${
            activeTab === 'notifications'
              ? 'bg-gradient-to-r from-blue-500/85 to-violet-600/85 text-white shadow-[0_4px_16px_rgba(99,102,241,0.35)]'
              : 'liquid-glass-subtle text-slate-200 hover:text-white hover:bg-white/10'
          }`}
        >
          <Bell className="w-4 h-4 shrink-0" aria-hidden="true" />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -end-1 min-w-[18px] h-[18px] px-1 rounded-full bg-rose-500 border border-white/40 text-[10px] font-bold font-math text-white flex items-center justify-center leading-none keep-white">
              {unreadCount > 99 ? '99+' : unreadCount}
            </span>
          )}
        </button>

        <button
          type="button"
          onClick={() => onNavigate('settings')}
          aria-label={t.navSettings}
          title={t.navSettings}
          className={`min-h-[40px] min-w-[40px] px-2.5 rounded-2xl inline-flex items-center justify-center transition-all ${
            activeTab === 'settings'
              ? 'bg-gradient-to-r from-blue-500/85 to-violet-600/85 text-white shadow-[0_4px_16px_rgba(99,102,241,0.35)]'
              : 'liquid-glass-subtle text-slate-200 hover:text-white hover:bg-white/10'
          }`}
        >
          <Settings className="w-4 h-4 shrink-0" aria-hidden="true" />
        </button>

        <PWAInstallButton variant="compact" />
        <LanguageSwitcher />
      </div>
    </header>
  );
}
