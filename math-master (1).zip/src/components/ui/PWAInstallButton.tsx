import { Capacitor } from '@capacitor/core';
import { Download, Share, Smartphone, X } from 'lucide-react';
import { useState } from 'react';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { usePWAInstall } from '@/src/hooks/usePWAInstall';

interface PWAInstallButtonProps {
  variant?: 'compact' | 'full';
}

export function PWAInstallButton({ variant = 'compact' }: PWAInstallButtonProps) {
  const { language } = useLanguage();
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  if (isInstalled || Capacitor.isNativePlatform()) {
    return null;
  }

  const label =
    language === 'ar'
      ? variant === 'compact'
        ? 'تثبيت'
        : 'تثبيت التطبيق على الهاتف'
      : variant === 'compact'
        ? 'Install'
        : 'Install Mobile App';

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={() => void install()}
        className={
          variant === 'compact'
            ? 'liquid-glass-button min-h-[40px] px-3 py-1.5 rounded-2xl text-xs font-semibold text-white inline-flex items-center gap-1.5 whitespace-nowrap shrink-0'
            : 'liquid-glass-button min-h-[46px] px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-white inline-flex items-center justify-center gap-2 whitespace-nowrap'
        }
      >
        <Download className="w-4 h-4 shrink-0" aria-hidden="true" />
        <span>{label}</span>
      </button>
    );
  }

  if (isIOS || variant === 'full') {
    return (
      <>
        <button
          type="button"
          onClick={() => setShowGuide(true)}
          className={
            variant === 'compact'
              ? 'liquid-glass-subtle min-h-[40px] px-3 py-1.5 rounded-2xl text-xs font-semibold text-sky-200 hover:bg-white/10 inline-flex items-center gap-1.5 whitespace-nowrap shrink-0'
              : 'liquid-glass-subtle min-h-[46px] px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold text-sky-200 hover:bg-white/10 inline-flex items-center justify-center gap-2 whitespace-nowrap'
          }
        >
          <Smartphone className="w-4 h-4 shrink-0" aria-hidden="true" />
          <span>{label}</span>
        </button>

        {showGuide && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
            <div className="liquid-glass w-full max-w-md rounded-3xl p-6 space-y-4">
              <div className="flex items-center justify-between gap-3">
                <h3 className="font-display text-lg font-bold text-white flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-sky-300 shrink-0" aria-hidden="true" />
                  <span>
                    {language === 'ar'
                      ? 'تثبيت Math Master على الهاتف'
                      : 'Install Math Master on Mobile'}
                  </span>
                </h3>
                <button
                  type="button"
                  onClick={() => setShowGuide(false)}
                  aria-label="Close"
                  className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 flex items-center justify-center text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {isIOS ? (
                <ol className="text-xs sm:text-sm text-slate-200 space-y-2 list-decimal list-inside leading-relaxed">
                  <li>
                    {language === 'ar' ? (
                      <>
                        اضغط على زر <strong>المشاركة</strong>{' '}
                        <Share className="inline w-3.5 h-3.5 mx-1" /> في شريط Safari.
                      </>
                    ) : (
                      <>
                        Tap the <strong>Share</strong> button{' '}
                        <Share className="inline w-3.5 h-3.5 mx-1" /> in Safari.
                      </>
                    )}
                  </li>
                  <li>
                    {language === 'ar'
                      ? 'اختر «إضافة إلى الشاشة الرئيسية» (Add to Home Screen).'
                      : 'Select "Add to Home Screen".'}
                  </li>
                </ol>
              ) : (
                <ol className="text-xs sm:text-sm text-slate-200 space-y-2 list-decimal list-inside leading-relaxed">
                  <li>
                    {language === 'ar'
                      ? 'في متصفح Chrome على أندرويد، افتح القائمة (⋮) ثم اختر «تثبيت التطبيق» لتثبيته كتطبيق مستقل.'
                      : 'In Android Chrome, open the menu (⋮) and tap "Install app" to install as a standalone app.'}
                  </li>
                  <li>
                    {language === 'ar'
                      ? 'ولإنشاء ملف APK رسمي، استخدم رابط التطبيق المنشور عبر PWABuilder أو غلّف المشروع عبر Capacitor Android Studio.'
                      : 'To build a signed APK file, package the live app URL with PWABuilder or wrap the project with Capacitor Android Studio.'}
                  </li>
                </ol>
              )}

              <button
                type="button"
                onClick={() => setShowGuide(false)}
                className="liquid-glass-button w-full min-h-[44px] rounded-2xl text-xs sm:text-sm font-semibold text-white"
              >
                {language === 'ar' ? 'حسناً' : 'Got it'}
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
}
