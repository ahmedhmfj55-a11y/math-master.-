interface MathMasterLogoProps {
  size?: 'sm' | 'md' | 'lg';
}

export function MathMasterLogo({ size = 'md' }: MathMasterLogoProps) {
  const dimensions =
    size === 'lg' ? 'w-24 h-24' : size === 'sm' ? 'w-10 h-10' : 'w-14 h-14';
  const radius =
    size === 'lg' ? 'rounded-[28px]' : size === 'sm' ? 'rounded-xl' : 'rounded-2xl';

  return (
    <div
      className={`relative ${dimensions} ${radius} flex items-center justify-center select-none shrink-0`}
      style={{
        background:
          'linear-gradient(145deg, rgba(96, 165, 250, 0.28) 0%, rgba(124, 58, 237, 0.26) 55%, rgba(15, 23, 42, 0.6) 100%)',
        boxShadow:
          'inset 0 1.5px 1px rgba(255, 255, 255, 0.45), inset 0 -2px 6px rgba(139, 92, 246, 0.3), 0 16px 40px -10px rgba(79, 70, 229, 0.55)',
        border: '1px solid rgba(255, 255, 255, 0.25)',
        backdropFilter: 'blur(24px)',
      }}
    >
      <svg
        viewBox="0 0 64 64"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-[62%] h-[62%]"
        aria-hidden="true"
      >
        <defs>
          <linearGradient id="mmStroke" x1="8" y1="8" x2="56" y2="56" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="55%" stopColor="#BAE6FD" />
            <stop offset="100%" stopColor="#C4B5FD" />
          </linearGradient>
        </defs>
        {/* Outer precision mathematical diamond */}
        <path
          d="M32 6L56 20V44L32 58L8 44V20L32 6Z"
          stroke="url(#mmStroke)"
          strokeWidth="2.4"
          strokeLinejoin="round"
          strokeOpacity="0.9"
        />
        {/* Inner M / Sigma geometric nexus */}
        <path
          d="M20 41V23L32 34L44 23V41"
          stroke="#FFFFFF"
          strokeWidth="3.2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {/* Golden ratio vertex dot */}
        <circle cx="32" cy="17" r="2.6" fill="#93C5FD" />
      </svg>
    </div>
  );
}
