import { BookOpen, Home, Swords, Trophy, UserCheck } from 'lucide-react';
import type { HubTab } from '@/src/components/ui/AppTopBar';
import { useDuels } from '@/src/contexts/DuelsContext';
import { useLanguage } from '@/src/contexts/LanguageContext';
import type { AppScreen } from '@/src/types/navigation';

interface MobileBottomNavProps {
  activeScreen: AppScreen;
  onNavigate: (tab: HubTab) => void;
}

export function MobileBottomNav({ activeScreen, onNavigate }: MobileBottomNavProps) {
  const { t } = useLanguage();
  const { pendingActionCount } = useDuels();

  const items: { id: HubTab; label: string; Icon: typeof Home; badge?: number; matchScreens: AppScreen[] }[] = [
    {
      id: 'home',
      label: t.navHome,
      Icon: Home,
      matchScreens: ['home'],
    },
    {
      id: 'sections',
      label: t.navSections,
      Icon: BookOpen,
      matchScreens: ['sections', 'section', 'question-bank', 'grade-level', 'genius-challenges'],
    },
    {
      id: 'duels',
      label: t.navDuels,
      Icon: Swords,
      badge: pendingActionCount,
      matchScreens: ['duels'],
    },
    {
      id: 'leaderboard',
      label: t.navLeaderboard,
      Icon: Trophy,
      matchScreens: ['leaderboard'],
    },
    {
      id: 'profile',
      label: t.navProfile,
      Icon: UserCheck,
      matchScreens: ['profile', 'shop', 'achievements', 'exams', 'settings', 'notifications'],
    },
  ];

  return (
    <nav
      aria-label="Mobile Bottom Navigation"
      className="fixed bottom-0 inset-x-0 z-40 md:hidden px-3 pt-1.5 pb-[calc(0.5rem+env(safe-area-inset-bottom,0px))] pointer-events-none"
    >
      <div className="liquid-glass rounded-3xl p-1.5 grid grid-cols-5 gap-1 max-w-lg mx-auto pointer-events-auto shadow-[0_12px_40px_rgba(4,7,24,0.65)]">
        {items.map(({ id, label, Icon, badge, matchScreens }) => {
          const active = matchScreens.includes(activeScreen);
          return (
            <button
              key={id}
              type="button"
              onClick={() => onNavigate(id)}
              className={`relative min-h-[48px] px-1 py-1.5 rounded-2xl flex flex-col items-center justify-center gap-0.5 text-[10px] font-semibold transition-all ${
                active
                  ? 'bg-gradient-to-r from-blue-500/85 to-violet-600/85 text-white shadow-[0_4px_14px_rgba(99,102,241,0.45)]'
                  : 'text-slate-300 hover:text-white hover:bg-white/[0.06]'
              }`}
            >
              <div className="relative">
                <Icon className="w-4 h-4 shrink-0" aria-hidden="true" />
                {badge !== undefined && badge > 0 && (
                  <span className="absolute -top-1.5 -end-2.5 min-w-[16px] h-[16px] px-1 rounded-full bg-rose-500 text-white text-[9px] font-bold font-math flex items-center justify-center leading-none keep-white">
                    {badge > 9 ? '9+' : badge}
                  </span>
                )}
              </div>
              <span className="truncate max-w-full leading-tight">{label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
