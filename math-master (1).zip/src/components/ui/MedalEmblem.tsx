import {
  Award,
  Brain,
  CheckCircle2,
  Compass,
  Crown,
  Flame,
  Gem,
  Layers,
  Lock,
  Medal,
  Shield,
  Sparkles,
  Star,
  Trophy,
  Zap,
} from 'lucide-react';
import type { MedalIconKey } from '@/src/types/achievements';

interface MedalEmblemProps {
  iconKey: MedalIconKey;
  accentFrom: string;
  accentTo: string;
  unlocked: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export function MedalEmblem({
  iconKey,
  accentFrom,
  accentTo,
  unlocked,
  size = 'md',
}: MedalEmblemProps) {
  const sizeMap = {
    sm: { box: 'w-11 h-11 rounded-2xl', icon: 'w-5 h-5' },
    md: { box: 'w-14 h-14 rounded-2xl', icon: 'w-7 h-7' },
    lg: { box: 'w-20 h-20 rounded-3xl', icon: 'w-10 h-10' },
  }[size];

  const renderIcon = () => {
    const cls = `${sizeMap.icon} relative z-10`;
    if (!unlocked) {
      return <Lock className={cls} aria-hidden="true" />;
    }
    switch (iconKey) {
      case 'bronze':
        return <Shield className={cls} aria-hidden="true" />;
      case 'silver':
        return <Compass className={cls} aria-hidden="true" />;
      case 'gold':
        return <Trophy className={cls} aria-hidden="true" />;
      case 'genius':
        return <Brain className={cls} aria-hidden="true" />;
      case 'king':
        return <Crown className={cls} aria-hidden="true" />;
      case 'challenge':
        return <Flame className={cls} aria-hidden="true" />;
      case 'excellence':
        return <Gem className={cls} aria-hidden="true" />;
      case 'stage1':
        return <Zap className={cls} aria-hidden="true" />;
      case 'stage10':
        return <Star className={cls} aria-hidden="true" />;
      case 'stage50':
        return <Medal className={cls} aria-hidden="true" />;
      case 'stage100':
        return <Award className={cls} aria-hidden="true" />;
      case 'section1':
        return <CheckCircle2 className={cls} aria-hidden="true" />;
      case 'section8':
        return <Layers className={cls} aria-hidden="true" />;
      case 'perfectExam':
        return <Sparkles className={cls} aria-hidden="true" />;
      case 'streak7':
      case 'streak30':
        return <Flame className={cls} aria-hidden="true" />;
    }
  };

  return (
    <div
      className={`${sizeMap.box} relative flex items-center justify-center shrink-0 border transition-all ${
        unlocked
          ? `bg-gradient-to-br ${accentFrom} ${accentTo} border-white/40 text-white shadow-[0_8px_24px_rgba(0,0,0,0.35),inset_0_1px_0_rgba(255,255,255,0.45)]`
          : 'bg-white/[0.04] border-white/12 text-slate-500'
      }`}
    >
      {unlocked && (
        <span
          aria-hidden="true"
          className="pointer-events-none absolute inset-1 rounded-[inherit] border border-white/25"
        />
      )}
      {renderIcon()}
    </div>
  );
}
