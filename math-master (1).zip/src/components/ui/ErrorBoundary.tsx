import { Component, type ErrorInfo, type ReactNode } from 'react';
import { TRANSLATIONS } from '@/src/data/translations';
import { storageService } from '@/src/services/storageService';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
  };

  public static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  public componentDidCatch(error: Error, info: ErrorInfo): void {
    console.error('Application ErrorBoundary caught:', error, info);
  }

  private handleReload = (): void => {
    window.location.reload();
  };

  public render(): ReactNode {
    if (this.state.hasError) {
      const lang = storageService.getLanguage();
      const t = TRANSLATIONS[lang];
      return (
        <div className="min-h-screen bg-[#060919] text-slate-50 flex items-center justify-center p-6">
          <div className="liquid-glass rounded-3xl max-w-md w-full p-8 text-center space-y-5">
            <div className="mx-auto w-14 h-14 rounded-2xl bg-rose-500/15 border border-rose-400/30 flex items-center justify-center text-rose-300 text-2xl font-math">
              !
            </div>
            <h1 className="text-xl font-bold text-white">{t.errorBoundaryTitle}</h1>
            <p className="text-sm text-slate-300 leading-relaxed">{t.errorBoundarySubtitle}</p>
            <button
              type="button"
              onClick={this.handleReload}
              className="liquid-glass-button w-full min-h-[48px] rounded-2xl px-5 py-3 text-sm font-semibold text-white transition-transform active:scale-[0.98]"
            >
              {t.errorBoundaryRetry}
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
