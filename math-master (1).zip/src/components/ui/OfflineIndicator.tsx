import { WifiOff } from 'lucide-react';
import { useLanguage } from '@/src/contexts/LanguageContext';
import { useOnlineStatus } from '@/src/hooks/useOnlineStatus';

export function OfflineIndicator() {
  const { language } = useLanguage();
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      role="status"
      className="fixed bottom-20 md:bottom-5 start-4 z-50 liquid-glass px-3.5 py-2 rounded-2xl border-amber-400/45 bg-amber-500/20 text-xs font-semibold text-amber-100 inline-flex items-center gap-2 shadow-lg"
    >
      <WifiOff className="w-3.5 h-3.5 text-amber-300 shrink-0" aria-hidden="true" />
      <span>
        {language === 'ar'
          ? 'وضع عدم الاتصال — يتم استخدام البيانات المحفوظة'
          : 'Offline Mode — Cached data is being used'}
      </span>
    </div>
  );
}
