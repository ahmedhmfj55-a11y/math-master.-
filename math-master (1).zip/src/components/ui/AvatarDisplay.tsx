import {
  Atom,
  Compass,
  Crown,
  Flame,
  Gem,
  Orbit,
  Sparkles,
} from 'lucide-react';
import { useState } from 'react';
import {
  DEFAULT_AVATAR_ID,
  getFreeAvatarPreset,
  getRewardById,
} from '@/src/data/rewardsCatalog';

interface AvatarDisplayProps {
  avatarId?: string;
  photoUrl?: string;
  displayName?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

const SIZE_CLASSES: Record<
  NonNullable<AvatarDisplayProps['size']>,
  { box: string; icon: string; text: string; glyph: string }
> = {
  sm: { box: 'w-9 h-9 rounded-2xl', icon: 'w-4 h-4', text: 'text-xs', glyph: 'text-base' },
  md: { box: 'w-11 h-11 rounded-2xl', icon: 'w-5 h-5', text: 'text-sm', glyph: 'text-xl' },
  lg: { box: 'w-16 h-16 rounded-3xl', icon: 'w-8 h-8', text: 'text-xl', glyph: 'text-3xl' },
  xl: { box: 'w-20 h-20 rounded-3xl', icon: 'w-10 h-10', text: 'text-2xl', glyph: 'text-4xl' },
};

export function AvatarDisplay({
  avatarId = DEFAULT_AVATAR_ID,
  photoUrl = '',
  displayName = 'M',
  size = 'md',
  className = '',
}: AvatarDisplayProps) {
  const [imgFailed, setImgFailed] = useState(false);
  const sz = SIZE_CLASSES[size];
  const reward = getRewardById(avatarId);
  const freePreset = getFreeAvatarPreset(avatarId);

  const shouldRenderGooglePhoto =
    avatarId === 'avatar-google' && Boolean(photoUrl) && photoUrl.startsWith('https://') && !imgFailed;

  if (shouldRenderGooglePhoto) {
    return (
      <div
        className={`${sz.box} overflow-hidden border border-white/25 bg-slate-900 shrink-0 shadow-[0_8px_24px_rgba(30,64,175,0.3)] ${className}`}
      >
        <img
          src={photoUrl}
          alt={displayName}
          referrerPolicy="no-referrer"
          onError={() => setImgFailed(true)}
          className="w-full h-full object-cover"
        />
      </div>
    );
  }

  const from = reward?.accentFrom ?? freePreset?.accentFrom ?? 'from-blue-500';
  const to = reward?.accentTo ?? freePreset?.accentTo ?? 'to-violet-600';

  const renderIcon = () => {
    switch (avatarId) {
      case 'avatar-pi':
        return (
          <span className={`font-math font-extrabold text-white ${sz.glyph}`} aria-hidden="true">
            π
          </span>
        );
      case 'avatar-sigma':
        return (
          <span className={`font-math font-extrabold text-white ${sz.glyph}`} aria-hidden="true">
            Σ
          </span>
        );
      case 'avatar-delta':
        return (
          <span className={`font-math font-extrabold text-white ${sz.glyph}`} aria-hidden="true">
            Δ
          </span>
        );
      case 'avatar-omega':
        return (
          <span className={`font-math font-extrabold text-white ${sz.glyph}`} aria-hidden="true">
            Ω
          </span>
        );
      case 'avatar-nova':
        return <Orbit className={`${sz.icon} text-white`} aria-hidden="true" />;
      case 'avatar-owl':
        return <Compass className={`${sz.icon} text-white`} aria-hidden="true" />;
      case 'avatar-prism':
        return <Gem className={`${sz.icon} text-white`} aria-hidden="true" />;
      case 'avatar-phoenix':
        return <Flame className={`${sz.icon} text-white`} aria-hidden="true" />;
      case 'avatar-dragon':
        return <Atom className={`${sz.icon} text-white`} aria-hidden="true" />;
      case 'avatar-aurora':
        return <Crown className={`${sz.icon} text-white`} aria-hidden="true" />;
      case 'avatar-google': {
        const initial = displayName.trim().charAt(0).toUpperCase() || 'M';
        return <span className={`font-display font-bold text-white ${sz.text}`}>{initial}</span>;
      }
      default:
        return <Sparkles className={`${sz.icon} text-white`} aria-hidden="true" />;
    }
  };

  return (
    <div
      className={`${sz.box} bg-gradient-to-br ${from} ${to} border border-white/25 flex items-center justify-center shrink-0 shadow-[0_8px_24px_rgba(59,130,246,0.28)] ${className}`}
    >
      {renderIcon()}
    </div>
  );
}
