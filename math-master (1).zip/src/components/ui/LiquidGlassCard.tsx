import type { HTMLAttributes, ReactNode } from 'react';

interface LiquidGlassCardProps extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
  variant?: 'default' | 'subtle';
}

export function LiquidGlassCard({
  children,
  variant = 'default',
  className = '',
  ...rest
}: LiquidGlassCardProps) {
  const baseClass = variant === 'subtle' ? 'liquid-glass-subtle' : 'liquid-glass';
  return (
    <div
      className={`${baseClass} rounded-3xl ${className}`}
      {...rest}
    >
      {children}
    </div>
  );
}
