import { Globe } from 'lucide-react';
import { useLanguage } from '@/src/contexts/LanguageContext';

export function LanguageSwitcher() {
  const { language, setLanguage } = useLanguage();

  return (
    <div
      className="liquid-glass-subtle inline-flex items-center gap-1 p-1 rounded-2xl shrink-0"
      role="group"
      aria-label="Language selector"
    >
      <span className="px-2 text-slate-300/80 hidden sm:inline-flex items-center" aria-hidden="true">
        <Globe className="w-4 h-4" />
      </span>
      <button
        type="button"
        onClick={() => setLanguage('ar')}
        aria-pressed={language === 'ar'}
        className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-all duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-400 ${
          language === 'ar'
            ? 'bg-white/20 text-white shadow-sm border border-white/20'
            : 'text-slate-300 hover:text-white hover:bg-white/5'
        }`}
      >
        العربية
      </button>
      <button
        type="button"
        onClick={() => setLanguage('en')}
        aria-pressed={language === 'en'}
        className={`min-h-[38px] px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-all duration-150 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-violet-400 ${
          language === 'en'
            ? 'bg-white/20 text-white shadow-sm border border-white/20'
            : 'text-slate-300 hover:text-white hover:bg-white/5'
        }`}
      >
        English
      </button>
    </div>
  );
}
