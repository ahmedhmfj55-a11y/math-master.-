import { motion } from 'motion/react';
import { useTheme } from '@/src/contexts/ThemeContext';

export function LiquidBackground() {
  const { resolvedTheme } = useTheme();
  const isLight = resolvedTheme === 'light';

  return (
    <div
      aria-hidden="true"
      className={`fixed inset-0 -z-10 overflow-hidden transition-colors duration-500 ${
        isLight ? 'bg-[#eef3ff]' : 'bg-[#060919]'
      }`}
    >
      {/* Base ambient field */}
      <div
        className="absolute inset-0 transition-opacity duration-500"
        style={{
          background: isLight
            ? 'radial-gradient(120% 85% at 50% 0%, #dbeafe 0%, #eef2ff 50%, #f8fafc 100%)'
            : 'radial-gradient(120% 80% at 50% 0%, #101A45 0%, #080D24 52%, #050816 100%)',
        }}
      />

      {/* Soft refractive ambient light fields */}
      <motion.div
        className={`absolute -top-32 -start-24 w-[36rem] h-[36rem] rounded-full blur-[120px] will-change-transform ${
          isLight ? 'opacity-65' : 'opacity-45'
        }`}
        style={{
          background: isLight
            ? 'radial-gradient(circle, rgba(96,165,250,0.45) 0%, rgba(147,197,253,0.18) 55%, transparent 75%)'
            : 'radial-gradient(circle, rgba(59,130,246,0.42) 0%, rgba(37,99,235,0.12) 55%, transparent 75%)',
        }}
        animate={{
          transform: [
            'translate3d(0px, 0px, 0) scale(1)',
            'translate3d(40px, 28px, 0) scale(1.08)',
            'translate3d(0px, 0px, 0) scale(1)',
          ],
        }}
        transition={{ duration: 16, repeat: Infinity, ease: 'easeInOut' }}
      />

      <motion.div
        className={`absolute top-1/3 -end-28 w-[34rem] h-[34rem] rounded-full blur-[130px] will-change-transform ${
          isLight ? 'opacity-60' : 'opacity-45'
        }`}
        style={{
          background: isLight
            ? 'radial-gradient(circle, rgba(167,139,250,0.42) 0%, rgba(196,181,253,0.18) 55%, transparent 75%)'
            : 'radial-gradient(circle, rgba(139,92,246,0.42) 0%, rgba(109,40,217,0.14) 55%, transparent 75%)',
        }}
        animate={{
          transform: [
            'translate3d(0px, 0px, 0) scale(1)',
            'translate3d(-36px, -24px, 0) scale(1.06)',
            'translate3d(0px, 0px, 0) scale(1)',
          ],
        }}
        transition={{ duration: 18, repeat: Infinity, ease: 'easeInOut' }}
      />

      <motion.div
        className={`absolute -bottom-40 start-1/3 w-[32rem] h-[32rem] rounded-full blur-[130px] will-change-transform ${
          isLight ? 'opacity-50' : 'opacity-35'
        }`}
        style={{
          background: isLight
            ? 'radial-gradient(circle, rgba(56,189,248,0.34) 0%, rgba(129,140,248,0.14) 60%, transparent 78%)'
            : 'radial-gradient(circle, rgba(79,70,229,0.38) 0%, rgba(30,27,75,0.12) 60%, transparent 78%)',
        }}
        animate={{
          transform: [
            'translate3d(0px, 0px, 0) scale(1)',
            'translate3d(24px, -30px, 0) scale(1.05)',
            'translate3d(0px, 0px, 0) scale(1)',
          ],
        }}
        transition={{ duration: 20, repeat: Infinity, ease: 'easeInOut' }}
      />

      {/* Subtle architectural coordinate grid with soft radial fade */}
      <div
        className={`absolute inset-0 ${isLight ? 'opacity-[0.08]' : 'opacity-[0.06]'}`}
        style={{
          backgroundImage: isLight
            ? 'linear-gradient(to right, rgba(30,64,175,0.35) 1px, transparent 1px), linear-gradient(to bottom, rgba(30,64,175,0.35) 1px, transparent 1px)'
            : 'linear-gradient(to right, rgba(255,255,255,0.5) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.5) 1px, transparent 1px)',
          backgroundSize: '64px 64px',
          maskImage:
            'radial-gradient(ellipse 70% 60% at 50% 45%, black 20%, transparent 80%)',
          WebkitMaskImage:
            'radial-gradient(ellipse 70% 60% at 50% 45%, black 20%, transparent 80%)',
        }}
      />
    </div>
  );
}
