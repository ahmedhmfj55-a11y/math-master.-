package com.mathmaster.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
